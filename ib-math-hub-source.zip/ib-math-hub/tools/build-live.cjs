const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..'),out=path.join(root,'docs');
fs.mkdirSync(out,{recursive:true});
fs.cpSync(path.join(root,'src'),out,{recursive:true,filter:p=>!p.endsWith('/seed.js')});
fs.writeFileSync(path.join(out,'.nojekyll'),'');
console.log('Built docs/ for GitHub Pages.');
