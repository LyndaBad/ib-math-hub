const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const files=['core','math','qcore','q_sl','q_hl','curriculum','roster','mastery','assess','donow'];
let code=`// Generated from the original, tested maths engine. Each request gets isolated state.\nexport function createEngine(state, session) {\nconst document={querySelector:()=>null,querySelectorAll:()=>[]};\nconst window={Hub:{},HUB_CONFIG:{}};\n`;
code+=fs.readFileSync(path.join(root,'src/js/pacing.js'),'utf8')+'\n';
for(const file of files){
 if(file==='roster')code+=`window.Hub.store={state,save(){},log(what){state.log.push({at:new Date().toISOString(),who:session.name,what});state.log=state.log.slice(-400)}};window.Hub.auth={who:()=>session.name,isPreview:()=>false,isTeacher:()=>session.role==='teacher'};\n`;
 code+=fs.readFileSync(path.join(root,'src/js/'+file+'.js'),'utf8')+'\n';
}
code+='return window.Hub;\n}\n';
fs.writeFileSync(path.join(root,'supabase/functions/hub/engine.js'),code);
