// Builds two single-file versions from src/:
//   dist/ib-math-hub.html     — complete standalone page (open locally, put on Google Drive/Sites, or upload to Canvas Files)
//   dist/artifact-preview.html — page body for the claude.ai Artifact preview (no doctype/head; routes kept in memory)
// Usage: node tools/build.cjs
const fs = require('fs'), path = require('path');
const SRC = path.join(__dirname, '..', 'src'), OUT = path.join(__dirname, '..', 'dist');
fs.mkdirSync(OUT, { recursive: true });
const html = fs.readFileSync(path.join(SRC, 'index.html'), 'utf8');
const scripts = [...html.matchAll(/<script src="([^"]+)"><\/script>/g)].map(m => m[1]);
const b64 = f => fs.readFileSync(path.join(SRC, f)).toString('base64');
const logo = 'data:image/png;base64,' + b64('assets/wolf-360.png');
const fontsCss = fs.readFileSync(path.join(SRC, 'css/fonts.css'), 'utf8').replace(/url\(\.\.\/(assets\/fonts\/[^)]+)\)/g, (m, f) => `url(data:font/woff2;base64,${b64(f)})`);
const css = fs.readFileSync(path.join(SRC, 'css/hub.css'), 'utf8');
const js = scripts.filter(s => s !== 'config.js').map(s => `/* ---- ${s} ---- */\n` + fs.readFileSync(path.join(SRC, s), 'utf8').replace(/<\/script/gi, '<\\/script')).join('\n');
const cfgSrc = fs.readFileSync(path.join(SRC, 'config.js'), 'utf8');
const body = host => `<a class="sr" href="#main">Skip to content</a>
<div id="app"><p style="padding:24px;font-family:Georgia,serif">Loading Miss Badmus’ IB Math Hub…</p></div>
<div id="toast" class="toast" role="status" aria-live="polite"></div>
<script>${cfgSrc}
window.HUB_CONFIG.host = ${JSON.stringify(host)}; window.HUB_CONFIG.logo = ${JSON.stringify(logo)};</script>
<script>${js}</script>`;
const standalone = `<!doctype html>
<html lang="en-GB"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Miss Badmus’ IB Math Hub</title><link rel="icon" href="${logo}">
<style>${fontsCss}\n${css}</style></head><body>
${body('web')}
</body></html>`;
const artifact = `<title>Miss Badmus’ IB Math Hub</title>
<meta name="claude:viewport-fit-sides" content="cover">
<style>${fontsCss}\n${css}</style>
${body('artifact')}`;
fs.writeFileSync(path.join(OUT, 'ib-math-hub.html'), standalone);
fs.writeFileSync(path.join(OUT, 'artifact-preview.html'), artifact);
console.log('Built dist/ib-math-hub.html (' + Math.round(standalone.length / 1024) + ' KB) and dist/artifact-preview.html (' + Math.round(artifact.length / 1024) + ' KB)');
