// Public configuration only. Permissions and teacher identity are enforced on the server.
window.HUB_CONFIG = {
 mode:'live',
 supabaseUrl:'https://innufzhtrttxecgainwo.supabase.co',
 supabaseKey:'sb_publishable_HzXyfgWxgazvIjFUI1WmJA_hEGZdiI9',
 aiAnalysis:{enabled:false}
};
