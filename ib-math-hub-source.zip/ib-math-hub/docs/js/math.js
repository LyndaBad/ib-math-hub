/* Miss Badmus' IB Math Hub — maths rendering and answer checking.
   - Hub.math.render(text): text with $...$ (inline) or $$...$$ (display) TeX-subset → native MathML.
     Fractions are always stacked (mfrac). No external library; works offline and on Chromebooks.
   - Hub.math.parse(input): student's typed answer → {value, ast} using a safe parser (no eval).
   - Hub.math.check(answerSpec, response): auto-marking with exact / 3 s.f. / d.p. rules. */
(function (Hub) {
  'use strict';
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* ---------- TeX subset → MathML ---------- */
  const SYM = {
    alpha: 'α', beta: 'β', gamma: 'γ', delta: 'δ', epsilon: 'ε', theta: 'θ', lambda: 'λ', mu: 'μ', pi: 'π', rho: 'ρ', sigma: 'σ', tau: 'τ', phi: 'φ', omega: 'ω',
    Delta: 'Δ', Sigma: 'Σ', Omega: 'Ω', Pi: 'Π'
  };
  const OPS = {
    times: '×', cdot: '·', div: '÷', pm: '±', mp: '∓', le: '≤', leq: '≤', ge: '≥', geq: '≥', ne: '≠', neq: '≠', approx: '≈', equiv: '≡',
    in: '∈', notin: '∉', subset: '⊂', cup: '∪', cap: '∩', circ: '∘', to: '→', rightarrow: '→', Rightarrow: '⇒', Leftrightarrow: '⇔', iff: '⇔',
    therefore: '∴', ldots: '…', cdots: '⋯', infty: '∞', prime: '′', lvert: '|', rvert: '|', mid: '|', partial: '∂', forall: '∀', exists: '∃', neg: '¬',
    emptyset: '∅', lt: '<', gt: '>', langle: '⟨', rangle: '⟩', degree: '°', sum: '∑', prod: '∏', int: '∫', star: '*', ast: '∗'
  };
  const FUNCS = ['sin', 'cos', 'tan', 'sec', 'csc', 'cot', 'arcsin', 'arccos', 'arctan', 'ln', 'log', 'exp', 'lim', 'max', 'min', 'det', 'Re', 'Im', 'arg'];
  const BB = { R: 'ℝ', N: 'ℕ', Z: 'ℤ', Q: 'ℚ', C: 'ℂ' };

  function tokenize(s) {
    const t = []; let i = 0;
    while (i < s.length) {
      const c = s[i], st = i;
      if (c === '\\') {
        let j = i + 1;
        if (/[a-zA-Z]/.test(s[j] || '')) { while (j < s.length && /[a-zA-Z]/.test(s[j])) j++; t.push({ k: 'cmd', v: s.slice(i + 1, j), s: st, e: j }); i = j; }
        else { t.push({ k: 'cmd', v: s[j] || '', s: st, e: j + 1 }); i = j + 1; }
      } else if (/\s/.test(c)) { i++; }
      else if (/[0-9.]/.test(c)) { let j = i; while (j < s.length && /[0-9.]/.test(s[j])) j++; t.push({ k: 'num', v: s.slice(i, j), s: st, e: j }); i = j; }
      else if (/[a-zA-Z]/.test(c)) { t.push({ k: 'id', v: c, s: st, e: i + 1 }); i++; }
      else { t.push({ k: 'ch', v: c, s: st, e: i + 1 }); i++; }
    }
    return t;
  }

  function texToMathML(src, display) {
    const toks = tokenize(src); let p = 0;
    const peek = () => toks[p], next = () => toks[p++];
    const mo = (v, a = '') => `<mo${a}>${esc(v)}</mo>`;
    function group() { // one argument: {...} or single token atom
      const t = peek(); if (!t) return '<mrow></mrow>';
      if (t.k === 'ch' && t.v === '{') { next(); const r = row('}'); next(); return `<mrow>${r}</mrow>`; }
      return atom();
    }
    function rawGroup() { // literal source text inside {...}, spaces kept
      const t = peek(); if (!(t && t.k === 'ch' && t.v === '{')) return t ? (next(), t.v) : '';
      next(); const start = t.e; let depth = 1, end = start;
      while (p < toks.length) {
        const x = next();
        if (x.k === 'ch' && x.v === '{') depth++;
        if (x.k === 'ch' && x.v === '}') { depth--; if (!depth) { end = x.s; break; } }
      }
      return src.slice(start, end);
    }
    const rawText = rawGroup;
    function atom() {
      const t = next(); if (!t) return '';
      if (t.k === 'num') return `<mn>${esc(t.v)}</mn>`;
      if (t.k === 'id') return `<mi>${esc(t.v)}</mi>`;
      if (t.k === 'ch') {
        if (t.v === '{') { const r = row('}'); next(); return `<mrow>${r}</mrow>`; }
        if (t.v === "'") return mo('′');
        if (t.v === '-') return mo('−');
        if (t.v === '*') return mo('×');
        if ('()[]|'.includes(t.v)) return mo(t.v, ' stretchy="false"');
        return mo(t.v);
      }
      const c = t.v;
      if (c === 'frac' || c === 'dfrac' || c === 'tfrac') { const a = group(), b = group(); return c === 'dfrac' ? `<mstyle displaystyle="true"><mfrac>${a}${b}</mfrac></mstyle>` : `<mfrac>${a}${b}</mfrac>`; }
      if (c === 'binom') { const a = group(), b = group(); return `<mrow>${mo('(')}<mfrac linethickness="0">${a}${b}</mfrac>${mo(')')}</mrow>`; }
      if (c === 'sqrt') {
        const n = peek();
        if (n && n.k === 'ch' && n.v === '[') { next(); const idx = row(']'); next(); const a = group(); return `<mroot>${a}<mrow>${idx}</mrow></mroot>`; }
        return `<msqrt>${group()}</msqrt>`;
      }
      if (c === 'text' || c === 'textrm' || c === 'mbox') return `<mtext>${esc(rawText()).replace(/ /g, '&#160;')}</mtext>`;
      if (c === 'textbf') return `<mtext mathvariant="bold">${esc(rawText())}</mtext>`;
      if (c === 'mathrm' || c === 'operatorname') { const r = rawGroup(); return `<mi mathvariant="normal">${esc(r)}</mi>`; }
      if (c === 'mathbb') { const r = rawGroup(); return `<mi mathvariant="normal">${esc(BB[r] || r)}</mi>`; }
      if (c === 'bar' || c === 'overline') return `<mover>${group()}<mo>‾</mo></mover>`;
      if (c === 'hat') return `<mover>${group()}<mo>^</mo></mover>`;
      if (c === 'vec') return `<mover>${group()}<mo>→</mo></mover>`;
      if (c === 'left' || c === 'right') { const d = next(); const v = d ? (d.k === 'cmd' ? (OPS[d.v] || (d.v === '{' ? '{' : d.v === '}' ? '}' : d.v === '|' ? '‖' : '')) : d.v) : ''; return v === '.' || !v ? '' : mo(v, ' stretchy="true"'); }
      if (c === '{' || c === '}' || c === '%' || c === '&' || c === '#' || c === '_') return mo(c);
      if (c === ',' ) return '<mspace width="0.17em"></mspace>';
      if (c === ';' || c === ' ') return '<mspace width="0.28em"></mspace>';
      if (c === '!') return '';
      if (c === 'quad') return '<mspace width="1em"></mspace>';
      if (c === 'qquad') return '<mspace width="2em"></mspace>';
      if (c === '\\') return '<mspace linebreak="newline"></mspace>';
      if (c === '|') return mo('‖');
      if (SYM[c]) return `<mi>${SYM[c]}</mi>`;
      if (c === 'sum' || c === 'prod' || c === 'int') return mo(OPS[c], ' largeop="true" movablelimits="false"');
      if (OPS[c]) return mo(OPS[c]);
      if (FUNCS.includes(c)) return `<mi>${c}</mi>${c === 'lim' ? '' : '<mo>&#x2061;</mo>'}`;
      return `<mi>${esc(c)}</mi>`;
    }
    function row(end) {
      let out = '';
      while (p < toks.length) {
        const t = peek();
        if (end && t.k === 'ch' && t.v === end) break;
        let base = atom();
        // scripts
        let sub = null, sup = null;
        for (let k = 0; k < 2; k++) {
          const s = peek();
          if (s && s.k === 'ch' && s.v === '_' && sub === null) { next(); sub = group(); }
          else if (s && s.k === 'ch' && s.v === '^' && sup === null) { next(); sup = group(); }
        }
        const big = /largeop/.test(base) || /<mi>lim<\/mi>/.test(base);
        const baseOnly = base.replace(/<mo>&#x2061;<\/mo>$/, '');
        if (sub !== null && sup !== null) base = big ? `<munderover>${baseOnly}${sub}${sup}</munderover>` : `<msubsup>${baseOnly}${sub}${sup}</msubsup>`;
        else if (sub !== null) base = big ? `<munder>${baseOnly}${sub}</munder>` : `<msub>${baseOnly}${sub}</msub>`;
        else if (sup !== null) base = big ? `<mover>${baseOnly}${sup}</mover>` : `<msup>${baseOnly}${sup}</msup>`;
        out += base;
      }
      return out;
    }
    const body = row(null);
    return `<math${display ? ' display="block"' : ''}><mrow>${body}</mrow></math>`;
  }

  /** Render a string containing $..$ / $$..$$ maths, ==highlight== and line breaks into safe HTML. */
  function render(text) {
    const s = String(text ?? '').replace(/\\\$/g, '\u0001'); // \$ is a literal dollar sign (money), not a maths delimiter
    let out = '', i = 0;
    while (i < s.length) {
      if (s.startsWith('$$', i)) { const j = s.indexOf('$$', i + 2); if (j < 0) { out += esc(s.slice(i)); break; } out += texToMathML(s.slice(i + 2, j), true); i = j + 2; continue; }
      if (s[i] === '$') { const j = s.indexOf('$', i + 1); if (j < 0) { out += esc(s.slice(i)); break; } out += texToMathML(s.slice(i + 1, j), false); i = j + 1; continue; }
      let j = i; while (j < s.length && s[j] !== '$') j++;
      out += esc(s.slice(i, j)).replace(/==(.+?)==/g, '<mark class="hl">$1</mark>').replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\n/g, '<br>');
      i = j;
    }
    return out.replace(/\u0001/g, '$');
  }

  /* ---------- Safe expression parser for typed answers ---------- */
  function lex(input) {
    let s = String(input).trim()
      .replace(/[−–—]/g, '-').replace(/×/g, '*').replace(/÷/g, '/').replace(/π/g, 'pi').replace(/√/g, 'sqrt').replace(/\s+/g, ' ')
      .replace(/²/g, '^2').replace(/³/g, '^3');
    const t = []; let i = 0;
    while (i < s.length) {
      const c = s[i];
      if (c === ' ') { i++; continue; }
      const num = /^(\d+\.?\d*|\.\d+)(e[+-]?\d+)?/i.exec(s.slice(i));
      if (num && !(num[2] && /[a-z]/i.test(s[i + num[0].length] || ''))) { t.push({ k: 'n', v: parseFloat(num[0]) }); i += num[0].length; continue; }
      const id = /^[a-z]+/i.exec(s.slice(i));
      if (id) {
        let w = id[0].toLowerCase();
        // split things like "2pi", "pie" sensibly: greedy match of known names
        const known = ['sqrt', 'cbrt', 'ln', 'log', 'sin', 'cos', 'tan', 'abs', 'exp', 'pi', 'e', 'x', 'n', 'k'];
        let pos = 0;
        while (pos < w.length) {
          const m = known.find(k => w.startsWith(k, pos));
          if (!m) return { error: `I don’t recognise “${id[0]}”. Use numbers, fractions like 3/4, sqrt( ), pi, e or ln( ).` };
          t.push({ k: 'w', v: m }); pos += m.length;
        }
        i += id[0].length; continue;
      }
      if ('+-*/^()|!,'.includes(c)) { t.push({ k: 'o', v: c }); i++; continue; }
      return { error: `The symbol “${c}” can’t be used in a numerical answer.` };
    }
    return { tokens: t };
  }

  function parse(input) {
    if (input === null || input === undefined || String(input).trim() === '') return { error: 'blank' };
    const lx = lex(input); if (lx.error) return { error: lx.error };
    const t = lx.tokens; let p = 0;
    const peek = () => t[p], is = (k, v) => t[p] && t[p].k === k && (v === undefined || t[p].v === v);
    const fns = ['sqrt', 'cbrt', 'ln', 'log', 'sin', 'cos', 'tan', 'abs', 'exp'];
    function expr() { let n = term(); while (is('o', '+') || is('o', '-')) { const op = t[p++].v; n = { op, a: n, b: term() }; } return n; }
    function startsPrimary() { const x = peek(); return x && (x.k === 'n' || x.k === 'w' || (x.k === 'o' && (x.v === '(' || x.v === '|'))); }
    function term() {
      let n = unary();
      for (;;) {
        if (is('o', '*') || is('o', '/')) { const op = t[p++].v; n = { op, a: n, b: unary() }; }
        else if (startsPrimary() && !is('o', '|')) { n = { op: '*', a: n, b: power(), implicit: true }; }
        else break;
      }
      return n;
    }
    function unary() { if (is('o', '-')) { p++; return { op: 'neg', a: unary() }; } if (is('o', '+')) { p++; return unary(); } return power(); }
    function power() { const b = postfix(); if (is('o', '^')) { p++; return { op: '^', a: b, b: unary() }; } return b; }
    function postfix() { let n = primary(); while (is('o', '!')) { p++; n = { op: '!', a: n }; } return n; }
    function primary() {
      const x = t[p++];
      if (!x) throw Error('Your answer seems to end early.');
      if (x.k === 'n') return { num: x.v };
      if (x.k === 'w') {
        if (x.v === 'pi') return { c: 'pi' };
        if (x.v === 'e') return { c: 'e' };
        if (['x', 'n', 'k'].includes(x.v)) throw Error('Give a number, not an expression in ' + x.v + '.');
        if (fns.includes(x.v)) { const arg = is('o', '(') ? (p++, (() => { const e = expr(); if (!is('o', ')')) throw Error('A bracket is missing.'); p++; return e; })()) : power(); return { fn: x.v, a: arg }; }
      }
      if (x.k === 'o' && x.v === '(') { const e = expr(); if (!is('o', ')')) throw Error('A bracket is missing.'); p++; return { op: '()', a: e }; }
      if (x.k === 'o' && x.v === '|') { const e = expr(); if (!is('o', '|')) throw Error('A | is missing.'); p++; return { fn: 'abs', a: e }; }
      throw Error('Check the order of symbols in your answer.');
    }
    let ast;
    try { ast = expr(); if (p < t.length) throw Error(is('o', ',') ? 'Use one value per box.' : 'Check the order of symbols in your answer.'); }
    catch (e) { return { error: e.message }; }
    const value = evaluate(ast);
    if (!Number.isFinite(value)) return { error: 'That doesn’t give a real number.' };
    return { value, ast, tex: toTex(ast) };
  }
  function fact(n) { if (n < 0 || n > 170 || Math.abs(n - Math.round(n)) > 1e-9) return NaN; let r = 1; for (let i = 2; i <= Math.round(n); i++) r *= i; return r; }
  function evaluate(n) {
    if ('num' in n) return n.num;
    if (n.c) return n.c === 'pi' ? Math.PI : Math.E;
    if (n.fn) { const a = evaluate(n.a); return { sqrt: Math.sqrt, cbrt: Math.cbrt, ln: Math.log, log: Math.log10, sin: Math.sin, cos: Math.cos, tan: Math.tan, abs: Math.abs, exp: Math.exp }[n.fn](a); }
    const a = evaluate(n.a);
    switch (n.op) { case 'neg': return -a; case '()': return a; case '!': return fact(a); }
    const b = evaluate(n.b);
    switch (n.op) { case '+': return a + b; case '-': return a - b; case '*': return a * b; case '/': return a / b; case '^': return Math.pow(a, b); }
    return NaN;
  }
  function toTex(n) {
    if ('num' in n) return String(n.num);
    if (n.c) return n.c === 'pi' ? '\\pi' : '\\mathrm{e}';
    if (n.fn) return n.fn === 'sqrt' ? `\\sqrt{${toTex(strip(n.a))}}` : n.fn === 'abs' ? `|${toTex(n.a)}|` : n.fn === 'cbrt' ? `\\sqrt[3]{${toTex(strip(n.a))}}` : `\\${n.fn}(${toTex(strip(n.a))})`;
    switch (n.op) {
      case 'neg': return '-' + toTex(n.a);
      case '()': return `(${toTex(n.a)})`;
      case '!': return toTex(n.a) + '!';
      case '/': return `\\frac{${toTex(strip(n.a))}}{${toTex(strip(n.b))}}`;
      case '^': return `${toTex(n.a)}^{${toTex(strip(n.b))}}`;
      case '*': return n.implicit ? `${toTex(n.a)}${toTex(n.b)}` : `${toTex(n.a)}\\times ${toTex(n.b)}`;
      default: return `${toTex(n.a)}${n.op === '-' ? '-' : '+'}${toTex(n.b)}`;
    }
  }
  function strip(n) { return n && n.op === '()' ? n.a : n; }
  function preview(input) { const r = parse(input); if (r.error) return r.error === 'blank' ? '' : `<span class="parse-error">${esc(r.error)}</span>`; return texToMathML(r.tex, false); }

  /* ---------- Marking ---------- */
  const sfTol = (key, sf = 3) => key === 0 ? 0.5 * Math.pow(10, -sf) : 0.5 * Math.pow(10, Math.floor(Math.log10(Math.abs(key))) - (sf - 1));
  /** Compare one numeric response (string) with a key under the part's accuracy rule.
      spec: {exact?:bool, sf?:n, dp?:n, int?:bool}. Returns 'correct' | 'inexact' | 'wrong' | 'invalid' | 'blank'. */
  function compareNum(raw, key, spec = {}) {
    const r = parse(raw);
    if (r.error) return { verdict: r.error === 'blank' ? 'blank' : 'invalid', error: r.error };
    const v = r.value, close = Math.abs(v - key) <= 1e-9 * Math.max(1, Math.abs(key));
    if (spec.int) return { verdict: close ? 'correct' : 'wrong', value: v };
    if (close) return { verdict: 'correct', value: v };
    if (spec.dp !== undefined) { const tol = 0.5 * Math.pow(10, -spec.dp) + 1e-9; return { verdict: Math.abs(v - key) <= tol ? 'correct' : 'wrong', value: v }; }
    const within3 = Math.abs(v - key) <= sfTol(key, spec.sf || 3) + 1e-12;
    if (spec.exact) return { verdict: within3 ? 'inexact' : 'wrong', value: v };
    return { verdict: within3 ? 'correct' : 'wrong', value: v };
  }
  /** Mark a part. answer: {kind, value, ...}. response: string | string[] | number (mc index).
      Returns {earned, max, verdict, detail, tag?, feedback?}. */
  function markPart(part, response) {
    const a = part.answer, max = part.marks;
    if (a.kind === 'open') return { earned: 0, max, verdict: 'teacher', detail: 'Marked by your teacher from your uploaded working.' };
    if (a.kind === 'mc') {
      if (response === undefined || response === null || response === '') return { earned: 0, max, verdict: 'blank' };
      const ok = Number(response) === a.correct; const err = !ok && (part.errors || []).find(e => e.choice === Number(response));
      return { earned: ok ? max : 0, max, verdict: ok ? 'correct' : 'wrong', tag: err && err.tag, feedback: err && err.fb };
    }
    const keys = a.kind === 'num' ? [a.value] : a.value;
    const resp = a.kind === 'num' ? [response] : (Array.isArray(response) ? response : []);
    if (resp.every(x => x === undefined || String(x).trim() === '')) return { earned: 0, max, verdict: 'blank' };
    let results;
    if (a.kind === 'list') { // unordered
      const used = new Set();
      results = resp.map(raw => {
        for (let k = 0; k < keys.length; k++) { if (used.has(k)) continue; const c = compareNum(raw, keys[k], a); if (c.verdict === 'correct' || c.verdict === 'inexact') { used.add(k); return c; } }
        const c = parse(raw); return { verdict: c.error ? (c.error === 'blank' ? 'blank' : 'invalid') : 'wrong', value: c.value, error: c.error };
      });
    } else results = keys.map((k, i) => compareNum(resp[i], k, a));
    const nOk = results.filter(r => r.verdict === 'correct').length, nInexact = results.filter(r => r.verdict === 'inexact').length;
    const invalid = results.find(r => r.verdict === 'invalid');
    const nonBlank = resp.filter(x => x !== undefined && x !== null && String(x).trim() !== '').length;
    const extras = a.kind === 'list' ? Math.max(0, nonBlank - (nOk + nInexact)) : 0;
    let earned = nOk === keys.length ? max : (a.markEach && nOk ? (max >= keys.length ? max - keys.length + nOk : Math.floor(max * nOk / keys.length)) : 0);
    let verdict = nOk === keys.length ? 'correct' : nOk + nInexact === keys.length && nInexact ? 'inexact' : nOk ? 'partial' : invalid ? 'invalid' : 'wrong';
    let tag, feedback;
    if (verdict === 'correct' && extras > 0) { earned = Math.max(0, max - 1); verdict = 'partial'; tag = 'extra-solution'; feedback = 'You found the right solution(s) but also gave a value that does not satisfy the equation. Check every answer in the original equation.'; }
    // misconception detection: compare the student's values with known error values
    if (verdict !== 'correct') {
      const vals = results.map(r => r.value).filter(v => v !== undefined && Number.isFinite(v));
      const near = (u, v) => Math.abs(u - v) <= Math.max(1e-9, sfTol(v || 1, 3));
      for (const e of part.errors || []) {
        const ev = Array.isArray(e.value) ? e.value : [e.value]; let hit;
        if (a.kind === 'list') { const pool = vals.slice(); hit = ev.length === pool.length && ev.every(x => { const i = pool.findIndex(v => near(v, x)); if (i < 0) return false; pool.splice(i, 1); return true; }); }
        else hit = ev.every((x, i) => results[i] && results[i].value !== undefined && near(results[i].value, x));
        if (hit) { tag = e.tag; feedback = e.fb; break; }
      }
      if (verdict === 'inexact') { tag = tag || 'not-exact'; feedback = feedback || part.inexactFb || 'Your value is right to 3 significant figures, but this question needs the exact answer (fraction, surd or π form).'; }
    }
    return { earned, max, verdict, results, tag, feedback, error: invalid && invalid.error };
  }

  Hub.math = { render, texToMathML, parse, evaluate, preview, compareNum, markPart, sfTol, esc };
})(window.Hub = window.Hub || {});
