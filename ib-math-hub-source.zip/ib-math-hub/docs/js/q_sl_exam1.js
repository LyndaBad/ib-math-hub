/* AA SL — IB exam-style question families (Units 1–2). Multi-part, built up with "Hence", with IB command terms and
   M/A/R markschemes. Modelled on the TYPES of exam-style questions in the Oxford SL 2019 chapter reviews (structure,
   difficulty, mark allocation); every question, context and number here is original and randomised. */
(function (Hub) {
  'use strict';
  const { F, fr, T, num, round, sf, lin, comb, mc, reg: reg0 } = Hub.qcore;
  const X = { exam: true };
  /** Bracket a negative number written straight after + or − (e.g. "2 − −1" → "2 − (−1)"). */
  const fixSigns = t => typeof t !== 'string' ? t : t.replace(/([+\-]|\\times) -((?:\\frac\{\d+\}\{\d+\})|\d+(?:\.\d+)?)(?![\d.]*[a-z(\\^{])/g, '$1 (-$2)');
  const tidyQ = q => { q.stem = fixSigns(q.stem); q.parts.forEach(p => { p.prompt = fixSigns(p.prompt); p.working = (p.working || []).map(fixSigns); p.ms = (p.ms || []).map(([m, t]) => [m, fixSigns(t)]); }); return q; };
  const reg = (id, meta, gen) => reg0(id, meta, (R, o) => tidyQ(gen(R, o)));

  const pct = v => num(round(v, 4));

  /* ---------- 1.3 Arithmetic series from a formula for Sₙ (Paper 1) ---------- */
  reg('slx1.snformula', Object.assign({ skill: 'SL-1.3a', title: 'Arithmetic series given Sₙ = pn² + qn', paper: 1, challenge: true }, X), (R, o) => {
    const p = R.int(1, o.challenge ? 6 : 4), k = R.int(o.challenge ? 25 : 10, o.challenge ? 60 : 30); let q; do q = R.nz(-6, 9); while (q === -p);
    const Sn = n => p * n * n + q * n, u1 = Sn(1), u2 = Sn(2) - Sn(1), d = 2 * p, uk = Sn(k) - Sn(k - 1);
    const S = `${p === 1 ? '' : p}n^{2}${q < 0 ? ' - ' + (-q) : ' + ' + q}n`;
    return {
      stem: `The sum of the first $n$ terms of an arithmetic sequence is given by $S_n = ${S}$, for $n \\in \\mathbb{Z}^{+}$.`,
      parts: [
        { command: 'Write down', prompt: 'the value of the first term, $u_1$.', marks: 1, answer: { kind: 'num', value: u1, exact: true, int: true, display: String(u1) },
          ms: [['A1', `$u_1 = S_1 = ${u1}$`]], working: [`$u_1 = S_1 = ${p}(1)^{2} ${q < 0 ? '-' : '+'} ${Math.abs(q)}(1) = ${u1}$`], hint: 'The first term is the sum of one term.', verify: `${p}+${q}` },
        { command: 'Find', prompt: 'the value of $u_2$.', marks: 2, dep: true, answer: { kind: 'num', value: u2, exact: true, int: true, display: String(u2) },
          ms: [['M1', `$S_2 - S_1 = ${Sn(2)} - ${u1}$`], ['A1', `$u_2 = ${u2}$`]], working: [`$S_2 = ${p}(4) ${q < 0 ? '-' : '+'} ${Math.abs(q)}(2) = ${Sn(2)}$`, `$u_2 = S_2 - S_1 = ${Sn(2)} - ${u1} = ${u2}$`],
          hint: 'S₂ is the sum of the first two terms. Take away the first term.', errors: [{ value: Sn(2), tag: 'term-not-sum', fb: 'That is S₂, the sum of two terms. Subtract u₁ to get u₂.' }], verify: `${p}*4+${q}*2-(${p}+${q})` },
        { command: 'Write down', prompt: 'the common difference, $d$.', marks: 1, dep: true, answer: { kind: 'num', value: d, exact: true, int: true, display: String(d) },
          ms: [['A1', `$d = ${u2} - ${u1} = ${d}$ (FT)`]], working: [`$d = u_2 - u_1 = ${u2} - ${u1} = ${d}$`], hint: 'd = u₂ − u₁.', errors: [{ value: u1 - u2, tag: 'difference-sign', fb: 'Subtract the earlier term from the later one: u₂ − u₁.' }], verify: `2*${p}` },
        { command: 'Find', prompt: `the value of $u_{${k}}$.`, marks: 2, dep: true, answer: { kind: 'num', value: uk, exact: true, int: true, display: String(uk) },
          ms: [['M1', `$u_1 + ${k - 1}d$ OR $S_{${k}} - S_{${k - 1}}$`], ['A1', `$${uk}$`]], working: [`$u_{${k}} = u_1 + (${k} - 1)d = ${u1} + ${k - 1}(${d}) = ${uk}$`],
          hint: 'Use uₙ = u₁ + (n − 1)d from the formula booklet.', errors: [{ value: Sn(k), tag: 'term-not-sum', fb: `That is S${k}, the sum. The question asks for the ${k}th term.` }, { value: u1 + k * d, tag: 'n-minus-1', fb: 'There are (n − 1) steps of d from u₁ to uₙ.' }], verify: `${p}*${k}**2+${q}*${k}-(${p}*${k - 1}**2+${q}*${k - 1})` }
      ]
    };
  });

  /* ---------- 1.3 Savings plan: least n with Sₙ > target (Paper 2) ---------- */
  reg('slx1.savings', Object.assign({ skill: 'SL-1.3a', title: 'Savings plan: arithmetic series and the least number of weeks', paper: 2, challenge: true }, X), (R, o) => {
    const name = R.pick(['Kofi', 'Mei', 'Lucía', 'Aarav', 'Imani', 'Tomás']), a = R.pick([5, 8, 10, 12, 15]), d = R.pick(o.challenge ? [1.5, 2.5, 3.5] : [2, 3, 4, 5]), k = R.int(8, 15);
    const uk = a + (k - 1) * d, Sk = k / 2 * (2 * a + (k - 1) * d);
    const T0 = R.pick(o.challenge ? [1500, 2000, 2500] : [600, 800, 1000, 1200]);
    let n = 1; while (n / 2 * (2 * a + (n - 1) * d) <= T0) n++;
    let m = 1; while (a + (m - 1) * d <= T0) m++;
    const Sn1 = (n - 1) / 2 * (2 * a + (n - 2) * d), Sn = n / 2 * (2 * a + (n - 1) * d), $ = v => `\\$${Number.isInteger(v) ? v : v.toFixed(2)}`;
    return {
      stem: `${name} saves money every week. In week $1$ ${name} saves $${$(a)}$, and each week saves $${$(d)}$ more than the week before.`,
      parts: [
        { command: 'Find', prompt: `the amount ${name} saves in week $${k}$.`, marks: 2, answer: { kind: 'num', value: uk, exact: true, display: $(uk) },
          ms: [['M1', `$${a} + (${k} - 1)(${num(d)})$`], ['A1', `$${$(uk)}$`]], working: [`$u_{${k}} = u_1 + (n-1)d = ${a} + ${k - 1}(${num(d)}) = ${num(uk)}$`], hint: 'Arithmetic: u₁ = first week, d = weekly increase.',
          errors: [{ value: a + k * d, tag: 'n-minus-1', fb: 'From week 1 to week k there are k − 1 increases.' }], verify: `${a}+(${k}-1)*Rational(${d * 2},2)` },
        { command: 'Find', prompt: `the total amount ${name} has saved after $${k}$ weeks.`, marks: 2, answer: { kind: 'num', value: Sk, exact: true, display: $(Sk) },
          ms: [['M1', `$\\frac{${k}}{2}\\left(2(${a}) + ${k - 1}(${num(d)})\\right)$`], ['A1', `$${$(Sk)}$`]], working: [`$S_{${k}} = \\frac{${k}}{2}\\left(2u_1 + (n-1)d\\right) = \\frac{${k}}{2}\\left(${2 * a} + ${num((k - 1) * d)}\\right) = ${num(Sk)}$`],
          hint: 'Total saved means a sum of the weekly amounts.', errors: [{ value: uk, tag: 'term-not-sum', fb: 'That is the amount for one week. Add up all the weeks.' }], verify: `Rational(${k},2)*(2*${a}+(${k}-1)*Rational(${d * 2},2))` },
        { command: 'Find', prompt: `the least number of weeks for ${name}’s total savings to be more than $${$(T0)}$.`, marks: 3, answer: { kind: 'num', value: n, int: true, display: String(n) },
          ms: [['M1', `$\\frac{n}{2}\\left(${2 * a} + (n-1)(${num(d)})\\right) > ${T0}$`], ['(A1)', `$S_{${n - 1}} = ${num(Sn1)}$ and $S_{${n}} = ${num(Sn)}$, or $n > ${num(sf((-(2 * a - d) + Math.sqrt((2 * a - d) ** 2 + 8 * d * T0)) / (2 * d), 4))}$`], ['A1', `$${n}$ weeks`]],
          working: [`Solve $\\frac{n}{2}\\left(${2 * a} + (n-1)(${num(d)})\\right) > ${T0}$`, `$S_{${n - 1}} = ${num(Sn1)}$ (not enough), $S_{${n}} = ${num(Sn)}$ (more than ${T0})`, `So $${n}$ weeks.`],
          hint: 'Use the sum, not the weekly amount. Check the whole numbers either side.', numworks: { app: 'Sequences', lines: [[`u(n)=${a}+(n-1)×${num(d)}`, ''], [`Σ of u(n), n=1..${n - 1}`, num(Sn1)], [`Σ of u(n), n=1..${n}`, num(Sn)]] },
          errors: [{ value: n - 1, tag: 'round-down', fb: `After ${n - 1} weeks the total is only ${num(Sn1)}.` }, { value: m, tag: 'term-not-sum', fb: 'You found when one week’s savings passes the target. The question is about the total.' }],
          verify: `next(t for t in range(1,500) if Rational(t,2)*(2*${a}+(t-1)*Rational(${d * 2},2)) > ${T0})` }
      ]
    };
  });

  /* ---------- 1.3 Bouncing ball: geometric sequence and sum to infinity (Paper 2) ---------- */
  reg('slx1.ball', Object.assign({ skill: 'SL-1.3b', title: 'Bouncing ball: geometric sequence and total distance', paper: 2, challenge: true }, X), (R, o) => {
    const H = R.pick([2, 2.5, 3, 4, 5, 6]), r = R.pick(o.challenge ? [0.55, 0.65, 0.72, 0.85] : [0.6, 0.7, 0.75, 0.8]), k = R.int(3, 5), lim = R.pick([0.1, 0.2, 0.25]);
    const hk = H * r ** k; let n = 1; while (H * r ** n >= lim) n++;
    const D = H + 2 * H * r / (1 - r);
    return {
      stem: `A ball is dropped from a height of $${num(H)}$ metres. After each bounce it rises to $${num(r * 100)}\\%$ of the height it fell from.`,
      parts: [
        { command: 'Find', prompt: `the height the ball reaches after bounce $${k}$.`, marks: 2, answer: { kind: 'num', value: hk, sf: 3, display: `${num(sf(hk, 3))}\\text{ m}` },
          ms: [['M1', `$${num(H)}(${num(r)})^{${k}}$`], ['A1', `$${num(sf(hk, 3))}$ m`]], working: [`Heights after each bounce: $${num(H)}r, ${num(H)}r^{2}, \\ldots$ with $r = ${num(r)}$`, `$h_{${k}} = ${num(H)}(${num(r)})^{${k}} = ${num(sf(hk, 3))}$ m`],
          hint: 'Each bounce multiplies the height by the same ratio.', errors: [{ value: H * r ** (k - 1), tag: 'power-count', fb: `After bounce ${k} the height has been multiplied by r exactly ${k} times.` }], verify: `${H}*Rational(${Math.round(r * 100)},100)**${k}` },
        { command: 'Find', prompt: `the number of the first bounce after which the ball rises less than $${num(lim * 100)}$ cm.`, marks: 3, answer: { kind: 'num', value: n, int: true, display: String(n) },
          ms: [['M1', `$${num(H)}(${num(r)})^{n} < ${num(lim)}$`], ['(A1)', `$n > ${num(sf(Math.log(lim / H) / Math.log(r), 4))}$`], ['A1', `bounce $${n}$`]],
          working: [`$${num(H)}(${num(r)})^{n} < ${num(lim)}$ (metres)`, `NumWorks: $n > ${num(sf(Math.log(lim / H) / Math.log(r), 4))}$`, `First whole number: $${n}$`],
          hint: 'Change cm to metres first. Then solve the inequality or use a table.', numworks: { app: 'Equations', lines: [[`${num(H)}×${num(r)}^n=${num(lim)}`, `n=${num(sf(Math.log(lim / H) / Math.log(r), 6))}`]] },
          errors: [{ value: n - 1, tag: 'round-down', fb: 'Round up: the bounce must be strictly below the height.' }], verify: `next(t for t in range(1,300) if ${H}*Rational(${Math.round(r * 100)},100)**t < Rational(${Math.round(lim * 100)},100))` },
        { command: 'Find', prompt: 'the total vertical distance the ball travels before it comes to rest.', marks: 3, answer: { kind: 'num', value: D, sf: 3, display: `${num(sf(D, 3))}\\text{ m}` },
          ms: [['M1', `recognising each rise is also a fall: $${num(H)} + 2\\left(\\frac{${num(H)}(${num(r)})}{1-${num(r)}}\\right)$`], ['A1', `$S_\\infty = \\frac{${num(sf(H * r, 4))}}{${num(round(1 - r, 2))}}$`], ['A1', `$${num(sf(D, 3))}$ m`]],
          working: [`Distance $= ${num(H)} + 2\\left(${num(H)}r + ${num(H)}r^{2} + \\cdots\\right)$`, `$= ${num(H)} + 2\\left(\\frac{${num(sf(H * r, 4))}}{1-${num(r)}}\\right) = ${num(sf(D, 3))}$ m`],
          hint: 'After the first drop, every bounce is travelled twice: up and down.', errors: [{ value: H / (1 - r), tag: 'up-and-down', fb: 'After the first drop the ball goes up AND down each time, so the bounces count twice.' }, { value: H + H * r / (1 - r), tag: 'up-and-down', fb: 'Each bounce height is travelled twice: up and down.' }],
          verify: `${H}+2*${H}*Rational(${Math.round(r * 100)},100)/(1-Rational(${Math.round(r * 100)},100))` }
      ]
    };
  });

  /* ---------- 1.3 Sum of first two terms and S∞ → two possible ratios (Paper 1) ---------- */
  reg('slx1.sinf2', Object.assign({ skill: 'SL-1.3b', title: 'Sum of two terms and sum to infinity: finding r', paper: 1, challenge: true }, X), (R, o) => {
    const [a, b] = R.pick(o.challenge ? [[2, 5], [3, 5], [3, 4], [2, 7]] : [[1, 2], [1, 3], [2, 3], [1, 4]]), k = R.int(1, 3);
    const r = fr(a, b), u1 = k * b * (b - a), A = k * (b - a) * (a + b), B = k * b * b;
    const S3 = F.of(u1).mul(fr(1).sub(r.pow(3))).div(fr(1).sub(r));
    return {
      stem: `A geometric series has first term $u_1$ and common ratio $r$. The sum of the first two terms is $${A}$ and the sum to infinity is $${B}$.`,
      parts: [
        { command: 'Show that', prompt: `$r^{2} = ${fr(B - A, B).tex()}$.`, marks: 3, answer: { kind: 'open' },
          ms: [['A1', `$u_1(1 + r) = ${A}$`], ['A1', `$\\frac{u_1}{1-r} = ${B}$`], ['M1', `dividing or substituting: $(1-r)(1+r) = \\frac{${A}}{${B}}$, so $1 - r^{2} = ${fr(A, B).tex()}$`], ['AG', `$r^{2} = ${fr(B - A, B).tex()}$`]],
          working: [`$u_1 + u_1 r = ${A}$ so $u_1(1+r) = ${A}$`, `$S_\\infty = \\frac{u_1}{1-r} = ${B}$ so $u_1 = ${B}(1-r)$`, `$${B}(1-r)(1+r) = ${A} \\Rightarrow 1 - r^{2} = ${fr(A, B).tex()} \\Rightarrow r^{2} = ${fr(B - A, B).tex()}$`],
          hint: 'Write both facts as equations in u₁ and r, then eliminate u₁.', verify: `simplify(${A}*(1-r**2) - ${A}) == simplify(-${A}*r**2) and Rational(${B - A},${B}) == Rational(${a * a},${b * b})` },
        { command: 'Find', prompt: 'the two possible values of $r$.', marks: 2, dep: true, answer: { kind: 'list', value: [a / b, -a / b], exact: true, display: `\\pm ${r.tex()}` },
          ms: [['A1', `$${r.tex()}$`], ['A1', `$-${r.tex()}$`]], working: [`$r = \\pm\\sqrt{${fr(B - A, B).tex()}} = \\pm ${r.tex()}$`, `Both satisfy $|r| < 1$, so both are valid.`], hint: 'A square root has two values. Check |r| < 1 for each.',
          errors: [{ value: [a / b], tag: 'missing-negative-root', fb: 'r² has two square roots.' }], verify: `[Rational(${a},${b}), -Rational(${a},${b})]` },
        { command: 'Find', prompt: 'the value of $u_1$, given that every term of the series is positive.', marks: 2, dep: true, answer: { kind: 'num', value: u1, exact: true, display: String(u1) },
          ms: [['M1', `$u_1 = ${B}\\left(1 - ${r.tex()}\\right)$`], ['A1', `$${u1}$`]], working: [`All terms positive $\\Rightarrow r = ${r.tex()}$`, `$u_1 = ${B}\\left(1 - ${r.tex()}\\right) = ${u1}$`], hint: 'Positive terms need a positive ratio.',
          errors: [{ value: B * (1 + a / b), tag: 'sign', fb: 'With every term positive, r is the positive value.' }], verify: `${B}*(1-Rational(${a},${b}))` },
        { command: 'Find', prompt: 'the sum of the first three terms.', marks: 2, dep: true, answer: { kind: 'num', value: S3.val(), exact: true, display: S3.tex() },
          ms: [['M1', `$${u1} + ${T(r.mul(u1))} + ${T(r.pow(2).mul(u1))}$ or $\\frac{${u1}\\left(1-\\left(${r.tex()}\\right)^{3}\\right)}{1-${r.tex()}}$`], ['A1', `$${S3.tex()}$`]],
          working: [`$S_3 = ${u1} + ${T(r.mul(u1))} + ${T(r.pow(2).mul(u1))} = ${S3.tex()}$`], hint: 'Three terms: u₁, u₁r, u₁r².', errors: [{ value: B, tag: 'term-off', fb: 'That is the sum to infinity, not of three terms.' }], verify: `${u1}*(1-Rational(${a},${b})**3)/(1-Rational(${a},${b}))` }
      ]
    };
  });

  /* ---------- 1.4 Comparing two accounts (Paper 2, NumWorks finance) ---------- */
  reg('slx1.accounts', Object.assign({ skill: 'SL-1.4', title: 'Comparing two savings accounts (compound interest)', paper: 2, challenge: true }, X), (R, o) => {
    const P = R.pick([2000, 3500, 4000, 5000, 8000]), i1 = R.pick([3, 3.5, 4]), i2 = R.pick([2.8, 3.2, 3.6, 3.9]), t = R.int(5, o.challenge ? 15 : 10);
    const A = P * (1 + i1 / 100) ** t, B = P * (1 + i2 / 1200) ** (12 * t), need = (Math.pow(A / P, 1 / (12 * t)) - 1) * 1200;
    const $ = v => `\\$${v.toFixed(2)}`;
    return {
      stem: `Ravi has $\\$${P}$ to invest for $${t}$ years. Bank A offers $${i1}\\%$ per year compounded annually. Bank B offers a nominal annual rate of $${i2}\\%$ compounded monthly.`,
      parts: [
        { command: 'Calculate', prompt: `the value of the investment in Bank A after $${t}$ years. Give your answer correct to two decimal places.`, marks: 2, answer: { kind: 'num', value: round(A, 2), dp: 2, display: $(round(A, 2)) },
          ms: [['M1', `$${P}\\left(1 + \\frac{${i1}}{100}\\right)^{${t}}$`], ['A1', `$${$(round(A, 2))}$`]], working: [`$FV = ${P}\\left(1+\\frac{${i1}}{100}\\right)^{${t}} = ${round(A, 2).toFixed(2)}$`],
          hint: 'Annual compounding: k = 1.', numworks: { app: 'Finance', lines: [['N=' + t + ', I%=' + i1 + ', PV=−' + P + ', payments per year = 1', 'FV=' + round(A, 2).toFixed(2)]] }, errors: [{ value: round(P * (1 + i1 * t / 100), 2), tag: 'simple-interest', fb: 'That is simple interest; this account compounds.' }],
          verify: `${P}*(1+Rational(${Math.round(i1 * 10)},1000))**${t}` },
        { command: 'Calculate', prompt: `the value of the investment in Bank B after $${t}$ years. Give your answer correct to two decimal places.`, marks: 2, answer: { kind: 'num', value: round(B, 2), dp: 2, display: $(round(B, 2)) },
          ms: [['M1', `$${P}\\left(1 + \\frac{${i2}}{100(12)}\\right)^{12(${t})}$`], ['A1', `$${$(round(B, 2))}$`]], working: [`$FV = ${P}\\left(1+\\frac{${i2}}{1200}\\right)^{${12 * t}} = ${round(B, 2).toFixed(2)}$`],
          hint: 'Monthly: divide the rate by 12 and use 12 periods per year.', numworks: { app: 'Finance', lines: [['N=' + 12 * t + ', I%=' + i2 + ', PV=−' + P + ', payments and compoundings per year = 12', 'FV=' + round(B, 2).toFixed(2)]] }, errors: [{ value: round(P * (1 + i2 / 100) ** t, 2), tag: 'annual-not-compounded', fb: 'Interest is added monthly: use i ÷ 12 and 12t periods.' }],
          verify: `${P}*(1+Rational(${Math.round(i2 * 10)},12000))**(12*${t})` },
        { command: 'Find', prompt: `the nominal annual rate, compounded monthly, that Bank B would need to offer for Ravi to have the same amount as Bank A after $${t}$ years. Give your answer as a percentage correct to three significant figures.`, marks: 2, answer: { kind: 'num', value: need, sf: 3, display: `${num(sf(need, 3))}\\%` },
          ms: [['M1', `$${P}\\left(1+\\frac{r}{1200}\\right)^{${12 * t}} = ${round(A, 2).toFixed(2)}$`], ['A1', `$${num(sf(need, 3))}\\%$`]], working: [`Solve $${P}\\left(1+\\frac{r}{1200}\\right)^{${12 * t}} = ${round(A, 2).toFixed(2)}$`, `NumWorks finance solver: $I\\% = ${num(sf(need, 4))}$`],
          hint: 'Use the finance solver with FV fixed and I% unknown.', numworks: { app: 'Finance', lines: [['N=' + 12 * t + ', PV=−' + P + ', FV=' + round(A, 2).toFixed(2) + ', payments and compoundings per year = 12', 'I%=' + num(sf(need, 4))]] }, verify: `(((1+Rational(${Math.round(i1 * 10)},1000))**${t})**Rational(1,${12 * t})-1)*1200` }
      ]
    };
  });

  /* ---------- 1.5 Expand, then approximate (Paper 1) ---------- */
  reg('slx1.binapprox', Object.assign({ skill: 'SL-1.5a', title: 'Binomial expansion used to approximate a power', paper: 1, challenge: true }, X), (R, o) => {
    const n = R.int(o.challenge ? 7 : 5, o.challenge ? 9 : 7), p = R.pick([2, 3, 4, 5]), x = R.pick([0.01, 0.02]);
    const c1 = n * p, c2 = comb(n, 2) * p * p, base = 1 + p * x, approx = Number((1 + c1 * x + c2 * x * x).toFixed(6));
    return {
      stem: `Consider the expansion of $(1 + ${p}x)^{${n}}$.`,
      parts: [
        { command: 'Find', prompt: 'the first three terms in ascending powers of $x$. Write them as $1 + ax + bx^{2}$ and give $a$ and $b$.', marks: 3, answer: { kind: 'tuple', labels: ['a', 'b'], value: [c1, c2], exact: true, markEach: true, display: `1 + ${c1}x + ${c2}x^{2}` },
          ms: [['(M1)', `$\\binom{${n}}{1}(${p}x)$ and $\\binom{${n}}{2}(${p}x)^{2}$ seen`], ['A1', `$${c1}x$`], ['A1', `$${c2}x^{2}$`]],
          working: [`$(1+${p}x)^{${n}} = 1 + \\binom{${n}}{1}(${p}x) + \\binom{${n}}{2}(${p}x)^{2} + \\cdots$`, `$= 1 + ${c1}x + ${comb(n, 2)}(${p * p}x^{2}) + \\cdots = 1 + ${c1}x + ${c2}x^{2} + \\cdots$`],
          hint: 'Use Pascal’s triangle or ⁿCᵣ. Square the whole bracket (px)², not just x.', errors: [{ value: [c1, comb(n, 2) * p], tag: 'power-on-coefficient', fb: `(${p}x)² = ${p * p}x²: the ${p} is squared too.` }, { value: [p, p * p], tag: 'missing-ncr', fb: 'Each term needs its binomial coefficient ⁿCᵣ.' }],
          verify: `(expand((1+${p}*x)**${n}).coeff(x,1), expand((1+${p}*x)**${n}).coeff(x,2))` },
        { command: 'Write down', prompt: `the value of $x$ that makes $(1 + ${p}x)^{${n}}$ equal to $(${num(base)})^{${n}}$.`, marks: 1, answer: { kind: 'num', value: x, exact: true, display: num(x) },
          ms: [['A1', `$x = ${num(x)}$`]], working: [`$1 + ${p}x = ${num(base)} \\Rightarrow x = ${num(x)}$`], hint: `Solve 1 + ${p}x = ${num(base)}.`, errors: [{ value: p * x, tag: 'multiplied-not-divided', fb: `Divide by ${p}: x = ${num(round(p * x, 4))} ÷ ${p}.` }], verify: `Rational(${Math.round(x * 100)},100)` },
        { command: 'Hence', prompt: `use your answer to part (a) to find an approximate value for $(${num(base)})^{${n}}$.`, marks: 2, dep: true, answer: { kind: 'num', value: approx, exact: true, display: num(approx) },
          ms: [['M1', `$1 + ${c1}(${num(x)}) + ${c2}(${num(x)})^{2}$`], ['A1', `$${num(approx)}$`]], working: [`$1 + ${c1}(${num(x)}) + ${c2}(${num(round(x * x, 6))})$`, `$= 1 + ${num(round(c1 * x, 6))} + ${num(round(c2 * x * x, 6))} = ${num(approx)}$`],
          hint: 'Substitute your x into the three terms only.', errors: [{ value: Number((1 + c1 * x).toFixed(6)), tag: 'term-off', fb: 'Use all three terms of your expansion.' }], verify: `1+${c1}*Rational(${Math.round(x * 100)},100)+${c2}*Rational(${Math.round(x * 100)},100)**2` }
      ]
    };
  });

  /* ---------- 1.5 Product of brackets: coefficient of x² (Paper 1) ---------- */
  reg('slx1.binprod', Object.assign({ skill: 'SL-1.5b', title: 'Coefficient of x² in (a + bx)(1 + cx)ⁿ', paper: 1, challenge: true }, X), (R, o) => {
    const n = R.int(4, o.challenge ? 8 : 6), c = R.nz(-3, 3), a = R.int(2, 5), b = R.nz(-4, 4);
    const cxs = c === 1 ? '' : c === -1 ? '-' : c, c1 = n * c, c2 = comb(n, 2) * c * c, coef = a * c2 + b * c1;
    return {
      stem: `Consider the expansion of $(1 ${c < 0 ? '-' : '+'} ${Math.abs(c) === 1 ? '' : Math.abs(c)}x)^{${n}}$.`,
      parts: [
        { command: 'Find', prompt: 'the first three terms in ascending powers of $x$, in the form $1 + px + qx^{2}$. Give $p$ and $q$.', marks: 3, answer: { kind: 'tuple', labels: ['p', 'q'], value: [c1, c2], exact: true, markEach: true, display: `1 ${c1 < 0 ? '-' : '+'} ${Math.abs(c1)}x + ${c2}x^{2}` },
          ms: [['(M1)', `$\\binom{${n}}{1}(${cxs}x) + \\binom{${n}}{2}(${cxs}x)^{2}$`], ['A1', `$p = ${c1}$`], ['A1', `$q = ${c2}$`]], working: [`$1 + ${n}(${cxs}x) + ${comb(n, 2)}(${cxs}x)^{2} = 1 ${c1 < 0 ? '-' : '+'} ${Math.abs(c1)}x + ${c2}x^{2} + \\cdots$`],
          hint: 'Keep the sign inside the bracket when you square.', errors: [{ value: [c1, -c2], tag: 'negative-squared', fb: 'A negative number squared is positive.' }, { value: [c1, comb(n, 2) * c], tag: 'power-on-coefficient', fb: 'Square the whole term, including the number.' }],
          verify: `(expand((1+(${c})*x)**${n}).coeff(x,1), expand((1+(${c})*x)**${n}).coeff(x,2))` },
        { command: 'Hence', prompt: `find the coefficient of $x^{2}$ in the expansion of $(${a} ${b < 0 ? '-' : '+'} ${Math.abs(b) === 1 ? '' : Math.abs(b)}x)(1 ${c < 0 ? '-' : '+'} ${Math.abs(c) === 1 ? '' : Math.abs(c)}x)^{${n}}$.`, marks: 3, dep: true, answer: { kind: 'num', value: coef, exact: true, int: true, display: String(coef) },
          ms: [['M1', 'two terms in $x^{2}$ identified'], ['A1', `$${a}(${c2}) + (${b})(${c1})$`], ['A1', `$${coef}$`]],
          working: [`$x^{2}$ terms: $${a} \\times ${c2}x^{2}$ and $(${b === 1 ? '' : b === -1 ? '-' : b}x)(${c1}x)$`, `$${a * c2} + (${b * c1}) = ${coef}$`], hint: 'Two ways to make x²: constant × x² term, and x term × x term.',
          errors: [{ value: a * c2, tag: 'forgot-cross-terms', fb: `You also get x² from (${b === 1 ? '' : b === -1 ? '-' : b}x) × (${c1}x).` }], verify: `expand((${a}+(${b})*x)*(1+(${c})*x)**${n}).coeff(x,2)` }
      ]
    };
  });

  /* ---------- 1.5 Constant term with a parameter, then another coefficient (Paper 1) ---------- */
  reg('slx1.binconst', Object.assign({ skill: 'SL-1.5b', title: 'Constant term gives k; hence another coefficient', paper: 1, challenge: true }, X), (R, o) => {
    const [P, Q, n] = R.pick(o.challenge ? [[2, 1, 9], [3, 1, 8], [1, 2, 9]] : [[2, 1, 6], [1, 1, 6], [1, 2, 6], [1, 1, 4]]);
    const r0 = P * n / (P + Q), k = R.pick(r0 >= 5 ? [2] : [2, 3]), K = comb(n, r0) * k ** r0;
    const rs = []; for (let r = 0; r <= n; r++) { const pw = P * (n - r) - Q * r; if (r !== r0 && pw > 0) rs.push([r, pw]); } const [r1, m] = R.pick(rs), C1 = comb(n, r1) * k ** r1;
    const tx = (b, e) => e === 1 ? b : `${b}^{${e}}`;
    return {
      stem: `In the expansion of $\\left(${tx('x', P)} + \\frac{k}{${tx('x', Q)}}\\right)^{${n}}$, where $k > 0$, the constant term is $${K}$.`,
      parts: [
        { command: 'Find', prompt: 'the value of $r$ for which the term in $k^{r}$ is the constant term.', marks: 2, answer: { kind: 'num', value: r0, int: true, display: String(r0) },
          ms: [['M1', `general term $\\binom{${n}}{r}\\left(${tx('x', P)}\\right)^{${n}-r}\\left(\\frac{k}{${tx('x', Q)}}\\right)^{r}$, power of $x$: $${P}(${n}-r) - ${Q === 1 ? '' : Q}r = 0$`], ['A1', `$r = ${r0}$`]],
          working: [`Power of $x$: $${P}(${n} - r) - ${Q === 1 ? '' : Q}r = ${P * n} - ${P + Q}r$`, `$${P * n} - ${P + Q}r = 0 \\Rightarrow r = ${r0}$`], hint: 'Write the general term and collect the powers of x.',
          errors: [{ value: n - r0, tag: 'powers-swapped', fb: 'Check which bracket term is raised to r.' }], verify: `solve(${P}*(${n}-r)-${Q}*r, r)[0]` },
        { command: 'Hence', prompt: 'find the value of $k$.', marks: 3, dep: true, answer: { kind: 'num', value: k, exact: true, display: String(k) },
          ms: [['M1', `$\\binom{${n}}{${r0}}k^{${r0}} = ${K}$`], ['A1', `$k^{${r0}} = ${k ** r0}$`], ['A1', `$k = ${k}$`]], working: [`$\\binom{${n}}{${r0}} = ${comb(n, r0)}$`, `$${comb(n, r0)}k^{${r0}} = ${K} \\Rightarrow k^{${r0}} = ${k ** r0} \\Rightarrow k = ${k}$ (as $k > 0$)`],
          hint: 'Divide by the binomial coefficient, then take the root.', errors: [{ value: K / comb(n, r0), tag: 'forgot-root', fb: `That is k^${r0}. Take the root.` }], verify: `[s for s in solve(binomial(${n},${r0})*r**${r0}-${K}, r) if s.is_real and s > 0][0]` },
        { command: 'Find', prompt: `the coefficient of $x^{${m}}$.`, marks: 2, dep: true, answer: { kind: 'num', value: C1, exact: true, int: true, display: String(C1) },
          ms: [['M1', `$r = ${r1}$: $\\binom{${n}}{${r1}}(${k})^{${r1}}$`], ['A1', `$${C1}$`]], working: [`$${P * n} - ${P + Q}r = ${m} \\Rightarrow r = ${r1}$`, `$\\binom{${n}}{${r1}}(${k})^{${r1}} = ${comb(n, r1)} \\times ${k ** r1} = ${C1}$`],
          hint: `Set the power of x equal to ${m} to find r.`, errors: [{ value: comb(n, r1), tag: 'forgot-constant-power', fb: `Multiply by k^${r1} as well.` }], verify: `binomial(${n},${r1})*${k}**${r1}` }
      ]
    };
  });

  /* ---------- 1.6 Identity, hence mental arithmetic (Paper 1) ---------- */
  reg('slx1.identity', Object.assign({ skill: 'SL-1.6', title: 'Prove an identity, hence evaluate and solve', paper: 1, challenge: true }, X), (R, o) => {
    const p = R.int(2, o.challenge ? 9 : 5), N = R.pick([100, 1000, 200, 500]), s = R.int(2, 7), n2 = R.int(4, 15);
    return {
      stem: `Let $n$ and $p$ be positive integers.`,
      parts: [
        { command: 'Show that', prompt: '$(n + p)^{2} - (n - p)^{2} = 4np$.', marks: 2, answer: { kind: 'open' },
          ms: [['M1', 'expanding both brackets: $n^{2} + 2np + p^{2} - (n^{2} - 2np + p^{2})$'], ['A1', 'correct simplification to $4np$'], ['AG', '']],
          working: ['LHS $= n^{2} + 2np + p^{2} - (n^{2} - 2np + p^{2})$', '$= n^{2} + 2np + p^{2} - n^{2} + 2np - p^{2}$', '$= 4np =$ RHS'], hint: 'Start from the left-hand side and expand. Be careful with the minus sign in front of the second bracket.',
          verify: `simplify((x+y)**2-(x-y)**2-4*x*y) == 0` },
        { command: 'Hence', prompt: `find the value of $${N + s}^{2} - ${N - s}^{2}$ without a calculator.`, marks: 2, dep: true, answer: { kind: 'num', value: 4 * N * s, int: true, display: String(4 * N * s) },
          ms: [['M1', `$n = ${N}$, $p = ${s}$`], ['A1', `$${4 * N * s}$`]], working: [`$n = ${N}$, $p = ${s}$`, `$4(${N})(${s}) = ${4 * N * s}$`], hint: 'Match the two numbers to n + p and n − p.',
          errors: [{ value: 2 * N * s, tag: 'term-off', fb: 'Use 4np, not 2np.' }], verify: `${N + s}**2-${N - s}**2` },
        { command: 'Find', prompt: `the value of $n$ given that $(n + ${p})^{2} - (n - ${p})^{2} = ${4 * p * n2}$.`, marks: 2, answer: { kind: 'num', value: n2, int: true, display: String(n2) },
          ms: [['M1', `$4(${p})n = ${4 * p * n2}$`], ['A1', `$n = ${n2}$`]], working: [`$4np = ${4 * p * n2}$ with $p = ${p}$`, `$${4 * p}n = ${4 * p * n2} \\Rightarrow n = ${n2}$`], hint: 'Use the identity from part (a).',
          errors: [{ value: n2 * 4, tag: 'multiplied-not-divided', fb: `Divide by ${4 * p}.` }], verify: `solve(4*${p}*x-${4 * p * n2}, x)[0]` }
      ]
    };
  });

  /* ---------- 2.5 / 2.6 Composite and inverse of linear and quadratic functions (Paper 1) ---------- */
  reg('slx2.compinv', Object.assign({ skill: 'SL-2.6', title: 'Composite and inverse functions: evaluate, invert, solve', paper: 1, challenge: true }, X), (R, o) => {
    const a = R.pick([2, 3, 4, 5, -2, -3]), b = R.nz(-7, 7), c = R.int(1, 9), k = R.nz(-3, 4), s = R.int(2, o.challenge ? 7 : 5), m = s * s - c;
    const fk = a * k + b, gfk = fk * fk - c, inv = [fr(1, a), fr(-b, a)];
    return {
      stem: `The functions $f$ and $g$ are defined for $x \\in \\mathbb{R}$ by $f(x) = ${lin(a, b)}$ and $g(x) = x^{2} - ${c}$.`,
      parts: [
        { command: 'Find', prompt: `$(g \\circ f)(${k})$.`, marks: 2, answer: { kind: 'num', value: gfk, int: true, display: String(gfk) },
          ms: [['(M1)', `$f(${k}) = ${fk}$`], ['A1', `$g(${fk}) = ${gfk}$`]], working: [`$f(${k}) = ${a}(${k}) ${b < 0 ? '-' : '+'} ${Math.abs(b)} = ${fk}$`, `$g(${fk}) = (${fk})^{2} - ${c} = ${gfk}$`],
          hint: 'Work from the inside out: f first, then g.', errors: [{ value: a * (k * k - c) + b, tag: 'order-of-composition', fb: '(g ∘ f)(x) means apply f first, then g.' }], verify: `((${a})*(${k})+(${b}))**2-${c}` },
        { command: 'Find', prompt: '$f^{-1}(x)$. Write it in the form $f^{-1}(x) = px + q$ and give $p$ and $q$.', marks: 2, answer: { kind: 'tuple', labels: ['p', 'q'], value: inv.map(v => v.val()), exact: true, markEach: true, display: `\\frac{x ${b < 0 ? '+' : '-'} ${Math.abs(b)}}{${a}}` },
          ms: [['M1', `$x = ${a}y ${b < 0 ? '-' : '+'} ${Math.abs(b)}$ (interchanging $x$ and $y$)`], ['A1', `$f^{-1}(x) = ${inv[0].tex()}x ${inv[1].n < 0 ? '-' : '+'} ${T(inv[1].n < 0 ? inv[1].neg() : inv[1])}$`]],
          working: [`$y = ${lin(a, b)}$; swap: $x = ${a}y ${b < 0 ? '-' : '+'} ${Math.abs(b)}$`, `$y = \\frac{x ${b < 0 ? '+' : '-'} ${Math.abs(b)}}{${a}} = ${inv[0].tex()}x ${inv[1].n < 0 ? '-' : '+'} ${T(inv[1].n < 0 ? inv[1].neg() : inv[1])}$`],
          hint: 'Swap x and y, then make y the subject.', errors: [{ value: [1 / a, b / a], tag: 'inverse-sign', fb: `Undo "${b < 0 ? 'subtract' : 'add'} ${Math.abs(b)}" by doing the opposite.` }], verify: `(Rational(1,${a}), Rational(${-b},${a}))` },
        { command: 'Solve', prompt: `$(f \\circ g)(x) = f(${m})$.`, marks: 3, answer: { kind: 'list', value: [s, -s], exact: true, display: `\\pm ${s}` },
          ms: [['M1', `$${a}(x^{2} - ${c}) ${b < 0 ? '-' : '+'} ${Math.abs(b)} = ${a * m + b}$`], ['A1', `$x^{2} = ${s * s}$`], ['A1', `$x = \\pm ${s}$`]],
          working: [`$(f \\circ g)(x) = ${a}(x^{2} - ${c}) ${b < 0 ? '-' : '+'} ${Math.abs(b)}$ and $f(${m}) = ${a * m + b}$`, `Since $f$ is one-to-one, $g(x) = ${m}$: $x^{2} - ${c} = ${m}$`, `$x^{2} = ${s * s} \\Rightarrow x = \\pm ${s}$`],
          hint: 'f is one-to-one, so f(A) = f(B) means A = B.', errors: [{ value: [s], tag: 'missing-negative-root', fb: 'x² = k has two solutions.' }], verify: `solve((${a})*(x**2-${c})+(${b})-((${a})*${m}+(${b})), x)` }
      ]
    };
  });

  /* ---------- 2.4 / 2.6 Radical function: domain, range, inverse (Paper 1) ---------- */
  reg('slx2.radical', Object.assign({ skill: 'SL-2.4', title: 'Square-root function: domain, range and inverse', paper: 1, challenge: true }, X), (R, o) => {
    const p = R.pick([1, 2, 3, 4]), q = R.int(1, 9), r = R.nz(-5, 6), s = R.int(2, o.challenge ? 9 : 6);
    const dom = fr(q, p), invv = fr(s * s + q, p);
    const f = `\\sqrt{${p === 1 ? '' : p}x - ${q}} ${r < 0 ? '-' : '+'} ${Math.abs(r)}`;
    return {
      stem: `The function $f$ is defined by $f(x) = ${f}$, for $x \\ge k$.`,
      parts: [
        { command: 'Find', prompt: 'the smallest possible value of $k$.', marks: 2, answer: { kind: 'num', value: dom.val(), exact: true, display: dom.tex() },
          ms: [['M1', `$${p === 1 ? '' : p}x - ${q} \\ge 0$`], ['A1', `$k = ${dom.tex()}$`]], working: [`The square root needs $${p === 1 ? '' : p}x - ${q} \\ge 0$`, `$x \\ge ${dom.tex()}$, so $k = ${dom.tex()}$`],
          hint: 'You cannot take the square root of a negative number.', errors: [{ value: q, tag: 'did-not-factor', fb: `Divide by ${p}.` }], verify: `Rational(${q},${p})` },
        { command: 'Write down', prompt: 'the range of $f$. Give the least value of $f(x)$.', marks: 1, answer: { kind: 'num', value: r, int: true, display: `f(x) \\ge ${r}` },
          ms: [['A1', `$f(x) \\ge ${r}$`]], working: [`$\\sqrt{\\;\\cdot\\;} \\ge 0$, so $f(x) \\ge ${r}$`], hint: 'The smallest value of a square root is 0.', errors: [{ value: 0, tag: 'endpoints-only', fb: `The graph is shifted ${r < 0 ? 'down' : 'up'} by ${Math.abs(r)}.` }], verify: `${r}` },
        { command: 'Find', prompt: `$f^{-1}(${r + s})$.`, marks: 2, answer: { kind: 'num', value: invv.val(), exact: true, display: invv.tex() },
          ms: [['M1', `$${f} = ${r + s}$ OR finding $f^{-1}(x) = \\frac{(x ${r < 0 ? '+' : '-'} ${Math.abs(r)})^{2} + ${q}}{${p}}$`], ['A1', `$${invv.tex()}$`]],
          working: [`Solve $f(x) = ${r + s}$: $\\sqrt{${p === 1 ? '' : p}x - ${q}} = ${s}$`, `$${p === 1 ? '' : p}x - ${q} = ${s * s} \\Rightarrow x = ${invv.tex()}$`], hint: 'f⁻¹(a) is the x-value that f sends to a.',
          verify: `solve(sqrt(${p}*x-${q})+(${r})-(${r + s}), x)[0]` },
        { command: 'Write down', prompt: 'the domain of $f^{-1}$. Give the least value of $x$.', marks: 1, answer: { kind: 'num', value: r, int: true, display: `x \\ge ${r}` },
          ms: [['A1', `$x \\ge ${r}$ (FT their range)`]], working: ['The domain of $f^{-1}$ is the range of $f$.', `$x \\ge ${r}$`], hint: 'Domain of the inverse = range of the function.',
          errors: [{ value: dom.val(), tag: 'domain-not-range', fb: 'The domain of f⁻¹ is the RANGE of f.' }], verify: `${r}` }
      ]
    };
  });

  /* ---------- 2.2 Two pricing models: function notation, intersection, inverse in context (Paper 1) ---------- */
  reg('slx2.models', Object.assign({ skill: 'SL-2.2', title: 'Two linear cost models: compare, solve and interpret', paper: 1, challenge: true }, X), (R, o) => {
    const a1 = R.pick([3, 4, 5]), b1 = R.pick([2, 2.5, 3]), d0 = R.pick([6, 8, 10, 12, 14]), b2 = b1 - 0.5, a2 = a1 + 0.5 * d0;
    const C = R.int(30, 60), dC = (C - a1) / b1, $ = v => `\\$${Number.isInteger(v) ? v : v.toFixed(2)}`;
    return {
      stem: `Taxi company A charges $${$(a1)}$ plus $${$(b1)}$ per kilometre, so the cost for $d$ km is $A(d) = ${a1} + ${num(b1)}d$. Company B charges $B(d) = ${num(a2)} + ${num(b2)}d$.`,
      parts: [
        { command: 'Find', prompt: `the cost of a $${d0 + 6}$ km journey with company B.`, marks: 1, answer: { kind: 'num', value: a2 + b2 * (d0 + 6), exact: true, display: $(a2 + b2 * (d0 + 6)) },
          ms: [['A1', `$B(${d0 + 6}) = ${$(a2 + b2 * (d0 + 6))}$`]], working: [`$B(${d0 + 6}) = ${num(a2)} + ${num(b2)}(${d0 + 6}) = ${num(a2 + b2 * (d0 + 6))}$`], hint: 'Substitute d into B(d).', verify: `Rational(${a2 * 10},10)+Rational(${b2 * 10},10)*${d0 + 6}` },
        { command: 'Find', prompt: 'the distance for which both companies charge the same.', marks: 2, answer: { kind: 'num', value: d0, exact: true, display: `${d0}\\text{ km}` },
          ms: [['M1', `$${a1} + ${num(b1)}d = ${num(a2)} + ${num(b2)}d$`], ['A1', `$d = ${d0}$`]], working: [`$${a1} + ${num(b1)}d = ${num(a2)} + ${num(b2)}d$`, `$${num(a1 - a2)} = ${num(b2 - b1)}d \\Rightarrow d = ${d0}$`],
          hint: 'Set A(d) = B(d).', verify: `solve(${a1}+Rational(${b1 * 10},10)*x-(Rational(${a2 * 10},10)+Rational(${b2 * 10},10)*x), x)[0]` },
        { command: 'Find', prompt: `$A^{-1}(${C})$.`, marks: 2, answer: { kind: 'num', value: dC, exact: true, display: `${fr(Math.round((C - a1) * 2), Math.round(b1 * 2)).tex()}\\text{ km}` },
          ms: [['M1', `$${a1} + ${num(b1)}d = ${C}$`], ['A1', `$${fr(Math.round((C - a1) * 2), Math.round(b1 * 2)).tex()}$`]],
          working: [`$${a1} + ${num(b1)}d = ${C} \\Rightarrow d = \\frac{${C - a1}}{${num(b1)}} = ${fr(Math.round((C - a1) * 2), Math.round(b1 * 2)).tex()}$`, `It is the distance, in km, a $${$(C)}$ fare buys with company A.`],
          hint: 'A⁻¹ takes a cost and gives back a distance.', errors: [{ value: a1 + b1 * C, tag: 'applied-f', fb: 'A⁻¹(C) is the distance that costs C.' }], verify: `Rational(${C - a1},1)/Rational(${b1 * 10},10)` },
        { command: 'Explain', prompt: `what $A^{-1}(${C})$ represents in this context.`, marks: 1, answer: { kind: 'open' },
          ms: [['R1', `the distance (km) that can be travelled with company A for $${$(C)}$`]], working: [`$A^{-1}$ turns a cost back into a distance: it is how far a $${$(C)}$ fare takes you with company A.`], hint: 'What goes in and what comes out of A⁻¹?', verify: 'True' }
      ]
    };
  });
})(window.Hub = window.Hub || {});
