/* Private Supabase storage. Short-lived URLs, no browser-only file records. */
(function(Hub){
 'use strict';
 async function compress(file){const bitmap=await createImageBitmap(file);const k=Math.min(1,1600/Math.max(bitmap.width,bitmap.height));const c=document.createElement('canvas');c.width=Math.round(bitmap.width*k);c.height=Math.round(bitmap.height*k);const g=c.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,c.width,c.height);g.drawImage(bitmap,0,0,c.width,c.height);bitmap.close();return new Promise((resolve,reject)=>c.toBlob(b=>b?resolve(b):reject(Error('Could not process photo.')),'image/jpeg',.82));}
 async function add(file){if(Hub.auth.isPreview())throw Error('Uploads are disabled in teacher preview.');let blob=file;if(file.type.startsWith('image/'))blob=await compress(file);if(!['image/jpeg','image/png','application/pdf'].includes(blob.type)||blob.size>10485760)throw Error('Choose a photo or PDF under 10 MB.');
 const r=await Hub.cloud.call('file-upload',{type:blob.type,size:blob.size});const {error}=await Hub.cloud.client.storage.from('hub-work').uploadToSignedUrl(r.path,r.token,blob,{contentType:blob.type});if(error)throw error;return {id:r.path,name:file.name,type:blob.type,size:blob.size,at:new Date().toISOString()};}
 async function url(id){const r=await Hub.cloud.call('file-read',{path:id});return r.signedUrl;}
 Hub.uploads={add,url,get:async id=>({id,url:await url(id)}),del:async()=>{throw Error('Unlink the attachment; existing submitted work is retained.')}};
})(window.Hub=window.Hub||{});
