/* Shared views: IA Studio (student notebook + teacher overview/feedback), Course & pacing, Data & settings. */
(function (Hub) {
  'use strict';
  const { esc, $, $$, fmtDate, fmtDateTime, toast, download, debounce, daysBetween, todayISO } = Hub.core;
  const U = Hub.ui, C = () => Hub.curriculum, S = () => Hub.store.state, M = t => Hub.math.render(t);
  const go = h => Hub.app.nav(h);

  /* ================= IA Studio ================= */
  const IA_SECTIONS = {
    cp1: [['interests', 'Three things you are genuinely curious about (sports, music, money, health, games, your culture…)', 4], ['connections', 'Where is the mathematics in each? (rates, optimisation, probability, modelling, geometry…)', 3], ['working', 'Working title', 1]],
    cp2: [['title', 'Final title', 1], ['why', 'Why me? — your personal connection', 3], ['aim', 'Aim — what you will find out', 2], ['planIntro', 'Plan — the steps of your exploration', 3], ['terms', 'Key terms you will define', 2]],
    cp3: [['rq', 'Research question', 2], ['outline', 'Outline — sections and the mathematics in each', 5]],
    cp4: [['intro', 'Introduction paragraph (your own words)', 9]],
    cp5: [['peerGiven', 'Feedback I gave (criterion-referenced)', 4], ['peerReceived', 'Feedback I received and what I will change', 4]],
    cp6: [['finalIntro', 'Final introduction paragraph', 9]],
    ws: [['mathsPlan', 'Mathematical plan — methods, why they fit, what you will calculate', 5], ['beyond', 'Anything beyond the syllabus you will need to learn', 2]],
    y1: [['explorationPlan', 'Exploration plan — the full structure, data and mathematics', 8]]
  };
  const TITLE_CHECK = [['QUESTION', 'Is it phrased as a question you can answer?'], ['FOCUSED', 'Is it narrow enough to explore in 12–20 pages?'], ['MATHS', 'Does it clearly need mathematics at the level of the course?'], ['PERSONAL', 'Does it come from your own interest or experience?'], ['DOABLE', 'Can you get the data or build the model you need?']];
  function rqCheck(t) {
    const s = String(t || '').trim(), w = s.split(/\s+/).filter(Boolean).length;
    return [
      ['Question', /\?\s*$/.test(s) || /^(how|to what extent|what|which|can|does|is|why|when)\b/i.test(s), 'Phrase it as a question.'],
      ['Focused', w >= 8 && w <= 35, `About 8–35 words works well (yours: ${w}).`],
      ['Mathematics named', /model|function|rate|optimi|maxim|minim|probab|regress|correlat|distribut|deriv|integr|area|volume|sequence|series|exponential|logarithm|trigon|vector|matri|statistic|calculus|geometr|graph|differential/i.test(s), 'Name the mathematics (a model, a rate of change, a regression…).'],
      ['Data or model source', /data|measure|collect|record|experiment|survey|simulat|model|my |own /i.test(s), 'Make clear where the data or the model comes from.']
    ];
  }
  const blankIA = () => ({ fields: {}, titleCheck: {}, status: {}, feedback: {}, versions: [], log: [], sources: [], self: {}, updatedAt: null });
  function iaNote(sid) { const st = S(); if (!st.ia[sid]) st.ia[sid] = blankIA(); const n = st.ia[sid]; ['fields', 'titleCheck', 'status', 'feedback', 'self'].forEach(k => (n[k] = n[k] || {})); ['versions', 'log', 'sources'].forEach(k => (n[k] = n[k] || [])); return n; }

  function iaStudent(main, sidParam) {
    const teacher = Hub.auth.isTeacher() && !Hub.auth.isPreview(), sid = sidParam || Hub.auth.sid(), s = Hub.roster.byId(sid);
    if (!s) { main.innerHTML = U.empty('Student not found.'); return; }
    const n = iaNote(sid), sch = C().iaSchedule(s.group), asOf = Hub.mastery.asOf(), ro = teacher || Hub.auth.isPreview();
    const nextCp = sch.find(x => x.date && x.date >= asOf);
    main.innerHTML = (teacher ? `<a class="back" href="#/ia?group=${s.group}">← IA overview</a>` : '') + U.heading('INQUIRE · EXPLORE · REFLECT', teacher ? `IA notebook · ${esc(s.name)}` : 'My IA Studio', `${C().GROUPS[s.group].label} · the Mathematical Exploration (12–20 pages, 20 marks)`) +
      `<div class="notice integrity">This is a <b>planning notebook</b>. Everything here is written by ${teacher ? 'the student' : 'you'}, in ${teacher ? 'their' : 'your'} own words. The Hub never writes IA text. Cite every source.</div>
      <section class="card timeline"><h2 class="bar-head amber">Checkpoints</h2><ol class="tl">${sch.map(st => { const stt = n.status[st.id] || 'not-started'; const dd = st.date ? daysBetween(asOf, st.date) : null; return `<li class="tl-i ${stt} ${nextCp && nextCp.id === st.id ? 'next' : ''}"><a href="#ia-${st.id}"><b>${esc(st.short)}</b><span>${st.date ? fmtDate(st.date) : 'date tbc'}${dd !== null && dd >= 0 && dd < 40 ? ` · ${dd === 0 ? 'today' : dd + ' days'}` : ''}</span><em>${stt.replace('-', ' ')}</em></a></li>`; }).join('')}</ol><p class="tiny muted">Dates from the ${C().GROUPS[s.group].label} pacing calendar.</p></section>
      <div class="ia-grid"><div class="ia-main">${sch.map(st => iaSection(st, n, s, ro, teacher)).join('')}
        <section class="card" id="ia-sources"><h2 class="bar-head blue">Sources & data log</h2><table class="tbl small"><thead><tr><th>Source</th><th>Link</th><th>Accessed</th><th>Notes</th>${ro ? '' : '<th></th>'}</tr></thead><tbody>${n.sources.map((x, i) => `<tr><td>${esc(x.title)}</td><td>${x.url ? `<a href="${esc(x.url)}" target="_blank" rel="noopener">link</a>` : ''}</td><td>${esc(x.accessed || '')}</td><td>${esc(x.notes || '')}</td>${ro ? '' : `<td><button class="btn small ghost" data-rmsrc="${i}">Remove</button></td>`}</tr>`).join('') || `<tr><td colspan="5" class="muted">No sources yet.</td></tr>`}</tbody></table>
        ${ro ? '' : `<form id="src-form" class="form-grid"><label>Title and author<input id="src-t" required></label><label>Link<input id="src-u" type="url" placeholder="https://"></label><label>Accessed<input id="src-d" type="date" value="${todayISO()}"></label><label>Notes (what you used it for)<input id="src-n"></label><div class="span2"><button class="btn small">Add source</button></div></form>`}</section>
        <section class="card"><h2 class="bar-head green">Reflection log</h2>${n.log.slice().reverse().map(l => `<div class="log-i"><span class="tiny muted">${fmtDateTime(l.at)}</span><p>${esc(l.text)}</p></div>`).join('') || '<p class="muted">Reflections are part of criterion D — note what you tried, what changed and why.</p>'}${ro ? '' : '<form id="log-form"><label>New entry<textarea id="log-t" rows="2" placeholder="Today I…, which changed my plan because…"></textarea></label><button class="btn small">Add reflection</button></form>'}</section></div>
        <aside class="ia-side"><section class="card criteria"><h2 class="bar-head pink">Criteria A–E</h2>${C().IA_CRITERIA.map(([k, name, max, d]) => `<div class="crit"><b>${k} · ${name}</b> <span class="tiny">/${max}</span><p class="tiny">${esc(d)}</p><label class="tiny">My confidence <input type="range" min="0" max="${max}" value="${n.self[k] ?? 0}" data-self="${k}" ${ro ? 'disabled' : ''}> <output>${n.self[k] ?? 0}</output></label></div>`).join('')}<p class="tiny muted">Self-check only — not a grade.</p></section>
        <section class="card"><h2 class="bar-head blue">Versions</h2>${n.versions.length ? n.versions.slice().reverse().slice(0, 10).map((v, i) => `<div class="row-between small"><span>${fmtDateTime(v.at)}${v.label ? ' · ' + esc(v.label) : ''}</span>${ro ? '' : `<button class="btn small ghost" data-restore="${n.versions.length - 1 - i}">Restore</button>`}</div>`).join('') : '<p class="tiny muted">A version is kept each time you submit a checkpoint, and every 10 minutes while you write.</p>'}<p class="tiny muted" id="ia-saved">${n.updatedAt ? 'Saved ' + fmtDateTime(n.updatedAt) : ''}</p></section></aside></div>`;
    bindIA(main, n, s, ro, teacher);
  }
  function iaSection(st, n, s, ro, teacher) {
    const fields = IA_SECTIONS[st.id] || [], stt = n.status[st.id] || 'not-started', fb = n.feedback[st.id];
    const extra = st.id === 'cp2' ? `<fieldset class="titlecheck"><legend>Title checklist</legend>${TITLE_CHECK.map(([k, q]) => `<label class="inline-check"><input type="checkbox" data-tc="${k}" ${n.titleCheck[k] ? 'checked' : ''} ${ro ? 'disabled' : ''}> <b>${k}</b> — ${esc(q)}</label>`).join('')}</fieldset>`
      : st.id === 'cp3' ? `<div class="rq-check" id="rq-check">${rqCheckHtml(n.fields.rq)}</div>`
      : st.id === 'ws' && s.course === 'HL' ? `<label>Is it HL enough? Which HL-level mathematics will you use and where?<textarea data-ia="hlEnough" rows="2" ${ro ? 'readonly' : ''}>${esc(n.fields.hlEnough || '')}</textarea></label>` : '';
    const wc = ['intro', 'finalIntro'].map(k => fields.some(f => f[0] === k) ? `<p class="tiny muted" data-wc="${k}">${(n.fields[k] || '').split(/\s+/).filter(Boolean).length} words</p>` : '').join('');
    return `<section class="card ia-sec ${stt}" id="ia-${st.id}"><div class="row-between"><h2 class="bar-head ${st.id === 'ws' || st.id === 'y1' ? 'blue' : 'green'}">${esc(st.title)}</h2><span class="pill ${stt === 'signed-off' ? 'green' : stt === 'submitted' ? 'blue' : stt === 'in-progress' ? 'amber' : 'grey'}">${stt.replace('-', ' ')}</span></div>
      <p class="small">${esc(st.focus)} <span class="tiny muted">Criteria: ${st.criteria.join(', ')}${st.date ? ' · due ' + fmtDate(st.date) : ''}</span></p>
      ${fields.map(([k, label, rows]) => `<label>${esc(label)}<textarea data-ia="${k}" rows="${rows}" ${ro ? 'readonly' : ''}>${esc(n.fields[k] || '')}</textarea></label>`).join('')}${extra}${wc}
      ${fb ? `<div class="sticky"><b>Miss Badmus${fb.criteria && fb.criteria.length ? ' · ' + fb.criteria.join(', ') : ''}:</b> ${esc(fb.text)} <span class="tiny muted">${fmtDateTime(fb.at)}</span></div>` : ''}
      ${!ro && ['not-started', 'in-progress'].includes(stt) ? `<button class="btn small" data-submit-cp="${st.id}">Submit this checkpoint for feedback</button>` : ''}
      ${teacher ? `<form class="fb-form" data-cp="${st.id}"><label>Feedback<textarea rows="2" name="t">${esc(fb ? fb.text : '')}</textarea></label><div class="crit-pick">${['A', 'B', 'C', 'D', 'E'].map(k => `<label class="inline-check"><input type="checkbox" name="c" value="${k}" ${fb && fb.criteria && fb.criteria.includes(k) ? 'checked' : ''}> ${k}</label>`).join('')}</div><div class="actions"><button class="btn small" name="act" value="return">Save & return for edits</button><button class="btn small primary" name="act" value="sign">Sign off checkpoint</button></div></form>` : ''}</section>`;
  }
  const rqCheckHtml = t => `<p class="tiny"><b>Quick checks</b> (a prompt for thinking, not a judgement):</p><ul class="checks">${rqCheck(t).map(([k, ok, tip]) => `<li class="${ok ? 'ok' : ''}">${ok ? '✓' : '○'} <b>${k}</b>${ok ? '' : ' — ' + esc(tip)}</li>`).join('')}</ul>`;
  function bindIA(main, n, s, ro, teacher) {
    const saved = () => { n.updatedAt = new Date().toISOString(); const el = $('#ia-saved'); if (el) el.textContent = 'Saved ' + fmtDateTime(n.updatedAt); };
    const snapshot = label => { const last = n.versions[n.versions.length - 1]; if (label || !last || (Date.now() - new Date(last.at)) > 10 * 60000) { n.versions.push({ at: new Date().toISOString(), label: label || '', fields: JSON.parse(JSON.stringify(n.fields)) }); if (n.versions.length > 25) n.versions.shift(); } };
    if (!ro) {
      const sectionOf = el => el.closest('.ia-sec') && el.closest('.ia-sec').id.replace('ia-', '');
      const save = debounce(el => { n.fields[el.dataset.ia] = el.value; const cp = sectionOf(el); if (cp && (!n.status[cp] || n.status[cp] === 'not-started')) n.status[cp] = 'in-progress'; snapshot(); saved(); Hub.store.save(); }, 600);
      $$('[data-ia]').forEach(t => t.addEventListener('input', () => { save(t); if (t.dataset.ia === 'rq') $('#rq-check').innerHTML = rqCheckHtml(t.value); const wc = $(`[data-wc="${t.dataset.ia}"]`); if (wc) wc.textContent = t.value.split(/\s+/).filter(Boolean).length + ' words'; }));
      $$('[data-tc]').forEach(c => (c.onchange = () => { n.titleCheck[c.dataset.tc] = c.checked; saved(); Hub.store.save(); }));
      $$('[data-self]').forEach(r => (r.oninput = () => { n.self[r.dataset.self] = Number(r.value); r.nextElementSibling.textContent = r.value; Hub.store.save(); }));
      $$('[data-submit-cp]').forEach(b => (b.onclick = async () => { const cp = b.dataset.submitCp; if (!(await U.confirmBox('Submit this checkpoint to Miss Badmus? You can keep editing afterwards, and a copy of this version is kept.', 'Submit checkpoint'))) return; n.status[cp] = 'submitted'; snapshot('Submitted ' + cp.toUpperCase()); saved(); Hub.store.save(true); toast('Checkpoint submitted.'); Hub.app.render(); }));
      const sf = $('#src-form'); if (sf) sf.onsubmit = e => { e.preventDefault(); n.sources.push({ title: $('#src-t').value.trim(), url: $('#src-u').value.trim(), accessed: $('#src-d').value, notes: $('#src-n').value.trim() }); saved(); Hub.store.save(true); Hub.app.render(); };
      $$('[data-rmsrc]').forEach(b => (b.onclick = () => { n.sources.splice(Number(b.dataset.rmsrc), 1); Hub.store.save(true); Hub.app.render(); }));
      const lf = $('#log-form'); if (lf) lf.onsubmit = e => { e.preventDefault(); const t = $('#log-t').value.trim(); if (!t) return; n.log.push({ at: new Date().toISOString(), text: t }); saved(); Hub.store.save(true); Hub.app.render(); };
      $$('[data-restore]').forEach(b => (b.onclick = async () => { const v = n.versions[Number(b.dataset.restore)]; if (!(await U.confirmBox(`Restore the version from ${fmtDateTime(v.at)}? Your current text is kept as a version first.`, 'Restore'))) return; snapshot('Before restore'); n.fields = JSON.parse(JSON.stringify(v.fields)); saved(); Hub.store.save(true); Hub.app.render(); }));
    }
    if (teacher) $$('.fb-form').forEach(f => f.addEventListener('submit', e => { e.preventDefault(); const act = e.submitter ? e.submitter.value : 'return', cp = f.dataset.cp; n.feedback[cp] = { text: f.t.value.trim(), criteria: $$('input[name="c"]:checked', f).map(x => x.value), at: new Date().toISOString() }; n.status[cp] = act === 'sign' ? 'signed-off' : 'in-progress'; Hub.store.log(`IA feedback (${cp}) for ${s.name}`); Hub.store.save(true); toast(act === 'sign' ? 'Checkpoint signed off.' : 'Feedback saved and returned.'); Hub.app.render(); }));
  }
  function iaTeacher(main, params) {
    if (params.id) return iaStudent(main, params.id);
    const group = params.group || Hub.teacher.pref('group') || 'HL-A'; Hub.teacher.pref('group', group);
    const sch = C().iaSchedule(group), students = Hub.roster.inGroup(group), asOf = Hub.mastery.asOf();
    const waiting = students.filter(s => Object.values((S().ia[s.id] || {}).status || {}).includes('submitted'));
    main.innerHTML = U.heading('INQUIRE · EXPLORE · REFLECT', 'IA overview', 'Checkpoint progress for every student, with dates from the pacing calendar. Students write; you give criterion-referenced feedback and sign off.', Hub.teacher.groupPick('ia-group', group)) +
      `${waiting.length ? `<div class="notice">${waiting.length} student${waiting.length > 1 ? 's have' : ' has'} submitted a checkpoint for feedback.</div>` : ''}
      <section class="card scroll"><table class="tbl ia-tbl"><thead><tr><th class="sticky-col">Student</th>${sch.map(st => `<th title="${esc(st.title)}"><div>${esc(st.short)}</div><span class="tiny ${st.date && st.date < asOf ? 'muted' : ''}">${st.date ? fmtDate(st.date) : ''}</span></th>`).join('')}<th>Title / RQ</th></tr></thead>
      <tbody>${students.map(s => { const nn = S().ia[s.id] || {}; return `<tr><td class="sticky-col"><a href="#/ia/${s.id}">${esc(s.name)}</a></td>${sch.map(st => { const v = (nn.status || {})[st.id] || 'not-started', late = st.date && st.date < asOf && !['submitted', 'signed-off'].includes(v); return `<td><span class="ia-dot ${v} ${late ? 'late' : ''}" title="${v.replace('-', ' ')}${late ? ' · overdue' : ''}">${v === 'signed-off' ? '✓' : v === 'submitted' ? '●' : v === 'in-progress' ? '◐' : late ? '!' : '○'}</span></td>`; }).join('')}<td class="small">${esc(((nn.fields || {}).rq || (nn.fields || {}).title || (nn.fields || {}).working || '').slice(0, 70))}</td></tr>`; }).join('')}</tbody></table>
      <p class="tiny muted">○ not started · ◐ in progress · ● submitted (waiting for you) · ✓ signed off · ! overdue</p></section>`;
    $('#ia-group').onchange = e => go('#/ia?group=' + e.target.value);
  }

  /* ================= Course & pacing ================= */
  function course(main, params) {
    const teacher = Hub.auth.role() === 'teacher', me = Hub.roster.byId(Hub.auth.sid());
    const group = teacher ? params.group || Hub.teacher.pref('group') || 'HL-A' : me.group, g = C().GROUPS[group], asOf = Hub.mastery.asOf(), view = params.view || 'upcoming';
    let rows = C().lessons(group); if (view === 'upcoming') rows = rows.filter(l => l.date >= asOf).slice(0, 20); if (view === 'tests') rows = rows.filter(l => l.kind === 'test'); if (view === 'ia') rows = rows.filter(l => l.ia || l.kind === 'ia');
    const ox = C().OXFORD[g.course];
    main.innerHTML = U.heading('YOUR COURSE COMPASS', teacher ? 'Course & pacing' : 'My calendar', `${C().COURSES[g.course]} · ${g.label} · ${g.block}`, teacher ? Hub.teacher.groupPick('c-group', group) : '') +
      `<div class="tabs">${[['upcoming', 'Upcoming'], ['all', 'Whole year'], ['tests', 'Tests'], ['ia', 'IA']].map(([k, l]) => `<a class="tab ${k === view ? 'on' : ''}" href="#/course?group=${group}&view=${k}">${l}</a>`).join('')}</div>
      <section class="card cal">${rows.map(l => `<div class="cal-row ${l.kind} ${l.date < asOf ? 'past' : ''} ${l.date === asOf ? 'today' : ''}"><div class="cal-date"><b>${fmtDate(l.date)}</b><span class="tiny">${l.day} day</span></div><div class="cal-body"><p>${esc(l.activity)}</p>${l.skills.length ? `<div class="chips">${l.skills.map(s => U.skillChip(s)).join('')}${l.kind !== 'test' ? l.skills.map(s => { const o = ox[C().SKILL[s].ox]; return o ? `<span class="tiny muted">Oxford ${C().SKILL[s].ox}, p.${o[1]}</span>` : ''; }).filter((v, i, a) => v && a.indexOf(v) === i).join(' ') : ''}</div>` : ''}</div>${l.kind !== 'lesson' ? `<span class="pill ${l.kind === 'test' ? 'red' : l.kind === 'ia' ? 'amber' : 'grey'}">${l.kind === 'test' ? 'Test' : l.kind === 'ia' ? 'IA' : l.kind === 'none' ? 'No class' : 'Review'}</span>` : l.ia ? '<span class="pill amber">+ IA</span>' : ''}</div>`).join('') || U.empty('No rows.')}</section>
      <p class="tiny muted">Source: 2026–27 ${g.course === 'HL' ? 'Analysis HL1 Pacing Calendar' : 'SL Year 1 Pacing Calendar'} (first sheet), ${g.day} day rows. “Today” is ${fmtDate(asOf, true)}${S().settings.asOf ? ' (planning date set in Data & settings)' : ''}.</p>
      ${teacher ? `<section class="card"><h2 class="bar-head green">Course map & question bank</h2><p class="small">Units follow the Oxford ${g.course} chapter order (mapping only — no textbook questions are reproduced). Each skill has original question families with markschemes.</p>${C().UNITS[g.course].map(([u, name]) => { const sk = C().skillsFor(g.course).filter(s => s.unit === u); return `<details class="unit-d" ${u <= 2 ? 'open' : ''}><summary class="unit-h ${U.unitColour(u)}">Unit ${u} · ${esc(name)} <span class="tiny">${sk.length ? sk.length + ' skills' : 'Year 2 / later'}</span></summary>${sk.map(s => { const gens = s.gens.map(id => Hub.qcore.registry[id]).filter(Boolean); const o = s.ox && ox[s.ox]; return `<div class="skill-row"><span>${U.skillLabel(s.id)}</span><span class="tiny muted">${o ? `Oxford ${s.ox} ${esc(o[0])}, p.${o[1]}` : ''}</span><span class="tiny">${gens.map(x => `${esc(x.title)} · P${x.paper}${x.challenge ? ' · challenge' : ''}`).join('<br>')}</span><span class="tiny muted">${C().taughtDate(s.id, group) ? (C().isTaught(s.id, group, asOf) ? 'taught ' : 'from ') + fmtDate(C().taughtDate(s.id, group)) : ''}</span></div>`; }).join('')}</details>`; }).join('')}</section>` : ''}`;
    const cg = $('#c-group'); if (cg) cg.onchange = e => { Hub.teacher.pref('group', e.target.value); go('#/course?group=' + e.target.value + '&view=' + view); };
  }

  /* ================= Data & settings ================= */
  function settings(main) { main.textContent="Loading cloud settings…"; }
  Hub.shared = { iaStudent, iaTeacher, course, settings, rqCheck };
})(window.Hub = window.Hub || {});
