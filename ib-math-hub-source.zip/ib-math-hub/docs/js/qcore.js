/* Question-bank core: seeded randomness, exact fractions, TeX formatting, registry.
   Every generator is ORIGINAL (parameterised by Miss Badmus' Hub), mapped to a lesson-level skill.
   Each part carries: command term, marks, answer spec, IB-style markscheme (M/A/R/AG), worked
   working, hint, known-error values (misconception detection) and a SymPy `verify` expression
   that tests/verify_answers.py re-derives independently. */
(function (Hub) {
  'use strict';
  function rng(seed) {
    let a = (seed >>> 0) || 1;
    const next = () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    const R = {
      next,
      int: (lo, hi) => lo + Math.floor(next() * (hi - lo + 1)),
      pick: arr => arr[Math.floor(next() * arr.length)],
      nz: (lo, hi) => { let v; do v = lo + Math.floor(next() * (hi - lo + 1)); while (v === 0); return v; },
      bool: () => next() < 0.5,
      shuffle: arr => { const b = arr.slice(); for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(next() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; } return b; },
      distinct: (n, lo, hi, avoid = []) => { const out = []; let guard = 0; while (out.length < n && guard++ < 999) { const v = lo + Math.floor(next() * (hi - lo + 1)); if (!out.includes(v) && !avoid.includes(v)) out.push(v); } return out; }
    };
    return R;
  }
  const gcd = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a || 1; };
  class F {
    constructor(n, d = 1) { if (d === 0) throw Error('zero denominator'); if (d < 0) { n = -n; d = -d; } const g = gcd(n, d); this.n = n / g; this.d = d / g; }
    static of(x) { return x instanceof F ? x : new F(x, 1); }
    add(o) { o = F.of(o); return new F(this.n * o.d + o.n * this.d, this.d * o.d); }
    sub(o) { o = F.of(o); return new F(this.n * o.d - o.n * this.d, this.d * o.d); }
    mul(o) { o = F.of(o); return new F(this.n * o.n, this.d * o.d); }
    div(o) { o = F.of(o); return new F(this.n * o.d, this.d * o.n); }
    neg() { return new F(-this.n, this.d); }
    pow(k) { let r = new F(1); const b = k < 0 ? new F(this.d, this.n) : this; for (let i = 0; i < Math.abs(k); i++) r = r.mul(b); return r; }
    val() { return this.n / this.d; }
    isInt() { return this.d === 1; }
    tex() { return this.d === 1 ? String(this.n) : (this.n < 0 ? `-\\frac{${-this.n}}{${this.d}}` : `\\frac{${this.n}}{${this.d}}`); }
    py() { return this.d === 1 ? String(this.n) : `Rational(${this.n},${this.d})`; }
    eq(o) { o = F.of(o); return this.n === o.n && this.d === o.d; }
  }
  const fr = (n, d = 1) => new F(n, d);
  const T = x => x instanceof F ? x.tex() : num(x);
  function num(x) { if (Number.isInteger(x)) return String(x); const r = Number(x.toPrecision(12)); return String(r); }
  function round(x, dp) { const m = Math.pow(10, dp); return Math.round((x + Number.EPSILON * Math.sign(x)) * m) / m; }
  function sf(x, s = 3) { if (x === 0) return 0; return Number(x.toPrecision(s)); }
  /** "+ 3" / "- 3" for joining terms; coefficient formatting for polynomials. */
  function poly(terms, first = true) { // terms: [[coef, '<tex var>'], ...]
    let out = '';
    for (const [c0, v] of terms) {
      const c = F.of(c0); if (c.n === 0) continue;
      const neg = c.n < 0, a = neg ? c.neg() : c;
      let body = v ? ((a.n === 1 && a.d === 1) ? v : (a.d === 1 ? `${a.n}${v}` : `${a.tex()}${v}`)) : a.tex();
      if (!out) out = (neg ? '-' : '') + body; else out += (neg ? ' - ' : ' + ') + body;
    }
    return out || '0';
  }
  const lin = (a, b, v = 'x') => poly([[a, v], [b, '']]);
  const sgn = c => (F.of(c).n < 0 ? ` - ${F.of(c).neg().tex()}` : ` + ${F.of(c).tex()}`);
  const paren = x => (F.of(x).n < 0 ? `(${T(x)})` : T(x));
  function comb(n, r) { if (r < 0 || r > n) return 0; let c = 1; for (let i = 1; i <= r; i++) c = c * (n - r + i) / i; return Math.round(c); }
  function factorial(n) { let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; }
  /** Build a multiple-choice answer: options [{tex, key}], correct key; shuffled with seeded rng. */
  function mc(R, options, correctKey) { const sh = R.shuffle(options); return { kind: 'mc', choices: sh.map(o => o.tex), keys: sh.map(o => o.key), correct: sh.findIndex(o => o.key === correctKey) }; }
  const pyF = x => x instanceof F ? x.py() : String(x);

  const registry = {};
  /** meta: {skill, title, paper:1|2, challenge?:bool} ; gen(R, opts) → {stem, parts, calc?, numworks?} */
  function reg(id, meta, gen) { registry[id] = Object.assign({ id, gen }, meta); }

  let counter = 0;
  function build(genId, seed, opts = {}) {
    const g = registry[genId]; if (!g) throw Error('Unknown generator ' + genId);
    const R = rng(seed * 7919 + genId.length * 104729 + (opts.challenge ? 31 : 0));
    const q = g.gen(R, opts);
    const course = g.skill.slice(0, 2);
    q.parts.forEach((p, i) => {
      p.label = p.label || String.fromCharCode(97 + i); p.id = p.label; p.ms = p.ms || []; p.working = p.working || [];
      // keep only misconception values that are finite and differ from the correct answer
      const same = (u, v) => Math.abs(u - v) <= 1e-9 * Math.max(1, Math.abs(v));
      p.errors = (p.errors || []).filter(e => {
        if (e.choice !== undefined) return true;
        const ev = Array.isArray(e.value) ? e.value : [e.value];
        if (!ev.every(Number.isFinite)) return false;
        if (p.answer.kind === 'num') return !same(ev[0], p.answer.value);
        if (p.answer.kind === 'tuple') return !(ev.length === p.answer.value.length && ev.every((v, j) => same(v, p.answer.value[j])));
        if (p.answer.kind === 'list') { const a = ev.slice().sort((u, v) => u - v), b = p.answer.value.slice().sort((u, v) => u - v); return !(a.length === b.length && a.every((v, j) => same(v, b[j]))); }
        return true;
      });
    });
    return Object.assign({
      id: 'q' + Date.now().toString(36) + (counter++).toString(36) + Math.floor(Math.random() * 1e4).toString(36),
      gen: genId, seed, skill: g.skill, course, title: g.title, paper: q.paper || g.paper, calc: (q.paper || g.paper) === 2,
      challenge: !!opts.challenge, marks: q.parts.reduce((s, p) => s + p.marks, 0)
    }, q);
  }

  Hub.qcore = { rng, F, fr, T, num, round, sf, poly, lin, sgn, paren, comb, factorial, mc, pyF, gcd, reg, registry, build };
})(window.Hub = window.Hub || {});
