/* Core helpers: DOM, formatting, dates, ids, toasts, save status. */
(function (Hub) {
  'use strict';
  const $ = (s, el = document) => el.querySelector(s), $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const uid = (p = 'id') => p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
  const todayISO = () => new Intl.DateTimeFormat('en-CA',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
  const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const parseISO = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  /** "Wed 4 Nov" — British order. */
  const fmtDate = (s, long) => { if (!s) return '—'; const d = parseISO(s.slice(0, 10)); return `${(long ? DAYS : DAYS.map(x => x.slice(0, 3)))[d.getDay()]} ${d.getDate()} ${MONTHS[d.getMonth()]}`; };
  const fmtDateTime = iso => { if (!iso) return '—'; const d = new Date(iso); return `${d.getDate()} ${MONTHS[d.getMonth()]}, ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
  const daysBetween = (a, b) => Math.round((parseISO(b) - parseISO(a)) / 86400000);
  const addDays = (s, n) => { const d = parseISO(s); d.setDate(d.getDate() + n); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };
  const pct = (e, m) => (m > 0 ? Math.round(100 * e / m) : null);
  const initials = name => name.split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase();
  function hashStr(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }

  let toastTimer;
  function toast(msg, kind = 'info') {
    const t = $('#toast'); if (!t) return;
    t.textContent = msg; t.className = 'toast show ' + kind; clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (t.className = 'toast'), 4200);
  }
  function saveStatus(text, kind = 'ok') { const el = $('#save-status'); if (el) { el.textContent = text; el.dataset.kind = kind; } }
  const HOST = (window.HUB_CONFIG && window.HUB_CONFIG.host) || 'web';
  Hub.LOGO = (window.HUB_CONFIG && window.HUB_CONFIG.logo) || 'assets/wolf.png';
  Hub.HOST = HOST;
  function download(name, content, type = 'application/json') {
    if (HOST === 'artifact' && typeof content === 'string' && Hub.ui) { // file downloads are blocked inside the claude.ai preview frame
      const m = Hub.ui.modal(`<h2 class="modal-title">${esc(name)}</h2><p class="small">Downloads are blocked in this preview. Copy the text below into a file (or open the hosted Hub to download).</p><textarea id="dl-text" rows="12" readonly>${esc(content)}</textarea><div class="actions"><button class="btn primary" id="dl-copy">Copy</button></div>`, { wide: true });
      m.el.querySelector('#dl-copy').onclick = async () => { try { await navigator.clipboard.writeText(content); toast('Copied.'); } catch (e) { const t = m.el.querySelector('#dl-text'); t.focus(); t.select(); toast('Select all and copy.'); } };
      return;
    }
    const blob = content instanceof Blob ? content : new Blob([content], { type }); const u = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 1500);
  }
  const csvCell = v => { const raw = String(v ?? ''); const s = /^[\s]*[=+@-]/.test(raw) ? "'" + raw : raw; return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  const toCSV = rows => rows.map(r => r.map(csvCell).join(',')).join('\n');
  const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

  Hub.core = { $, $$, esc, uid, todayISO, fmtDate, fmtDateTime, daysBetween, addDays, pct, initials, hashStr, toast, saveStatus, download, toCSV, debounce, parseISO };
})(window.Hub = window.Hub || {});
