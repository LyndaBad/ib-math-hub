/* CSV import merges by verified-email identity; existing work is preserved. */
(function(Hub){
 'use strict';const S=()=>Hub.store.state;
 const all=()=>S().roster.students.filter(s=>s.active!==false),byId=id=>S().roster.students.find(s=>s.id===id),byEmail=e=>all().find(s=>s.email.toLowerCase()===String(e).toLowerCase()),inGroup=g=>all().filter(s=>s.group===g),inCourse=c=>all().filter(s=>s.course===c);
 function parseImport(text){
 const records=[],errors=[];let row=[],cell='',quoted=false;const sep=text.split(/\r?\n/)[0].includes('\t')?'\t':',';
 text=String(text).replace(/^\uFEFF/,'');
 for(let i=0;i<=text.length;i++){const c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++;}else quoted=!quoted;}
 else if((c===sep||c==='\n'||c===undefined)&&!quoted){row.push(cell.trim());cell='';if(c!==sep){if(row.some(Boolean))records.push(row);row=[];}}else if(c!=='\r')cell+=c||'';}
 if(quoted)errors.push('Unclosed quotation mark.');
 let names=['name','email','group'];if(records[0]?.some(x=>/^email$/i.test(x))){names=records.shift().map(x=>x.toLowerCase().trim());}
 const rows=[],seen=new Set();records.forEach((r,i)=>{const name=r[names.indexOf('name')],email=r[names.indexOf('email')]?.toLowerCase(),group=r[names.indexOf('group')]?.toUpperCase().replace(/\s+/g,'-');
 if(!name||!/^\S+@\S+\.\S+$/.test(email||'')||!['HL-A','HL-B','SL-A','SL-B'].includes(group)){errors.push('Row '+(i+2)+': expected name, valid email, and SL-A / SL-B / HL-A / HL-B.');return;}
 if(seen.has(email)){errors.push('Duplicate email: '+email);return;}seen.add(email);rows.push({name,email,group,course:group.slice(0,2)});
 });return {rows,errors};
 }
 function applyImport(rows){const st=S();for(const r of rows){const existing=st.roster.students.find(s=>s.email.toLowerCase()===r.email);if(existing)Object.assign(existing,r,{active:true});else st.roster.students.push({...r,id:crypto.randomUUID(),active:true});}st.roster.source='imported';Hub.store.log('Merged '+rows.length+' roster rows; existing work preserved');Hub.store.save(true);}
 Hub.roster={all,byId,byEmail,inGroup,inCourse,parseImport,applyImport};
})(window.Hub=window.Hub||{});
