/* AA SL — original parameterised questions (Units 1–7, Year 1). Mapped to Oxford SL 2019 section numbers
   for curriculum alignment only; no textbook questions are reproduced. */
(function (Hub) {
  'use strict';
  const { F, fr, T, num, round, sf, poly, lin, sgn, paren, comb, mc, pyF, reg } = Hub.qcore;

  /* ---------- Number systems & rounding (SL prior learning / Unit 1 start) ---------- */
  reg('sl.round', { skill: 'SL-0.1', title: 'Significant figures, standard form and percentage error', paper: 2 }, R => {
    let N, s4;
    do { const m = R.int(1000000, 9999999); const e = R.pick([-6, -5, -4, 1, 2, 3]); N = Number((m * Math.pow(10, e - 6)).toPrecision(7)); s4 = Number(String(m)[3]); } while (s4 === 5);
    const N3 = sf(N, 3), e = Math.floor(Math.log10(Math.abs(N))), a = Number((N3 / Math.pow(10, e)).toPrecision(3));
    const trunc = Number((Math.trunc(N / Math.pow(10, e - 2)) * Math.pow(10, e - 2)).toPrecision(3));
    const E = sf(N, 1), pct = Math.abs(E - N) / Math.abs(N) * 100, wrongPct = Math.abs(E - N) / Math.abs(E) * 100;
    return {
      stem: `A measurement is recorded as $N = ${num(N)}$.`,
      parts: [
        { command: 'Write down', prompt: `$N$ correct to three significant figures.`, marks: 1, answer: { kind: 'num', value: N3, exact: true, display: num(N3) },
          inexactFb: 'Give exactly three significant figures.', ms: [['A1', `$${num(N3)}$`]], working: [`The first three significant figures are followed by a digit ${s4 < 5 ? 'less than 5, so round down' : 'of 5 or more, so round up'}: $${num(N3)}$`],
          hint: 'Count significant figures from the first non-zero digit.', errors: [{ value: trunc, tag: 'truncated', fb: 'You truncated (cut off) the digits instead of rounding.' }], verify: `sf(${N},3)` },
        { command: 'Write down', dep: true, prompt: `your answer to part (a) in the form $a\\times 10^{k}$, where $1\\le a<10$ and $k\\in\\mathbb{Z}$.`, marks: 2, answer: { kind: 'tuple', labels: ['a', 'k'], value: [a, e], markEach: true, exact: true, display: `${num(a)}\\times 10^{${e}}` },
          ms: [['A1', `$a=${num(a)}$`], ['A1', `$k=${e}$`]], working: [`$${num(N3)} = ${num(a)}\\times 10^{${e}}$`], hint: 'Move the decimal point until exactly one non-zero digit is in front of it; count the moves.',
          errors: [{ value: [a, -e], tag: 'standard-form-sign', fb: 'Check the sign of the power: small numbers have a negative power of 10, large numbers a positive one.' }], verify: `(sf(${N},3)/10**${e}, ${e})` },
        { command: 'Calculate', prompt: `A student estimates $N$ as $${num(E)}$. Calculate the percentage error in this estimate.`, marks: 2, answer: { kind: 'num', value: pct, sf: 3, display: `${num(sf(pct, 3))}\\%` },
          ms: [['M1', `$\\left|\\frac{${num(E)} - ${num(N)}}{${num(N)}}\\right|\\times 100\\%$`], ['A1', `$${num(sf(pct, 3))}\\%$`]],
          working: [`$\\varepsilon = \\left|\\frac{v_A - v_E}{v_E}\\right|\\times 100\\%$ where $v_E$ is the exact value`, `$= \\left|\\frac{${num(E)} - ${num(N)}}{${num(N)}}\\right|\\times 100\\% = ${num(sf(pct, 3))}\\%$`],
          hint: 'Divide by the exact value, not the estimate (formula booklet SL 1.6).', errors: [{ value: wrongPct, tag: 'pct-wrong-denominator', fb: 'You divided by the estimate. Percentage error divides by the exact value.' }], verify: `abs(${E}-${N})/abs(${N})*100` }
      ]
    };
  });

  /* ---------- 1.1 Sigma notation ---------- */
  reg('sl.sigma', { skill: 'SL-1.1', title: 'Sigma notation for arithmetic series', paper: 1, challenge: true }, (R, o) => {
    const a = R.int(2, 6), b = R.nz(-5, 7), n = o.challenge ? R.int(25, 40) : R.int(8, 20);
    const S = a * n * (n + 1) / 2 + b * n, m = R.int(3, 9), q = R.int(20, 45);
    return {
      stem: `Consider the series $\\sum_{r=1}^{${n}} (${lin(a, b, 'r')})$.`,
      parts: [
        { command: 'Write down', prompt: 'the first three terms of the series.', marks: 1, answer: { kind: 'tuple', labels: ['u_1', 'u_2', 'u_3'], value: [a + b, 2 * a + b, 3 * a + b], display: `${a + b},\\ ${2 * a + b},\\ ${3 * a + b}` },
          ms: [['A1', `$${a + b},\\ ${2 * a + b},\\ ${3 * a + b}$`]], working: [`Substitute $r = 1, 2, 3$ into $${lin(a, b, 'r')}$.`], hint: 'Replace r with 1, then 2, then 3.', verify: `(${a}*1+${b}, ${a}*2+${b}, ${a}*3+${b})` },
        { command: 'Find', prompt: 'the value of the series.', marks: 3, answer: { kind: 'num', value: S, exact: true, display: String(S) },
          ms: [['M1', `recognising an arithmetic series with $u_1 = ${a + b}$, $d = ${a}$`], ['M1', `$S_{${n}} = \\frac{${n}}{2}\\left(2(${a + b}) + ${n - 1}(${a})\\right)$`], ['A1', `$${S}$`]],
          working: [`$u_1 = ${a + b}$, $d = ${a}$, $n = ${n}$`, `$S_{${n}} = \\frac{${n}}{2}\\left(2u_1 + (n-1)d\\right) = \\frac{${n}}{2}\\left(${2 * (a + b)} + ${(n - 1) * a}\\right) = ${S}$`],
          hint: 'Is the series arithmetic? Find u₁ and d, then use the formula for Sₙ in the booklet.',
          errors: [{ value: a * n * (n + 1) / 2 + b, tag: 'constant-once', fb: `The constant ${b} is added in every one of the ${n} terms, not just once.` },
            { value: a * (n - 1) * n / 2 + b * (n - 1), tag: 'off-by-one-terms', fb: `There are ${n} terms from r = 1 to r = ${n}.` }],
          verify: `summation(${a}*r+(${b}),(r,1,${n}))` },
        { command: 'Write down', prompt: `the number of terms in $\\sum_{r=${m}}^{${q}} (${lin(a, b, 'r')})$.`, marks: 1, answer: { kind: 'num', value: q - m + 1, int: true, display: String(q - m + 1) },
          ms: [['A1', `$${q} - ${m} + 1 = ${q - m + 1}$`]], working: [`Number of terms $= ${q} - ${m} + 1 = ${q - m + 1}$`], hint: 'Try a small case: how many terms from r = 3 to r = 5?',
          errors: [{ value: q - m, tag: 'count-terms', fb: 'Count both ends: from r = m to r = q there are q − m + 1 terms.' }], verify: `len(range(${m},${q}+1))` }
      ]
    };
  });

  /* ---------- 1.2 Arithmetic sequences ---------- */
  reg('sl.arith', { skill: 'SL-1.2a', title: 'Arithmetic sequences: finding d, u₁ and n', paper: 1, challenge: true }, (R, o) => {
    const u1 = R.int(-10, 20), d = o.challenge ? R.pick([-7, -4, -3, 3, 5, 7]) + R.pick([0.5, -0.5]) : R.nz(-5, 7);
    const [p, q] = (() => { const p = R.int(2, 6), q = p + R.int(3, 7); return [p, q]; })();
    const up = u1 + (p - 1) * d, uq = u1 + (q - 1) * d, k = R.int(20, 60), T = u1 + (k - 1) * d;
    return {
      stem: `In an arithmetic sequence, $u_{${p}} = ${num(up)}$ and $u_{${q}} = ${num(uq)}$.`,
      parts: [
        { command: 'Find', prompt: 'the common difference, $d$.', marks: 2, answer: { kind: 'num', value: d, exact: true, display: num(d) },
          ms: [['M1', `$${q - p}d = ${num(uq)} - ${paren(up)}$`], ['A1', `$d = ${num(d)}$`]], working: [`$u_{${q}} - u_{${p}} = (${q} - ${p})d$`, `$${q - p}d = ${num(uq - up)} \\Rightarrow d = ${num(d)}$`],
          hint: `How many steps of d are there from term ${p} to term ${q}?`, errors: [{ value: (up - uq) / (q - p), tag: 'difference-sign', fb: 'Subtract the earlier term from the later term.' }, { value: (uq - up) / (q - p + 1), tag: 'steps-count', fb: `From u${p} to u${q} there are ${q - p} steps, not ${q - p + 1}.` }],
          verify: `(${uq}-(${up}))/(${q}-${p})` },
        { command: 'Find', prompt: '$u_1$.', marks: 1, answer: { kind: 'num', value: u1, exact: true, display: num(u1) },
          ms: [['A1', `$u_1 = ${num(u1)}$ (FT their $d$)`]], working: [`$u_1 = u_{${p}} - ${p - 1}d = ${num(up)} - ${p - 1}(${num(d)}) = ${num(u1)}$`], hint: `Go back ${p - 1} steps from u${p}.`,
          errors: [{ value: up - p * d, tag: 'n-minus-1', fb: `u${p} is ${p - 1} steps after u₁, not ${p}.` }], verify: `${up}-(${p}-1)*(${d})` },
        { command: 'Find', prompt: `the value of $n$ for which $u_n = ${num(T)}$.`, marks: 2, answer: { kind: 'num', value: k, int: true, display: String(k) },
          ms: [['M1', `$${num(u1)} + (n-1)(${num(d)}) = ${num(T)}$`], ['A1', `$n = ${k}$`]], working: [`$u_n = u_1 + (n-1)d$`, `$${num(T)} = ${num(u1)} + (n-1)(${num(d)})$`, `$n - 1 = ${k - 1} \\Rightarrow n = ${k}$`],
          hint: 'Use uₙ = u₁ + (n − 1)d and solve for n.', errors: [{ value: k - 1, tag: 'n-minus-1', fb: 'You found n − 1. Add 1 to get n.' }], verify: `solve(Eq(${u1}+(n-1)*(${d}),${T}),n)[0]` }
      ]
    };
  });

  /* ---------- 1.2 Geometric sequences ---------- */
  reg('sl.geo', { skill: 'SL-1.2b', title: 'Geometric sequences: r, u₁ and the first term to exceed a value', paper: 1, challenge: true }, (R, o) => {
    let a, rr, rTex, rv;
    if (o.challenge || R.bool()) { const c = R.pick([[3, 2], [5, 4], [4, 3]]); rr = fr(c[0], c[1]); const k = R.int(1, 3); a = k * Math.pow(c[1], 4); }
    else { rr = fr(R.pick([2, 3])); a = R.int(2, 9); }
    rv = rr.val(); rTex = rr.tex();
    const u2 = fr(a).mul(rr), u5 = fr(a).mul(rr.pow(4));
    const L = R.pick([1000, 5000, 10000, 50000]) * (rv > 2 ? 10 : 1);
    let n = 1; while (a * Math.pow(rv, n - 1) <= L) n++;
    const xInt = 1 + Math.log(L / a) / Math.log(rv);
    return {
      stem: `The second term of a geometric sequence is $${u2.tex()}$ and the fifth term is $${u5.tex()}$.`,
      parts: [
        { command: 'Find', prompt: 'the common ratio, $r$.', marks: 2, answer: { kind: 'num', value: rv, exact: true, display: rTex },
          ms: [['M1', `$r^{3} = \\frac{${u5.tex()}}{${u2.tex()}}$`], ['A1', `$r = ${rTex}$`]], working: [`$u_5 = u_2 r^{3}$`, `$r^{3} = \\frac{${u5.tex()}}{${u2.tex()}} = ${rr.pow(3).tex()}$`, `$r = ${rTex}$`],
          hint: 'How many multiplications by r take you from the 2nd term to the 5th term?', errors: [{ value: Math.pow(rv, 4 / 3), tag: 'power-count', fb: 'From u₂ to u₅ is three multiplications by r, so r³ = u₅ ÷ u₂.' }], verify: `real_root(${u5.py()}/(${u2.py()}),3)` },
        { command: 'Find', prompt: '$u_1$.', marks: 1, answer: { kind: 'num', value: a, exact: true, display: String(a) },
          ms: [['A1', `$u_1 = \\frac{${u2.tex()}}{${rTex}} = ${a}$`]], working: [`$u_1 = \\frac{u_2}{r} = ${a}$`], hint: 'Divide the second term by r.', errors: [{ value: u2.mul(rr).val(), tag: 'multiplied-not-divided', fb: 'To go backwards one term, divide by r.' }], verify: `${u2.py()}/(${rr.py()})` },
        { command: 'Find', prompt: `the smallest value of $n$ for which $u_n > ${L}$.`, marks: 3, paper: 2, answer: { kind: 'num', value: n, int: true, display: String(n) },
          ms: [['M1', `$${a}\\left(${rTex}\\right)^{n-1} > ${L}$`], ['(A1)', `$n > ${num(sf(xInt, 4))}$`], ['A1', `$n = ${n}$`]],
          working: [`$${a}\\left(${rTex}\\right)^{n-1} > ${L}$`, `NumWorks: graph $y = ${a}\\times(${num(rv)})^{x-1}$ and $y = ${L}$; intersection at $x \\approx ${num(sf(xInt, 4))}$`, `$n$ is a whole number, so $n = ${n}$`],
          hint: 'Set up an inequality, then use the NumWorks (Grapher or Sequences table). n must be a whole number.', numworks: { app: 'Grapher', lines: [[`y=${a}×${num(rv)}^(x-1)`, ''], [`y=${L}`, ''], ['Intersection', `x=${num(sf(xInt, 4))}`]] },
          errors: [{ value: n - 1, tag: 'round-down', fb: `u${n - 1} is not yet bigger than ${L}. Check both neighbouring terms.` }], verify: `next(m for m in range(1,500) if ${a}*(${rr.py()})**(m-1) > ${L})` }
      ]
    };
  });

  /* ---------- 1.3 Arithmetic series ---------- */
  reg('sl.arseries', { skill: 'SL-1.3a', title: 'Arithmetic series: Sₙ and finding n', paper: 1, challenge: true }, (R, o) => {
    const a = R.int(3, 15), d = R.int(2, 7), m = R.int(15, 30);
    const S = m * (2 * a + (m - 1) * d) / 2, n0 = R.int(20, 40), Sn = k => k * (2 * a + (k - 1) * d) / 2;
    const variant = o.challenge ? 'exceed' : R.pick(['exact', 'exceed']);
    const X = variant === 'exact' ? Sn(n0) : Sn(n0 - 1) + R.int(1, Sn(n0) - Sn(n0 - 1) - 1);
    const termN = (X - a) / d + 1;
    const partB = variant === 'exact'
      ? { command: 'Find', prompt: `The sum of the first $n$ terms is $${X}$. Find $n$.`, marks: 3, paper: 2, answer: { kind: 'num', value: n0, int: true, display: String(n0) },
          ms: [['M1', `$\\frac{n}{2}\\left(2(${a}) + (n-1)(${d})\\right) = ${X}$`], ['(M1)', 'attempt to solve their quadratic (NumWorks)'], ['A1', `$n = ${n0}$`]],
          working: [`$\\frac{n}{2}(${2 * a} + ${d}(n-1)) = ${X}$`, `$${d}n^{2} + ${2 * a - d}n - ${2 * X} = 0$`, `NumWorks Equations: $n = ${n0}$ (reject the negative root)`],
          hint: 'Use Sₙ, not uₙ. You will get a quadratic in n: solve it on the NumWorks.', errors: [{ value: termN, tag: 'term-not-sum', fb: 'You set the n-th TERM equal to the total. The total of the first n terms is Sₙ.' }],
          verify: `[s for s in solve(Eq(n/2*(2*${a}+(n-1)*${d}),${X}),n) if s>0][0]` }
      : { command: 'Find', prompt: `the least number of terms for which the sum of the series is greater than $${X}$.`, marks: 3, paper: 2, answer: { kind: 'num', value: n0, int: true, display: String(n0) },
          ms: [['M1', `$\\frac{n}{2}\\left(2(${a}) + (n-1)(${d})\\right) > ${X}$`], ['(A1)', `$S_{${n0 - 1}} = ${Sn(n0 - 1)}$, $S_{${n0}} = ${Sn(n0)}$`], ['A1', `$n = ${n0}$`]],
          working: [`$S_n = \\frac{n}{2}(${2 * a} + ${d}(n-1)) > ${X}$`, `Check both neighbours: $S_{${n0 - 1}} = ${Sn(n0 - 1)}$ (too small), $S_{${n0}} = ${Sn(n0)}$ ✓`, `$n = ${n0}$`],
          hint: 'Use Sₙ and check BOTH the term count just below and just above your NumWorks solution.', errors: [{ value: n0 - 1, tag: 'not-checking-both', fb: `S${n0 - 1} is ${Sn(n0 - 1)}, which is not greater than ${X}. Always check both neighbouring values.` }, { value: Math.ceil(termN), tag: 'term-not-sum', fb: 'You used the n-th term instead of the sum Sₙ.' }],
          verify: `next(k for k in range(1,500) if Rational(k,2)*(2*${a}+(k-1)*${d}) > ${X})` };
    return {
      stem: `An arithmetic series has first term $${a}$ and common difference $${d}$.`,
      parts: [
        { command: 'Find', prompt: `the sum of the first $${m}$ terms.`, marks: 2, answer: { kind: 'num', value: S, exact: true, display: String(S) },
          ms: [['M1', `$\\frac{${m}}{2}\\left(2(${a}) + ${m - 1}(${d})\\right)$`], ['A1', `$${S}$`]], working: [`$S_{${m}} = \\frac{${m}}{2}\\left(2(${a}) + (${m}-1)(${d})\\right) = ${S}$`],
          hint: 'Formula booklet: $S_n = \\frac{n}{2}(2u_1 + (n - 1)d)$.', errors: [{ value: a + (m - 1) * d, tag: 'term-not-sum', fb: `That is u${m}, the ${m}th term, not the sum.` }, { value: m * (2 * a + m * d) / 2, tag: 'n-not-n-1', fb: 'The formula uses (n − 1)d.' }],
          verify: `summation(${a}+(r-1)*${d},(r,1,${m}))` },
        partB
      ]
    };
  });

  /* ---------- 1.3 Geometric series and sum to infinity ---------- */
  reg('sl.geoseries', { skill: 'SL-1.3b', title: 'Geometric series and the sum to infinity', paper: 1 }, R => {
    const rr = R.pick([fr(1, 2), fr(-1, 2), fr(1, 3), fr(-1, 3), fr(2, 3), fr(3, 4), fr(-2, 3)]);
    const a = R.int(2, 9) * rr.d * rr.d, n = 4;
    const Sinf = fr(a).div(fr(1).sub(rr)), S4 = fr(a).mul(fr(1).sub(rr.pow(n))).div(fr(1).sub(rr));
    const u2 = fr(a).mul(rr), u3 = u2.mul(rr);
    const mcA = mc(R, [{ tex: '$|r| < 1$', key: 'abs' }, { tex: '$r < 1$', key: 'lt1' }, { tex: '$u_1 < 1$', key: 'u1' }, { tex: '$r > 0$', key: 'pos' }], 'abs');
    return {
      stem: `Consider the geometric series $${a} ${sgn(u2)} ${sgn(u3)} + \\cdots$`,
      parts: [
        { command: 'Write down', prompt: 'the common ratio.', marks: 1, answer: { kind: 'num', value: rr.val(), exact: true, display: rr.tex() }, ms: [['A1', `$r = ${rr.tex()}$`]], working: [`$r = \\frac{${u2.tex()}}{${a}} = ${rr.tex()}$`], hint: 'Divide the second term by the first.', verify: `${u2.py()}/${a}` },
        { command: 'Find', prompt: 'the sum of the first four terms. Give your answer as an exact value.', marks: 2, answer: { kind: 'num', value: S4.val(), exact: true, display: S4.tex() },
          ms: [['M1', `$\\frac{${a}\\left(1-\\left(${rr.tex()}\\right)^{4}\\right)}{1-\\left(${rr.tex()}\\right)}$`], ['A1', `$${S4.tex()}$`]], working: [`$S_4 = \\frac{u_1(1-r^{4})}{1-r} = ${S4.tex()}$`],
          hint: 'Use $S_n = \\frac{u_1(1 - r^{n})}{1 - r}$, or add the four terms.', errors: [{ value: fr(a).mul(fr(1).sub(rr.pow(3))).div(fr(1).sub(rr)).val(), tag: 'n-minus-1', fb: 'Use rⁿ with n = 4 in the sum formula.' }], verify: `summation(${a}*(${rr.py()})**(r-1),(r,1,4))` },
        { command: 'State', prompt: 'the condition that guarantees this series has a sum to infinity.', marks: 1, answer: Object.assign(mcA, { display: '|r| < 1' }), ms: [['R1', '$|r| < 1$']], working: ['A geometric series converges exactly when $|r| < 1$, i.e. $-1 < r < 1$.'], hint: 'Negative ratios can still converge.', verify: `'abs' if abs(${rr.py()})<1 else 'none'` },
        { command: 'Find', prompt: 'the exact value of the sum to infinity.', marks: 2, answer: { kind: 'num', value: Sinf.val(), exact: true, display: Sinf.tex() },
          ms: [['M1', `$\\frac{${a}}{1-\\left(${rr.tex()}\\right)}$`], ['A1', `$${Sinf.tex()}$`]], working: [`$S_\\infty = \\frac{u_1}{1-r} = \\frac{${a}}{1-\\left(${rr.tex()}\\right)} = ${Sinf.tex()}$`],
          hint: '$S_\\infty = \\frac{u_1}{1 - r}$. Take care with a negative $r$.', errors: [{ value: fr(a).div(fr(1).add(rr)).val(), tag: 'sinf-sign', fb: 'The denominator is 1 − r. With a negative r, 1 − r is bigger than 1.' }], verify: `${a}/(1-(${rr.py()}))` }
      ]
    };
  });

  /* ---------- 1.4 Applications: compound interest / depreciation ---------- */
  reg('sl.finance', { skill: 'SL-1.4', title: 'Compound interest and depreciation (NumWorks)', paper: 2 }, R => {
    if (R.bool()) {
      const P = R.pick([1500, 2000, 2500, 3000, 4000, 5000]), i = R.pick([2.5, 3, 3.5, 4, 4.5, 5.2]), k = R.pick([12, 4]), t = R.int(4, 10);
      const FV = P * Math.pow(1 + i / (100 * k), k * t), per = k === 12 ? 'monthly' : 'quarterly';
      let y = 1; while (P * Math.pow(1 + i / (100 * k), k * y) <= 1.5 * P) y++;
      return {
        stem: `Ama invests $\\$${P}$ in an account that pays a nominal annual interest rate of $${i}\\%$, compounded ${per}.`,
        parts: [
          { command: 'Find', prompt: `the value of the investment after $${t}$ years, correct to two decimal places.`, marks: 3, answer: { kind: 'num', value: round(FV, 2), dp: 2, display: `\\$${round(FV, 2).toFixed(2)}` },
            ms: [['M1', `$${P}\\left(1+\\frac{${i}}{100(${k})}\\right)^{${k}(${t})}$`], ['A1', `$k = ${k}$, $n = ${k * t}$ seen`], ['A1', `$\\$${round(FV, 2).toFixed(2)}$`]],
            working: [`$FV = PV\\left(1+\\frac{r}{100k}\\right)^{kn}$`, `$= ${P}\\left(1+\\frac{${i}}{${100 * k}}\\right)^{${k * t}} = ${round(FV, 2).toFixed(2)}$`],
            hint: `${per[0].toUpperCase() + per.slice(1)} means k = ${k} compounding periods per year.`, numworks: { app: 'Calculation', lines: [[`${P}×(1+${i}/(100×${k}))^(${k}×${t})`, round(FV, 2).toFixed(2)]] },
            errors: [{ value: round(P * Math.pow(1 + i / 100, t), 2), tag: 'annual-not-compounded', fb: `Interest is added ${per}: divide the rate by ${k} and use ${k * t} periods.` }, { value: round(P * (1 + i * t / 100), 2), tag: 'simple-interest', fb: 'That is simple interest. Compound interest grows by a percentage of the new amount each period.' }],
            verify: `${P}*(1+Rational(${Math.round(i * 10)},${1000 * k}))**(${k * t})` },
          { command: 'Find', prompt: `the number of complete years until the investment is first worth more than $\\$${1.5 * P}$.`, marks: 3, answer: { kind: 'num', value: y, int: true, display: String(y) },
            ms: [['M1', `$${P}\\left(1+\\frac{${i}}{${100 * k}}\\right)^{${k}n} > ${1.5 * P}$`], ['(A1)', `$n > ${num(sf(Math.log(1.5) / (k * Math.log(1 + i / (100 * k))), 4))}$`], ['A1', `$${y}$ years`]],
            working: [`$${P}\\left(1+\\frac{${i}}{${100 * k}}\\right)^{${k}n} > ${1.5 * P}$`, `NumWorks: $n \\approx ${num(sf(Math.log(1.5) / (k * Math.log(1 + i / (100 * k))), 4))}$`, `Complete years: $${y}$`],
            hint: 'Graph both sides on the NumWorks, or use a table of values for whole years.', errors: [{ value: y - 1, tag: 'round-down', fb: `After ${y - 1} years it has not yet passed ${1.5 * P}. Round UP to a complete year.` }],
            verify: `next(m for m in range(1,200) if ${P}*(1+Rational(${Math.round(i * 10)},${1000 * k}))**(${k}*m) > ${1.5 * P})` }
        ]
      };
    }
    const V0 = R.pick([18000, 22000, 26000, 32000]), p = R.pick([12, 15, 18, 20]), t = R.int(3, 6);
    const V = V0 * Math.pow(1 - p / 100, t); let y = 1; while (V0 * Math.pow(1 - p / 100, y) >= V0 / 2) y++;
    return {
      stem: `A car is bought for $\\$${V0}$. Its value depreciates by $${p}\\%$ each year.`,
      parts: [
        { command: 'Find', prompt: `the value of the car after $${t}$ years, correct to the nearest dollar.`, marks: 2, answer: { kind: 'num', value: Math.round(V), dp: 0, display: `\\$${Math.round(V)}` },
          ms: [['M1', `$${V0}(${1 - p / 100})^{${t}}$`], ['A1', `$\\$${Math.round(V)}$`]], working: [`Each year the value is multiplied by $1 - \\frac{${p}}{100} = ${1 - p / 100}$`, `$${V0}\\times ${1 - p / 100}^{${t}} = ${Math.round(V)}$`],
          hint: 'Losing p% means keeping (100 − p)%.', numworks: { app: 'Calculation', lines: [[`${V0}×${1 - p / 100}^${t}`, num(sf(V, 7))]] },
          errors: [{ value: Math.round(V0 * Math.pow(1 - p / 100, t - 1)), tag: 'n-minus-1', fb: `After ${t} years the multiplier has been applied ${t} times.` }, { value: Math.round(V0 * (1 - p * t / 100)), tag: 'simple-interest', fb: 'Depreciation is a percentage of the CURRENT value each year, so it is geometric, not linear.' }],
          verify: `${V0}*(1-Rational(${p},100))**${t}` },
        { command: 'Find', prompt: 'after how many complete years the value of the car first falls below half of its original value.', marks: 3, answer: { kind: 'num', value: y, int: true, display: String(y) },
          ms: [['M1', `$${V0}(${1 - p / 100})^{n} < ${V0 / 2}$`], ['(A1)', `$n > ${num(sf(Math.log(0.5) / Math.log(1 - p / 100), 4))}$`], ['A1', `$${y}$`]],
          working: [`$(${1 - p / 100})^{n} < 0.5$`, `NumWorks: $n > ${num(sf(Math.log(0.5) / Math.log(1 - p / 100), 4))}$`, `$n = ${y}$ complete years`], hint: 'Solve the inequality with the NumWorks, then think about whole years.',
          errors: [{ value: y - 1, tag: 'round-down', fb: 'Round up: the value must have actually fallen below half.' }], verify: `next(m for m in range(1,200) if (1-Rational(${p},100))**m < Rational(1,2))` }
      ]
    };
  });

  /* ---------- 1.5 Binomial theorem: expansion and coefficients ---------- */
  reg('sl.binom1', { skill: 'SL-1.5a', title: 'Binomial coefficients and a single coefficient', paper: 1 }, R => {
    const n1 = R.int(5, 9), r1 = R.int(2, 4), n = R.int(4, 6), p = R.int(1, 3), q = R.pick([-3, -2, -1, 2, 3]), k = R.int(2, 3);
    const coef = comb(n, k) * Math.pow(p, n - k) * Math.pow(q, k);
    return {
      stem: `This question is about the binomial expansion of $(${p}${q < 0 ? ' - ' : ' + '}${Math.abs(q) === 1 ? '' : Math.abs(q)}x)^{${n}}$.`,
      parts: [
        { command: 'Find', prompt: `the value of $\\binom{${n1}}{${r1}}$.`, marks: 1, answer: { kind: 'num', value: comb(n1, r1), int: true, display: String(comb(n1, r1)) }, ms: [['A1', `$${comb(n1, r1)}$`]],
          working: [`$\\binom{${n1}}{${r1}} = \\frac{${n1}!}{${r1}!\\,${n1 - r1}!} = ${comb(n1, r1)}$`], hint: 'Use Pascal’s triangle (row ' + n1 + ') or nCr on the NumWorks.',
          errors: [{ value: comb(n1, r1) * Hub.qcore.factorial(r1), tag: 'perm-not-comb', fb: 'That is ⁿPᵣ (order matters). The binomial coefficient is ⁿCᵣ.' }], verify: `binomial(${n1},${r1})` },
        { command: 'Write down', prompt: 'the number of terms in the expansion.', marks: 1, answer: { kind: 'num', value: n + 1, int: true, display: String(n + 1) }, ms: [['A1', `$${n + 1}$`]], working: [`Powers of $x$ from $0$ to $${n}$: $${n + 1}$ terms`], hint: 'List the powers of x that appear.',
          errors: [{ value: n, tag: 'terms-n', fb: `Powers 0, 1, …, ${n} give ${n + 1} terms.` }], verify: `${n}+1` },
        { command: 'Find', prompt: `the coefficient of $x^{${k}}$.`, marks: 3, answer: { kind: 'num', value: coef, exact: true, display: String(coef) },
          ms: [['(M1)', `term $\\binom{${n}}{${k}}(${p})^{${n - k}}(${q}x)^{${k}}$`], ['A1', 'correct values of each factor'], ['A1', `$${coef}$`]],
          working: [`$\\binom{${n}}{${k}}(${p})^{${n - k}}(${q}x)^{${k}} = ${comb(n, k)}\\times ${Math.pow(p, n - k)}\\times ${paren(Math.pow(q, k))}x^{${k}}$`, `Coefficient $= ${coef}$`],
          hint: 'The x-term must be raised to the same power as x. Keep the sign inside the bracket.',
          errors: [{ value: Math.pow(p, n - k) * Math.pow(q, k), tag: 'missing-ncr', fb: `Each term needs its binomial coefficient ⁿCᵣ (here ${comb(n, k)}).` }, { value: comb(n, k) * Math.pow(p, n - k) * q, tag: 'power-on-coefficient', fb: `Raise the whole term (${q}x) to the power ${k}, including the ${q}.` }, { value: -coef, tag: 'sign', fb: 'Check the sign: a negative number raised to an even power is positive.' }],
          verify: `Poly(expand((${p}+(${q})*x)**${n}),x).coeff_monomial(x**${k})` }
      ]
    };
  });

  /* ---------- 1.5 Binomial theorem: general term, working backwards ---------- */
  reg('sl.binom2', { skill: 'SL-1.5b', title: 'General term: constant term and working backwards', paper: 1, challenge: true }, (R, o) => {
    const n = o.challenge ? R.pick([6, 9]) : R.pick([3, 6]), c = n === 9 ? R.pick([-2, -1, 1, 2]) : R.pick([-3, -2, 2, 3]), r = 2 * n / 3;
    const ct = comb(n, r) * Math.pow(c, r);
    const n2 = R.int(5, 8), a = R.int(2, 5), K = comb(n2, 2) * a * a;
    return {
      stem: '',
      parts: [
        { command: 'Find', prompt: `the constant term in the expansion of $\\left(x^{2}${c < 0 ? ' - ' : ' + '}\\frac{${Math.abs(c)}}{x}\\right)^{${n}}$.`, marks: 4, answer: { kind: 'num', value: ct, exact: true, display: String(ct) },
          ms: [['M1', `general term $\\binom{${n}}{r}(x^{2})^{${n}-r}\\left(\\frac{${c}}{x}\\right)^{r}$`], ['M1', `$2(${n}-r) - r = 0$`], ['A1', `$r = ${r}$`], ['A1', `$${ct}$`]],
          working: [`$\\binom{${n}}{r}(x^{2})^{${n}-r}\\left(${c}x^{-1}\\right)^{r} = \\binom{${n}}{r}(${c})^{r}x^{${2 * n}-3r}$`, `Constant term: $${2 * n} - 3r = 0 \\Rightarrow r = ${r}$`, `$\\binom{${n}}{${r}}(${c})^{${r}} = ${comb(n, r)}\\times ${paren(Math.pow(c, r))} = ${ct}$`],
          hint: 'Write the general term and collect the powers of x. Which r makes the power zero?',
          errors: [{ value: comb(n, r), tag: 'forgot-constant-power', fb: `Don't forget the ${c} is raised to the power r as well.` }, { value: -ct, tag: 'sign', fb: 'Check the sign of the negative term raised to the power r.' }],
          verify: `expand((x**2+Rational(${c})/x)**${n}).as_coefficients_dict()[1]` },
        { command: 'Find', prompt: `the value of $a$, given that $a > 0$ and the coefficient of $x^{2}$ in the expansion of $(1 + ax)^{${n2}}$ is $${K}$.`, marks: 3, answer: { kind: 'num', value: a, exact: true, display: String(a) },
          ms: [['M1', `$\\binom{${n2}}{2}a^{2} = ${K}$`], ['A1', `$a^{2} = ${a * a}$`], ['A1', `$a = ${a}$`]],
          working: [`Term in $x^{2}$: $\\binom{${n2}}{2}(ax)^{2} = ${comb(n2, 2)}a^{2}x^{2}$`, `$${comb(n2, 2)}a^{2} = ${K} \\Rightarrow a^{2} = ${a * a}$`, `$a > 0 \\Rightarrow a = ${a}$`],
          hint: 'Write the x² term with a in it, then set its coefficient equal to the given value.', errors: [{ value: a * a, tag: 'forgot-square', fb: 'The coefficient contains a², so take the square root at the end.' }, { value: K / comb(n2, 2) / 2, tag: 'halved', fb: 'Solve a² = …, then square root.' }],
          verify: `[s for s in solve(Eq(binomial(${n2},2)*k**2,${K}),k) if s>0][0]` }
      ]
    };
  });

  /* ---------- 1.6 Simple deductive proof ---------- */
  const PROOFS = [
    a => ({ claim: `(n + ${a})^{2} - (n - ${a})^{2} \\equiv ${4 * a}n`, lines: [
      [`\\text{LHS} = (n^{2} + ${2 * a}n + ${a * a}) - (n^{2} - ${2 * a}n + ${a * a})`, `\\text{LHS} = (n^{2} + ${a * a}) - (n^{2} - ${a * a})`],
      [`= n^{2} + ${2 * a}n + ${a * a} - n^{2} + ${2 * a}n - ${a * a}`, `= n^{2} + ${2 * a}n + ${a * a} - n^{2} - ${2 * a}n + ${a * a}`],
      [`= ${4 * a}n = \\text{RHS}`, null]], py: `expand((n+${a})**2-(n-${a})**2-${4 * a}*n)==0` }),
    a => ({ claim: `\\frac{${a}}{n} - \\frac{${a}}{n + 1} \\equiv \\frac{${a}}{n(n + 1)}`, lines: [
      [`\\text{LHS} = \\frac{${a}(n + 1) - ${a}n}{n(n + 1)}`, `\\text{LHS} = \\frac{${a} - ${a}}{n - (n + 1)}`],
      [`= \\frac{${a}n + ${a} - ${a}n}{n(n + 1)}`, `= \\frac{${a}n + ${a} + ${a}n}{n(n + 1)}`],
      [`= \\frac{${a}}{n(n + 1)} = \\text{RHS}`, null]], py: `simplify(Rational(${a})/n-Rational(${a})/(n+1)-Rational(${a})/(n*(n+1)))==0` }),
    a => ({ claim: `(n + 1)^{3} - n^{3} \\equiv 3n^{2} + 3n + 1`, lines: [
      [`\\text{LHS} = (n^{3} + 3n^{2} + 3n + 1) - n^{3}`, `\\text{LHS} = (n^{3} + 1) - n^{3}`],
      [`= n^{3} + 3n^{2} + 3n + 1 - n^{3}`, `= n^{3} + 3n^{2} + 3n + 1 + n^{3}`],
      [`= 3n^{2} + 3n + 1 = \\text{RHS}`, null]], py: `expand((n+1)**3-n**3-(3*n**2+3*n+1))==0` })
  ];
  reg('sl.proof', { skill: 'SL-1.6', title: 'Deductive proof: LHS to RHS and spotting errors', paper: 1 }, R => {
    const a = R.int(2, 6), fam = R.int(0, PROOFS.length - 1), P = PROOFS[fam](a), errLine = R.int(0, 1);
    const shown = P.lines.map((l, i) => i === errLine ? l[1] : l[0]);
    const choice = mc(R, [0, 1, 2].map(i => ({ tex: `Line ${i + 1}`, key: 'L' + (i + 1) })).concat([{ tex: 'There is no error', key: 'none' }]), 'L' + (errLine + 1));
    const choiceFixed = Object.assign({}, choice); // keep labels in natural order
    const order = ['L1', 'L2', 'L3', 'none'];
    choiceFixed.choices = ['Line 1', 'Line 2', 'Line 3', 'There is no error']; choiceFixed.keys = order; choiceFixed.correct = errLine;
    const other = PROOFS[(fam + 1) % PROOFS.length](a);
    return {
      stem: `A student tries to prove that $${P.claim}$.\n` + shown.map((l, i) => `(${i + 1})  $${l}$`).join('\n'),
      parts: [
        { command: 'State', prompt: 'the number of the first line that contains an error.', marks: 1, answer: Object.assign(choiceFixed, { display: `Line ${errLine + 1}` }), ms: [['A1', `Line ${errLine + 1}`]],
          working: [`Correct line ${errLine + 1}: $${P.lines[errLine][0]}$`], hint: 'Check each line carefully: expansion first, then signs when you remove brackets.', verify: `'L${errLine + 1}' if ${P.py.replace('==0', '')}==0 else 'x'` },
        { command: 'Show that', prompt: `$${other.claim}$.`, marks: 3, answer: { kind: 'open', display: 'See markscheme' },
          ms: [['M1', 'correct expansion, or a common denominator, of the LHS'], ['A1', 'correct simplification'], ['AG', `reaching the RHS with no errors`]], working: other.lines.map(l => `$${l[0]}$`),
          hint: 'Start with the left-hand side only, and work step by step until you reach the right-hand side.', verify: `${other.py}` }
      ]
    };
  });

  /* ---------- 2.1 What is a function ---------- */
  reg('sl.function', { skill: 'SL-2.1', title: 'Relations and functions', paper: 1 }, R => {
    const mkSet = isFn => { const xs = R.distinct(4, -3, 6); const pts = xs.map(x => [x, R.int(-5, 9)]); if (!isFn) pts[3] = [pts[R.int(0, 2)][0], pts[3][1] + 1 + R.int(0, 3)]; return pts; };
    const sets = [mkSet(true), mkSet(false), mkSet(false), mkSet(false)];
    const opts = sets.map((s, i) => ({ tex: `$\\{${s.map(p => `(${p[0]},\\,${p[1]})`).join(',\\,')}\\}$`, key: i === 0 ? 'fn' : 'no' + i, py: `[${s.map(p => `(${p[0]},${p[1]})`).join(',')}]` }));
    const c = R.int(1, 5), m = mc(R, [{ tex: `$y = x^{2} + ${c}$`, key: 'a' }, { tex: `$x = y^{2} + ${c}$`, key: 'b' }, { tex: `$y = \\sqrt{x + ${c}}$`, key: 'c' }, { tex: `$y = |x - ${c}|$`, key: 'd' }], 'b');
    return {
      stem: '',
      parts: [
        { command: 'State', prompt: 'which one of these relations is a function.', marks: 1, answer: Object.assign(mc(R, opts, 'fn'), { display: opts[0].tex }), ms: [['A1', 'the set in which every input appears exactly once']],
          working: ['A relation is a function when each input ($x$-value) has exactly one output. In the other sets, an $x$-value repeats with a different $y$-value.'], hint: 'Look for an x-value that is paired with two different y-values.',
          verify: `'fn' if len(set(p[0] for p in ${opts[0].py}))==len(${opts[0].py}) else 'x'` },
        { command: 'State', prompt: 'which equation does NOT define $y$ as a function of $x$.', marks: 1, answer: Object.assign(m, { display: `x = y^{2} + ${c}` }), ms: [['A1', `$x = y^{2} + ${c}$`]],
          working: [`For $x = ${c + 1}$: $y^{2} = 1$, so $y = 1$ or $y = -1$ — one input, two outputs.`], hint: 'Try one x-value in each equation. Do you get more than one y?', verify: `'b' if len(solve(Eq(${c}+1, y**2+${c}), y))==2 else 'x'` }
      ]
    };
  });

  /* ---------- 2.2 Function notation ---------- */
  reg('sl.notation', { skill: 'SL-2.2', title: 'Function notation: evaluate and solve', paper: 1 }, R => {
    const a = R.pick([1, 2]), [s1, s2] = R.distinct(2, -6, 6), k = R.int(-5, 10), b = -a * (s1 + s2), c = a * s1 * s2 + k, p = R.nz(-4, 4);
    const f = poly([[a, 'x^{2}'], [b, 'x'], [c, '']]), fp = a * p * p + b * p + c;
    return {
      stem: `Let $f(x) = ${f}$.`,
      parts: [
        { command: 'Find', prompt: `$f(${p})$.`, marks: 2, answer: { kind: 'num', value: fp, exact: true, display: String(fp) },
          ms: [['M1', `$${a === 1 ? '' : a}(${p})^{2} ${sgn(b)}(${p}) ${sgn(c)}$`], ['A1', `$${fp}$`]], working: [`$f(${p}) = ${a === 1 ? '' : a}(${p})^{2} ${sgn(b)}(${p}) ${sgn(c)} = ${fp}$`],
          hint: 'Put brackets round the input before squaring.', errors: p < 0 ? [{ value: -a * p * p + b * p + c, tag: 'negative-squared', fb: `(${p})² is positive: brackets matter when you square a negative.` }] : [], verify: `${a}*(${p})**2+(${b})*(${p})+(${c})` },
        { command: 'Solve', prompt: `$f(x) = ${k}$.`, marks: 3, answer: { kind: 'list', value: [s1, s2], exact: true, markEach: true, display: `x = ${s1}\\text{ or }x = ${s2}` },
          ms: [['M1', `$${poly([[a, 'x^{2}'], [b, 'x'], [c - k, '']])} = 0$`], ['A1', `$x = ${s1}$`], ['A1', `$x = ${s2}$`]],
          working: [`$${poly([[a, 'x^{2}'], [b, 'x'], [c - k, '']])} = 0$`, `$${a === 1 ? '' : a}(x ${sgn(-s1)})(x ${sgn(-s2)}) = 0$`, `$x = ${s1}$ or $x = ${s2}$`],
          hint: 'Rearrange so one side is zero, then factorise.', errors: [{ value: [-s1, -s2], tag: 'root-signs', fb: 'If (x − 3) is a factor, the solution is x = +3.' }], verify: `solve(Eq(${a}*x**2+(${b})*x+(${c}),${k}),x)` }
      ]
    };
  });

  /* ---------- 2.4 Domain and range ---------- */
  reg('sl.domain', { skill: 'SL-2.4', title: 'Domain and range', paper: 1 }, R => {
    const a = R.int(2, 5), b = R.int(1, 9), m = fr(b, a), c = R.nz(-6, 6), d = R.nz(-5, 5), e = R.nz(-4, 7), p = R.nz(-4, 4), q = R.int(-6, 8);
    return {
      stem: `Let $f(x) = \\sqrt{${a}x - ${b}}$ and $g(x) = \\frac{${c}}{x ${sgn(-d)}} ${sgn(e)}$, $x \\ne ${d}$.`,
      parts: [
        { command: 'Find', prompt: 'the largest possible domain of $f$. Give the least value of $x$.', marks: 2, answer: { kind: 'num', value: m.val(), exact: true, display: `x \\ge ${m.tex()}` },
          ms: [['M1', `$${a}x - ${b} \\ge 0$`], ['A1', `$x \\ge ${m.tex()}$`]], working: [`$${a}x - ${b} \\ge 0 \\Rightarrow x \\ge ${m.tex()}$`], hint: 'The expression under a square root cannot be negative.',
          errors: [{ value: -m.val(), tag: 'sign', fb: 'Solve $ax - b \\ge 0$ carefully: $x \\ge \\frac{b}{a}$.' }, { value: b * a, tag: 'multiplied', fb: 'Divide by the coefficient of x.' }], verify: `solve(${a}*x-${b},x)[0]` },
        { command: 'Write down', prompt: 'the value of $x$ that is excluded from the domain of $g$.', marks: 1, answer: { kind: 'num', value: d, exact: true, display: `x = ${d}` }, ms: [['A1', `$${d}$`]], working: [`The denominator $x ${sgn(-d)}$ is zero when $x = ${d}$.`],
          hint: 'You cannot divide by zero.', errors: [{ value: -d, tag: 'sign', fb: `x ${sgn(-d)} = 0 gives x = ${d}.` }], verify: `solve(x-(${d}),x)[0]` },
        { command: 'Write down', prompt: 'the value of $y$ that is not in the range of $g$.', marks: 1, answer: { kind: 'num', value: e, exact: true, display: `y = ${e}` }, ms: [['A1', `$${e}$`]], working: [`$\\frac{${c}}{x ${sgn(-d)}}$ can never equal $0$, so $g(x)$ can never equal $${e}$ (horizontal asymptote).`],
          hint: 'Which value can the fraction never take?', verify: `limit(${c}/(x-(${d}))+(${e}),x,oo)` },
        { command: 'Write down', prompt: `the minimum value of $h(x) = (x ${sgn(-p)})^{2} ${sgn(q)}$, $x\\in\\mathbb{R}$.`, marks: 1, answer: { kind: 'num', value: q, exact: true, display: `h(x) \\ge ${q}` }, ms: [['A1', `$${q}$`]],
          working: [`A square is never negative, so the least value is when $x = ${p}$: $h = ${q}$. Range: $h(x) \\ge ${q}$.`], hint: 'What is the smallest a squared bracket can be?', verify: `minimum((x-(${p}))**2+(${q}),x)` }
      ]
    };
  });

  /* ---------- 2.5 Composite functions ---------- */
  reg('sl.composite', { skill: 'SL-2.5', title: 'Composite functions', paper: 1 }, R => {
    const a = R.pick([-3, -2, 2, 3, 4]), b = R.nz(-6, 6), c = R.int(1, 6), p = R.nz(-3, 4), x0 = R.int(2, 6);
    const fog = v => a * (v * v - c) + b, gof = v => Math.pow(a * v + b, 2) - c, K = fog(x0);
    return {
      stem: `Let $f(x) = ${lin(a, b)}$ and $g(x) = x^{2} - ${c}$.`,
      parts: [
        { command: 'Find', prompt: `$(f\\circ g)(${p})$.`, marks: 2, answer: { kind: 'num', value: fog(p), exact: true, display: String(fog(p)) },
          ms: [['M1', `$g(${p}) = ${p * p - c}$`], ['A1', `$f(${p * p - c}) = ${fog(p)}$`]], working: [`$g(${p}) = (${p})^{2} - ${c} = ${p * p - c}$`, `$f(${p * p - c}) = ${a}(${p * p - c}) ${sgn(b)} = ${fog(p)}$`],
          hint: '(f∘g)(x) means f(g(x)): apply g FIRST.', errors: [{ value: gof(p), tag: 'order-of-composition', fb: 'You found g(f(x)). In (f∘g)(x), g acts first.' }], verify: `(${a}*x+(${b})).subs(x,(${p})**2-${c})` },
        { command: 'Find', prompt: '$(g\\circ f)(x)$, giving your answer in the form $px^{2} + qx + r$.', marks: 3, answer: { kind: 'tuple', labels: ['p', 'q', 'r'], value: [a * a, 2 * a * b, b * b - c], exact: true, markEach: true, display: poly([[a * a, 'x^{2}'], [2 * a * b, 'x'], [b * b - c, '']]) },
          ms: [['M1', `$(${lin(a, b)})^{2} - ${c}$`], ['A1', 'correct expansion'], ['A1', `$${poly([[a * a, 'x^{2}'], [2 * a * b, 'x'], [b * b - c, '']])}$`]],
          working: [`$g(f(x)) = (${lin(a, b)})^{2} - ${c}$`, `$= ${poly([[a * a, 'x^{2}'], [2 * a * b, 'x'], [b * b, '']])} - ${c}$`, `$= ${poly([[a * a, 'x^{2}'], [2 * a * b, 'x'], [b * b - c, '']])}$`],
          hint: 'Substitute the whole of f(x) for x in g, then expand the bracket squared.', errors: [{ value: [a * a, 0, b * b - c], tag: 'square-of-sum', fb: '(a + b)² = a² + 2ab + b²: don’t forget the middle term.' }],
          verify: `tuple(Poly(expand((${a}*x+(${b}))**2-${c}),x).all_coeffs())` },
        { command: 'Solve', prompt: `$(f\\circ g)(x) = ${K}$.`, marks: 3, answer: { kind: 'list', value: [x0, -x0], exact: true, markEach: true, display: `x = \\pm ${x0}` },
          ms: [['M1', `$${a}(x^{2} - ${c}) ${sgn(b)} = ${K}$`], ['A1', `$x^{2} = ${x0 * x0}$`], ['A1', `$x = \\pm ${x0}$`]],
          working: [`$${a}(x^{2} - ${c}) ${sgn(b)} = ${K}$`, `$x^{2} - ${c} = ${x0 * x0 - c}$`, `$x^{2} = ${x0 * x0} \\Rightarrow x = \\pm ${x0}$`], hint: 'There are two solutions when you square root.',
          errors: [], verify: `solve(Eq(${a}*(x**2-${c})+(${b}),${K}),x)` }
      ]
    };
  });

  /* ---------- 2.6 Inverse functions ---------- */
  reg('sl.inverse', { skill: 'SL-2.6', title: 'Inverse functions', paper: 1 }, R => {
    const p = R.pick([-4, -3, -2, 2, 3, 4, 5]), q = R.nz(-9, 9), K = R.int(-10, 15), a = R.nz(-6, 8), b = R.nz(-4, 4), K2 = R.pick([-3, -2, -1, 1, 2, 3, 4]);
    const finvK = fr(K - q, p), ginvK = fr(a, K2).add(b);
    return {
      stem: `Let $f(x) = ${lin(p, q)}$ and $g(x) = \\frac{${a}}{x ${sgn(-b)}}$, $x \\ne ${b}$.`,
      parts: [
        { command: 'Find', prompt: `$f^{-1}(x)$, giving your answer in the form $mx + c$.`, marks: 2, answer: { kind: 'tuple', labels: ['m', 'c'], value: [1 / p, -q / p], exact: true, markEach: true, display: `${fr(1, p).tex()}x ${sgn(fr(-q, p))}` },
          ms: [['M1', `$x = ${lin(p, q, 'y')}$`], ['A1', `$f^{-1}(x) = ${poly([[fr(1, p), 'x'], [fr(-q, p), '']])}$`]],
          working: [`Swap $x$ and $y$: $x = ${lin(p, q, 'y')}$`, `$y = \\frac{x ${sgn(-q)}}{${p}} = ${poly([[fr(1, p), 'x'], [fr(-q, p), '']])}$`], hint: 'Write y = f(x), swap x and y, then make y the subject.',
          errors: [{ value: [1 / p, q / p], tag: 'inverse-sign', fb: 'Undo the addition with a subtraction.' }], verify: `tuple(Poly(solve(Eq(x,${p}*y+(${q})),y)[0],x).all_coeffs())` },
        { command: 'Find', prompt: `$f^{-1}(${K})$.`, marks: 1, answer: { kind: 'num', value: finvK.val(), exact: true, display: finvK.tex() }, ms: [['A1', `$${finvK.tex()}$`]], working: [`$f^{-1}(${K}) = \\frac{${K} ${sgn(-q)}}{${p}} = ${finvK.tex()}$`],
          hint: 'Use your answer to (a), or solve f(x) = ' + K + '.', errors: [{ value: 1 / (p * K + q), tag: 'reciprocal-not-inverse', fb: '$f^{-1}$ is the inverse function, not $\\frac{1}{f(x)}$.' }, { value: p * K + q, tag: 'applied-f', fb: 'You applied f, not its inverse.' }], verify: `solve(Eq(${p}*x+(${q}),${K}),x)[0]` },
        { command: 'Find', prompt: `$g^{-1}(${K2})$.`, marks: 2, answer: { kind: 'num', value: ginvK.val(), exact: true, display: ginvK.tex() },
          ms: [['M1', `$${K2} = \\frac{${a}}{x ${sgn(-b)}}$`], ['A1', `$${ginvK.tex()}$`]], working: [`Solve $g(x) = ${K2}$: $x ${sgn(-b)} = \\frac{${a}}{${K2}}$`, `$x = ${ginvK.tex()}$`],
          hint: 'g⁻¹(k) is the x-value that g sends to k.', errors: [{ value: a / (K2 - b), tag: 'applied-f', fb: 'You worked out g(' + K2 + '). Solve g(x) = ' + K2 + ' instead.' }], verify: `solve(Eq(${a}/(x-(${b})),${K2}),x)[0]` },
        { command: 'Write down', prompt: `$(f\\circ f^{-1})(${K + 7})$.`, marks: 1, answer: { kind: 'num', value: K + 7, exact: true, display: String(K + 7) }, ms: [['A1', `$${K + 7}$`]], working: ['$f$ undoes $f^{-1}$, so $(f\\circ f^{-1})(x) = x$.'], hint: 'What does applying a function after its inverse do?', verify: `${K}+7` }
      ]
    };
  });

  /* ---------- 3.1–3.2 Linear functions ---------- */
  reg('sl.lines', { skill: 'SL-3.1', title: 'Gradient, perpendicular lines and midpoints', paper: 1 }, R => {
    let x1, y1, x2, y2; do { x1 = R.int(-6, 5); y1 = R.int(-6, 8); x2 = R.int(-5, 8); y2 = R.int(-6, 9); } while (x1 === x2 || y1 === y2);
    const m = fr(y2 - y1, x2 - x1), mp = fr(-1).div(m), c = fr(y1).sub(mp.mul(x1));
    return {
      stem: `The points $A(${x1},\\,${y1})$ and $B(${x2},\\,${y2})$ are shown on a coordinate grid.`,
      parts: [
        { command: 'Find', prompt: 'the gradient of $AB$.', marks: 2, answer: { kind: 'num', value: m.val(), exact: true, display: m.tex() },
          ms: [['M1', `$\\frac{${y2} - ${paren(y1)}}{${x2} - ${paren(x1)}}$`], ['A1', `$${m.tex()}$`]], working: [`$m = \\frac{y_2 - y_1}{x_2 - x_1} = \\frac{${y2 - y1}}{${x2 - x1}} = ${m.tex()}$`],
          hint: 'Change in y over change in x.', errors: [{ value: fr(x2 - x1, y2 - y1).val(), tag: 'inverted-gradient', fb: 'Gradient is rise ÷ run: change in y on top.' }], verify: `Rational(${y2}-(${y1}),${x2}-(${x1}))` },
        { command: 'Write down', prompt: 'the coordinates of the midpoint of $AB$.', marks: 1, answer: { kind: 'tuple', labels: ['x', 'y'], value: [(x1 + x2) / 2, (y1 + y2) / 2], exact: true, display: `\\left(${fr(x1 + x2, 2).tex()},\\,${fr(y1 + y2, 2).tex()}\\right)` },
          ms: [['A1', `$\\left(${fr(x1 + x2, 2).tex()},\\,${fr(y1 + y2, 2).tex()}\\right)$`]], working: [`Average the coordinates: $\\left(\\frac{${x1} + ${paren(x2)}}{2},\\,\\frac{${y1} + ${paren(y2)}}{2}\\right)$`], hint: 'Midpoint = average of the x’s, average of the y’s.', verify: `(Rational(${x1 + x2},2),Rational(${y1 + y2},2))` },
        { command: 'Find', prompt: 'the equation of the line $L$ that passes through $A$ and is perpendicular to $AB$. Give your answer in the form $y = mx + c$.', marks: 3, answer: { kind: 'tuple', labels: ['m', 'c'], value: [mp.val(), c.val()], exact: true, markEach: true, display: `y = ${poly([[mp, 'x'], [c, '']])}` },
          ms: [['M1', `$m_\\perp = ${mp.tex()}$`], ['M1', `$y ${sgn(-y1)} = ${mp.tex()}(x ${sgn(-x1)})$`], ['A1', `$y = ${poly([[mp, 'x'], [c, '']])}$`]],
          working: [`$m_\\perp = -\\frac{1}{m} = ${mp.tex()}$`, `$y - ${paren(y1)} = ${mp.tex()}\\left(x - ${paren(x1)}\\right)$`, `$y = ${poly([[mp, 'x'], [c, '']])}$`],
          hint: 'Perpendicular gradients multiply to −1.', errors: [{ value: [m.val(), fr(y1).sub(m.mul(x1)).val()], tag: 'parallel-not-perpendicular', fb: 'You used the same gradient (that gives a parallel line). Perpendicular: $m_\\perp = -\\frac{1}{m}$.' }, { value: [fr(1).div(m).val(), fr(y1).sub(fr(1).div(m).mul(x1)).val()], tag: 'reciprocal-no-sign', fb: 'Take the negative reciprocal: change the sign as well as flipping.' }],
          verify: `(-1/Rational(${y2}-(${y1}),${x2}-(${x1})), ${y1}+1/Rational(${y2}-(${y1}),${x2}-(${x1}))*(${x1}))` }
      ]
    };
  });

  /* ---------- 3.3 Transformations ---------- */
  reg('sl.transform', { skill: 'SL-3.3', title: 'Transformations of graphs: images of a point', paper: 1 }, R => {
    const p = R.nz(-5, 6), q = R.nz(-5, 6), h = R.nz(-4, 4), k = R.nz(-5, 5), a = R.pick([2, 3, -2, -1]), b = R.pick([2, 3, 4]);
    return {
      stem: `The point $P(${p},\\,${q})$ lies on the graph of $y = f(x)$. Write down the coordinates of the image of $P$ on each graph.`,
      parts: [
        { command: 'Write down', prompt: `$y = f(x ${sgn(-h)}) ${sgn(k)}$`, marks: 2, answer: { kind: 'tuple', labels: ['x', 'y'], value: [p + h, q + k], exact: true, markEach: true, display: `(${p + h},\\,${q + k})` },
          ms: [['A1', `$x = ${p + h}$`], ['A1', `$y = ${q + k}$`]], working: [`Translation by $\\binom{${h}}{${k}}$: $(${p} ${sgn(h)},\\,${q} ${sgn(k)}) = (${p + h},\\,${q + k})$`], hint: 'Inside the bracket acts on x in the OPPOSITE way to how it looks.',
          errors: [{ value: [p - h, q + k], tag: 'translation-direction', fb: `f(x − ${h}) moves the graph ${h > 0 ? 'right' : 'left'} by ${Math.abs(h)}.` }], verify: `(${p}+(${h}),${q}+(${k}))` },
        { command: 'Write down', prompt: `$y = ${a === -1 ? '-' : a}f(x)$`, marks: 1, answer: { kind: 'tuple', labels: ['x', 'y'], value: [p, a * q], exact: true, display: `(${p},\\,${a * q})` }, ms: [['A1', `$(${p},\\,${a * q})$`]],
          working: [`Vertical ${a === -1 ? 'reflection in the x-axis' : `stretch, scale factor ${a}`}: multiply the $y$-coordinate by $${a}$.`], hint: 'Outside the function acts on y as it looks.', verify: `(${p},${a}*(${q}))` },
        { command: 'Write down', prompt: `$y = f(${b}x)$`, marks: 1, answer: { kind: 'tuple', labels: ['x', 'y'], value: [p / b, q], exact: true, display: `\\left(${fr(p, b).tex()},\\,${q}\\right)` }, ms: [['A1', `$\\left(${fr(p, b).tex()},\\,${q}\\right)$`]],
          working: [`Horizontal stretch, scale factor $\\frac{1}{${b}}$: divide the $x$-coordinate by $${b}$.`], hint: 'f(bx) squashes the graph towards the y-axis.', errors: [{ value: [p * b, q], tag: 'horizontal-stretch-factor', fb: `$f(${b}x)$ is a stretch by factor $\\frac{1}{${b}}$: divide $x$ by $${b}$.` }], verify: `(Rational(${p},${b}),${q})` }
      ]
    };
  });

  /* ---------- 3.4 Graphing quadratics ---------- */
  reg('sl.vertex', { skill: 'SL-3.4', title: 'Quadratic graphs: axis, vertex and intercepts', paper: 1 }, R => {
    const a = R.pick([1, 2, -1, 3, -2]), h = R.nz(-5, 5), k = R.int(-9, 9), b = -2 * a * h, c = a * h * h + k;
    return {
      stem: `The graph of $y = ${poly([[a, 'x^{2}'], [b, 'x'], [c, '']])}$ is a parabola.`,
      parts: [
        { command: 'Find', prompt: 'the equation of the axis of symmetry.', marks: 2, answer: { kind: 'num', value: h, exact: true, display: `x = ${h}` }, ms: [['M1', `$x = -\\frac{${b}}{2(${a})}$`], ['A1', `$x = ${h}$`]], working: [`$x = -\\frac{b}{2a} = -\\frac{${b}}{${2 * a}} = ${h}$`],
          hint: 'Axis of symmetry: $x = -\\frac{b}{2a}$, in the formula booklet.', errors: [{ value: -h, tag: 'axis-sign', fb: 'Remember the minus sign in $x = -\\frac{b}{2a}$.' }], verify: `-Rational(${b},2*${a})` },
        { command: 'Write down', prompt: 'the coordinates of the vertex.', marks: 1, answer: { kind: 'tuple', labels: ['x', 'y'], value: [h, k], exact: true, display: `(${h},\\,${k})` }, ms: [['A1', `$(${h},\\,${k})$`]], working: [`$y(${h}) = ${k}$`], hint: 'Substitute your axis value into the equation.', verify: `(${h}, (${a}*x**2+(${b})*x+(${c})).subs(x,${h}))` },
        { command: 'Write down', prompt: 'the $y$-intercept.', marks: 1, answer: { kind: 'num', value: c, exact: true, display: String(c) }, ms: [['A1', `$${c}$`]], working: ['Set $x = 0$.'], hint: 'Where does the graph cross the y-axis?', verify: `${c}` },
        { command: 'State', prompt: 'whether the vertex is a maximum or a minimum point.', marks: 1, answer: Object.assign(mc(R, [{ tex: 'Maximum', key: 'max' }, { tex: 'Minimum', key: 'min' }], a < 0 ? 'max' : 'min'), { display: a < 0 ? 'Maximum' : 'Minimum' }),
          ms: [['A1', a < 0 ? 'maximum, since $a < 0$' : 'minimum, since $a > 0$']], working: [`$a = ${a} ${a < 0 ? '< 0' : '> 0'}$: the parabola opens ${a < 0 ? 'downwards' : 'upwards'}.`], hint: 'Look at the sign of the x² coefficient.', verify: `'max' if ${a}<0 else 'min'` }
      ]
    };
  });

  /* ---------- 3.5 Solving quadratics ---------- */
  reg('sl.solvequad', { skill: 'SL-3.5', title: 'Factorising and completing the square', paper: 1 }, R => {
    const [r1, r2] = R.distinct(2, -7, 7, [0]), a = R.pick([1, 2, 3]), h = R.nz(-4, 4), k = R.nz(-9, 9);
    return {
      stem: '',
      parts: [
        { command: 'Solve', prompt: `$${poly([[1, 'x^{2}'], [-(r1 + r2), 'x'], [r1 * r2, '']])} = 0$.`, marks: 2, answer: { kind: 'list', value: [r1, r2], exact: true, markEach: true, display: `x = ${r1},\\ x = ${r2}` },
          ms: [['M1', `$(x ${sgn(-r1)})(x ${sgn(-r2)}) = 0$`], ['A1', `$x = ${r1},\\ x = ${r2}$`]], working: [`Two numbers that multiply to $${r1 * r2}$ and add to $${-(r1 + r2)}$: $${-r1}$ and $${-r2}$`, `$(x ${sgn(-r1)})(x ${sgn(-r2)}) = 0 \\Rightarrow x = ${r1}$ or $x = ${r2}$`],
          hint: 'Find two numbers that multiply to give the constant and add to give the x-coefficient.', errors: [{ value: [-r1, -r2], tag: 'root-signs', fb: 'If (x + 3) = 0 then x = −3. Change the sign.' }], verify: `solve(x**2-(${r1 + r2})*x+(${r1 * r2}),x)` },
        { command: 'Write', prompt: `$${poly([[a, 'x^{2}'], [-2 * a * h, 'x'], [a * h * h + k, '']])}$ in the form $a(x - h)^{2} + k$.`, marks: 3, answer: { kind: 'tuple', labels: ['a', 'h', 'k'], value: [a, h, k], exact: true, markEach: true, display: `${a === 1 ? '' : a}(x ${sgn(-h)})^{2} ${sgn(k)}` },
          ms: [['A1', `$a = ${a}$`], ['A1', `$h = ${h}$`], ['A1', `$k = ${k}$`]],
          working: [`$${a === 1 ? '' : a + '\\left('}x^{2} ${sgn(-2 * h)}x${a === 1 ? '' : '\\right)'} ${sgn(a * h * h + k)}$`, `$= ${a === 1 ? '' : a}(x ${sgn(-h)})^{2} - ${a * h * h} ${sgn(a * h * h + k)}$`, `$= ${a === 1 ? '' : a}(x ${sgn(-h)})^{2} ${sgn(k)}$`],
          hint: 'Take out a first, then halve the x-coefficient inside the bracket.', errors: [{ value: [a, -h, k], tag: 'vertex-sign', fb: 'In a(x − h)², h has the opposite sign to the number in the bracket.' }], verify: `(${a}, ${h}, expand(${a}*x**2-2*${a}*(${h})*x+${a * h * h + k} - ${a}*(x-(${h}))**2))` }
      ]
    };
  });

  /* ---------- 3.6 Quadratic formula and discriminant ---------- */
  reg('sl.discriminant', { skill: 'SL-3.6', title: 'The discriminant and exact roots', paper: 1, challenge: true }, (R, o) => {
    const m = R.int(2, 7), b = R.pick([4, 6, 8, 10]), p = R.int(1, 5), s = R.pick([2, 3, 5, 6, 7]);
    const q = p * p - s; // x^2 - 2p x + q = 0 → x = p ± √s
    return {
      stem: '',
      parts: [
        { command: 'Find', prompt: `the values of $k$ for which $x^{2} + kx + ${m * m} = 0$ has two equal roots.`, marks: 3, answer: { kind: 'list', value: [2 * m, -2 * m], exact: true, markEach: true, display: `k = \\pm ${2 * m}` },
          ms: [['M1', '$\\Delta = b^{2} - 4ac = 0$'], ['A1', `$k^{2} - ${4 * m * m} = 0$`], ['A1', `$k = \\pm ${2 * m}$`]], working: [`$\\Delta = k^{2} - 4(1)(${m * m}) = 0$`, `$k^{2} = ${4 * m * m} \\Rightarrow k = \\pm ${2 * m}$`],
          hint: 'Equal roots means the discriminant is zero.', errors: [{ value: [2 * m], tag: 'missing-negative-root', fb: 'k² = … has a negative solution too.' }], verify: `solve(k**2-4*${m * m},k)` },
        { command: 'Find', prompt: `the set of values of $c$ for which $x^{2} - ${b}x + c = 0$ has two distinct real roots. Give the boundary value $t$, where $c < t$.`, marks: 3, answer: { kind: 'num', value: b * b / 4, exact: true, display: `c < ${fr(b * b, 4).tex()}` },
          ms: [['M1', '$\\Delta > 0$'], ['A1', `$${b * b} - 4c > 0$`], ['A1', `$c < ${fr(b * b, 4).tex()}$`]], working: [`$\\Delta = (-${b})^{2} - 4(1)(c) > 0$`, `$${b * b} > 4c \\Rightarrow c < ${fr(b * b, 4).tex()}$`],
          hint: 'Two distinct real roots: Δ > 0.', errors: [{ value: b * b, tag: 'forgot-4ac', fb: 'Δ = b² − 4ac: remember the 4.' }], verify: `solve(Eq(${b}**2-4*k,0),k)[0]` },
        { command: 'Solve', prompt: `$x^{2} - ${2 * p}x ${sgn(q)} = 0$, giving your answers in exact form.`, marks: 3, answer: { kind: 'list', value: [p + Math.sqrt(s), p - Math.sqrt(s)], exact: true, markEach: true, display: `x = ${p} \\pm \\sqrt{${s}}` },
          ms: [['M1', `$x = \\frac{${2 * p} \\pm \\sqrt{${4 * p * p} - 4(${q})}}{2}$`], ['A1', `$\\frac{${2 * p} \\pm \\sqrt{${4 * s}}}{2}$`], ['A1', `$${p} \\pm \\sqrt{${s}}$`]],
          working: [`$x = \\frac{-b \\pm \\sqrt{b^{2} - 4ac}}{2a} = \\frac{${2 * p} \\pm \\sqrt{${4 * s}}}{2}$`, `$= \\frac{${2 * p} \\pm 2\\sqrt{${s}}}{2} = ${p} \\pm \\sqrt{${s}}$`],
          hint: 'Use the quadratic formula and simplify the surd. Type answers like 3+sqrt(5).', errors: [], verify: `solve(x**2-${2 * p}*x+(${q}),x)` }
      ]
    };
  });

  /* ---------- 3.7 Applications of quadratics ---------- */
  reg('sl.quadapp', { skill: 'SL-3.7', title: 'Quadratic models: projectile', paper: 2 }, R => {
    const v = R.int(12, 28), h0 = R.pick([1.2, 1.5, 1.8, 2]), H = h0 + v * v / 19.6, tm = v / 9.8;
    const tg = (v + Math.sqrt(v * v + 4 * 4.9 * h0)) / 9.8;
    return {
      stem: `A ball is thrown upwards. Its height, in metres, after $t$ seconds is $h(t) = -4.9t^{2} + ${v}t + ${h0}$.`,
      parts: [
        { command: 'Write down', prompt: 'the height from which the ball is thrown.', marks: 1, answer: { kind: 'num', value: h0, display: `${h0}\\text{ m}` }, ms: [['A1', `$${h0}$ m`]], working: ['$h(0)$'], hint: 'What happens when t = 0?', verify: `${h0}` },
        { command: 'Find', prompt: 'the maximum height of the ball.', marks: 2, answer: { kind: 'num', value: H, sf: 3, display: `${num(sf(H, 3))}\\text{ m}` }, ms: [['(M1)', `$t = \\frac{${v}}{9.8}$ or NumWorks maximum`], ['A1', `$${num(sf(H, 3))}$ m`]],
          working: [`Vertex at $t = -\\frac{b}{2a} = \\frac{${v}}{9.8} = ${num(sf(tm, 4))}$`, `$h = ${num(sf(H, 3))}$ m`], hint: 'Use the axis of symmetry or the NumWorks Grapher (Maximum).', numworks: { app: 'Grapher', lines: [[`y=-4.9x^2+${v}x+${h0}`, ''], ['Maximum', `x=${num(sf(tm, 4))}  y=${num(sf(H, 4))}`]] },
          errors: [{ value: tm, tag: 'time-not-height', fb: 'That is the TIME of the maximum. The question asks for the height.' }], verify: `maximum(-Rational(49,10)*t**2+${v}*t+Rational(${Math.round(h0 * 10)},10),t)` },
        { command: 'Find', prompt: 'the time at which the ball hits the ground.', marks: 2, answer: { kind: 'num', value: tg, sf: 3, display: `${num(sf(tg, 3))}\\text{ s}` }, ms: [['(M1)', '$h(t) = 0$'], ['A1', `$t = ${num(sf(tg, 3))}$ s`]],
          working: [`Solve $-4.9t^{2} + ${v}t + ${h0} = 0$ on the NumWorks`, `Reject the negative root: $t = ${num(sf(tg, 3))}$ s`], hint: 'The ground is h = 0. Which root makes sense?', numworks: { app: 'Equations', lines: [[`-4.9x^2+${v}x+${h0}=0`, `x=${num(sf(tg, 4))}`]] },
          errors: [{ value: 2 * tm, tag: 'ignored-start-height', fb: 'The ball starts above the ground, so it lands slightly after 2 × (time to the top).' }], verify: `max(solve(-Rational(49,10)*t**2+${v}*t+Rational(${Math.round(h0 * 10)},10),t))` }
      ]
    };
  });

  /* ---------- 4 Rational functions ---------- */
  reg('sl.rational', { skill: 'SL-4.1', title: 'Rational functions: asymptotes and intercepts', paper: 1 }, R => {
    let a, b, c, d; do { a = R.nz(-5, 6); b = R.nz(-8, 8); c = R.pick([1, 2, 3, -1, -2]); d = R.nz(-6, 6); } while (a * d === b * c);
    return {
      stem: `Let $f(x) = \\frac{${lin(a, b)}}{${lin(c, d)}}$, $x \\ne ${fr(-d, c).tex()}$.`,
      parts: [
        { command: 'Write down', prompt: 'the equation of the vertical asymptote.', marks: 1, answer: { kind: 'num', value: -d / c, exact: true, display: `x = ${fr(-d, c).tex()}` }, ms: [['A1', `$x = ${fr(-d, c).tex()}$`]], working: [`Denominator zero: $${lin(c, d)} = 0$`], hint: 'Where is the denominator zero?', errors: [{ value: d / c, tag: 'sign', fb: 'Solve cx + d = 0 carefully.' }], verify: `solve(${c}*x+(${d}),x)[0]` },
        { command: 'Write down', prompt: 'the equation of the horizontal asymptote.', marks: 1, answer: { kind: 'num', value: a / c, exact: true, display: `y = ${fr(a, c).tex()}` }, ms: [['A1', `$y = ${fr(a, c).tex()}$`]], working: [`For large $|x|$: $f(x) \\to \\frac{${a}}{${c}}$`], hint: 'Compare the coefficients of x.', errors: [{ value: b / d, tag: 'constants-not-leading', fb: 'Use the coefficients of x (the leading terms), not the constants.' }], verify: `limit((${a}*x+(${b}))/(${c}*x+(${d})),x,oo)` },
        { command: 'Find', prompt: 'the coordinates of the $x$-intercept.', marks: 1, answer: { kind: 'num', value: -b / a, exact: true, display: `\\left(${fr(-b, a).tex()},\\,0\\right)` }, ms: [['A1', `$x = ${fr(-b, a).tex()}$`]], working: [`Numerator zero: $${lin(a, b)} = 0$`], hint: 'A fraction is zero when its numerator is zero.', verify: `solve(${a}*x+(${b}),x)[0]` },
        { command: 'Find', prompt: 'the $y$-intercept.', marks: 1, answer: { kind: 'num', value: b / d, exact: true, display: fr(b, d).tex() }, ms: [['A1', `$${fr(b, d).tex()}$`]], working: [`$f(0) = \\frac{${b}}{${d}}$`], hint: 'Set x = 0.', verify: `Rational(${b},${d})` }
      ]
    };
  });

  /* ---------- 5 Differentiation ---------- */
  reg('sl.deriv', { skill: 'SL-5.2', title: 'Derivatives, tangents and normals', paper: 1 }, R => {
    let a, n, b, p; do { a = R.pick([1, 2, 3]); n = R.pick([2, 3]); b = R.pick([-8, -6, -4, 4, 6, 8]); p = R.pick([1, 2, -1, -2]); } while (a * n * Math.pow(p, n - 1) * p * p === b);
    const y0 = fr(a * Math.pow(p, n)).add(fr(b, p)), mF = fr(a * n * Math.pow(p, n - 1)).sub(fr(b, p * p)), c = y0.sub(mF.mul(p));
    return {
      stem: `Let $f(x) = ${a === 1 ? '' : a}x^{${n}} ${sgn(b).replace(/(\d+)$/, '\\frac{$1}{x}')}$, $x \\ne 0$.`,
      parts: [
        { command: 'Find', prompt: `$f'(x)$ and hence $f'(${p})$.`, marks: 3, answer: { kind: 'num', value: mF.val(), exact: true, display: mF.tex() },
          ms: [['A1', `$${a * n}x^{${n - 1}}$`], ['A1', `$${-b < 0 ? '-' : ''}${Math.abs(b)}x^{-2}$`], ['A1', `$f'(${p}) = ${mF.tex()}$`]],
          working: [`$f(x) = ${a === 1 ? '' : a}x^{${n}} ${sgn(b)}x^{-1}$`, `$f'(x) = ${a * n}x^{${n - 1}} ${sgn(-b)}x^{-2}$`, `$f'(${p}) = ${mF.tex()}$`], hint: 'Rewrite $\\frac{b}{x}$ as $bx^{-1}$ before differentiating.',
          errors: [{ value: a * n * Math.pow(p, n - 1) + b / (p * p), tag: 'power-rule-negative', fb: '$\\frac{d}{dx}(x^{-1}) = -x^{-2}$: the power rule brings down $-1$.' }], verify: `diff(${a}*x**${n}+Rational(${b})/x,x).subs(x,${p})` },
        { command: 'Find', prompt: `the equation of the tangent to the curve at $x = ${p}$, in the form $y = mx + c$.`, marks: 3, answer: { kind: 'tuple', labels: ['m', 'c'], value: [mF.val(), c.val()], exact: true, markEach: true, display: `y = ${poly([[mF, 'x'], [c, '']])}` },
          ms: [['A1', `$f(${p}) = ${y0.tex()}$`], ['M1', `$y - ${paren(y0)} = ${mF.tex()}(x - ${paren(p)})$`], ['A1', `$y = ${poly([[mF, 'x'], [c, '']])}$`]],
          working: [`Point: $(${p},\\,${y0.tex()})$, gradient $${mF.tex()}$`, `$y - ${paren(y0)} = ${mF.tex()}(x - ${paren(p)})$`, `$y = ${poly([[mF, 'x'], [c, '']])}$`], hint: 'You need a point (use f) and a gradient (use f′).',
          errors: [], verify: `(diff(${a}*x**${n}+Rational(${b})/x,x).subs(x,${p}), (${a}*x**${n}+Rational(${b})/x).subs(x,${p}) - diff(${a}*x**${n}+Rational(${b})/x,x).subs(x,${p})*(${p}))` },
        { command: 'Write down', prompt: `the gradient of the normal at $x = ${p}$.`, marks: 1, answer: { kind: 'num', value: -1 / mF.val(), exact: true, display: fr(-1).div(mF).tex() }, ms: [['A1', `$${fr(-1).div(mF).tex()}$`]], working: ['Normal gradient $= -\\frac{1}{m}$'], hint: 'The normal is perpendicular to the tangent.',
          errors: [{ value: 1 / mF.val(), tag: 'reciprocal-no-sign', fb: 'Negative reciprocal: flip AND change sign.' }], verify: `-1/diff(${a}*x**${n}+Rational(${b})/x,x).subs(x,${p})` }
      ]
    };
  });

  reg('sl.stationary', { skill: 'SL-5.4', title: 'Stationary points and their nature', paper: 1 }, R => {
    let s1, s2; do { [s1, s2] = R.distinct(2, -4, 5); } while ((s1 + s2) % 2 !== 0); if (s1 > s2) [s1, s2] = [s2, s1];
    const b = -3 * (s1 + s2) / 2, c = 3 * s1 * s2, d = R.int(-5, 5);
    return {
      stem: `The curve $y = ${poly([[1, 'x^{3}'], [b, 'x^{2}'], [c, 'x'], [d, '']])}$ has two stationary points.`,
      parts: [
        { command: 'Find', prompt: 'the $x$-coordinates of the stationary points.', marks: 3, answer: { kind: 'list', value: [s1, s2], exact: true, markEach: true, display: `x = ${s1},\\ x = ${s2}` },
          ms: [['M1', `$\\frac{dy}{dx} = ${poly([[3, 'x^{2}'], [2 * b, 'x'], [c, '']])} = 0$`], ['A1', `$x = ${s1}$`], ['A1', `$x = ${s2}$`]], working: [`$\\frac{dy}{dx} = ${poly([[3, 'x^{2}'], [2 * b, 'x'], [c, '']])}$`, `$3(x ${sgn(-s1)})(x ${sgn(-s2)}) = 0$`],
          hint: 'Stationary points: $\\frac{dy}{dx} = 0$.', errors: [], verify: `solve(diff(x**3+(${b})*x**2+(${c})*x+(${d}),x),x)` },
        { command: 'Find', prompt: `the value of $\\frac{d^{2}y}{dx^{2}}$ at $x = ${s1}$.`, marks: 1, answer: { kind: 'num', value: 6 * s1 + 2 * b, exact: true, display: String(6 * s1 + 2 * b) }, ms: [['A1', `$${6 * s1 + 2 * b}$`]], working: [`$\\frac{d^{2}y}{dx^{2}} = 6x ${sgn(2 * b)}$`], hint: 'Differentiate $\\frac{dy}{dx}$ again.', verify: `diff(x**3+(${b})*x**2+(${c})*x+(${d}),x,2).subs(x,${s1})` },
        { command: 'Hence', dep: true, prompt: `state the nature of the stationary point at $x = ${s1}$.`, marks: 1, answer: Object.assign(mc(R, [{ tex: 'Local maximum', key: 'max' }, { tex: 'Local minimum', key: 'min' }, { tex: 'Point of inflection', key: 'inf' }], 'max'), { display: 'Local maximum' }),
          ms: [['R1', `$\\frac{d^{2}y}{dx^{2}} < 0$ so local maximum`]], working: ['Second derivative negative ⇒ concave down ⇒ local maximum.'], hint: 'Negative second derivative: concave down.', verify: `'max' if diff(x**3+(${b})*x**2+(${c})*x,x,2).subs(x,${s1})<0 else 'min'` }
      ]
    };
  });

  reg('sl.optim', { skill: 'SL-5.5', title: 'Optimisation: fencing against a wall', paper: 1 }, R => {
    const L = 4 * R.int(10, 50), x = L / 4, A = L * L / 8;
    return {
      stem: `A rectangular pen is built against a long straight wall. Fencing is used for the other three sides; the total length of fencing is $${L}$ m. The two sides perpendicular to the wall each have length $x$ m.`,
      parts: [
        { command: 'Show that', prompt: `the area of the pen is $A = ${L}x - 2x^{2}$.`, marks: 2, answer: { kind: 'open', display: 'See markscheme' }, ms: [['M1', `side parallel to wall $= ${L} - 2x$`], ['AG', `$A = x(${L} - 2x) = ${L}x - 2x^{2}$`]], working: [`Length along the wall $= ${L} - 2x$`, `$A = x(${L} - 2x) = ${L}x - 2x^{2}$`], hint: 'Two sides of length x use up 2x of the fencing.', verify: `expand(x*(${L}-2*x)-(${L}*x-2*x**2))==0` },
        { command: 'Find', dep: true, prompt: 'the value of $x$ that maximises the area.', marks: 3, answer: { kind: 'num', value: x, exact: true, display: String(x) }, ms: [['M1', `$\\frac{dA}{dx} = ${L} - 4x$`], ['M1', '$\\frac{dA}{dx} = 0$'], ['A1', `$x = ${x}$`]], working: [`$\\frac{dA}{dx} = ${L} - 4x = 0 \\Rightarrow x = ${x}$`], hint: 'Differentiate and set equal to zero.', verify: `solve(diff(${L}*x-2*x**2,x),x)[0]` },
        { command: 'Find', dep: true, prompt: 'the maximum area.', marks: 1, answer: { kind: 'num', value: A, exact: true, display: `${A}\\text{ m}^{2}` }, ms: [['A1', `$${A}$ m²`]], working: [`$A = ${L}(${x}) - 2(${x})^{2} = ${A}$`], hint: 'Substitute your x into A.', errors: [{ value: x, tag: 'x-not-area', fb: 'That is the value of x. Substitute it into A.' }], verify: `(${L}*x-2*x**2).subs(x,${x})` }
      ]
    };
  });

  /* ---------- 6–7 Statistics ---------- */
  reg('sl.stats', { skill: 'SL-6.3', title: 'Mean, median, standard deviation and outliers (NumWorks)', paper: 2 }, R => {
    const n = R.pick([8, 9, 10]), data = Array.from({ length: n }, () => R.int(10, 40)).sort((a, b) => a - b);
    const mean = data.reduce((s, v) => s + v, 0) / n, med = n % 2 ? data[(n - 1) / 2] : (data[n / 2 - 1] + data[n / 2]) / 2;
    const sd = Math.sqrt(data.reduce((s, v) => s + (v - mean) ** 2, 0) / n), Q1 = R.int(14, 20), Q3 = Q1 + R.int(6, 12), fence = Q3 + 1.5 * (Q3 - Q1);
    return {
      stem: `The number of minutes that ${n} students spent on homework one evening is recorded:\n$${data.join(',\\ ')}$`,
      parts: [
        { command: 'Find', prompt: 'the mean.', marks: 1, answer: { kind: 'num', value: mean, sf: 3, display: num(sf(mean, 3)) }, ms: [['A1', `$${num(sf(mean, 4))}$`]], working: [`$\\bar{x} = \\frac{${data.reduce((s, v) => s + v, 0)}}{${n}}$`], hint: 'NumWorks: Statistics app, enter the list, then Stats.', numworks: { app: 'Statistics', lines: [['Mean', num(sf(mean, 6))], ['Median', num(med)], ['Standard deviation σ', num(sf(sd, 6))]] }, verify: `Rational(${data.reduce((s, v) => s + v, 0)},${n})` },
        { command: 'Write down', prompt: 'the median.', marks: 1, answer: { kind: 'num', value: med, exact: true, display: num(med) }, ms: [['A1', `$${num(med)}$`]], working: [`Middle of the ordered list (position $\\frac{${n} + 1}{2}$)`], hint: 'The data is already in order.', verify: `median([${data.join(',')}])` },
        { command: 'Find', prompt: 'the standard deviation.', marks: 2, answer: { kind: 'num', value: sd, sf: 3, display: num(sf(sd, 3)) }, ms: [['(M1)', 'use of GDC'], ['A1', `$${num(sf(sd, 3))}$`]], working: [`NumWorks σ $= ${num(sf(sd, 4))}$`], hint: 'Use σ (population standard deviation), as in IB.', verify: `sqrt(sum((v-Rational(${data.reduce((s, v) => s + v, 0)},${n}))**2 for v in [${data.join(',')}])/${n})` },
        { command: 'Calculate', prompt: `For a different data set, $Q_1 = ${Q1}$ and $Q_3 = ${Q3}$. Calculate the smallest value that would be an outlier above $Q_3$.`, marks: 2, answer: { kind: 'num', value: fence, exact: true, display: num(fence) },
          ms: [['M1', `$${Q3} + 1.5(${Q3} - ${Q1})$`], ['A1', `$${num(fence)}$`]], working: [`IQR $= ${Q3 - Q1}$`, `Upper fence $= Q_3 + 1.5\\times\\text{IQR} = ${num(fence)}$`], hint: 'Outliers lie more than 1.5 × IQR beyond the quartiles.', errors: [{ value: 1.5 * (Q3 - Q1), tag: 'forgot-q3', fb: 'Add 1.5 × IQR on to Q3.' }], verify: `${Q3}+Rational(3,2)*(${Q3}-${Q1})` }
      ]
    };
  });

  function regressionGen(R, skill) {
    const n = 6, slope = R.pick([1.5, 2, 2.5, -1.5, 3]), icpt = R.int(5, 20);
    const xs = R.distinct(n, 1, 14).sort((a, b) => a - b), ys = xs.map(x => Math.round(slope * x + icpt + R.int(-3, 3)));
    const mx = xs.reduce((s, v) => s + v, 0) / n, my = ys.reduce((s, v) => s + v, 0) / n;
    const sxy = xs.reduce((s, x, i) => s + (x - mx) * (ys[i] - my), 0), sxx = xs.reduce((s, x) => s + (x - mx) ** 2, 0), syy = ys.reduce((s, y) => s + (y - my) ** 2, 0);
    const a = sxy / sxx, b = my - a * mx, r = sxy / Math.sqrt(sxx * syy), x0 = R.int(xs[1], xs[n - 2]), pred = a * x0 + b;
    return {
      stem: `A scientist records $${n}$ pairs of measurements.\n$x$: $${xs.join(',\\ ')}$\n$y$: $${ys.join(',\\ ')}$`,
      parts: [
        { command: 'Find', prompt: 'the Pearson product-moment correlation coefficient, $r$.', marks: 2, answer: { kind: 'num', value: r, sf: 3, display: num(sf(r, 3)) }, ms: [['(M1)', 'use of GDC'], ['A1', `$${num(sf(r, 3))}$`]], working: [`NumWorks Regression → Linear: $r = ${num(sf(r, 4))}$`], hint: 'NumWorks: Regression app, enter x and y, choose Linear.', numworks: { app: 'Regression', lines: [['a', num(sf(a, 6))], ['b', num(sf(b, 6))], ['r', num(sf(r, 6))]] }, verify: `(${sxy})/sqrt((${sxx})*(${syy}))` },
        { command: 'Write down', prompt: 'the equation of the regression line of $y$ on $x$, in the form $y = ax + b$.', marks: 2, answer: { kind: 'tuple', labels: ['a', 'b'], value: [a, b], sf: 3, markEach: true, display: `y = ${num(sf(a, 3))}x ${sgn(sf(b, 3))}` }, ms: [['A1', `$a = ${num(sf(a, 3))}$`], ['A1', `$b = ${num(sf(b, 3))}$`]], working: ['From the NumWorks regression output.'], hint: 'Give each value to 3 significant figures.', errors: [], verify: `((${sxy})/(${sxx}), Rational(${ys.reduce((s, v) => s + v, 0)},${n}) - (${sxy})/(${sxx})*Rational(${xs.reduce((s, v) => s + v, 0)},${n}))` },
        { command: 'Use', dep: true, prompt: `your regression line to estimate $y$ when $x = ${x0}$.`, marks: 2, answer: { kind: 'num', value: pred, sf: 3, display: num(sf(pred, 3)) }, ms: [['M1', `$${num(sf(a, 3))}(${x0}) ${sgn(sf(b, 3))}$`], ['A1', `$${num(sf(pred, 3))}$`]], working: [`$y = ${num(sf(a, 6))}(${x0}) ${sgn(sf(b, 6))} = ${num(sf(pred, 4))}$`], hint: 'Substitute x into the line (use stored values, not rounded ones).', verify: `(${sxy})/(${sxx})*${x0} + Rational(${ys.reduce((s, v) => s + v, 0)},${n}) - (${sxy})/(${sxx})*Rational(${xs.reduce((s, v) => s + v, 0)},${n})` },
        { command: 'Explain', prompt: `why it would not be reliable to use the line to estimate $y$ when $x = ${xs[n - 1] + 15}$.`, marks: 1, answer: Object.assign(mc(R, [{ tex: 'It is extrapolation: outside the range of the data', key: 'extrap' }, { tex: 'The correlation is negative', key: 'neg' }, { tex: 'There are too many data points', key: 'many' }, { tex: 'The line does not pass through the origin', key: 'origin' }], 'extrap'), { display: 'Extrapolation' }),
          ms: [['R1', `$x = ${xs[n - 1] + 15}$ is outside the data range (extrapolation)`]], working: [`The data run from $x = ${xs[0]}$ to $x = ${xs[n - 1]}$.`], hint: 'Compare the x-value with the data you were given.', verify: `'extrap' if ${xs[n - 1] + 15} > ${xs[n - 1]} else 'x'` }
      ]
    };
  }
  reg('sl.regression', { skill: 'SL-7.4', title: 'Correlation and regression (NumWorks)', paper: 2 }, R => regressionGen(R, 'SL-7.4'));
  Hub.qcore.regressionGen = regressionGen;
})(window.Hub = window.Hub || {});
