/* Printable worksheets and answer keys for anything built in the Assessment Studio
   (Exit Ticket, Quiz, Homework, Unit test, Retest). Route: #/print/<id>?key=1&mc=1&space=large&two=1
   House rules: title on one line, then Name · Block · A day / B day tick · Date on one line; no school or district
   name; no source lines; big working boxes sized by marks; a question is never split across two pages;
   fractions stay stacked (MathML); every worksheet has an answer key with the M/A/R markscheme. */
(function (Hub) {
  'use strict';
  const { esc, $, $$ } = Hub.core, U = Hub.ui, C = () => Hub.curriculum, M = t => Hub.math.render(t);
  const go = h => Hub.app.nav(h);
  const SECTION = { 1: ['A', 'Paper 1 style', 'No calculator'], 2: ['B', 'Paper 2 style', 'NumWorks calculator allowed'], 3: ['C', 'Paper 3 style', 'Extended response'] };
  const SPACE = { compact: [1.3, 0.65, 7], large: [2.2, 1.1, 11], xl: [3, 1.5, 14] }; // cm: base + per mark, cap
  const LETTERS = 'ABCDEF';
  const blockFor = course => (Object.values(C().GROUPS).find(g => g.course === course) || {}).block || '';
  const total = qs => qs.reduce((s, q) => s + q.marks, 0);
  const isTest = a => a.type === 'Unit test' || a.type === 'Retest';

  /** Title on ONE line: the font shrinks for long titles instead of wrapping. */
  function titleLine(text, tag = 'h1', max = 26) {
    const px = Math.max(13, Math.min(max, Math.floor(720 / (Math.max(18, text.length) * 0.5))));
    return `<${tag} class="ws-title" style="font-size:${px}px">${esc(text)}</${tag}>`;
  }
  const nameLine = a => `<div class="ws-line"><span>Name: <i class="fill f-name"></i></span><span>Block: <b>${esc(blockFor(a.course).replace('Block ', '')) || '<i class="fill f-short"></i>'}</b></span><span class="ab"><span class="tick"></span> A day <span class="tick"></span> B day</span><span>Date: <i class="fill f-date"></i></span></div>`;
  function header(a, o) {
    const t = o.key ? a.title + ' — Answer key' : a.title;
    return `<header class="ws-head">${titleLine(t)}${o.key ? `<div class="ws-line key-line"><span>AA ${a.course} · ${esc(a.type)}</span><span>Teacher copy</span><span>${total(o.qs)} marks</span>${a.cap ? `<span>Retest · capped at ${a.cap}%</span>` : ''}</div>` : nameLine(a)}</header>`;
  }
  /** Unit tests and retests: cover page in the HL Unit 1 style (badge, numbered instructions, Section/Marks/Score table). */
  function cover(a, o, sections) {
    const units = [...new Set(a.skills.map(s => (C().SKILL[s] || {}).unit).filter(Boolean))];
    const badge = (units.length === 1 ? `UNIT ${units[0]} ` : '') + (a.type === 'Retest' ? 'RETEST' : 'TEST');
    const papers = sections.map(([p]) => p), minutes = a.minutes || 60;
    const instr = [
      'Write your name and tick A day or B day.',
      'Answer <b>all</b> questions in the boxes provided. Show all your working: marks are given for correct method, even if the final answer is wrong.',
      papers.includes(1) ? '<b>Section A</b>: no calculator.' : '',
      papers.includes(2) ? '<b>Section B</b>: you may use your NumWorks calculator.' : '',
      papers.includes(3) ? '<b>Section C</b>: extended response. Explain your reasoning fully.' : '',
      'Unless a question says otherwise, answers must be exact or correct to three significant figures.',
      'You may use your one-page formula and vocabulary sheet.',
      a.type === 'Retest' ? `This is a retest. Your recorded score is capped at ${a.cap || 80}%.` : '',
      `There are <b>${total(o.qs)} marks</b>. You have about ${minutes} minutes.`
    ].filter(Boolean);
    return `<section class="sheet cover"><div class="cover-top"><img class="cover-logo" src="${Hub.LOGO}" alt=""><span class="cover-badge">${esc(badge)}</span></div>${titleLine(a.title, 'h1', 30)}${o.key ? '<p class="key-line ws-line"><span>Answer key</span><span>Teacher copy</span></p>' : nameLine(a)}
      <h2 class="cover-h">Instructions</h2><ol class="cover-ins">${instr.map(x => `<li>${x}</li>`).join('')}</ol>
      <table class="cover-table"><thead><tr><th>Section</th><th>Style</th><th>Marks</th><th>Score</th></tr></thead><tbody>${sections.map(([p, qs]) => `<tr><td><b>${SECTION[p][0]}</b></td><td>${SECTION[p][1]} · ${SECTION[p][2]}</td><td>${total(qs)}</td><td></td></tr>`).join('')}<tr class="tot"><td colspan="2"><b>Total</b></td><td><b>${total(o.qs)}</b></td><td></td></tr></tbody></table></section>`;
  }
  /** Which parts show A–D options: real multiple-choice parts always; converted homework parts only when asked. */
  const showOptions = (p, o) => p.answer.kind === 'mc' && (!p.wasNumeric || o.mc);
  function answerLine(p) {
    const a = p.answer;
    if (a.kind === 'open') return '';
    if (a.kind === 'tuple') return `<div class="ans-line">${a.labels.map(l => `<span>${M('$' + l + ' =$')} <i class="fill f-ans"></i></span>`).join('')}</div>`;
    if (a.kind === 'list') return `<div class="ans-line"><span>Answer: <i class="fill f-long"></i></span></div>`;
    return `<div class="ans-line"><span>Answer: <i class="fill f-ans"></i></span></div>`;
  }
  function workBox(p, o) {
    const [b, per, cap] = SPACE[o.space] || SPACE.large;
    const opts = showOptions(p, o);
    const h = (o.two ? Math.min(4, 1 + 0.45 * p.marks) : Math.min(cap, b + per * p.marks)) * (opts ? 0.6 : 1);
    return `<div class="work" style="min-height:${h.toFixed(2)}cm">${opts ? '' : answerLine(p)}</div>`;
  }
  function options(p) {
    return `<ol class="p-opts">${p.answer.choices.map((c, i) => `<li><span class="opt-l">${LETTERS[i]}</span> ${M(c)}</li>`).join('')}</ol>`;
  }
  function keyAnswer(p, o) {
    const a = p.answer;
    if (a.kind === 'mc') { const v = M(a.choices[a.correct]); return showOptions(p, o) ? `<b>${LETTERS[a.correct]}</b> · ${v}` : v; }
    return U.answerDisplay(p);
  }
  function keyBlock(p, o) {
    return `<div class="pk"><div class="pk-row"><span class="pk-lab">Answer</span><span class="pk-ans">${keyAnswer(p, o)}</span><span class="tiny muted">${p.wasNumeric && !o.mc ? 'Written answer' : U.accuracyText(p.answer)}</span></div>
      ${p.ms.length ? `<div class="pk-ms">${p.ms.map(([m, t]) => `<div class="ms-line"><b class="ms-mark">${esc(m)}</b> ${M(t)}</div>`).join('')}</div>` : ''}
      ${p.working.length ? `<div class="hand pk-hand">${p.working.map(w => `<div>${M(w)}</div>`).join('')}</div>` : ''}${p.numworks ? `<div class="pk-nw">${U.numworks(p.numworks)}</div>` : ''}</div>`;
  }
  function paperTag(q) { const s = SECTION[q.paper] || SECTION[1]; return `<span class="pq-paper p${q.paper || 1}">Paper ${q.paper || 1} · ${s[2]}</span>`; }
  function question(q, n, o, inSection) {
    return `<article class="pq${o.key ? ' pq-key' : ''}"><div class="pq-head"><span class="pq-n">${n}</span>${inSection ? '' : paperTag(q)}<span class="pq-marks">[${q.marks} mark${q.marks === 1 ? '' : 's'}]</span></div>
      ${q.stem ? `<div class="pq-stem">${M(q.stem)}</div>` : ''}
      ${q.parts.map(p => `<div class="pp"><div class="pp-q">${q.parts.length > 1 || p.label !== 'a' ? `<span class="pp-l">(${esc(p.label)})</span>` : ''}<div class="pp-t">${U.cmd(p.command)} ${M(p.prompt)}</div><span class="pp-m">[${p.marks}]</span></div>
        ${showOptions(p, o) ? options(p) : ''}${o.key ? keyBlock(p, o) : workBox(p, o)}</div>`).join('')}</article>`;
  }
  /** Group questions into Sections A/B/C by paper (tests always; quizzes when they mix papers). */
  function sectionsOf(qs) {
    const by = {}; qs.forEach(q => (by[q.paper || 1] = by[q.paper || 1] || []).push(q));
    return Object.keys(by).map(Number).sort().map(p => [p, by[p]]);
  }
  function sheetBody(a, o) {
    const qs = o.qs, secs = sectionsOf(qs), useSections = isTest(a) || (a.type === 'Quiz' && secs.length > 1);
    if (!useSections) return qs.map((q, i) => question(q, i + 1, o, false)).join('');
    let n = 0;
    return secs.map(([p, list], si) => `<section class="ws-sec${isTest(a) && si > 0 ? ' new-page' : ''}"><h2 class="sec-h"><span>Section ${SECTION[p][0]}</span> ${SECTION[p][1]} · ${SECTION[p][2]} · ${total(list)} marks</h2>${list.map(q => question(q, ++n, o, true)).join('')}</section>`).join('');
  }
  function sheets(a, o) {
    const secs = sectionsOf(o.qs);
    if (isTest(a)) {
      const ordered = secs.flatMap(([, l]) => l); o.qs = ordered;
      return cover(a, o, secs) + `<section class="sheet">${o.key ? header(a, o) : `<header class="ws-head mini">${titleLine(a.title, 'h2', 18)}<div class="ws-line"><span>Name: <i class="fill f-name"></i></span></div></header>`}${sheetBody(a, o)}</section>`;
    }
    if (o.two && !o.key) { const slip = `<div class="half">${header(a, o)}${sheetBody(a, o)}</div>`; return `<section class="sheet halves">${slip}<div class="cut" aria-hidden="true">✂</div>${slip}</section>`; }
    const intro = !o.key && a.type === 'Homework' ? `<p class="ws-intro">Show your working in each box${o.mc ? ', then circle the letter of your answer' : ' and write your final answer on the line'}. ${o.mc ? '' : 'The Canvas version has the same questions as multiple choice.'}</p>` : !o.key ? '<p class="ws-intro">Show your working in each box and write your final answer on the line.</p>' : '';
    return `<section class="sheet">${header(a, o)}${intro}${sheetBody(a, o)}</section>`;
  }

  function view(main, params) {
    const a = Hub.assess.byId(params.id);
    if (!a) { main.innerHTML = U.empty('That assessment no longer exists.', '<a class="btn" href="#/studio">Back to the studio</a>'); return; }
    const o = { key: params.key === '1', mc: params.mc === '1', space: SPACE[params.space] ? params.space : 'large', two: params.two === undefined ? a.type === 'Exit Ticket' : params.two === '1', qs: a.questions.slice() };
    if (o.key) o.two = false;
    const hasConverted = a.questions.some(q => q.parts.some(p => p.wasNumeric)), canTwo = !isTest(a) && !o.key;
    const link = ch => { const p = Object.assign({ key: o.key ? '1' : '0', mc: o.mc ? '1' : '0', space: o.space, two: o.two ? '1' : '0' }, ch); return `#/print/${a.id}?` + new URLSearchParams(p).toString(); };
    const unreviewed = a.status === 'draft' && a.questions.some(q => !a.reviewed[q.id]);
    main.innerHTML = `<div class="no-print print-bar">
        <div class="row-between"><a class="back" href="#/edit/${a.id}">← Back to the editor</a><span class="pill">${esc(a.type)} · AA ${a.course}</span></div>
        <h1 class="print-h">Print: ${esc(a.title)}</h1>
        ${unreviewed ? '<div class="notice preview">This is still a draft with unreviewed questions. Check them in the editor before printing for students.</div>' : ''}
        <div class="print-ctl">
          <div class="seg" role="group" aria-label="Version"><a class="seg-b ${o.key ? '' : 'on'}" href="${link({ key: '0' })}" aria-current="${!o.key}">Student worksheet</a><a class="seg-b ${o.key ? 'on' : ''}" href="${link({ key: '1' })}" aria-current="${o.key}">Answer key</a></div>
          ${hasConverted ? `<label class="inline-check"><input type="checkbox" id="pr-mc" ${o.mc ? 'checked' : ''}> Include the multiple-choice options (as on Canvas)</label>` : ''}
          ${canTwo ? `<label class="inline-check"><input type="checkbox" id="pr-two" ${o.two ? 'checked' : ''}> Two per page (cut in half)</label>` : ''}
          ${o.key ? '' : `<label class="inline">Working space <select id="pr-space"><option value="compact" ${o.space === 'compact' ? 'selected' : ''}>Compact</option><option value="large" ${o.space === 'large' ? 'selected' : ''}>Large</option><option value="xl" ${o.space === 'xl' ? 'selected' : ''}>Extra large</option></select></label>`}
          ${Hub.HOST === 'artifact' ? '<span class="tiny muted">Printing works in the hosted Hub (Ctrl+P / ⌘P).</span>' : '<button class="btn primary" id="pr-go" type="button">🖨 Print</button>'}
        </div>
        <p class="tiny muted">To keep a PDF, choose <b>Save as PDF</b> as the printer. US Letter. ${isTest(a) ? 'Questions are grouped into Sections by paper; numbers follow the printed order.' : ''}</p>
        <p class="tiny muted" id="pr-warn" hidden></p>
      </div>
      <div class="print-root ${o.key ? 'is-key' : ''}">${sheets(a, o)}</div>`;
    const mc = $('#pr-mc'); if (mc) mc.onchange = () => go(link({ mc: mc.checked ? '1' : '0' }));
    const two = $('#pr-two'); if (two) two.onchange = () => go(link({ two: two.checked ? '1' : '0' }));
    const sp = $('#pr-space'); if (sp) sp.onchange = () => go(link({ space: sp.value }));
    const pg = $('#pr-go'); if (pg) pg.onclick = () => window.print();
    // Two-per-page only if one copy really fits in half a page; otherwise fall back to one per page.
    if (o.two) requestAnimationFrame(() => { const h = $('.half'); if (h && h.scrollHeight > h.clientHeight + 4) { const s = $('.sheet.halves'); s.classList.remove('halves'); $$('.half', s).slice(1).forEach(x => x.remove()); $$('.half', s).forEach(x => x.classList.remove('half')); const c = $('.cut', s); if (c) c.remove(); const w = $('#pr-warn'); w.hidden = false; w.textContent = 'This one is too long for half a page, so it prints one per page.'; } });
  }
  Hub.print = { view, sheets };
})(window.Hub = window.Hub || {});
