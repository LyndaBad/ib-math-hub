/* Assessment lifecycle and marking.
   draft → (every question reviewed) → approved → published to chosen groups → closed/archived.
   Editing or regenerating any question withdraws its review tick; editing an approved assessment returns it to draft.
   Published assessments are locked (duplicate to change). Teacher previews never create attempts or evidence. */
(function (Hub) {
  'use strict';
  const { uid, toCSV, pct } = Hub.core;
  const S = () => Hub.store.state, A = id => S().assessments.find(a => a.id === id);
  const TYPES = {
    'Exit Ticket': { count: 2, upload: false, release: 'auto', minutes: 8 },
    'Quiz': { count: 4, upload: true, release: 'hold', minutes: 25 },
    'Homework': { count: 5, upload: false, release: 'auto', minutes: 40, mc: true },
    'Unit test': { count: 8, upload: true, release: 'hold', minutes: 60 },
    'Retest': { count: 6, upload: true, release: 'hold', minutes: 60 }
  };
  const hist = (a, what) => { a.history = a.history || []; a.history.push({ at: new Date().toISOString(), who: Hub.auth.who(), what }); };

  /* ---------- values as TeX (for multiple-choice options) ---------- */
  function valueTex(v) {
    if (Number.isInteger(v)) return String(v);
    for (let q = 2; q <= 200; q++) { const p = Math.round(v * q); if (Math.abs(v - p / q) < 1e-9) return Hub.qcore.fr(p, q).tex(); }
    const s2 = v * v; if (Math.abs(s2 - Math.round(s2)) < 1e-9 && Math.round(s2) < 1000) return (v < 0 ? '-' : '') + `\\sqrt{${Math.round(s2)}}`;
    return Hub.qcore.num(Hub.qcore.sf(v, 4));
  }
  /** Convert a numeric part into multiple choice; distractors come from its known misconceptions. */
  function toMC(part, seed) {
    if (part.answer.kind !== 'num') return part;
    const R = Hub.qcore.rng(seed), key = part.answer.value, vals = [key];
    (part.errors || []).forEach(e => { const v = Array.isArray(e.value) ? e.value[0] : e.value; if (Number.isFinite(v) && !vals.some(x => Math.abs(x - v) < 1e-9)) vals.push(v); });
    const tweak = [k => -k, k => k + 1, k => k - 1, k => 2 * k, k => k / 2, k => k + 2];
    for (let g = 0; vals.length < 4 && g < 40; g++) { const v = R.pick(tweak)(key); if (Number.isFinite(v) && !vals.some(x => Math.abs(x - v) < 1e-9)) vals.push(v); }
    const opts = vals.slice(0, 4).map((v, i) => ({ tex: '$' + (i === 0 && part.answer.display && !/[a-z]{3,}|=|\\le|\\ge|<|>/i.test(part.answer.display) ? part.answer.display : valueTex(v)) + '$', key: 'v' + i, v }));
    const m = Hub.qcore.mc(R, opts, 'v0');
    const errors = (part.errors || []).map(e => { const v = Array.isArray(e.value) ? e.value[0] : e.value; const k = opts.find(o => Math.abs(o.v - v) < 1e-9); return k ? { choice: m.keys.indexOf(k.key), tag: e.tag, fb: e.fb } : null; }).filter(Boolean);
    return Object.assign({}, part, { answer: Object.assign(m, { display: part.answer.display }), errors, wasNumeric: true });
  }

  /* ---------- drafts ---------- */
  function pickGenerators(skills, paper) {
    const gens = skills.flatMap(id => (Hub.curriculum.SKILL[id] || { gens: [] }).gens);
    return gens.filter(g => { const r = Hub.qcore.registry[g]; return r && (paper !== 'P1' || r.paper === 1); });
  }
  function createDraft(o) {
    const t = TYPES[o.type] || TYPES.Quiz, gens = pickGenerators(o.skills, o.paper);
    if (!gens.length) return { ok: false, error: o.paper === 'P1' ? 'No Paper 1 (non-calculator) questions exist for that selection yet. Try Mixed.' : 'Choose at least one skill.' };
    const n = Math.max(1, Math.min(12, Number(o.count) || t.count)), qs = [];
    for (let i = 0; i < n; i++) qs.push(buildQ(gens[i % gens.length], o.rigour === 'challenge', o.type === 'Homework' || o.mc));
    const a = { id: uid('a'), course: o.course, title: o.title || defaultTitle(o), type: o.type, lessonDate: o.lessonDate || null, skills: o.skills.slice(), paper: o.paper || 'Mixed', rigour: o.rigour || 'standard',
      questions: qs, reviewed: {}, status: 'draft', version: 1, groups: o.groups || [], uploadRequired: t.upload, release: t.release, minutes: t.minutes, due: null, retestOf: o.retestOf || null, cap: o.type === 'Retest' ? 80 : null, createdAt: new Date().toISOString(), history: [] };
    hist(a, 'Draft generated'); S().assessments.unshift(a); Hub.store.log(`Generated draft “${a.title}”`); Hub.store.save(); return { ok: true, assessment: a };
  }
  function defaultTitle(o) { const sk = o.skills.map(id => Hub.curriculum.SKILL[id]).filter(Boolean); return `${o.course} · ${sk.length === 1 ? sk[0].ox ? sk[0].ox + ' ' + sk[0].name : sk[0].name : 'Unit ' + (sk[0] ? sk[0].unit : '')} · ${o.type}`; }
  function buildQ(gen, challenge, mcOnly) {
    const seed = Math.floor(Math.random() * 1e6) + 1, q = Hub.qcore.build(gen, seed, { challenge });
    if (mcOnly) q.parts = q.parts.filter(p => p.answer.kind !== 'open').map((p, i) => toMC(p, seed + i));
    q.marks = q.parts.reduce((s, p) => s + p.marks, 0); return q;
  }
  function edited(a, qid, what) {
    if (qid) delete a.reviewed[qid];
    if (a.status === 'approved') { a.status = 'draft'; hist(a, 'Edited after approval — approval withdrawn'); }
    hist(a, what); Hub.store.save();
  }
  function editable(a) { return a && (a.status === 'draft' || a.status === 'approved'); }
  function updatePart(aid, qid, pid, patch) {
    const a = A(aid); if (!editable(a)) return false; const q = a.questions.find(x => x.id === qid); const p = q && q.parts.find(x => x.id === pid); if (!p) return false;
    if ('prompt' in patch) p.prompt = patch.prompt;
    if ('marks' in patch) { p.marks = Math.max(1, Math.min(20, Number(patch.marks) || 1)); q.marks = q.parts.reduce((s, x) => s + x.marks, 0); }
    if ('answer' in patch) Object.assign(p.answer, patch.answer);
    if ('working' in patch) p.working = patch.working;
    if ('ms' in patch) p.ms = patch.ms;
    p.teacherEdited = true; edited(a, qid, `Edited Q${a.questions.indexOf(q) + 1}(${pid})`); return true;
  }
  function updateStem(aid, qid, stem) { const a = A(aid); if (!editable(a)) return false; const q = a.questions.find(x => x.id === qid); if (!q) return false; q.stem = stem; q.teacherEdited = true; edited(a, qid, `Edited Q${a.questions.indexOf(q) + 1} stem`); return true; }
  function regenerate(aid, qid) {
    const a = A(aid); if (!editable(a)) return false; const i = a.questions.findIndex(x => x.id === qid); if (i < 0) return false;
    a.questions[i] = buildQ(a.questions[i].gen, a.questions[i].challenge, a.type === 'Homework'); edited(a, qid, `Regenerated Q${i + 1} with new numbers`); return true;
  }
  function removeQ(aid, qid) { const a = A(aid); if (!editable(a) || a.questions.length < 2) return false; a.questions = a.questions.filter(x => x.id !== qid); edited(a, qid, 'Removed a question'); return true; }
  function addQ(aid, skillId) { const a = A(aid); if (!editable(a)) return false; const gens = pickGenerators([skillId], a.paper); if (!gens.length) return false; a.questions.push(buildQ(gens[0], a.rigour === 'challenge', a.type === 'Homework')); if (!a.skills.includes(skillId)) a.skills.push(skillId); edited(a, null, 'Added a question'); return true; }
  function setReviewed(aid, qid, on) { const a = A(aid); if (!editable(a)) return false; if (on) a.reviewed[qid] = new Date().toISOString(); else { delete a.reviewed[qid]; if (a.status === 'approved') { a.status = 'draft'; hist(a, 'Review withdrawn — approval withdrawn'); } } Hub.store.save(); return true; }
  /** Problems that block approval. */
  function problems(a) {
    const out = []; if (!a.title || !a.title.trim()) out.push('The assessment needs a title.');
    a.questions.forEach((q, i) => q.parts.forEach(p => {
      const tag = `Q${i + 1}(${p.id})`, an = p.answer;
      if (!p.prompt || !String(p.prompt).trim()) out.push(`${tag}: the question text is empty.`);
      if (!(p.marks > 0)) out.push(`${tag}: needs at least 1 mark.`);
      if (an.kind === 'num' && !Number.isFinite(an.value)) out.push(`${tag}: the answer key is not a number.`);
      if ((an.kind === 'tuple' || an.kind === 'list') && !(Array.isArray(an.value) && an.value.length && an.value.every(Number.isFinite))) out.push(`${tag}: every answer box needs a number.`);
      if (an.kind === 'mc' && !(an.correct >= 0 && an.correct < an.choices.length)) out.push(`${tag}: choose the correct option.`);
    }));
    const unrev = a.questions.filter(q => !a.reviewed[q.id]).length; if (unrev) out.push(`${unrev} question${unrev > 1 ? 's' : ''} still to review.`);
    return out;
  }
  function approve(aid) { const a = A(aid); if (!a || a.status !== 'draft') return { ok: false, error: 'Only drafts can be approved.' }; const pr = problems(a); if (pr.length) return { ok: false, error: pr[0] }; a.status = 'approved'; a.approvedAt = new Date().toISOString(); a.version++; hist(a, `Approved (version ${a.version})`); Hub.store.log(`Approved “${a.title}”`); Hub.store.save(true); return { ok: true }; }
  function publish(aid, o) {
    const a = A(aid); if (!a || a.status !== 'approved') return { ok: false, error: 'Approve the assessment before publishing.' };
    if (!o.groups || !o.groups.length) return { ok: false, error: 'Choose at least one group.' };
    if (o.groups.some(g => Hub.curriculum.GROUPS[g].course !== a.course)) return { ok: false, error: `This is a ${a.course} assessment: publish it to ${a.course} groups only.` };
    Object.assign(a, { groups: o.groups.slice(), due: o.due || null, uploadRequired: !!o.uploadRequired, release: o.release === 'auto' ? 'auto' : 'hold', minutes: Number(o.minutes) || a.minutes, status: 'published', publishedAt: new Date().toISOString() });
    hist(a, `Published to ${o.groups.map(g => Hub.curriculum.GROUPS[g].label).join(', ')}`); Hub.store.log(`Published “${a.title}”`); Hub.store.save(true); return { ok: true };
  }
  function unpublish(aid) { const a = A(aid); if (!a || a.status !== 'published') return { ok: false }; if (S().attempts.some(t => t.aid === aid)) return { ok: false, error: 'Students have already submitted. Close it instead.' }; a.status = 'approved'; hist(a, 'Unpublished'); Hub.store.save(true); return { ok: true }; }
  function close(aid) { const a = A(aid); if (!a || a.status !== 'published') return { ok: false }; a.status = 'closed'; hist(a, 'Closed to new submissions'); Hub.store.save(true); return { ok: true }; }
  function archive(aid) { const a = A(aid); if (!a) return { ok: false }; a.status = 'archived'; hist(a, 'Archived'); Hub.store.save(true); return { ok: true }; }
  function duplicate(aid, asRetest) {
    const src = A(aid); if (!src) return null;
    const qs = asRetest ? src.questions.map(q => buildQ(q.gen, q.challenge, src.type === 'Homework')) : JSON.parse(JSON.stringify(src.questions)).map(q => Object.assign(q, { id: uid('q') }));
    const a = Object.assign(JSON.parse(JSON.stringify(src)), { id: uid('a'), questions: qs, reviewed: {}, status: 'draft', version: 1, createdAt: new Date().toISOString(), approvedAt: null, publishedAt: null, history: [] });
    if (asRetest) Object.assign(a, { type: 'Retest', title: src.title.replace(/ · [^·]+$/, '') + ' · Retest', retestOf: src.id, cap: 80, uploadRequired: true, release: 'hold' });
    else a.title = src.title + ' (copy)';
    hist(a, asRetest ? `Retest drafted from “${src.title}” with new numbers` : `Duplicated from “${src.title}”`); S().assessments.unshift(a); Hub.store.save(); return a;
  }
  function remove(aid) { const a = A(aid); if (!a || a.status !== 'draft') return false; S().assessments = S().assessments.filter(x => x.id !== aid); Hub.store.save(true); return true; }

  /* ---------- student side ---------- */
  function score(t) { const e = t.final ? t.final.earned : t.auto.earned, m = t.max; const p = pct(e, m); const a = A(t.aid); return { earned: e, max: m, pct: p, capped: a && a.cap && p !== null ? Math.min(p, a.cap) : p }; }
  function attemptsFor(aid, sid) { return S().attempts.filter(t => t.aid === aid && t.sid === sid).sort((x, y) => x.at < y.at ? -1 : 1); }
  /** Published assessments a student can see now. Retests appear only for students below 80 % on the original. */
  function forStudent(sid) {
    const st = Hub.roster.byId(sid); if (!st) return [];
    return S().assessments.filter(a => a.status === 'published' && a.groups.includes(st.group)).filter(a => {
      if (a.type !== 'Retest' || !a.retestOf) return true;
      const orig = attemptsFor(a.retestOf, sid).filter(t => t.status === 'released').pop(); return !!orig && score(orig).pct < 80;
    });
  }
  const progressKey = (sid, aid) => sid + '|' + aid;
  function saveProgress(sid, aid, data) { if (Hub.auth.isPreview()) return; S().progress[progressKey(sid, aid)] = Object.assign({ updatedAt: new Date().toISOString() }, data); Hub.store.save(); }
  const getProgress = (sid, aid) => S().progress[progressKey(sid, aid)] || null;

  /** Mark responses against an assessment-like object {questions}. */
  function autoMark(questions, responses) {
    let earned = 0, max = 0; const parts = {};
    questions.forEach(q => q.parts.forEach(p => { const r = Hub.math.markPart(p, (responses[q.id] || {})[p.id]); parts[q.id + '|' + p.id] = r; max += p.marks; earned += r.earned; }));
    return { earned, max, parts };
  }
  /** Submit. Guarded against double clicks by token; previews return results without saving anything. */
  function submit(aid, sid, data, opts = {}) {
    const a = opts.assessment || A(aid); if (!a) return { ok: false, error: 'This assessment no longer exists.' };
    const preview = Hub.auth.isPreview() || opts.preview;
    const existing = !preview && data.token && S().attempts.find(t => t.token === data.token); if (existing) return { ok: true, attempt: existing, duplicate: true };
    if (!opts.assessment && !preview) {
      if (a.status !== 'published') return { ok: false, error: 'This assessment is not open.' };
      const st = Hub.roster.byId(sid); if (!st || !a.groups.includes(st.group)) return { ok: false, error: 'This assessment is not assigned to your group.' };
      if (attemptsFor(aid, sid).length && a.type !== 'Practice') return { ok: false, error: 'You have already submitted this. Your teacher can allow a retest.' };
      if (a.uploadRequired && !(data.uploads || []).length) return { ok: false, error: 'Upload a photo of your working first (required for this task).' };
      if (a.type === 'Retest' && !data.proof) return { ok: false, error: 'Confirm your proof of studying before starting the retest.' };
    }
    const auto = autoMark(a.questions, data.responses || {});
    const needsTeacher = Object.values(auto.parts).some(r => r.verdict === 'teacher');
    const t = { id: uid('t'), token: data.token || uid('tok'), aid: a.id, sid, at: new Date().toISOString(), date: Hub.mastery.asOf(), type: a.type, responses: data.responses || {}, uploads: data.uploads || [], reflection: data.reflection || '', proof: !!data.proof,
      auto, max: auto.max, status: a.release === 'auto' && !needsTeacher ? 'released' : 'submitted', final: null, comment: '', hints: data.hints || {} };
    if (preview) return { ok: true, attempt: t, preview: true };
    if (opts.assessment) t.inline = { title: a.title, type: a.type, questions: a.questions, course: a.course }; // Do Now / practice keep their questions
    S().attempts.push(t);
    delete S().progress[progressKey(sid, a.id)];
    if (t.status === 'released') { t.final = { earned: auto.earned, parts: Object.fromEntries(Object.entries(auto.parts).map(([k, r]) => [k, r.earned])) }; t.releasedAt = t.at; writeEvidence(t, a); }
    Hub.store.save(true); return { ok: true, attempt: t };
  }
  function questionsOf(t) { return t.inline ? t.inline.questions : (A(t.aid) || { questions: [] }).questions; }
  function writeEvidence(t, a) {
    // Earlier released attempts at the same assessment (or its original, for a retest) are superseded.
    const related = new Set([t.aid, a.retestOf].filter(Boolean));
    S().attempts.filter(x => x !== t && x.sid === t.sid && related.has(x.aid) && x.status === 'released').forEach(x => S().evidence.forEach(e => { if (e.attemptId === x.id) e.superseded = true; }));
    S().evidence = S().evidence.filter(e => e.attemptId !== t.id);
    questionsOf(t).forEach(q => {
      let earned = 0, max = 0; const tags = [];
      q.parts.forEach(p => { const k = q.id + '|' + p.id, r = t.auto.parts[k]; if (r.verdict === 'teacher' && (!t.final || t.final.parts[k] === undefined)) return; earned += t.final ? t.final.parts[k] ?? r.earned : r.earned; max += p.marks; if (r.tag) tags.push(r.tag); });
      if (max > 0) S().evidence.push({ id: uid('e'), sid: t.sid, skill: q.skill, earned, max, date: t.date, source: a.type, attemptId: t.id, tags, preview: !!q.preview, hinted: Object.keys(t.hints || {}).some(k => k.startsWith(q.id)) });
    });
  }
  /** Teacher confirms marks (per part) and releases results + feedback to the student. */
  function release(attemptId, partMarks, comment) {
    const t = S().attempts.find(x => x.id === attemptId); if (!t) return { ok: false };
    const a = A(t.aid) || { type: t.type, questions: questionsOf(t) }; const parts = {}; let earned = 0;
    questionsOf(t).forEach(q => q.parts.forEach(p => { const k = q.id + '|' + p.id; const v = partMarks && partMarks[k] !== undefined ? Math.max(0, Math.min(p.marks, Number(partMarks[k]) || 0)) : t.auto.parts[k].earned; parts[k] = v; earned += v; }));
    t.final = { earned, parts }; t.comment = comment || ''; t.status = 'released'; t.releasedAt = new Date().toISOString(); t.markedBy = Hub.auth.who();
    writeEvidence(t, a); Hub.store.log(`Released marks for ${Hub.roster.byId(t.sid)?.name || t.sid}`); Hub.store.save(true); return { ok: true };
  }
  /** Release every waiting attempt that has no teacher-only parts (and has its upload if required). */
  function releaseAuto(aid) {
    const a = A(aid); let n = 0;
    S().attempts.filter(t => t.aid === aid && t.status === 'submitted').forEach(t => { const open = Object.values(t.auto.parts).some(r => r.verdict === 'teacher'); if (!open && (!a.uploadRequired || t.uploads.length)) { release(t.id, null, ''); n++; } });
    return n;
  }
  function queue() { return S().attempts.filter(t => t.status === 'submitted' && !t.inline).sort((x, y) => x.at < y.at ? -1 : 1); }

  /* ---------- analysis & gradebook ---------- */
  function itemAnalysis(aid) {
    const a = A(aid), ts = S().attempts.filter(t => t.aid === aid); if (!a) return [];
    return a.questions.flatMap((q, qi) => q.parts.map(p => {
      const k = q.id + '|' + p.id, rs = ts.map(t => ({ t, r: t.auto.parts[k], fin: t.final ? t.final.parts[k] : undefined })).filter(x => x.r);
      const marks = rs.map(x => x.fin ?? x.r.earned), full = marks.filter(m => m >= p.marks).length;
      const wrong = {}; rs.filter(x => x.r.verdict !== 'correct').forEach(x => { const raw = (x.t.responses[q.id] || {})[p.id]; const key = Array.isArray(raw) ? raw.join(' ; ') : raw === undefined || raw === '' ? '(blank)' : p.answer.kind === 'mc' ? 'option ' + 'ABCD'[raw] : String(raw); wrong[key] = (wrong[key] || 0) + 1; });
      const tags = {}; rs.forEach(x => { if (x.r.tag) tags[x.r.tag] = (tags[x.r.tag] || 0) + 1; });
      return { label: `Q${qi + 1}(${p.id})`, skill: q.skill, marks: p.marks, n: rs.length, mean: rs.length ? Math.round(100 * marks.reduce((s, m) => s + m, 0) / (rs.length * p.marks)) : null, full: rs.length ? Math.round(100 * full / rs.length) : null, wrong: Object.entries(wrong).sort((x, y) => y[1] - x[1]).slice(0, 3), tags: Object.entries(tags).sort((x, y) => y[1] - x[1]) };
    }));
  }
  function gradebookCSV(aid) {
    const a = A(aid); const head = ['Student', 'Email', 'Group', 'Status', 'Submitted'];
    const keys = a.questions.flatMap((q, i) => q.parts.map(p => ({ k: q.id + '|' + p.id, h: `Q${i + 1}${p.id} /${p.marks}` })));
    const rows = [head.concat(keys.map(x => x.h), ['Total', 'Max', '%', a.cap ? `Retest % (capped at ${a.cap})` : 'Gradebook %', 'Misconceptions', 'Teacher comment'])];
    Hub.roster.all().filter(s => a.groups.includes(s.group)).forEach(s => {
      const t = attemptsFor(aid, s.id).pop();
      if (!t) { rows.push([s.name, s.email, Hub.curriculum.GROUPS[s.group].label, 'Not submitted', '']); return; }
      const sc = score(t), tags = Object.values(t.auto.parts).map(r => r.tag).filter(Boolean).map(Hub.mastery.tagText);
      rows.push([s.name, s.email, Hub.curriculum.GROUPS[s.group].label, t.status === 'released' ? 'Released' : 'Awaiting marking', t.at.slice(0, 16).replace('T', ' ')].concat(keys.map(x => t.final ? t.final.parts[x.k] : t.auto.parts[x.k].earned), [sc.earned, sc.max, sc.pct, sc.capped, tags.join('; '), t.comment || '']));
    });
    return toCSV(rows);
  }
  Hub.assess = { TYPES, createDraft, updatePart, updateStem, regenerate, removeQ, addQ, setReviewed, problems, approve, publish, unpublish, close, archive, duplicate, remove, forStudent, attemptsFor, saveProgress, getProgress, submit, autoMark, release, releaseAuto, queue, itemAnalysis, gradebookCSV, score, questionsOf, toMC, valueTex, buildQ, byId: A };
})(window.Hub = window.Hub || {});
