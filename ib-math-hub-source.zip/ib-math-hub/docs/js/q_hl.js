/* AA HL — original parameterised questions (Units 1–5, Year 1). Higher rigour than SL: multi-step,
   parameters, AHL content (partial fractions, extended binomial, proof by induction, complex numbers,
   implicit differentiation). Oxford HL 2019 / Mr Le section numbers are used for mapping only. */
(function (Hub) {
  'use strict';
  const { F, fr, T, num, round, sf, poly, lin, sgn, paren, comb, factorial, mc, reg, regressionGen } = Hub.qcore;

  /* ---------- 1.1 Sigma: mixed arithmetic and geometric ---------- */
  reg('hl.sigma', { skill: 'HL-1.1', title: 'Sigma notation: splitting sums and writing series', paper: 1, challenge: true }, (R, o) => {
    const a = R.int(2, 5), c = R.pick([2, 3]), nn = o.challenge ? R.int(9, 12) : R.int(6, 9);
    const ar = a * nn * (nn + 1) / 2, ge = c * (Math.pow(c, nn) - 1) / (c - 1), S = ar + ge;
    const f = R.int(2, 9), d = R.int(3, 7), N = R.int(12, 25), last = f + (N - 1) * d;
    const opts = [
      { tex: `$\\sum_{r=1}^{${N}} (${lin(d, f - d, 'r')})$`, key: 'ok' },
      { tex: `$\\sum_{r=1}^{${N - 1}} (${lin(d, f - d, 'r')})$`, key: 'short' },
      { tex: `$\\sum_{r=0}^{${N}} (${lin(d, f, 'r')})$`, key: 'extra' },
      { tex: `$\\sum_{r=1}^{${N}} (${lin(d, f, 'r')})$`, key: 'shift' }];
    return {
      stem: '',
      parts: [
        { command: 'Find', prompt: `the exact value of $\\sum_{r=1}^{${nn}} \\left(${a}r + ${c}^{r}\\right)$.`, marks: 4, answer: { kind: 'num', value: S, exact: true, display: String(S) },
          ms: [['M1', `splitting into $${a}\\sum r + \\sum ${c}^{r}$`], ['A1', `$${a}\\times\\frac{${nn}(${nn + 1})}{2} = ${ar}$`], ['A1', `$\\frac{${c}(${c}^{${nn}} - 1)}{${c} - 1} = ${ge}$`], ['A1', `$${S}$`]],
          working: [`$\\sum_{r=1}^{${nn}} ${a}r = ${a}\\cdot\\frac{${nn}\\cdot ${nn + 1}}{2} = ${ar}$ (arithmetic)`, `$\\sum_{r=1}^{${nn}} ${c}^{r} = \\frac{${c}\\left(${c}^{${nn}} - 1\\right)}{${c} - 1} = ${ge}$ (geometric, $u_1 = ${c}$)`, `Total $= ${S}$`],
          hint: 'Split into an arithmetic part and a geometric part. What is the first term of the geometric part when r = 1?',
          errors: [{ value: S + 1, tag: 'geometric-from-r-0', fb: `The geometric part starts at ${c}¹ = ${c}, not ${c}⁰ = 1.` }, { value: ar + Math.pow(c, nn), tag: 'last-term-only', fb: 'Σ cʳ is a sum of terms: use the geometric series formula.' }],
          verify: `summation(${a}*r+${c}**r,(r,1,${nn}))` },
        { command: 'Write down', prompt: `which expression is equal to $${f} + ${f + d} + ${f + 2 * d} + \\cdots + ${last}$.`, marks: 2, answer: Object.assign(mc(R, opts, 'ok'), { display: opts[0].tex.replace(/\$/g, '') }),
          ms: [['M1', `$u_r = ${lin(d, f - d, 'r')}$`], ['A1', `upper limit $${N}$`]], working: [`$u_r = ${f} + (r - 1)${d} = ${lin(d, f - d, 'r')}$`, `$${lin(d, f - d, 'r')} = ${last} \\Rightarrow r = ${N}$`],
          hint: 'Find the general term first; then work out which r gives the last term.', verify: `'ok' if summation(${d}*r+(${f - d}),(r,1,${N}))==sum(range(${f},${last}+1,${d})) else 'x'` }
      ]
    };
  });

  /* ---------- 1.2 Arithmetic/geometric: simultaneous conditions ---------- */
  reg('hl.arithgeo', { skill: 'HL-1.2a', title: 'Sequences from simultaneous conditions', paper: 1 }, R => {
    const u1 = R.int(-8, 12), d = R.nz(-4, 6), m = R.int(3, 8); let nn; do nn = R.int(10, 16); while (nn === 2 * m - 1); // S(2m−1) = (2m−1)·u(m) would make the equations dependent
    const A = u1 + (m - 1) * d, B = nn * (2 * u1 + (nn - 1) * d) / 2;
    const q = R.pick([3, 4, 5]), p = R.int(1, q - 1), kk = R.int(1, 3), S = q * q * kk, U = kk * p * (q - p), r1 = fr(p, q), r2 = fr(q - p, q);
    const roots = r1.eq(r2) ? [r1.val()] : [r1.val(), r2.val()];
    return {
      stem: '',
      parts: [
        { command: 'Find', prompt: `An arithmetic sequence has $u_{${m}} = ${A}$ and $S_{${nn}} = ${B}$. Find $u_1$ and $d$.`, marks: 5, answer: { kind: 'tuple', labels: ['u_1', 'd'], value: [u1, d], exact: true, markEach: true, display: `u_1 = ${u1},\\ d = ${d}` },
          ms: [['M1', `$u_1 + ${m - 1}d = ${A}$`], ['M1', `$\\frac{${nn}}{2}\\left(2u_1 + ${nn - 1}d\\right) = ${B}$`], ['M1', 'attempt to solve simultaneously'], ['A1', `$u_1 = ${u1}$`], ['A1', `$d = ${d}$`]],
          working: [`$u_1 + ${m - 1}d = ${A}$ … (1)`, `$${nn}u_1 + ${nn * (nn - 1) / 2}d = ${B}$ … (2)`, `Solving: $u_1 = ${u1}$, $d = ${d}$`], hint: 'Write one equation from uₘ and one from Sₙ, then solve them simultaneously.',
          errors: [{ value: [d, u1], tag: 'swapped', fb: 'Check which value is u₁ and which is d.' }], verify: `tuple(solve([Eq(x+${m - 1}*y,${A}),Eq(Rational(${nn},2)*(2*x+${nn - 1}*y),${B})],[x,y]).values())` },
        { command: 'Find', prompt: `A geometric sequence has second term $${U}$ and sum to infinity $${S}$. Find the possible values of the common ratio.`, marks: 5, answer: { kind: 'list', value: roots, exact: true, markEach: true, boxes: 2, display: roots.length > 1 ? `r = ${r1.tex()}\\text{ or }r = ${r2.tex()}` : `r = ${r1.tex()}` },
          ms: [['M1', `$u_1 r = ${U}$ and $\\frac{u_1}{1 - r} = ${S}$`], ['M1', `$${S}r(1 - r) = ${U}$`], ['A1', `$${S}r^{2} - ${S}r + ${U} = 0$`], ['A1A1', `$r = ${r1.tex()}$, $r = ${r2.tex()}$ (both satisfy $|r| < 1$)`]],
          working: [`$u_1 = \\frac{${U}}{r}$ and $u_1 = ${S}(1 - r)$`, `$${S}r(1 - r) = ${U} \\Rightarrow ${S}r^{2} - ${S}r + ${U} = 0$`, `$r = ${r1.tex()}$ or $r = ${r2.tex()}$; both have $|r| < 1$, so both are valid`],
          hint: 'Eliminate u₁. Then check each root satisfies |r| < 1.', verify: `solve(${S}*k**2-${S}*k+${U},k)` }
      ]
    };
  });

  /* ---------- 1.2 Convergence ---------- */
  reg('hl.convergence', { skill: 'HL-1.2b', title: 'Convergence of a geometric series with a variable ratio', paper: 1 }, R => {
    const p = R.int(2, 5), q = R.nz(-6, 6), s = R.pick([3, 4, 5, 7]);
    const lo = fr(q - s, p), hi = fr(q + s, p);
    let x0; do { x0 = R.int(Math.ceil(lo.val()), Math.floor(hi.val())); } while (!(x0 > lo.val() && x0 < hi.val()) || p * x0 - q === s);
    const rr = fr(p * x0 - q, s), Sinf = fr(1).div(fr(1).sub(rr));
    return {
      stem: `Consider the geometric series $1 + \\left(\\frac{${lin(p, -q)}}{${s}}\\right) + \\left(\\frac{${lin(p, -q)}}{${s}}\\right)^{2} + \\cdots$`,
      parts: [
        { command: 'Find', prompt: 'the set of values of $x$ for which the series has a sum to infinity. Give the end-points $a < x < b$.', marks: 4, answer: { kind: 'tuple', labels: ['a', 'b'], value: [lo.val(), hi.val()], exact: true, markEach: true, display: `${lo.tex()} < x < ${hi.tex()}` },
          ms: [['M1', `$\\left|\\frac{${lin(p, -q)}}{${s}}\\right| < 1$`], ['A1', `$-${s} < ${lin(p, -q)} < ${s}$`], ['A1A1', `$${lo.tex()} < x < ${hi.tex()}$`]],
          working: [`Need $|r| < 1$: $-1 < \\frac{${lin(p, -q)}}{${s}} < 1$`, `$${-s} < ${lin(p, -q)} < ${s}$`, `$${lo.tex()} < x < ${hi.tex()}$`], hint: 'A geometric series converges when |r| < 1. Solve the double inequality.',
          errors: [{ value: [-hi.val(), -lo.val()], tag: 'sign', fb: 'Add the constant to all three parts of the inequality before dividing.' }], verify: `tuple(sorted(solve((${p}*x-(${q}))**2-${s * s},x)))` },
        { command: 'Find', prompt: `the exact sum to infinity when $x = ${x0}$.`, marks: 2, answer: { kind: 'num', value: Sinf.val(), exact: true, display: Sinf.tex() },
          ms: [['M1', `$r = ${rr.tex()}$`], ['A1', `$S_\\infty = ${Sinf.tex()}$`]], working: [`$r = \\frac{${p}(${x0}) ${sgn(-q)}}{${s}} = ${rr.tex()}$`, `$S_\\infty = \\frac{1}{1 - ${paren(rr)}} = ${Sinf.tex()}$`],
          hint: 'Work out $r$, then use $S_\\infty = \\frac{u_1}{1 - r}$.', errors: [{ value: fr(1).div(fr(1).add(rr)).val(), tag: 'sinf-sign', fb: '$S_\\infty = \\frac{u_1}{1 - r}$.' }], verify: `1/(1-Rational(${p * x0 - q},${s}))` }
      ]
    };
  });

  /* ---------- 1.2 Financial comparison ---------- */
  reg('hl.finance', { skill: 'HL-1.2c', title: 'Comparing simple and compound growth (NumWorks)', paper: 2 }, R => {
    const P = R.pick([2000, 5000, 8000, 10000]), i = R.pick([6, 7, 8]), j = R.pick([4.5, 5, 5.5]);
    const A = tt => P * (1 + i * tt / 100), B = tt => P * Math.pow(1 + j / 1200, 12 * tt);
    let y = 1; while (B(y) <= A(y)) y++;
    const B10 = round(B(10), 2);
    return {
      stem: `Two investment plans each start with $\\$${P}$. Plan A pays simple interest of $${i}\\%$ of the original amount each year. Plan B pays $${j}\\%$ per year compounded monthly.`,
      parts: [
        { command: 'Find', prompt: 'the value of Plan B after 10 years, correct to two decimal places.', marks: 2, answer: { kind: 'num', value: B10, dp: 2, display: `\\$${B10.toFixed(2)}` },
          ms: [['M1', `$${P}\\left(1 + \\frac{${j}}{1200}\\right)^{120}$`], ['A1', `$\\$${B10.toFixed(2)}$`]], working: [`$${P}\\left(1 + \\frac{${j}}{1200}\\right)^{120} = ${B10.toFixed(2)}$`], hint: '12 compounding periods each year for 10 years.',
          numworks: { app: 'Calculation', lines: [[`${P}×(1+${j}/1200)^120`, B10.toFixed(2)]] }, errors: [{ value: round(P * Math.pow(1 + j / 100, 10), 2), tag: 'annual-not-compounded', fb: 'Monthly compounding: divide the rate by 12 and use 120 periods.' }],
          verify: `${P}*(1+Rational(${Math.round(j * 10)},12000))**120` },
        { command: 'Find', prompt: 'the least number of complete years after which Plan B is worth more than Plan A.', marks: 4, answer: { kind: 'num', value: y, int: true, display: String(y) },
          ms: [['A1', `$A = ${P}(1 + ${i / 100}n)$`], ['A1', `$B = ${P}\\left(1 + \\frac{${j}}{1200}\\right)^{12n}$`], ['M1', 'comparing with a graph or table on the GDC'], ['A1', `$n = ${y}$`]],
          working: [`Solve $${P}\\left(1 + \\frac{${j}}{1200}\\right)^{12n} > ${P}(1 + ${i / 100}n)$`, `NumWorks table: year $${y - 1}$: A $= ${round(A(y - 1), 2).toFixed(2)}$, B $= ${round(B(y - 1), 2).toFixed(2)}$`, `year $${y}$: A $= ${round(A(y), 2).toFixed(2)}$, B $= ${round(B(y), 2).toFixed(2)}$ ✓`],
          hint: 'Model each plan as a function of n, then use a NumWorks table to compare whole years.', errors: [{ value: y - 1, tag: 'round-down', fb: 'Check the year before: B has not yet overtaken A.' }],
          verify: `next(m for m in range(1,200) if ${P}*(1+Rational(${Math.round(j * 10)},12000))**(12*m) > ${P}*(1+Rational(${i},100)*m))` }
      ]
    };
  });

  /* ---------- 1.3 Proof: counterexample, contradiction, direct ---------- */
  reg('hl.proof', { skill: 'HL-1.3a', title: 'Proof: counterexample, contradiction and direct proof', paper: 1 }, R => {
    const p = R.pick([5, 11, 17]); let first = 1; const isP = v => { if (v < 2) return false; for (let d = 2; d * d <= v; d++) if (v % d === 0) return false; return true; };
    while (isP(first * first + first + p)) first++;
    const primeNs = []; for (let m = 1; m < first; m++) primeNs.push(m);
    const wrong = R.shuffle(primeNs).slice(0, 3);
    const opts = [{ tex: `$n = ${first}$`, key: 'n' + first }].concat(wrong.map(w => ({ tex: `$n = ${w}$`, key: 'n' + w })));
    const kq = R.pick([2, 3, 5, 7]);
    const cmc = mc(R, [{ tex: `Assume $\\sqrt{${kq}} = \\frac{a}{b}$ where $a, b\\in\\mathbb{Z}$, $b \\ne 0$, and $\\frac{a}{b}$ is in lowest terms`, key: 'lowest' },
      { tex: `Assume $\\sqrt{${kq}}$ is irrational`, key: 'irr' }, { tex: `Assume $\\sqrt{${kq}} = \\frac{a}{b}$ for some integers $a$ and $b$`, key: 'nolowest' }, { tex: `Assume $${kq} = a^{2}$ for some integer $a$`, key: 'square' }], 'lowest');
    return {
      stem: '',
      parts: [
        { command: 'Find', prompt: `which value of $n$ is a counterexample to the statement “$n^{2} + n + ${p}$ is prime for every positive integer $n$”.`, marks: 2, answer: Object.assign(mc(R, opts, 'n' + first), { display: `n = ${first}` }),
          ms: [['A1', `$n = ${first}$`], ['R1', `$${first * first + first + p}$ is not prime`]], working: [`$${first}^{2} + ${first} + ${p} = ${first * first + first + p} = ${(() => { const v = first * first + first + p; for (let d = 2; d * d <= v; d++) if (v % d === 0) return d + '\\times' + v / d; return v; })()}$, which is not prime.`],
          hint: 'Substitute each option. A single failure disproves a “for every” statement.', verify: `'n${first}' if not isprime(${first}**2+${first}+${p}) and all(isprime(m**2+m+${p}) for m in [${wrong.join(',')}]) else 'x'` },
        { command: 'State', prompt: `the assumption that begins a proof by contradiction that $\\sqrt{${kq}}$ is irrational.`, marks: 1, answer: Object.assign(cmc, { display: 'lowest terms' }), ms: [['A1', 'rational, in lowest terms (needed for the contradiction)']],
          working: ['Assume the opposite of what you want to prove, with $\\frac{a}{b}$ in lowest terms: the contradiction is that $a$ and $b$ then share a factor.'], hint: 'Assume the opposite — and set it up so a contradiction is possible.', verify: `'lowest'` },
        { command: 'Prove', prompt: 'that the product of any two odd integers is odd.', marks: 4, answer: { kind: 'open', display: 'See markscheme' },
          ms: [['M1', 'writing odd integers as $2m + 1$ and $2n + 1$ (different letters)'], ['A1', '$(2m + 1)(2n + 1) = 4mn + 2m + 2n + 1$'], ['A1', '$= 2(2mn + m + n) + 1$'], ['R1', '$2mn + m + n \\in \\mathbb{Z}$, so the product is odd']],
          working: ['Let the integers be $2m + 1$ and $2n + 1$, $m, n \\in \\mathbb{Z}$', '$(2m + 1)(2n + 1) = 4mn + 2m + 2n + 1 = 2(2mn + m + n) + 1$', 'which is one more than a multiple of 2, so it is odd.'],
          hint: 'Use DIFFERENT letters for the two odd numbers.', verify: `expand((2*x+1)*(2*y+1) - (2*(2*x*y+x+y)+1))==0` }
      ]
    };
  });

  /* ---------- 1.3 Proof by induction ---------- */
  const IND = [
    { lhs: 'r(r+1)', rhs: '\\frac{n(n+1)(n+2)}{3}', term: k => `(${k}+1)(${k}+2)`, wrong: [k => `${k}(${k}+1)`, k => `(${k}+1)^{2}`, k => `(${k}+2)(${k}+3)`], f: m => m * (m + 1) * (m + 2) / 3, u: m => m * (m + 1), py: ['r*(r+1)', 'n*(n+1)*(n+2)/3'] },
    { lhs: '\\frac{1}{r(r+1)}', rhs: '\\frac{n}{n+1}', term: k => `\\frac{1}{(${k}+1)(${k}+2)}`, wrong: [k => `\\frac{1}{${k}(${k}+1)}`, k => `\\frac{1}{${k}+1}`, k => `\\frac{1}{(${k}+2)(${k}+3)}`], f: m => m / (m + 1), u: m => 1 / (m * (m + 1)), py: ['1/(r*(r+1))', 'n/(n+1)'], frac: true },
    { lhs: 'r^{3}', rhs: '\\frac{n^{2}(n+1)^{2}}{4}', term: k => `(${k}+1)^{3}`, wrong: [k => `${k}^{3}`, k => `(${k}+1)^{2}`, k => `${k}^{3}+1`], f: m => m * m * (m + 1) * (m + 1) / 4, u: m => m ** 3, py: ['r**3', 'n**2*(n+1)**2/4'] },
    { lhs: 'r\\cdot 2^{r}', rhs: '(n-1)2^{n+1} + 2', term: k => `(${k}+1)2^{${k}+1}`, wrong: [k => `${k}\\cdot 2^{${k}}`, k => `(${k}+1)2^{${k}}`, k => `${k}\\cdot 2^{${k}+1}`], f: m => (m - 1) * Math.pow(2, m + 1) + 2, u: m => m * Math.pow(2, m), py: ['r*2**r', '(n-1)*2**(n+1)+2'] }
  ];
  reg('hl.induction', { skill: 'HL-1.3b', title: 'Proof by induction: series', paper: 1 }, R => {
    const P = R.pick(IND), m = R.int(5, 8);
    const opts = [{ tex: `$${P.term('k')}$`, key: 'ok' }].concat(P.wrong.map((w, i) => ({ tex: `$${w('k')}$`, key: 'w' + i })));
    const fm = P.frac ? fr(m, m + 1) : null;
    return {
      stem: `Let $P(n)$ be the statement $\\sum_{r=1}^{n} ${P.lhs} = ${P.rhs}$, $n\\in\\mathbb{Z}^{+}$.`,
      parts: [
        { command: 'Verify', prompt: `that $P(${m})$ is true by finding the value of the left-hand side when $n = ${m}$.`, marks: 1, answer: { kind: 'num', value: P.f(m), exact: true, display: fm ? fm.tex() : String(P.f(m)) }, ms: [['A1', `$${fm ? fm.tex() : P.f(m)}$ = RHS`]],
          working: [`Add the first $${m}$ terms directly; the RHS also gives $${fm ? fm.tex() : P.f(m)}$.`], hint: 'Add the terms for r = 1, 2, …, ' + m + '.', verify: `summation(${P.py[0]},(r,1,${m}))` },
        { command: 'Write down', prompt: 'the term that is added to $\\sum_{r=1}^{k}$ to obtain $\\sum_{r=1}^{k+1}$ in the inductive step.', marks: 1, answer: Object.assign(mc(R, opts, 'ok'), { display: P.term('k') }), ms: [['A1', `$${P.term('k')}$`]],
          working: [`Replace $r$ with $k + 1$ in $${P.lhs}$.`], hint: 'The next term is the (k + 1)th term: substitute r = k + 1.', verify: `'ok' if simplify((${P.py[0]}).subs(r,k+1) - ((${P.py[1]}).subs(n,k+1)-(${P.py[1]}).subs(n,k)))==0 else 'x'` },
        { command: 'Prove', prompt: '$P(n)$ by mathematical induction.', marks: 7, answer: { kind: 'open', display: 'See markscheme' },
          ms: [['A1', '$P(1)$ shown true: LHS = RHS'], ['M1', 'assume $P(k)$ true for some $k\\in\\mathbb{Z}^{+}$'], ['M1', `$\\sum_{r=1}^{k+1} = ${P.rhs.replace(/n/g, 'k')} + ${P.term('k')}$`], ['A1', 'correct common factor or common denominator'], ['A1', 'correct algebra'], ['A1', `reaching $${P.rhs.replace(/n/g, '(k+1)')}$`], ['R1', '$P(1)$ true and $P(k) \\Rightarrow P(k+1)$, so $P(n)$ true for all $n\\in\\mathbb{Z}^{+}$ (only if the first four marks are earned)']],
          working: ['Basis, assumption, inductive step, conclusion — see markscheme.'], hint: 'Four parts: base case, assumption, inductive step, conclusion sentence.', verify: `simplify(summation(${P.py[0]},(r,1,n)) - (${P.py[1]}))==0` }
      ]
    };
  });

  /* ---------- 1.4 Counting principles ---------- */
  const WORDS = [['BANANA', [3, 2]], ['LETTER', [2, 2]], ['ALGEBRA', [2]], ['CALCULUS', [2, 2, 2]], ['INDUCTION', [2, 2]], ['SEQUENCE', [3]], ['PARALLEL', [2, 3]]];
  reg('hl.counting', { skill: 'HL-1.4a', title: 'Permutations and combinations with restrictions', paper: 1 }, R => {
    const [w, reps] = R.pick(WORDS), arr = factorial(w.length) / reps.reduce((s, v) => s * factorial(v), 1);
    const hl = R.int(6, 9), sl = R.int(5, 8), size = 5, k = R.int(2, 3), com = comb(hl, k) * comb(sl, size - k);
    const np = R.int(5, 8), row = 2 * factorial(np - 1);
    return {
      stem: '',
      parts: [
        { command: 'Find', prompt: `the number of different arrangements of the letters of the word ${w}.`, marks: 2, answer: { kind: 'num', value: arr, int: true, display: String(arr) },
          ms: [['M1', `$\\frac{${w.length}!}{${reps.map(v => v + '!').join('\\,')}}$`], ['A1', `$${arr}$`]], working: [`$${w.length}$ letters with repeats: $\\frac{${w.length}!}{${reps.map(v => v + '!').join('\\,')}} = ${arr}$`],
          hint: 'Divide by the factorial of each repeated letter count.', errors: [{ value: factorial(w.length), tag: 'repeats-not-divided', fb: 'Swapping identical letters gives the same word: divide by the repeats.' }], verify: `factorial(len('${w}'))/prod([factorial('${w}'.count(ch)) for ch in set('${w}')])` },
        { command: 'Find', prompt: `A committee of ${size} is chosen from ${hl} HL students and ${sl} SL students. Find the number of committees with exactly ${k} HL students.`, marks: 2, answer: { kind: 'num', value: com, int: true, display: String(com) },
          ms: [['M1', `$\\binom{${hl}}{${k}}\\binom{${sl}}{${size - k}}$`], ['A1', `$${com}$`]], working: [`$\\binom{${hl}}{${k}} \\times \\binom{${sl}}{${size - k}} = ${comb(hl, k)}\\times ${comb(sl, size - k)} = ${com}$`],
          hint: 'Choose the HL members and the SL members separately, then multiply.', errors: [{ value: comb(hl + sl, size), tag: 'ignored-restriction', fb: `That counts every committee of ${size}. Use exactly ${k} HL students.` }, { value: comb(hl, k) + comb(sl, size - k), tag: 'added-not-multiplied', fb: 'Each HL choice can go with each SL choice: multiply.' }],
          verify: `binomial(${hl},${k})*binomial(${sl},${size - k})` },
        { command: 'Find', prompt: `the number of ways ${np} people can sit in a row if two particular people must sit next to each other.`, marks: 2, answer: { kind: 'num', value: row, int: true, display: String(row) },
          ms: [['M1', `$${np - 1}!$ treating the pair as one unit`], ['A1', `$2\\times ${np - 1}! = ${row}$`]], working: [`Glue the pair together: $${np - 1}$ units, $${np - 1}!$ ways`, `The pair can swap: $\\times 2$, total $${row}$`],
          hint: 'Treat the pair as one block — and remember the pair can be in either order.', errors: [{ value: factorial(np - 1), tag: 'forgot-internal-arrangement', fb: 'The two people can swap places within their block: × 2.' }, { value: factorial(np), tag: 'ignored-restriction', fb: 'That counts every arrangement.' }], verify: `2*factorial(${np - 1})` }
      ]
    };
  });

  /* ---------- 1.4 Binomial theorem incl. extension ---------- */
  reg('hl.binomial', { skill: 'HL-1.4b', title: 'Binomial theorem: general term and fractional/negative powers', paper: 1, challenge: true }, (R, o) => {
    const nn = R.pick([6, 9]), a = nn === 9 ? R.pick([1, 2]) : R.pick([1, 2, 3]), b = nn === 9 ? R.pick([1, 2]) : R.pick([1, 2, 3]), rr = 2 * nn / 3;
    const ct = comb(nn, rr) * Math.pow(a, nn - rr) * Math.pow(-b, rr);
    // extension: (A + Bx)^m, A in {1,4,9} for m=±1/2; A in {1,2,3} for m = -1, -2
    const m = o.challenge ? R.pick([fr(1, 2), fr(-1, 2), fr(-3, 2)]) : R.pick([fr(-1), fr(-2), fr(1, 2), fr(-1, 2)]);
    const A = m.d === 2 ? R.pick([1, 4, 9]) : R.pick([1, 2, 3]), B = R.pick([-3, -2, -1, 1, 2, 3]);
    const sq = Math.round(Math.sqrt(A));
    const Apow = m.d === 2 ? fr(sq).pow(m.n) : fr(A).pow(m.n); // A^m
    const c2 = Apow.mul(m).mul(m.sub(1)).div(2).mul(fr(B, A).pow(2));
    const valid = fr(A, Math.abs(B));
    return {
      stem: '',
      parts: [
        { command: 'Find', prompt: `the constant term in the expansion of $\\left(${a === 1 ? '' : a}x^{2} - \\frac{${b}}{x}\\right)^{${nn}}$.`, marks: 4, answer: { kind: 'num', value: ct, exact: true, display: String(ct) },
          ms: [['M1', `general term $\\binom{${nn}}{r}(${a === 1 ? '' : a}x^{2})^{${nn}-r}\\left(-\\frac{${b}}{x}\\right)^{r}$`], ['M1', `$2(${nn} - r) - r = 0$`], ['A1', `$r = ${rr}$`], ['A1', `$${ct}$`]],
          working: [`Power of $x$: $2(${nn} - r) - r = ${2 * nn} - 3r$`, `$${2 * nn} - 3r = 0 \\Rightarrow r = ${rr}$`, `$\\binom{${nn}}{${rr}}(${a})^{${nn - rr}}(-${b})^{${rr}} = ${ct}$`],
          hint: 'Collect powers of x in the general term. Keep the minus sign with the second term.',
          errors: [{ value: Math.abs(ct), tag: 'sign-of-negative-term', fb: `The second term is negative; (−${b})^${rr} keeps track of the sign.` }, { value: comb(nn, rr) * Math.pow(a, rr) * Math.pow(-b, nn - rr), tag: 'powers-swapped', fb: 'Match each power to the right term in the general term.' }],
          verify: `expand((${a}*x**2-Rational(${b})/x)**${nn}).as_coefficients_dict()[1]` },
        { command: 'Find', prompt: `the coefficient of $x^{2}$ in the expansion of $(${A} ${B < 0 ? '-' : '+'} ${Math.abs(B) === 1 ? '' : Math.abs(B)}x)^{${m.tex()}}$.`, marks: 4, answer: { kind: 'num', value: c2.val(), exact: true, display: c2.tex() },
          ms: [['M1', A === 1 ? 'use of the extended binomial expansion' : `$${A}^{${m.tex()}}\\left(1 ${B < 0 ? '-' : '+'} \\frac{${Math.abs(B)}}{${A}}x\\right)^{${m.tex()}}$`], ['M1', `$\\frac{(${m.tex()})(${m.sub(1).tex()})}{2!}\\left(${fr(B, A).tex()}x\\right)^{2}$`], ['A1', 'correct values'], ['A1', `$${c2.tex()}$`]],
          working: [A === 1 ? `$(1 + y)^{n} = 1 + ny + \\frac{n(n-1)}{2!}y^{2} + \\cdots$ with $y = ${B}x$` : `Factor out $${A}^{${m.tex()}} = ${Apow.tex()}$: $${Apow.tex()}\\left(1 + ${fr(B, A).tex()}x\\right)^{${m.tex()}}$`,
            `$x^{2}$ term: $${Apow.isInt() && Apow.n === 1 ? '' : Apow.tex() + '\\times'}\\frac{(${m.tex()})(${m.sub(1).tex()})}{2}\\left(${fr(B, A).tex()}\\right)^{2} = ${c2.tex()}$`],
          hint: 'Get the bracket into the form (1 + something)ⁿ first.', errors: [{ value: m.mul(m.sub(1)).div(2).mul(fr(B).pow(2)).val(), tag: 'did-not-factor', fb: `The formula needs (1 + y)ⁿ: factor out ${A} first.` }, { value: c2.neg().val(), tag: 'sign', fb: 'Check signs: n(n − 1) with n negative.' }],
          verify: `series((${A}+(${B})*x)**(${m.py()}),x,0,3).removeO().coeff(x,2)` },
        { command: 'Write down', dep: true, prompt: 'the values of $x$ for which this expansion is valid. Give $c$ where the condition is $|x| < c$.', marks: 1, answer: { kind: 'num', value: valid.val(), exact: true, display: `|x| < ${valid.tex()}` }, ms: [['A1', `$|x| < ${valid.tex()}$`]],
          working: [`Need $\\left|${fr(B, A).tex()}x\\right| < 1 \\Rightarrow |x| < ${valid.tex()}$`], hint: 'The expansion of (1 + y)ⁿ is valid for |y| < 1.', errors: [{ value: Math.abs(B) / A, tag: 'inverted-validity', fb: '$\\left|\\frac{B}{A}x\\right| < 1$ gives $|x| < \\frac{A}{|B|}$.' }], verify: `Rational(${A},${Math.abs(B)})` }
      ]
    };
  });

  /* ---------- 2.1 Functional relationships ---------- */
  reg('hl.funcrel', { skill: 'HL-2.1', title: 'Domain and range of composite-type expressions', paper: 1 }, R => {
    const a = R.int(2, 9), b = R.int(-a + 1, 6), c = R.int(-5, 9), h = R.int(-3, 3);
    let p, q; do { p = R.int(-6, 2); q = R.int(1, 7); } while (!(p < h && h < q) || (h - p) === (q - h));
    const ext = Math.max((p - h) ** 2, (q - h) ** 2), mn = c - ext, ends = [c - (p - h) ** 2, c - (q - h) ** 2];
    const bb = b === 0 ? 1 : b;
    return {
      stem: `Let $f(x) = \\sqrt{${a} - x} + \\frac{1}{x ${sgn(bb)}}$ and $g(x) = ${c} - (x ${sgn(-h)})^{2}$, $${p} \\le x \\le ${q}$.`,
      parts: [
        { command: 'Write down', prompt: 'the largest value of $x$ in the domain of $f$.', marks: 1, answer: { kind: 'num', value: a, exact: true, display: String(a) }, ms: [['A1', `$x \\le ${a}$`]], working: [`$${a} - x \\ge 0 \\Rightarrow x \\le ${a}$`], hint: 'Square roots need a non-negative input.', verify: `${a}` },
        { command: 'Write down', prompt: 'the value of $x$ that must also be excluded from the domain of $f$.', marks: 1, answer: { kind: 'num', value: -bb, exact: true, display: String(-bb) }, ms: [['A1', `$x \\ne ${-bb}$`]], working: [`Denominator zero at $x = ${-bb}$`], hint: 'Where is the denominator zero?', verify: `solve(x+(${bb}),x)[0]` },
        { command: 'Find', prompt: 'the range of $g$. Give the least and greatest values.', marks: 3, answer: { kind: 'tuple', labels: ['\\text{least}', '\\text{greatest}'], value: [mn, c], exact: true, markEach: true, display: `${mn} \\le g(x) \\le ${c}` },
          ms: [['M1', `vertex $(${h},\\,${c})$ lies in the domain`], ['A1', `greatest $= ${c}$`], ['A1', `least $= ${mn}$ at $x = ${(p - h) ** 2 > (q - h) ** 2 ? p : q}$`]],
          working: [`Maximum at the vertex $x = ${h}$: $g = ${c}$`, `Check both ends: $g(${p}) = ${ends[0]}$, $g(${q}) = ${ends[1]}$`, `Range: $${mn} \\le g(x) \\le ${c}$`], hint: 'Is the vertex inside the domain? Check BOTH end-points too.',
          errors: [{ value: [Math.min(...ends), Math.max(...ends)], tag: 'endpoints-only', fb: 'The turning point is inside the domain, so the greatest value is at the vertex, not an end-point.' }],
          verify: `(minimum(${c}-(x-(${h}))**2,x,Interval(${p},${q})), maximum(${c}-(x-(${h}))**2,x,Interval(${p},${q})))` }
      ]
    };
  });

  /* ---------- 2.2 Special functions: rational, radical, tangent condition ---------- */
  reg('hl.special', { skill: 'HL-2.2a', title: 'Quadratic, rational and radical functions', paper: 1 }, R => {
    let a, b, c, d; do { a = R.nz(-5, 6); b = R.nz(-8, 8); c = R.pick([1, 2, 3, -2]); d = R.nz(-6, 6); } while (a * d === b * c);
    const k = R.int(2, 7), p = R.nz(-6, 6), m = R.nz(-5, 5), q = R.int(-6, 9);
    let pp = p; if ((pp - m) % 2) pp += 1; const cTan = q - (pp - m) * (pp - m) / 4;
    return {
      stem: '',
      parts: [
        { command: 'Write down', prompt: `the equations of the asymptotes of $y = \\frac{${lin(a, b)}}{${lin(c, d)}}$. Give $x = h$ and $y = v$.`, marks: 2, answer: { kind: 'tuple', labels: ['h', 'v'], value: [-d / c, a / c], exact: true, markEach: true, display: `x = ${fr(-d, c).tex()},\\ y = ${fr(a, c).tex()}` },
          ms: [['A1', `$x = ${fr(-d, c).tex()}$`], ['A1', `$y = ${fr(a, c).tex()}$`]], working: [`Vertical: $${lin(c, d)} = 0$`, `Horizontal: ratio of leading coefficients $\\frac{${a}}{${c}}$`], hint: 'Vertical: denominator zero. Horizontal: behaviour as |x| → ∞.', verify: `(solve(${c}*x+(${d}),x)[0], limit((${a}*x+(${b}))/(${c}*x+(${d})),x,oo))` },
        { command: 'Write down', prompt: `the range of $h(x) = \\sqrt{${k * k} - x^{2}}$. Give the least and greatest values.`, marks: 2, answer: { kind: 'tuple', labels: ['\\text{least}', '\\text{greatest}'], value: [0, k], exact: true, markEach: true, display: `0 \\le h(x) \\le ${k}` },
          ms: [['A1', '$0$'], ['A1', `$${k}$`]], working: [`Domain $-${k} \\le x \\le ${k}$; the graph is a semicircle of radius $${k}$`, `Range $0 \\le h(x) \\le ${k}$`], hint: 'Sketch it: y = √(r² − x²) is the top half of a circle.', errors: [{ value: [0, k * k], tag: 'forgot-root', fb: 'Take the square root of the largest value inside.' }], verify: `(0, sqrt(${k * k}))` },
        { command: 'Find', prompt: `the value of $c$ for which the line $y = ${lin(m, 0)} + c$ is a tangent to the curve $y = ${poly([[1, 'x^{2}'], [pp, 'x'], [q, '']])}$.`, marks: 4, answer: { kind: 'num', value: cTan, exact: true, display: String(cTan) },
          ms: [['M1', `$${poly([[1, 'x^{2}'], [pp, 'x'], [q, '']])} = ${lin(m, 0)} + c$`], ['A1', `$${poly([[1, 'x^{2}'], [pp - m, 'x'], [q, '']])} - c = 0$`], ['M1', '$\\Delta = 0$'], ['A1', `$c = ${cTan}$`]],
          working: [`$x^{2} ${sgn(pp - m)}x + (${q} - c) = 0$`, `Tangent: $\\Delta = ${(pp - m) ** 2} - 4(${q} - c) = 0$`, `$c = ${cTan}$`], hint: 'Set the equations equal, rearrange to = 0, and use Δ = 0 for exactly one intersection.',
          errors: [{ value: q - pp * pp / 4, tag: 'did-not-rearrange', fb: `Move the ${m}x term across before finding the discriminant.` }], verify: `solve(Eq((${pp - m})**2-4*(${q}-k),0),k)[0]` }
      ]
    };
  });

  /* ---------- 2.2 Partial fractions ---------- */
  reg('hl.partialfrac', { skill: 'HL-2.2b', title: 'Partial fractions (distinct linear factors)', paper: 1 }, R => {
    let A, B, a, b; do { A = R.nz(-5, 6); B = R.nz(-5, 6); [a, b] = R.distinct(2, -6, 7, [0]); } while (A + B === 0 || a === b);
    const p = A + B, qq = A * b + B * a, x0 = R.pick([1, 2, 3].filter(v => v !== -a && v !== -b));
    const val = fr(A, x0 + a).add(fr(B, x0 + b));
    return {
      stem: `$\\frac{${lin(p, qq)}}{${poly([[1, 'x^{2}'], [a + b, 'x'], [a * b, '']])}} \\equiv \\frac{A}{x ${sgn(a)}} + \\frac{B}{x ${sgn(b)}}$`,
      parts: [
        { command: 'Find', prompt: 'the values of $A$ and $B$.', marks: 4, answer: { kind: 'tuple', labels: ['A', 'B'], value: [A, B], exact: true, markEach: true, display: `A = ${A},\\ B = ${B}` },
          ms: [['M1', `denominator $= (x ${sgn(a)})(x ${sgn(b)})$`], ['M1', `$${lin(p, qq)} \\equiv A(x ${sgn(b)}) + B(x ${sgn(a)})$`], ['A1', `$A = ${A}$`], ['A1', `$B = ${B}$`]],
          working: [`$${lin(p, qq)} \\equiv A(x ${sgn(b)}) + B(x ${sgn(a)})$`, `$x = ${-a}$: $${p * -a + qq} = A(${b - a}) \\Rightarrow A = ${A}$`, `$x = ${-b}$: $${p * -b + qq} = B(${a - b}) \\Rightarrow B = ${B}$`],
          hint: 'Factorise the denominator, multiply through, then substitute values of x that make a bracket zero.', errors: [{ value: [B, A], tag: 'swapped', fb: 'A goes with (x ' + (a < 0 ? '−' : '+') + ' ' + Math.abs(a) + '). Check which value belongs to which fraction.' }],
          verify: `(Rational(${p}*(-(${a}))+(${qq}),-(${a})+(${b})), Rational(${p}*(-(${b}))+(${qq}),-(${b})+(${a})))` },
        { command: 'Hence', dep: true, prompt: `find the exact value of the expression when $x = ${x0}$.`, marks: 1, answer: { kind: 'num', value: val.val(), exact: true, display: val.tex() }, ms: [['A1', `$${val.tex()}$`]],
          working: [`$\\frac{${A}}{${x0 + a}} + \\frac{${B}}{${x0 + b}} = ${val.tex()}$`], hint: 'Substitute into your partial fractions (or into the original).', verify: `Rational(${p * x0 + qq},${x0 * x0 + (a + b) * x0 + a * b})` }
      ]
    };
  });

  /* ---------- 2.2 Absolute value & piecewise ---------- */
  reg('hl.abspiece', { skill: 'HL-2.2c', title: 'Absolute value equations and piecewise continuity', paper: 1 }, R => {
    let a, b, c, d, sols, ext;
    for (let g = 0; g < 200; g++) {
      a = R.pick([1, 2, 3]); b = R.nz(-6, 6); c = R.pick([-1, 1, 2, -2]); d = R.int(-4, 8);
      if (a === c || a === -c) continue;
      const x1 = fr(d - b, a - c), x2 = fr(-d - b, a + c); // ax+b = cx+d ; -(ax+b) = cx+d
      const ok = v => c * v.val() + d >= 0;
      sols = [x1, x2].filter(ok); ext = [x1, x2].filter(v => !ok(v));
      if (sols.length && ext.length && !x1.eq(x2)) break;
    }
    const p = R.int(1, 3), k = R.nz(-4, 5), m = p * p - k - k * p;
    return {
      stem: '',
      parts: [
        { command: 'Solve', prompt: `$|${lin(a, b)}| = ${lin(c, d)}$.`, marks: 4, answer: { kind: 'list', value: sols.map(v => v.val()), exact: true, boxes: 2, display: sols.map(v => `x = ${v.tex()}`).join(',\\ ') },
          ms: [['M1', `$${lin(a, b)} = ${lin(c, d)}$ or $-(${lin(a, b)}) = ${lin(c, d)}$`], ['A1', 'both candidate solutions'], ['R1', `rejecting $x = ${ext[0].tex()}$ (gives a negative RHS)`], ['A1', `$x = ${sols.map(v => v.tex()).join(',\\ ')}$`]],
          working: [`Case 1: $${lin(a, b)} = ${lin(c, d)}$; case 2: $-(${lin(a, b)}) = ${lin(c, d)}$`, `Candidates: $${[...sols, ...ext].map(v => v.tex()).join(',\\ ')}$`, `$|\\ldots| \\ge 0$, so the RHS must be $\\ge 0$: reject $x = ${ext[0].tex()}$`],
          hint: 'Solve both cases, then CHECK each answer in the original equation. Leave a box blank if it is not needed.', errors: [{ value: [...sols, ...ext].map(v => v.val()), tag: 'extraneous-root', fb: `x = ${num(round(ext[0].val(), 4))} makes the right-hand side negative, which an absolute value cannot equal.` }],
          verify: `solve(Eq(Abs(${a}*xr+(${b})),${c}*xr+(${d})),xr)` },
        { command: 'Find', prompt: `the value of $k$ for which the function defined by $f(x) = kx ${sgn(m)}$ for $x < ${p}$ and $f(x) = x^{2} - k$ for $x \\ge ${p}$ is continuous.`, marks: 3, answer: { kind: 'num', value: k, exact: true, display: String(k) },
          ms: [['M1', `$k(${p}) ${sgn(m)} = ${p}^{2} - k$`], ['A1', `$${p + 1}k = ${p * p - m}$`], ['A1', `$k = ${k}$`]], working: [`Both pieces must meet at $x = ${p}$: $${p}k ${sgn(m)} = ${p * p} - k$`, `$${p + 1}k = ${p * p - m} \\Rightarrow k = ${k}$`],
          hint: 'Continuous means the two pieces give the same value at the join.', verify: `solve(Eq(k*${p}+(${m}),${p}**2-k),k)[0]` }
      ]
    };
  });

  /* ---------- 2.3 Classification: odd/even, one-to-one ---------- */
  const PAR = [
    c => ({ tex: `x^{3} - ${c}x`, py: `x**3-${c}*x`, key: 'odd' }), c => ({ tex: `x^{4} + ${c}x^{2} - 1`, py: `x**4+${c}*x**2-1`, key: 'even' }), c => ({ tex: `x^{3} + ${c}`, py: `x**3+${c}`, key: 'neither' }),
    c => ({ tex: `\\frac{x}{x^{2} + ${c}}`, py: `x/(x**2+${c})`, key: 'odd' }), c => ({ tex: `x|x| + ${c}x`, py: `x*Abs(x)+${c}*x`, key: 'odd' }), c => ({ tex: `|x| + ${c}x^{2}`, py: `Abs(x)+${c}*x**2`, key: 'even' }),
    c => ({ tex: `x^{2} + ${c}x`, py: `x**2+${c}*x`, key: 'neither' }), c => ({ tex: `\\frac{x^{2} + ${c}}{x^{4} + 1}`, py: `(x**2+${c})/(x**4+1)`, key: 'even' })];
  reg('hl.classify', { skill: 'HL-2.3', title: 'Odd, even and one-to-one functions', paper: 1 }, R => {
    const c = R.int(1, 6), f = R.pick(PAR)(c), p = R.nz(-5, 5), q = R.int(-4, 9), cc = R.int(1, 5);
    const oneOne = mc(R, [{ tex: `$y = x^{3} + ${cc}$`, key: 'cube' }, { tex: `$y = x^{2} + ${cc}$`, key: 'sq' }, { tex: `$y = |x - ${cc}|$`, key: 'abs' }, { tex: `$y = x^{4} - ${cc}x^{2}$`, key: 'quart' }], 'cube');
    return {
      stem: '',
      parts: [
        { command: 'Determine', prompt: `whether $f(x) = ${f.tex}$ is odd, even or neither.`, marks: 2, answer: Object.assign(mc(R, [{ tex: 'Odd', key: 'odd' }, { tex: 'Even', key: 'even' }, { tex: 'Neither', key: 'neither' }], f.key), { display: f.key }),
          ms: [['M1', 'finding $f(-x)$'], ['A1', `${f.key}, since $f(-x) = ${f.key === 'odd' ? '-f(x)' : f.key === 'even' ? 'f(x)' : '\\text{neither } f(x) \\text{ nor } -f(x)'}$`]], working: [`Replace $x$ by $-x$ and compare with $f(x)$ and $-f(x)$.`],
          hint: 'Even: f(−x) = f(x). Odd: f(−x) = −f(x).', verify: `parity(${f.py})` },
        { command: 'Find', prompt: `the least value of $k$ such that $g(x) = ${poly([[1, 'x^{2}'], [-2 * p, 'x'], [q, '']])}$, $x \\ge k$, is one-to-one.`, marks: 2, answer: { kind: 'num', value: p, exact: true, display: String(p) },
          ms: [['M1', `vertex at $x = ${p}$`], ['A1', `$k = ${p}$`]], working: [`$g(x) = (x ${sgn(-p)})^{2} ${sgn(q - p * p)}$`, `One-to-one on one side of the vertex: $k = ${p}$`], hint: 'A parabola is one-to-one on either side of its vertex.', errors: [{ value: -p, tag: 'vertex-sign', fb: '$x = -\\frac{b}{2a}$: check the sign.' }], verify: `-Rational(${-2 * p},2)` },
        { command: 'State', prompt: 'which function is one-to-one on its whole domain $x\\in\\mathbb{R}$.', marks: 1, answer: Object.assign(oneOne, { display: `y = x^{3} + ${cc}` }), ms: [['A1', `$y = x^{3} + ${cc}$`]], working: ['It is strictly increasing, so it passes the horizontal line test.'], hint: 'Horizontal line test.', verify: `'cube' if is_increasing(x**3+${cc}, Interval(-oo,oo)) and solve(diff(x**3+${cc},x),x)==[0] and not is_monotonic(x**2+${cc}, Interval(-oo,oo)) and not is_monotonic(Abs(xr-${cc}), Interval(-oo,oo)) else 'x'` }
      ]
    };
  });

  /* ---------- 2.4 Composite functions ---------- */
  reg('hl.composite', { skill: 'HL-2.4a', title: 'Composite functions and their domains', paper: 1 }, R => {
    let a, b, c, d, e, p, T;
    for (let g = 0; g < 300; g++) {
      a = R.nz(-4, 5); b = R.nz(-6, 6); c = R.nz(-4, 4); d = R.pick([-3, -2, 2, 3]); e = R.nz(-5, 5); p = R.nz(-4, 4); T = R.nz(-6, 6);
      if (a === -b / c) continue; if (d * p + e === c) continue; if (T === a) continue; if (a * c + b === 0) continue; if ((b + T * c) === c * (T - a)) continue;
      break;
    }
    const f = v => fr(a).mul(v).add(b).div(F.of(v).sub(c)), gp = d * p + e, fogp = f(fr(gp)), gofp = p !== c ? fr(d).mul(f(fr(p))).add(e) : null;
    const xUndef = fr(c - e, d), K = d * T + e, xs = fr(b + T * c, T - a);
    return {
      stem: `Let $f(x) = \\frac{${lin(a, b)}}{x ${sgn(-c)}}$, $x \\ne ${c}$, and $g(x) = ${lin(d, e)}$.`,
      parts: [
        { command: 'Find', prompt: `$(f\\circ g)(${p})$.`, marks: 2, answer: { kind: 'num', value: fogp.val(), exact: true, display: fogp.tex() }, ms: [['M1', `$g(${p}) = ${gp}$`], ['A1', `$f(${gp}) = ${fogp.tex()}$`]],
          working: [`$g(${p}) = ${gp}$`, `$f(${gp}) = \\frac{${a * gp + b}}{${gp - c}} = ${fogp.tex()}$`], hint: 'Apply g first.', errors: c !== p ? [{ value: gofp.val(), tag: 'order-of-composition', fb: '(f∘g)(x) = f(g(x)): g first.' }] : [], verify: `((${a}*x+(${b}))/(x-(${c}))).subs(x,${d}*(${p})+(${e}))` },
        { command: 'Find', prompt: 'the value of $x$ that is excluded from the domain of $f\\circ g$.', marks: 2, answer: { kind: 'num', value: xUndef.val(), exact: true, display: `x = ${xUndef.tex()}` },
          ms: [['M1', `$g(x) = ${c}$`], ['A1', `$x = ${xUndef.tex()}$`]], working: [`$f$ is undefined at $${c}$, so we need $g(x) \\ne ${c}$`, `$${lin(d, e)} = ${c} \\Rightarrow x = ${xUndef.tex()}$`], hint: 'Which outputs of g can f not accept?',
          errors: [{ value: c, tag: 'domain-of-f-not-composite', fb: `x = ${c} is excluded from f. For f∘g, find the x that makes g(x) = ${c}.` }], verify: `solve(Eq(${d}*x+(${e}),${c}),x)[0]` },
        { command: 'Solve', prompt: `$(g\\circ f)(x) = ${K}$.`, marks: 3, answer: { kind: 'num', value: xs.val(), exact: true, display: `x = ${xs.tex()}` },
          ms: [['M1', `$${d}f(x) ${sgn(e)} = ${K}$`], ['A1', `$f(x) = ${T}$`], ['A1', `$x = ${xs.tex()}$`]], working: [`$${d}f(x) ${sgn(e)} = ${K} \\Rightarrow f(x) = ${T}$`, `$${lin(a, b)} = ${T}(x ${sgn(-c)})$`, `$x = ${xs.tex()}$`],
          hint: 'Undo g first to find what f(x) must equal.', verify: `solve(Eq(${d}*(${a}*x+(${b}))/(x-(${c}))+(${e}),${K}),x)[0]` }
      ]
    };
  });

  /* ---------- 2.4 Inverse functions ---------- */
  reg('hl.inverse', { skill: 'HL-2.4b', title: 'Inverse functions and self-inverse functions', paper: 1 }, R => {
    let a, b, c, d, K; do { a = R.nz(-4, 5); b = R.nz(-6, 6); c = R.pick([1, 2, -1, 3]); d = R.nz(-5, 5); K = R.nz(-6, 6); } while (a * d === b * c || K * c === a || (d * K - b) === 0);
    const finv = fr(d * K - b, a - c * K), m = fr(a, c); let bb, cc, dd; do { bb = R.nz(-6, 6); cc = R.pick([1, 2, 3]); dd = R.nz(-5, 5); } while (bb * cc + dd * dd === 0); // avoid a constant h
    return {
      stem: `Let $f(x) = \\frac{${lin(a, b)}}{${lin(c, d)}}$, $x \\ne ${fr(-d, c).tex()}$.`,
      parts: [
        { command: 'Find', prompt: `$f^{-1}(${K})$.`, marks: 3, answer: { kind: 'num', value: finv.val(), exact: true, display: finv.tex() },
          ms: [['M1', `$${K} = \\frac{${lin(a, b)}}{${lin(c, d)}}$ or interchanging $x$ and $y$`], ['M1', 'rearranging to make $x$ (or $y$) the subject'], ['A1', `$${finv.tex()}$`]],
          working: [`Solve $f(x) = ${K}$: $${lin(a, b)} = ${K}(${lin(c, d)})$`, `$x(${a} - ${paren(c * K)}) = ${d * K} - ${paren(b)}$`, `$x = ${finv.tex()}$`], hint: 'f⁻¹(k) is the x with f(x) = k.',
          errors: a * K + b !== 0 ? [{ value: (c * K + d) / (a * K + b), tag: 'reciprocal-not-inverse', fb: '$f^{-1}$ is not $\\frac{1}{f}$.' }] : [], verify: `solve(Eq((${a}*x+(${b}))/(${c}*x+(${d})),${K}),x)[0]` },
        { command: 'Write down', prompt: 'the value of $x$ that is not in the domain of $f^{-1}$.', marks: 1, answer: { kind: 'num', value: m.val(), exact: true, display: `x \\ne ${m.tex()}` }, ms: [['A1', `$${m.tex()}$`]],
          working: [`Domain of $f^{-1}$ = range of $f$; $f$ never equals its horizontal asymptote $y = ${m.tex()}$.`], hint: 'The domain of f⁻¹ is the range of f.', errors: [{ value: -d / c, tag: 'domain-not-range', fb: 'That value is excluded from the domain of f. The inverse swaps domain and range.' }], verify: `limit((${a}*x+(${b}))/(${c}*x+(${d})),x,oo)` },
        { command: 'Find', prompt: `the value of $k$ for which $h(x) = \\frac{kx ${sgn(bb)}}{${lin(cc, dd)}}$ is self-inverse.`, marks: 2, answer: { kind: 'num', value: -dd, exact: true, display: String(-dd) },
          ms: [['M1', '$h(h(x)) = x$ or $h^{-1} = h$'], ['A1', `$k = ${-dd}$`]], working: [`$h^{-1}(x) = \\frac{${dd === 0 ? '' : -dd}x ${sgn(bb)}}{${cc}x - k}$`, `Matching with $h$: $k = ${-dd}$`], hint: 'Find h⁻¹ and compare it with h.', errors: [{ value: dd, tag: 'sign', fb: 'Compare the denominators carefully.' }],
          verify: `(-(${dd})) if simplify(((-(${dd})*x+(${bb}))/(${cc}*x+(${dd}))).subs(x,(-(${dd})*x+(${bb}))/(${cc}*x+(${dd})))-x)==0 and simplify(((1-(${dd}))*x+(${bb}))/(${cc}*x+(${dd})) - x)!=0 else None` }
      ]
    };
  });

  /* ---------- 2.5 Transformations ---------- */
  reg('hl.transform', { skill: 'HL-2.5a', title: 'Sequences of transformations', paper: 1 }, R => {
    const p = R.nz(-5, 5), q = R.nz(-5, 6), h = R.nz(-4, 4), k = R.nz(-4, 4), a = R.pick([2, 3, 4]), b = R.pick([2, 3]);
    const img = [p + h, -a * (q + k)];
    const opts = [{ tex: `$y = -${a}f(x ${sgn(-h)}) ${sgn(-a * k)}$`, key: 'ok' }, { tex: `$y = -${a}f(x ${sgn(h)}) ${sgn(-a * k)}$`, key: 'h' }, { tex: `$y = -${a}f(x ${sgn(-h)}) ${sgn(k)}$`, key: 'k' }, { tex: `$y = ${a}f(x ${sgn(-h)}) ${sgn(a * k)}$`, key: 'refl' }];
    return {
      stem: `The point $P(${p},\\,${q})$ lies on $y = f(x)$. The graph is transformed by: a translation by the vector $\\binom{${h}}{${k}}$, followed by a vertical stretch with scale factor $${a}$, followed by a reflection in the $x$-axis.`,
      parts: [
        { command: 'Find', prompt: 'the coordinates of the image of $P$.', marks: 3, answer: { kind: 'tuple', labels: ['x', 'y'], value: img, exact: true, markEach: true, display: `(${img[0]},\\,${img[1]})` },
          ms: [['M1', `after translation $(${p + h},\\,${q + k})$`], ['A1', `$x = ${img[0]}$`], ['A1', `$y = ${img[1]}$`]], working: [`Translate: $(${p + h},\\,${q + k})$`, `Stretch: $(${p + h},\\,${a * (q + k)})$`, `Reflect: $(${img[0]},\\,${img[1]})$`],
          hint: 'Apply the transformations one at a time, in the order given.', errors: [{ value: [p + h, -a * q + k], tag: 'order-of-transformations', fb: 'Order matters: translate FIRST, then stretch and reflect.' }], verify: `(${p}+(${h}), -${a}*((${q})+(${k})))` },
        { command: 'Write down', prompt: 'the equation of the transformed graph.', marks: 2, answer: Object.assign(mc(R, opts, 'ok'), { display: opts[0].tex.replace(/\$/g, '') }), ms: [['A2', opts[0].tex]],
          working: [`$y = f(x ${sgn(-h)}) ${sgn(k)} \\to y = ${a}(f(x ${sgn(-h)}) ${sgn(k)}) \\to y = -${a}f(x ${sgn(-h)}) ${sgn(-a * k)}$`], hint: 'The stretch multiplies the WHOLE right-hand side, including the translation term.', verify: `'ok' if (-${a}*((${q})+(${k}))) == -${a}*(${q}) - ${a * k} else 'x'` },
        { command: 'Write down', prompt: `the image of $P$ on $y = f(${b}x)$.`, marks: 1, answer: { kind: 'tuple', labels: ['x', 'y'], value: [p / b, q], exact: true, display: `\\left(${fr(p, b).tex()},\\,${q}\\right)` }, ms: [['A1', `$\\left(${fr(p, b).tex()},\\,${q}\\right)$`]], working: [`Horizontal stretch, factor $\\frac{1}{${b}}$`], hint: 'Inside the function: the opposite of what it looks like.', errors: [{ value: [p * b, q], tag: 'horizontal-stretch-factor', fb: `Divide x by ${b}.` }], verify: `(Rational(${p},${b}),${q})` }
      ]
    };
  });

  reg('hl.modrecip', { skill: 'HL-2.5b', title: 'Modulus and reciprocal graphs', paper: 1 }, R => {
    let r1, r2; do { [r1, r2] = R.distinct(2, -5, 6); } while ((r1 + r2) % 2 !== 0); if (r1 > r2) [r1, r2] = [r2, r1];
    const h = (r1 + r2) / 2, mmin = -(((r2 - r1) / 2) ** 2), kk = R.pick(['inside', 'equal', 'above']);
    const kv = kk === 'inside' ? R.int(1, -mmin - 1) : kk === 'equal' ? -mmin : -mmin + R.int(1, 5); const count = kk === 'inside' ? 4 : kk === 'equal' ? 3 : 2;
    const kvv = kk === 'inside' && -mmin - 1 < 1 ? -mmin : kv; const cnt = kk === 'inside' && -mmin - 1 < 1 ? 3 : count;
    return {
      stem: `Let $f(x) = ${poly([[1, 'x^{2}'], [-(r1 + r2), 'x'], [r1 * r2, '']])}$.`,
      parts: [
        { command: 'Write down', prompt: 'the equations of the vertical asymptotes of $y = \\frac{1}{f(x)}$.', marks: 2, answer: { kind: 'list', value: [r1, r2], exact: true, markEach: true, display: `x = ${r1},\\ x = ${r2}` }, ms: [['A1', `$x = ${r1}$`], ['A1', `$x = ${r2}$`]],
          working: [`Zeros of $f$: $(x ${sgn(-r1)})(x ${sgn(-r2)}) = 0$`], hint: '$\\frac{1}{f(x)}$ has vertical asymptotes where $f(x) = 0$.', errors: [{ value: [-r1, -r2], tag: 'root-signs', fb: 'Solve f(x) = 0: the roots have the opposite sign to the numbers in the brackets.' }], verify: `solve(x**2-(${r1 + r2})*x+(${r1 * r2}),x)` },
        { command: 'Find', prompt: 'the coordinates of the local maximum point on the graph of $y = \\frac{1}{f(x)}$.', marks: 2, answer: { kind: 'tuple', labels: ['x', 'y'], value: [h, 1 / mmin], exact: true, markEach: true, display: `\\left(${h},\\,${fr(1, mmin).tex()}\\right)` },
          ms: [['M1', `minimum of $f$ at $(${h},\\,${mmin})$`], ['A1', `$\\left(${h},\\,${fr(1, mmin).tex()}\\right)$`]], working: [`$f$ has a minimum $(${h},\\,${mmin})$`, `The reciprocal turns it into a local maximum at $\\left(${h},\\,\\frac{1}{${mmin}}\\right)$`],
          hint: 'A minimum of $f$ below the $x$-axis becomes a maximum of $\\frac{1}{f}$. Take the reciprocal of the $y$-coordinate only.', errors: [{ value: [h, mmin], tag: 'did-not-take-reciprocal', fb: 'Take the reciprocal of the y-value.' }], verify: `(Rational(${r1 + r2},2), 1/((x**2-(${r1 + r2})*x+(${r1 * r2})).subs(x,Rational(${r1 + r2},2))))` },
        { command: 'Write down', prompt: `the number of solutions of $|f(x)| = ${kvv}$.`, marks: 1, answer: { kind: 'num', value: cnt, int: true, display: String(cnt) }, ms: [['A1', `$${cnt}$`]],
          working: [`Sketch $y = |f(x)|$: the part below the axis reflects up, with a local maximum height $${-mmin}$ at $x = ${h}$. Count intersections with $y = ${kvv}$.`], hint: 'Sketch y = |f(x)| and the horizontal line.', verify: `len(solve(Eq(Abs(xr**2-(${r1 + r2})*xr+(${r1 * r2})),${kvv}),xr))` }
      ]
    };
  });

  /* ---------- 3.1 Quadratic inequalities ---------- */
  reg('hl.quadineq', { skill: 'HL-3.1', title: 'Quadratic inequalities and the discriminant', paper: 1 }, R => {
    const [r1, r2] = R.distinct(2, -6, 7).sort((u, v) => u - v), s = R.int(2, 7), ge = R.bool();
    const opts = [{ tex: `$${r1} < x < ${r2}$`, key: 'in' }, { tex: `$x < ${r1}$ or $x > ${r2}$`, key: 'out' }, { tex: `$x \\le ${r1}$ or $x \\ge ${r2}$`, key: 'outE' }, { tex: `$${r1} \\le x \\le ${r2}$`, key: 'inE' }];
    const key = ge ? 'outE' : 'in';
    return {
      stem: '',
      parts: [
        { command: 'Solve', prompt: `$${poly([[1, 'x^{2}'], [-(r1 + r2), 'x'], [r1 * r2, '']])} ${ge ? '\\ge' : '<'} 0$.`, marks: 3, answer: Object.assign(mc(R, opts, key), { display: opts.find(o => o.key === key).tex.replace(/\$/g, '') }),
          ms: [['M1', `roots $${r1}$ and $${r2}$`], ['M1', 'sketch or sign diagram'], ['A1', opts.find(o => o.key === key).tex]], working: [`$(x ${sgn(-r1)})(x ${sgn(-r2)}) ${ge ? '\\ge' : '<'} 0$`, `Upward parabola: ${ge ? 'on or outside' : 'strictly between'} the roots`],
          hint: 'Find the roots, sketch the parabola, and read off where it is above/below the x-axis.', verify: `'${key}'` },
        { command: 'Find', prompt: `the set of values of $k$ for which $x^{2} + kx + ${s * s} > 0$ for all $x\\in\\mathbb{R}$. Give $a < k < b$.`, marks: 4, answer: { kind: 'tuple', labels: ['a', 'b'], value: [-2 * s, 2 * s], exact: true, markEach: true, display: `${-2 * s} < k < ${2 * s}` },
          ms: [['M1', '$\\Delta < 0$'], ['A1', `$k^{2} - ${4 * s * s} < 0$`], ['A1A1', `$${-2 * s} < k < ${2 * s}$`]], working: [`Always positive: no real roots, $\\Delta < 0$`, `$k^{2} - 4(${s * s}) < 0 \\Rightarrow ${-2 * s} < k < ${2 * s}$`],
          hint: 'An upward parabola is always positive when it never meets the x-axis.', errors: [{ value: [-s, s], tag: 'forgot-4ac', fb: 'Δ = k² − 4ac: include the 4.' }], verify: `tuple(sorted(solve(k**2-4*${s * s},k)))` }
      ]
    };
  });

  /* ---------- 3.2 Complex numbers ---------- */
  reg('hl.complex', { skill: 'HL-3.2', title: 'Complex numbers in Cartesian form', paper: 1 }, R => {
    const a = R.nz(-5, 6), b = R.nz(-5, 6), c = R.nz(-4, 5), d = R.nz(-4, 5), den = c * c + d * d;
    const re = fr(a * c + b * d, den), im = fr(b * c - a * d, den);
    const pp = R.nz(-4, 5), qq = R.int(1, 5);
    const ztex = (u, v) => v === 0 ? `${u}` : `${u} ${v < 0 ? '-' : '+'} ${Math.abs(v) === 1 ? '' : Math.abs(v)}\\mathrm{i}`;
    return {
      stem: `Let $z = ${ztex(a, b)}$ and $w = ${ztex(c, d)}$.`,
      parts: [
        { command: 'Find', prompt: '$zw$, giving your answer in the form $p + q\\mathrm{i}$.', marks: 2, answer: { kind: 'tuple', labels: ['p', 'q'], value: [a * c - b * d, a * d + b * c], exact: true, markEach: true, display: ztex(a * c - b * d, a * d + b * c) },
          ms: [['M1', 'expanding with $\\mathrm{i}^{2} = -1$'], ['A1', `$${ztex(a * c - b * d, a * d + b * c)}$`]], working: [`$(${ztex(a, b)})(${ztex(c, d)}) = ${a * c} ${sgn(a * d)}\\mathrm{i} ${sgn(b * c)}\\mathrm{i} ${sgn(b * d)}\\mathrm{i}^{2}$`, `$= ${ztex(a * c - b * d, a * d + b * c)}$`],
          hint: 'Expand like two brackets, then use i² = −1.', errors: [{ value: [a * c + b * d, a * d + b * c], tag: 'i-squared', fb: 'i² = −1, so the i² term changes sign.' }], verify: `(re(expand((${a}+${b}*I)*(${c}+${d}*I))), im(expand((${a}+${b}*I)*(${c}+${d}*I))))` },
        { command: 'Find', prompt: '$\\frac{z}{w}$, giving your answer in the form $p + q\\mathrm{i}$ where $p, q\\in\\mathbb{Q}$.', marks: 3, answer: { kind: 'tuple', labels: ['p', 'q'], value: [re.val(), im.val()], exact: true, markEach: true, display: `${re.tex()} ${im.n < 0 ? '-' : '+'} ${im.n < 0 ? im.neg().tex() : im.tex()}\\mathrm{i}` },
          ms: [['M1', `multiplying by $\\frac{w^{*}}{w^{*}} = \\frac{${ztex(c, -d)}}{${ztex(c, -d)}}$`], ['A1', `denominator $${den}$`], ['A1', `$${re.tex()} ${im.n < 0 ? '-' : '+'} ${im.n < 0 ? im.neg().tex() : im.tex()}\\mathrm{i}$`]],
          working: [`$\\frac{(${ztex(a, b)})(${ztex(c, -d)})}{${c}^{2} + ${d * d}} = \\frac{${ztex(a * c + b * d, b * c - a * d)}}{${den}}$`], hint: 'Multiply top and bottom by the conjugate of w.', verify: `(re(simplify((${a}+${b}*I)/(${c}+${d}*I))), im(simplify((${a}+${b}*I)/(${c}+${d}*I))))` },
        { command: 'Find', prompt: '$|z|$.', marks: 1, answer: { kind: 'num', value: Math.sqrt(a * a + b * b), exact: true, display: `\\sqrt{${a * a + b * b}}` }, ms: [['A1', `$\\sqrt{${a * a + b * b}}$`]], working: [`$|z| = \\sqrt{${a}^{2} + ${paren(b)}^{2}} = \\sqrt{${a * a + b * b}}$`], hint: 'Modulus = distance from the origin on the Argand diagram.', errors: [{ value: a * a + b * b, tag: 'forgot-root', fb: 'Take the square root.' }], verify: `Abs(${a}+${b}*I)` },
        { command: 'Solve', prompt: `$z^{2} ${sgn(-2 * pp)}z + ${pp * pp + qq * qq} = 0$, giving your answers in the form $p \\pm q\\mathrm{i}$, $q > 0$.`, marks: 3, answer: { kind: 'tuple', labels: ['p', 'q'], value: [pp, qq], exact: true, markEach: true, display: `${pp} \\pm ${qq === 1 ? '' : qq}\\mathrm{i}` },
          ms: [['M1', `$\\Delta = ${4 * pp * pp} - ${4 * (pp * pp + qq * qq)} = ${-4 * qq * qq}$`], ['A1', `$\\sqrt{\\Delta} = ${2 * qq}\\mathrm{i}$`], ['A1', `$${pp} \\pm ${qq === 1 ? '' : qq}\\mathrm{i}$`]],
          working: [`$z = \\frac{${2 * pp} \\pm \\sqrt{${-4 * qq * qq}}}{2} = \\frac{${2 * pp} \\pm ${2 * qq}\\mathrm{i}}{2} = ${pp} \\pm ${qq === 1 ? '' : qq}\\mathrm{i}$`], hint: 'Quadratic formula; the square root of a negative number gives i.',
          verify: `(re(solve(z**2-${2 * pp}*z+${pp * pp + qq * qq},z)[0]), abs(im(solve(z**2-${2 * pp}*z+${pp * pp + qq * qq},z)[0])))` }
      ]
    };
  });

  /* ---------- 3.3 Factor and remainder theorems ---------- */
  reg('hl.factorrem', { skill: 'HL-3.3', title: 'Factor and remainder theorems (simultaneous)', paper: 1 }, R => {
    let a, b, c, r, s; do { a = R.int(-6, 6); b = R.int(-9, 9); [r, s] = R.distinct(2, -3, 3, [0]); c = -(r ** 3 + a * r * r + b * r); } while (Math.abs(c) > 60 || c === 0);
    const Rm = s ** 3 + a * s * s + b * s + c;
    return {
      stem: `$p(x) = x^{3} + ax^{2} + bx ${sgn(c)}$, where $a, b\\in\\mathbb{Z}$. $(x ${sgn(-r)})$ is a factor of $p(x)$, and when $p(x)$ is divided by $(x ${sgn(-s)})$ the remainder is $${Rm}$.`,
      parts: [
        { command: 'Find', prompt: 'the values of $a$ and $b$.', marks: 5, answer: { kind: 'tuple', labels: ['a', 'b'], value: [a, b], exact: true, markEach: true, display: `a = ${a},\\ b = ${b}` },
          ms: [['M1', `$p(${r}) = 0$`], ['M1', `$p(${s}) = ${Rm}$`], ['A1', `$${r * r}a ${sgn(r)}b = ${-(r ** 3) - c}$ and $${s * s}a ${sgn(s)}b = ${Rm - s ** 3 - c}$`], ['A1', `$a = ${a}$`], ['A1', `$b = ${b}$`]],
          working: [`Factor theorem: $p(${r}) = ${r ** 3} + ${r * r}a ${sgn(r)}b ${sgn(c)} = 0$`, `Remainder theorem: $p(${s}) = ${s ** 3} + ${s * s}a ${sgn(s)}b ${sgn(c)} = ${Rm}$`, `Solving simultaneously: $a = ${a}$, $b = ${b}$`],
          hint: 'Factor theorem gives one equation, remainder theorem the other.', errors: [{ value: [b, a], tag: 'swapped', fb: 'Check which value is a and which is b.' }],
          verify: `tuple(solve([Eq((${r})**3+x*(${r})**2+y*(${r})+(${c}),0),Eq((${s})**3+x*(${s})**2+y*(${s})+(${c}),${Rm})],[x,y]).values())` }
      ]
    };
  });

  /* ---------- 3.4 Sum and product of roots ---------- */
  reg('hl.vieta', { skill: 'HL-3.4', title: 'Sum and product of roots of polynomials', paper: 1 }, R => {
    const an = R.pick([1, 2, 3, -2]), b = R.nz(-9, 9), c = R.nz(-9, 9), d = R.nz(-9, 9);
    const sum = fr(-b, an), sp = fr(c, an), prod = fr(-d, an), sq = sum.mul(sum).sub(sp.mul(2));
    return {
      stem: `The cubic equation $${poly([[an, 'x^{3}'], [b, 'x^{2}'], [c, 'x'], [d, '']])} = 0$ has roots $\\alpha$, $\\beta$ and $\\gamma$.`,
      parts: [
        { command: 'Write down', prompt: 'the value of $\\alpha + \\beta + \\gamma$.', marks: 1, answer: { kind: 'num', value: sum.val(), exact: true, display: sum.tex() }, ms: [['A1', `$${sum.tex()}$`]], working: [`Sum $= -\\frac{a_{n-1}}{a_n} = -\\frac{${b}}{${an}}$`], hint: 'Formula booklet: sum of roots $= -\\frac{a_{n-1}}{a_n}$.', errors: [{ value: -sum.val(), tag: 'vieta-sign', fb: 'Sum of roots is $-\\frac{a_{n-1}}{a_n}$: watch the sign.' }], verify: `re(N(sum(Poly(${an}*x**3+(${b})*x**2+(${c})*x+(${d}),x).nroots())))` },
        { command: 'Write down', prompt: 'the value of $\\alpha\\beta\\gamma$.', marks: 1, answer: { kind: 'num', value: prod.val(), exact: true, display: prod.tex() }, ms: [['A1', `$${prod.tex()}$`]], working: [`Product $= \\frac{(-1)^{3}a_0}{a_n} = \\frac{${-d}}{${an}}$`], hint: 'Product $= \\frac{(-1)^{n}a_0}{a_n}$.', errors: [{ value: -prod.val(), tag: 'vieta-sign', fb: 'For a cubic, (−1)³ = −1.' }], verify: `re(N(prod(Poly(${an}*x**3+(${b})*x**2+(${c})*x+(${d}),x).nroots())))` },
        { command: 'Find', prompt: 'the value of $\\alpha^{2} + \\beta^{2} + \\gamma^{2}$.', marks: 3, answer: { kind: 'num', value: sq.val(), exact: true, display: sq.tex() },
          ms: [['M1', '$(\\alpha + \\beta + \\gamma)^{2} - 2(\\alpha\\beta + \\beta\\gamma + \\gamma\\alpha)$'], ['A1', `$\\alpha\\beta + \\beta\\gamma + \\gamma\\alpha = ${sp.tex()}$`], ['A1', `$${sq.tex()}$`]],
          working: [`$\\alpha\\beta + \\beta\\gamma + \\gamma\\alpha = \\frac{${c}}{${an}}$`, `$\\left(${sum.tex()}\\right)^{2} - 2\\left(${sp.tex()}\\right) = ${sq.tex()}$`], hint: 'Expand (α + β + γ)² and rearrange.',
          errors: [{ value: sum.mul(sum).val(), tag: 'forgot-cross-terms', fb: '(α + β + γ)² also contains 2(αβ + βγ + γα).' }], verify: `re(N(sum(rt**2 for rt in Poly(${an}*x**3+(${b})*x**2+(${c})*x+(${d}),x).nroots())))` }
      ]
    };
  });

  /* ---------- 3.6 Systems of linear equations ---------- */
  reg('hl.systems', { skill: 'HL-3.6', title: 'Systems of linear equations', paper: 2 }, R => {
    let M, det, sol; const d3 = m => m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
    do { M = [0, 1, 2].map(() => [R.nz(-3, 4), R.nz(-3, 4), R.nz(-3, 4)]); det = d3(M); } while (det === 0);
    sol = [R.nz(-4, 5), R.nz(-4, 5), R.int(-4, 5)]; const rhs = M.map(row => row[0] * sol[0] + row[1] * sol[1] + row[2] * sol[2]);
    const eq = (row, v) => `${poly([[row[0], 'x'], [row[1], 'y'], [row[2], 'z']])} = ${v}`;
    // k-system: rows [1,1,1],[1,2,k],[1,k,u]; det = (2u - k^2) - (u - k) + (k - 2) = -k^2 + 2k + u - 2 → choose integer roots
    const k1 = R.int(-3, 1), k2 = R.int(2, 5); // det = -(k-k1)(k-k2) = -k^2 + (k1+k2)k - k1k2 → need 2 = k1+k2 → adjust
    const kk1 = 1 - R.int(1, 4), kk2 = 2 - kk1, u = 2 - kk1 * kk2;
    return {
      stem: '',
      parts: [
        { command: 'Solve', prompt: `the system $\\quad ${eq(M[0], rhs[0])},\\quad ${eq(M[1], rhs[1])},\\quad ${eq(M[2], rhs[2])}$.`, marks: 3, answer: { kind: 'tuple', labels: ['x', 'y', 'z'], value: sol, exact: true, markEach: true, display: `x = ${sol[0]},\\ y = ${sol[1]},\\ z = ${sol[2]}` },
          ms: [['(M1)', 'use of GDC'], ['A2', `$x = ${sol[0]},\\ y = ${sol[1]},\\ z = ${sol[2]}$`]], working: ['NumWorks Equations app: enter all three equations and solve.'], hint: 'NumWorks: Equations app → add three equations → Solve.', numworks: { app: 'Equations', lines: [[eq(M[0], rhs[0]).replace(/\\,/g, ''), ''], [eq(M[1], rhs[1]), ''], [eq(M[2], rhs[2]), ''], ['Solve', `x=${sol[0]}  y=${sol[1]}  z=${sol[2]}`]] },
          verify: `tuple(solve([${M.map((row, i) => `Eq(${row[0]}*x+(${row[1]})*y+(${row[2]})*z,${rhs[i]})`).join(',')}],[x,y,z]).values())` },
        { command: 'Find', prompt: `the values of $k$ for which the system $x + y + z = 1,\\ x + 2y + kz = 3,\\ x + ky + ${u}z = 2$ does not have a unique solution.`, marks: 4, paper: 1, answer: { kind: 'list', value: [kk1, kk2], exact: true, markEach: true, display: `k = ${kk1},\\ k = ${kk2}` },
          ms: [['M1', 'determinant of coefficients $= 0$ (or row reduction)'], ['A1', `$-k^{2} + 2k ${sgn(u - 2)} = 0$`], ['A1A1', `$k = ${kk1},\\ ${kk2}$`]], working: [`$\\det\\begin{pmatrix}1&1&1\\\\1&2&k\\\\1&k&${u}\\end{pmatrix}$`.replace(/\\begin\{pmatrix\}.*\\end\{pmatrix\}/, '(\\text{coefficient matrix})'), `$= -k^{2} + 2k ${sgn(u - 2)} = -(k ${sgn(-kk1)})(k ${sgn(-kk2)})$`, `$k = ${kk1}$ or $k = ${kk2}$`],
          hint: 'No unique solution when the determinant of the coefficient matrix is zero (or use row reduction).', verify: `solve(Matrix([[1,1,1],[1,2,k],[1,k,${u}]]).det(),k)` }
      ]
    };
  });

  /* ---------- 4 Differentiation (HL) ---------- */
  reg('hl.limits', { skill: 'HL-4.1', title: 'Limits', paper: 1 }, R => {
    const a = R.nz(-6, 6), p = R.int(2, 7), q = R.nz(-9, 9), rr = R.int(2, 6), s = R.nz(-9, 9);
    return {
      stem: '',
      parts: [
        { command: 'Find', prompt: `$\\lim_{x\\to ${a}} \\frac{x^{2} - ${a * a}}{x ${sgn(-a)}}$.`, marks: 2, answer: { kind: 'num', value: 2 * a, exact: true, display: String(2 * a) }, ms: [['M1', `$\\frac{(x ${sgn(-a)})(x ${sgn(a)})}{x ${sgn(-a)}}$`], ['A1', `$${2 * a}$`]], working: [`Factorise and cancel: $x ${sgn(a)} \\to ${2 * a}$`], hint: 'Direct substitution gives $\\frac{0}{0}$: factorise first.', errors: [{ value: 0, tag: 'substituted-0-over-0', fb: '$\\frac{0}{0}$ is not $0$: it is undefined. Simplify first.' }], verify: `limit((x**2-${a * a})/(x-(${a})),x,${a})` },
        { command: 'Find', prompt: `$\\lim_{x\\to\\infty} \\frac{${p}x^{2} ${sgn(q)}}{${rr}x^{2} ${sgn(s)}}$.`, marks: 2, answer: { kind: 'num', value: p / rr, exact: true, display: fr(p, rr).tex() }, ms: [['M1', 'dividing by $x^{2}$'], ['A1', `$${fr(p, rr).tex()}$`]], working: [`Divide by $x^{2}$; the constant terms $\\to 0$`], hint: 'Divide every term by the highest power of x.', errors: [{ value: q / s, tag: 'constants-not-leading', fb: 'As x → ∞ the x² terms dominate.' }], verify: `limit((${p}*x**2+(${q}))/(${rr}*x**2+(${s})),x,oo)` }
      ]
    };
  });

  reg('hl.chain', { skill: 'HL-4.3', title: 'Chain, product and quotient rules', paper: 1 }, R => {
    let a, b, p; do { a = R.nz(-3, 3); b = R.nz(-4, 4); p = R.nz(-2, 2); } while (a * p + b === 0);
    const nn = R.pick([2, 3]), u = a * p + b, fprime = 2 * p * Math.pow(u, nn) + nn * a * p * p * Math.pow(u, nn - 1);
    let c, q; do { c = R.nz(-4, 4); q = R.nz(-3, 3); } while (q + c === 0);
    const gprime = fr(q * q + 2 * c * q, (q + c) * (q + c));
    return {
      stem: '',
      parts: [
        { command: 'Find', prompt: `$f'(${p})$, where $f(x) = x^{2}(${lin(a, b)})^{${nn}}$.`, marks: 4, answer: { kind: 'num', value: fprime, exact: true, display: String(fprime) },
          ms: [['M1', 'product rule'], ['A1', `$2x(${lin(a, b)})^{${nn}}$`], ['A1', `$${nn * a}x^{2}(${lin(a, b)})^{${nn - 1}}$ (chain rule)`], ['A1', `$${fprime}$`]],
          working: [`$f'(x) = 2x(${lin(a, b)})^{${nn}} + x^{2}\\cdot ${nn}(${lin(a, b)})^{${nn - 1}}\\cdot ${a}$`, `$f'(${p}) = ${2 * p}(${u})^{${nn}} + ${p * p}\\cdot ${nn}(${u})^{${nn - 1}}\\cdot ${paren(a)} = ${fprime}$`], hint: 'Product rule, and the chain rule for the bracket (don’t forget the derivative of the inside).',
          errors: [{ value: 2 * p * Math.pow(u, nn) + nn * p * p * Math.pow(u, nn - 1), tag: 'chain-rule-inside', fb: `Multiply by the derivative of the inside, ${a}.` }, { value: 2 * p * nn * a * Math.pow(u, nn - 1), tag: 'product-of-derivatives', fb: '(uv)′ = u′v + uv′, not u′v′.' }], verify: `diff(x**2*(${a}*x+(${b}))**${nn},x).subs(x,${p})` },
        { command: 'Find', prompt: `$g'(${q})$, where $g(x) = \\frac{x^{2}}{x ${sgn(c)}}$.`, marks: 3, answer: { kind: 'num', value: gprime.val(), exact: true, display: gprime.tex() },
          ms: [['M1', 'quotient rule'], ['A1', `$\\frac{2x(x ${sgn(c)}) - x^{2}}{(x ${sgn(c)})^{2}}$`], ['A1', `$${gprime.tex()}$`]], working: [`$g'(x) = \\frac{2x(x ${sgn(c)}) - x^{2}(1)}{(x ${sgn(c)})^{2}} = \\frac{x^{2} ${sgn(2 * c)}x}{(x ${sgn(c)})^{2}}$`, `$g'(${q}) = ${gprime.tex()}$`],
          hint: 'Quotient rule: $\\frac{vu\\prime - uv\\prime}{v^{2}}$.', errors: [{ value: fr(-(q * q + 2 * c * q), (q + c) * (q + c)).val(), tag: 'quotient-order', fb: 'The numerator is vu′ − uv′ (in that order).' }], verify: `diff(x**2/(x+(${c})),x).subs(x,${q})` }
      ]
    };
  });

  reg('hl.implicit', { skill: 'HL-4.6', title: 'Implicit differentiation and related rates', paper: 1 }, R => {
    let a, p, q; do { a = R.nz(-3, 3); p = R.nz(-3, 3); q = R.nz(-3, 3); } while (a * p + 2 * q === 0 || 2 * p + a * q === 0);
    const C = p * p + a * p * q + q * q, dydx = fr(-(2 * p + a * q), a * p + 2 * q);
    const rad = R.int(3, 9), rate = R.pick([0.2, 0.3, 0.5, 1.5]), dV = 4 * Math.PI * rad * rad * rate;
    return {
      stem: '',
      parts: [
        { command: 'Find', prompt: `the gradient of the curve $x^{2} ${sgn(a)}xy + y^{2} = ${C}$ at the point $(${p},\\,${q})$.`, marks: 5, answer: { kind: 'num', value: dydx.val(), exact: true, display: dydx.tex() },
          ms: [['M1', 'implicit differentiation'], ['A1', `$2x ${sgn(a)}y ${sgn(a)}x\\frac{dy}{dx}$ (product rule)`], ['A1', '$2y\\frac{dy}{dx}$'], ['M1', 'substituting the point'], ['A1', `$${dydx.tex()}$`]],
          working: [`$2x + ${a}\\left(y + x\\frac{dy}{dx}\\right) + 2y\\frac{dy}{dx} = 0$`, `$\\frac{dy}{dx} = -\\frac{2x ${sgn(a)}y}{${a}x + 2y}$`, `At $(${p},\\,${q})$: $\\frac{dy}{dx} = ${dydx.tex()}$`],
          hint: 'Differentiate every term with respect to x; use the product rule on the xy term.', errors: [{ value: fr(-2 * p, a * p + 2 * q).val(), tag: 'product-rule-missing', fb: `$\\frac{d}{dx}(${a}xy)$ needs the product rule: $${a}\\left(y + x\\frac{dy}{dx}\\right)$.` }],
          verify: `(-diff(x**2+(${a})*x*y+y**2,x)/diff(x**2+(${a})*x*y+y**2,y)).subs({x:${p},y:${q}})` },
        { command: 'Find', prompt: `The radius of a spherical balloon increases at $${rate}$ cm s$^{-1}$. Find the rate at which its volume increases when the radius is $${rad}$ cm.`, marks: 3, paper: 2, answer: { kind: 'num', value: dV, sf: 3, display: `${num(sf(dV, 3))}\\text{ cm}^{3}\\text{ s}^{-1}` },
          ms: [['M1', '$\\frac{dV}{dr} = 4\\pi r^{2}$'], ['M1', '$\\frac{dV}{dt} = \\frac{dV}{dr}\\times\\frac{dr}{dt}$'], ['A1', `$${num(sf(dV, 3))}$ cm³ s⁻¹`]], working: [`$\\frac{dV}{dt} = 4\\pi(${rad})^{2}(${rate}) = ${num(round(4 * rad * rad * rate, 4))}\\pi \\approx ${num(sf(dV, 3))}$`],
          hint: 'Chain rule: $\\frac{dV}{dt} = \\frac{dV}{dr}\\times\\frac{dr}{dt}$.', errors: [{ value: 4 / 3 * Math.PI * rad ** 3 * rate, tag: 'did-not-differentiate', fb: 'Differentiate $V = \\frac{4}{3}\\pi r^{3}$ before multiplying by $\\frac{dr}{dt}$.' }], verify: `4*pi*${rad}**2*Rational(${Math.round(rate * 10)},10)` }
      ]
    };
  });

  reg('hl.optim', { skill: 'HL-4.5', title: 'Optimisation: minimum surface area (NumWorks)', paper: 2 }, R => {
    const V = R.pick([330, 500, 750, 1000]), r = Math.cbrt(V / (2 * Math.PI)), A = 2 * Math.PI * r * r + 2 * V / r;
    return {
      stem: `A closed cylindrical can has volume $${V}$ cm³, radius $r$ cm and height $h$ cm.`,
      parts: [
        { command: 'Show that', prompt: `the surface area is $A = 2\\pi r^{2} + \\frac{${2 * V}}{r}$.`, marks: 2, answer: { kind: 'open', display: 'See markscheme' }, ms: [['M1', `$h = \\frac{${V}}{\\pi r^{2}}$`], ['AG', `$A = 2\\pi r^{2} + 2\\pi r\\cdot\\frac{${V}}{\\pi r^{2}} = 2\\pi r^{2} + \\frac{${2 * V}}{r}$`]], working: [`$\\pi r^{2}h = ${V}$`, `$A = 2\\pi r^{2} + 2\\pi rh = 2\\pi r^{2} + \\frac{${2 * V}}{r}$`], hint: 'Eliminate h using the volume.', verify: `simplify(2*pi*x**2+2*pi*x*(${V}/(pi*x**2)) - (2*pi*x**2+${2 * V}/x))==0` },
        { command: 'Find', dep: true, prompt: 'the value of $r$ that minimises $A$.', marks: 3, answer: { kind: 'num', value: r, sf: 3, display: num(sf(r, 3)) }, ms: [['M1', `$\\frac{dA}{dr} = 4\\pi r - \\frac{${2 * V}}{r^{2}}$`], ['M1', '$\\frac{dA}{dr} = 0$'], ['A1', `$r = ${num(sf(r, 3))}$`]],
          working: [`$4\\pi r = \\frac{${2 * V}}{r^{2}} \\Rightarrow r^{3} = \\frac{${V}}{2\\pi}$`, `$r = ${num(sf(r, 4))}$`], hint: 'Differentiate, set to zero (or use NumWorks Minimum).', numworks: { app: 'Grapher', lines: [[`$y=2\\pi x^{2}+\\frac{${2 * V}}{x}$`, ''], ['Minimum', `x=${num(sf(r, 4))}  y=${num(sf(A, 4))}`]] }, verify: `real_root(Rational(${V})/(2*pi),3)` },
        { command: 'Find', dep: true, prompt: 'the minimum surface area.', marks: 1, answer: { kind: 'num', value: A, sf: 3, display: `${num(sf(A, 3))}\\text{ cm}^{2}` }, ms: [['A1', `$${num(sf(A, 3))}$ cm²`]], working: [`$A = ${num(sf(A, 4))}$`], hint: 'Substitute your r (unrounded) into A.', verify: `(2*pi*x**2+${2 * V}/x).subs(x,real_root(Rational(${V})/(2*pi),3))` }
      ]
    };
  });

  /* ---------- 5 Statistics (HL) ---------- */
  reg('hl.statsT', { skill: 'HL-5.2', title: 'Effect of linear transformations on mean and SD', paper: 1 }, R => {
    const mu = R.int(12, 40), sd = R.int(2, 9), a = R.pick([2, 3, -2, 1.5, 0.5]), b = R.nz(-10, 15);
    return {
      stem: `A data set has mean $${mu}$ and standard deviation $${sd}$. Each value $x$ is transformed to $${a === 1 ? '' : num(a)}x ${sgn(b)}$.`,
      parts: [
        { command: 'Write down', prompt: 'the new mean.', marks: 1, answer: { kind: 'num', value: a * mu + b, exact: true, display: num(a * mu + b) }, ms: [['A1', `$${num(a * mu + b)}$`]], working: [`$${num(a)}(${mu}) ${sgn(b)} = ${num(a * mu + b)}$`], hint: 'The mean is affected by both the multiplication and the addition.', verify: `Rational(${Math.round(a * 10)},10)*${mu}+(${b})` },
        { command: 'Write down', prompt: 'the new standard deviation.', marks: 1, answer: { kind: 'num', value: Math.abs(a) * sd, exact: true, display: num(Math.abs(a) * sd) }, ms: [['A1', `$${num(Math.abs(a) * sd)}$`]], working: [`Adding $${b}$ does not change the spread; multiplying by $${num(a)}$ scales it by $|${num(a)}|$.`], hint: 'Does adding a constant change how spread out the data are?',
          errors: [{ value: a * sd + b, tag: 'sd-shifted', fb: 'Adding a constant shifts every value equally: the spread is unchanged.' }, { value: a * sd, tag: 'sd-negative', fb: 'Standard deviation is never negative: use |a|.' }], verify: `Abs(Rational(${Math.round(a * 10)},10))*${sd}` },
        { command: 'Write down', prompt: 'the new variance.', marks: 1, answer: { kind: 'num', value: a * a * sd * sd, exact: true, display: num(a * a * sd * sd) }, ms: [['A1', `$${num(a * a * sd * sd)}$`]], working: [`Variance $= (\\text{SD})^{2}$`], hint: 'Variance is the square of the standard deviation.', errors: [{ value: Math.abs(a) * sd * sd, tag: 'variance-scale', fb: 'Variance scales by a².' }], verify: `(Rational(${Math.round(a * 10)},10)*${sd})**2` }
      ]
    };
  });
  reg('hl.regression', { skill: 'HL-5.4', title: 'Correlation and regression (NumWorks)', paper: 2 }, R => regressionGen(R, 'HL-5.4'));
})(window.Hub = window.Hub || {});
