/* Supabase transport. Public configuration contains no privileged key. */
(function(Hub){
 'use strict';
 const cfg=window.HUB_CONFIG, clone=x=>JSON.parse(JSON.stringify(x));
 const client=window.supabase.createClient(cfg.supabaseUrl,cfg.supabaseKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
 async function call(action,data={}){
  const {data:{session}}=await client.auth.getSession();if(!session)throw Error('Please sign in again.');
  const r=await fetch(cfg.supabaseUrl+'/functions/v1/hub',{method:'POST',headers:{'Content-Type':'application/json',apikey:cfg.supabaseKey,Authorization:'Bearer '+session.access_token},body:JSON.stringify({action,...data})});
  const body=await r.json();if(!r.ok)throw Error(body.error||'Could not reach the Hub.');return body;
 }
 Hub.cloud={client,call,clone};
})(window.Hub=window.Hub||{});
