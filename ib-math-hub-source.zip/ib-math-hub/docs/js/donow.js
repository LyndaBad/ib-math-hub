/* Personalised Do Now — four questions plus an extension, chosen per student from accumulated evidence and the
   group's pacing calendar. Every choice carries a plain-English reason. Students only see a Do Now after
   Miss Badmus approves it for that lesson; editing a student's plan withdraws the approval.
     1 · Repair       lowest-mastery taught skill with enough evidence
     2 · Retrieve     longest-unseen taught skill (spaced retrieval), or a skill with too little evidence
     3 · Prerequisite weakest prerequisite of the next lesson
     4 · Bridge       a first look at the next lesson (preview: never counts against mastery if not yet taught)
     ★ · Extension    challenge-level question (harder parameters / HL stretch) */
(function (Hub) {
  'use strict';
  const C = () => Hub.curriculum, M = () => Hub.mastery, S = () => Hub.store.state;
  const SLOTS = [['repair', 'Repair'], ['retrieve', 'Retrieve'], ['prereq', 'Prerequisite'], ['bridge', 'Bridge'], ['extension', 'Extension']];

  /** One short, standalone part from a skill's generator (no "hence"/dependent parts, no teacher-only parts). */
  function single(skillId, seed, challenge) {
    const sk = C().SKILL[skillId]; if (!sk) return null;
    const gen = sk.gens[seed % sk.gens.length], q = Hub.qcore.build(gen, seed, { challenge });
    const cands = q.parts.filter(p => p.answer.kind !== 'open' && !p.dep);
    const short = cands.filter(p => p.marks <= 3); const pool = short.length ? short : cands;
    // an extension takes the most demanding standalone part; other slots take a short one
    const part = challenge ? cands.slice().sort((a, b) => b.marks - a.marks)[0] : pool[seed % pool.length] || cands[0]; if (!part) return null;
    return Object.assign({}, q, { parts: [Object.assign({}, part, { label: 'a', id: 'a' })], marks: part.marks });
  }
  function fmtReason(st, name) {
    if (!st) return '';
    const ev = st.marks ? `${st.pct}% from ${st.marks} marks of evidence` : 'no evidence yet';
    return `${name}: ${ev}${st.last ? `, last seen ${Hub.core.fmtDate(st.last)}` : ''}`;
  }
  /** Build the plan for one student for the group's next lesson. */
  function planFor(sid, groupId, asOf) {
    const g = C().GROUPS[groupId], lesson = C().nextLesson(groupId, asOf), skills = C().skillsFor(g.course);
    const taught = skills.filter(s => C().isTaught(s.id, groupId, asOf));
    const stats = Object.fromEntries(taught.map(s => [s.id, M().stat(sid, s.id)]));
    const used = new Set(), items = [];
    const seedBase = Hub.core.hashStr(sid + '|' + (lesson ? lesson.date : asOf));
    const add = (slot, skillId, reason, opt = {}) => { if (!skillId) return; used.add(skillId); items.push({ slot, skill: skillId, reason, preview: !!opt.preview, challenge: !!opt.challenge, seed: (seedBase + items.length * 7919) % 900000 + 1 }); };
    const nextSkills = lesson ? lesson.skills : [], bridgeSkill = nextSkills[0];
    const solid = taught.filter(s => !['no-evidence', 'low-evidence'].includes(stats[s.id].status) && (s.id !== bridgeSkill || taught.length < 4));
    // 1 Repair
    const repair = solid.slice().sort((a, b) => stats[a.id].pct - stats[b.id].pct || (stats[a.id].last || '').localeCompare(stats[b.id].last || ''))[0];
    if (repair) add('repair', repair.id, `Lowest secure-evidence skill — ${fmtReason(stats[repair.id], repair.name)}.`);
    // 2 Retrieve: a skill with too little evidence first, else the longest-unseen skill not yet secure (then any)
    const thin = taught.filter(s => !used.has(s.id) && s.id !== bridgeSkill && ['no-evidence', 'low-evidence'].includes(stats[s.id].status));
    if (thin.length) add('retrieve', thin[0].id, `Not enough evidence yet on ${thin[0].name} (${stats[thin[0].id].marks} marks) — this check-in tells us where you are.`);
    else {
      const stale = taught.filter(s => !used.has(s.id) && s.id !== bridgeSkill).sort((a, b) => (stats[a.id].last || '').localeCompare(stats[b.id].last || '') || (stats[a.id].pct ?? 0) - (stats[b.id].pct ?? 0));
      const pick = stale.find(s => stats[s.id].status !== 'secure') || stale[0];
      if (pick) add('retrieve', pick.id, `Spaced retrieval — ${fmtReason(stats[pick.id], pick.name)}${stats[pick.id].last ? ` (${Hub.core.daysBetween(stats[pick.id].last, asOf)} days ago)` : ''}.`);
    }
    // 3 Prerequisite for the next lesson
    const pre = [...new Set(nextSkills.flatMap(id => (C().SKILL[id] || { prereq: [] }).prereq))].filter(id => stats[id] && !used.has(id) && id !== bridgeSkill);
    const preSorted = pre.sort((a, b) => (stats[a].pct ?? 0) - (stats[b].pct ?? 0));
    if (preSorted.length) add('prereq', preSorted[0], `Needed for ${lesson ? Hub.core.fmtDate(lesson.date) : 'next lesson'} (${nextSkills.map(id => C().SKILL[id].name).join(', ')}) — ${fmtReason(stats[preSorted[0]], C().SKILL[preSorted[0]].name)}.`);
    else { const recent = taught.filter(s => !used.has(s.id) && s.id !== bridgeSkill).sort((a, b) => (C().taughtDate(b.id, groupId) || '').localeCompare(C().taughtDate(a.id, groupId) || ''))[0]; if (recent) add('prereq', recent.id, `Most recent lesson, to connect to ${lesson ? Hub.core.fmtDate(lesson.date) : 'next lesson'} — ${fmtReason(stats[recent.id], recent.name)}.`); }
    // 4 Bridge into the next lesson
    const bridge = nextSkills.find(id => !used.has(id)) || nextSkills[0];
    if (bridge) { const newSkill = !C().isTaught(bridge, groupId, asOf); add('bridge', bridge, newSkill ? `First look at ${lesson ? Hub.core.fmtDate(lesson.date) : 'next lesson'}: ${C().SKILL[bridge].name}. Preview only — it does not count against you.` : `Continues in ${lesson ? Hub.core.fmtDate(lesson.date) : 'the next lesson'}: ${fmtReason(stats[bridge], C().SKILL[bridge].name)}.`, { preview: newSkill }); }
    else if (lesson && lesson.kind === 'test') { const t = taught.filter(s => !used.has(s.id))[0]; if (t) add('bridge', t.id, `Test preparation for ${Hub.core.fmtDate(lesson.date)}.`); }
    // ★ Extension: stretch on the strongest recent skill, or the repair skill if nothing is secure
    const secure = solid.filter(s => stats[s.id].status === 'secure').sort((a, b) => (C().taughtDate(b.id, groupId) || '').localeCompare(C().taughtDate(a.id, groupId) || ''));
    const strong = secure.find(s => !used.has(s.id)) || secure[0];
    const best = solid.slice().sort((a, b) => stats[b.id].pct - stats[a.id].pct);
    const ext = strong || best.find(s => !used.has(s.id)) || best[0] || taught[0];
    if (ext) { used.delete(ext.id); add('extension', ext.id, strong ? `Extension — challenge version of a secure skill (${stats[ext.id].pct}%).` : `Extension — challenge version of your strongest skill so far, ${ext.name} (${stats[ext.id].pct ?? '—'}%).`, { challenge: true }); }
    // Not enough taught content yet (start of course): fill with the next lesson's skills as previews
    while (items.length < 5 && nextSkills.length) add(items.length === 4 ? 'extension' : 'bridge', nextSkills[items.length % nextSkills.length], 'Preview of the next lesson.', { preview: true, challenge: items.length === 4 });
    return { sid, lesson, items };
  }
  function planGroup(groupId, asOf) { return Hub.roster.inGroup(groupId).map(s => planFor(s.id, groupId, asOf)); }
  /** Freeze questions for the plan and store it as a draft awaiting approval. */
  function draft(groupId) {
    const asOf = M().asOf(), plans = planGroup(groupId, asOf); const lesson = plans[0] && plans[0].lesson;
    const rec = { groupId, lessonDate: lesson ? lesson.date : asOf, lessonTitle: lesson ? lesson.activity : '', status: 'draft', createdAt: new Date().toISOString(), plans: {} };
    plans.forEach(p => { rec.plans[p.sid] = p.items.map(it => Object.assign({}, it, { question: freeze(single(it.skill, it.seed, it.challenge), it) })); });
    S().donow[groupId] = rec; Hub.store.log(`Drafted personalised Do Now for ${C().GROUPS[groupId].label} (${Hub.core.fmtDate(rec.lessonDate)})`); Hub.store.save(); return rec;
  }
  function freeze(q, it) { if (!q) return null; q.preview = !!it.preview; q.slot = it.slot; return q; }
  function swap(groupId, sid, index, skillId) {
    const rec = S().donow[groupId]; if (!rec || !rec.plans[sid]) return false;
    const it = rec.plans[sid][index], seed = Math.floor(Math.random() * 9e5) + 1, preview = !C().isTaught(skillId, groupId, M().asOf());
    Object.assign(it, { skill: skillId, seed, preview, reason: 'Chosen by Miss Badmus.', question: freeze(single(skillId, seed, it.challenge), { preview, slot: it.slot }) });
    if (rec.status !== 'draft') { rec.status = 'draft'; rec.withdrawn = new Date().toISOString(); }
    Hub.store.save(); return true;
  }
  function approve(groupId) { const rec = S().donow[groupId]; if (!rec) return false; rec.status = 'published'; rec.approvedAt = new Date().toISOString(); Hub.store.log(`Approved and published Do Now for ${C().GROUPS[groupId].label}`); Hub.store.save(true); return true; }
  function withdraw(groupId) { const rec = S().donow[groupId]; if (!rec) return false; rec.status = 'draft'; Hub.store.save(true); return true; }
  /** What a student sees: their frozen questions, only when published. */
  function forStudent(sid) {
    const st = Hub.roster.byId(sid); if (!st) return null; const rec = S().donow[st.group];
    if (!rec || rec.status !== 'published' || !rec.plans[sid]) return null;
    const done = S().attempts.find(t => t.type === 'Do Now' && t.sid === sid && t.donowKey === st.group + '|' + rec.lessonDate);
    return { rec, items: rec.plans[sid], done, assessment: { id: 'donow-' + st.group + '-' + rec.lessonDate, title: `Do Now · ${Hub.core.fmtDate(rec.lessonDate)}`, type: 'Do Now', course: st.course, release: 'auto', questions: rec.plans[sid].map(it => it.question).filter(Boolean) } };
  }
  function submit(sid, responses, token) {
    const d = forStudent(sid); if (!d) return { ok: false, error: 'No Do Now is open.' }; if (d.done) return { ok: true, attempt: d.done, duplicate: true };
    const r = Hub.assess.submit(d.assessment.id, sid, { responses, token }, { assessment: d.assessment });
    if (r.ok && !r.preview) { r.attempt.donowKey = Hub.roster.byId(sid).group + '|' + d.rec.lessonDate; Hub.store.save(true); }
    return r;
  }
  Hub.donow = { SLOTS, single, planFor, planGroup, draft, swap, approve, withdraw, forStudent, submit };
})(window.Hub = window.Hub || {});
