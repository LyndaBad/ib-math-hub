/* AA HL — IB exam-style question families (Units 1–2), including a Paper 3-style investigation. Modelled on the TYPES
   of exam-style questions in the Oxford HL 2019 chapter reviews (structure, difficulty, mark allocation); every question,
   context and number here is original and randomised. */
(function (Hub) {
  'use strict';
  const { F, fr, T, num, round, sf, lin, comb, factorial, mc, reg: reg0, gcd } = Hub.qcore;
  const X = { exam: true };
  /** Bracket a negative number written straight after + or − (e.g. "2 − −1" → "2 − (−1)"). */
  const fixSigns = t => typeof t !== 'string' ? t : t.replace(/([+\-]|\\times) -((?:\\frac\{\d+\}\{\d+\})|\d+(?:\.\d+)?)(?![\d.]*[a-z(\\^{])/g, '$1 (-$2)');
  const tidyQ = q => { q.stem = fixSigns(q.stem); q.parts.forEach(p => { p.prompt = fixSigns(p.prompt); p.working = (p.working || []).map(fixSigns); p.ms = (p.ms || []).map(([m, t]) => [m, fixSigns(t)]); }); return q; };
  const reg = (id, meta, gen) => reg0(id, meta, (R, o) => tidyQ(gen(R, o)));

  const sgn = (v, first) => v === 0 ? (first ? '0' : '') : v < 0 ? (first ? '-' : ' - ') + Math.abs(v) : (first ? '' : ' + ') + v;
  /** ' + 3x', ' - x', '' (for 0): a signed term in x */
  const tm = (v, sym) => v === 0 ? '' : (v < 0 ? ' - ' : ' + ') + (Math.abs(v) === 1 ? '' : Math.abs(v)) + sym;
  const xm = v => v === 0 ? 'x' : `x${sgn(-v)}`; // x - v
  const co = v => v === 1 ? '' : v === -1 ? '-' : String(v); // coefficient in front of x

  /* ================= Unit 2: Functions ================= */
  /* 2.2 Rational function that is its own inverse (Paper 1) */
  reg('hlx2.selfinv', Object.assign({ skill: 'HL-2.2a', title: 'Rational function: asymptotes, self-inverse condition, f(x) = x', paper: 1, challenge: true }, X), (R, o) => {
    const c = R.nz(-4, 5); let s; do s = R.int(1, o.challenge ? 8 : 6); while (s === Math.abs(c)); const b = s * s - c * c;
    return {
      stem: `The function $f$ is defined by $f(x) = \\frac{kx${sgn(b)}}{${xm(c)}}$, for $x \\in \\mathbb{R}, x \\ne ${c}$, where $k$ is a constant.`,
      parts: [
        { command: 'Write down', prompt: 'the equation of the vertical asymptote of the graph of $y = f(x)$. Give the value of $x$.', marks: 1, answer: { kind: 'num', value: c, int: true, display: `x = ${c}` },
          ms: [['A1', `$x = ${c}$`]], working: [`The denominator is zero when $x = ${c}$ (and the numerator is not).`], hint: 'Where is the denominator zero?', errors: [{ value: -c, tag: 'sign', fb: `${xm(c)} = 0 gives x = ${c}.` }], verify: `${c}` },
        { command: 'Find', prompt: 'the value of $k$ for which $f$ is a self-inverse function.', marks: 3, answer: { kind: 'num', value: c, int: true, display: `k = ${c}` },
          ms: [['M1', `attempt to find $f^{-1}$: $x = \\frac{ky${sgn(b)}}{y${sgn(-c)}}$`], ['A1', `$f^{-1}(x) = \\frac{${co(c)}x${sgn(b)}}{x - k}$`], ['A1', `comparing with $f$: $k = ${c}$`]],
          working: [`Swap: $x(y${sgn(-c)}) = ky${sgn(b)}$`, `$xy - ky = ${co(c)}x${sgn(b)} \\Rightarrow y = \\frac{${co(c)}x${sgn(b)}}{x - k}$`, `$f^{-1} = f$ for all $x$ $\\Rightarrow$ $x - k$ must be $${xm(c)}$, so $k = ${c}$`],
          hint: 'Find f⁻¹ in terms of k and compare it with f. (For (ax + b) ÷ (cx + d) to be self-inverse, a = −d.)', errors: [{ value: -c, tag: 'self-inverse-sign', fb: 'For (ax + b) ÷ (cx + d), the condition is a = −d.' }], verify: `[kk for kk in range(-20, 21) if simplify((kk*((kk*x+(${b}))/(x-(${c})))+(${b}))/(((kk*x+(${b}))/(x-(${c})))-(${c})) - x) == 0][0]` },
        { command: 'Write down', prompt: 'the equation of the horizontal asymptote, using your value of $k$. Give the value of $y$.', marks: 1, dep: true, answer: { kind: 'num', value: c, int: true, display: `y = ${c}` },
          ms: [['A1', `$y = ${c}$ (FT their $k$)`]], working: [`As $x \\to \\pm\\infty$, $f(x) \\to \\frac{k}{1} = ${c}$`], hint: 'Compare the leading coefficients of top and bottom.', verify: `limit((${c}*x+(${b}))/(x-(${c})), x, oo)` },
        { command: 'Solve', prompt: '$f(x) = x$.', marks: 3, dep: true, answer: { kind: 'list', value: [c + s, c - s], exact: true, display: `${c + s},\\ ${c - s}` },
          ms: [['M1', `$${co(c)}x${sgn(b)} = x(${xm(c)})$`], ['A1', `$x^{2}${tm(-2 * c, 'x')}${sgn(-b)} = 0$`], ['A1', `$x = ${c + s}$ or $x = ${c - s}$`]],
          working: [`$${co(c)}x${sgn(b)} = x^{2}${tm(-c, 'x')}$`, `$x^{2}${tm(-2 * c, 'x')}${sgn(-b)} = 0$`, `$(x - ${c + s})(x ${c - s < 0 ? '+ ' + (s - c) : '- ' + (c - s)}) = 0 \\Rightarrow x = ${c + s}, ${c - s}$`],
          hint: 'Multiply both sides by the denominator first.', errors: [{ value: [c + s], tag: 'missing-negative-root', fb: 'The quadratic has two roots; check both are allowed (x ≠ the asymptote).' }], verify: `solve(${c}*x+(${b})-x*(x-(${c})), x)` }
      ]
    };
  });

  /* 2.4 Restricting a quadratic so it has an inverse; f(x) = f⁻¹(x) (Paper 1) */
  reg('hlx2.restrict', Object.assign({ skill: 'HL-2.4b', title: 'Restricted domain, inverse, and f(x) = f⁻¹(x)', paper: 1, challenge: true }, X), (R, o) => {
    let r1, r2; do { r1 = R.int(-4, 3); r2 = r1 + R.pick(o.challenge ? [5, 7] : [3, 5]); } while (r1 + r2 === 1);
    const h = (r1 + r2 - 1) / 2, m = r1 * r2, k = m - h * h, t = R.int(2, 6);
    return {
      stem: `Let $f(x) = x^{2}${tm(-2 * h, 'x')}${sgn(m)}$, for $x \\ge a$.`,
      parts: [
        { command: 'Express', prompt: '$f(x)$ in the form $(x - h)^{2} + k$. Give $h$ and $k$.', marks: 2, answer: { kind: 'tuple', labels: ['h', 'k'], value: [h, k], exact: true, markEach: true, display: `(${xm(h)})^{2}${sgn(k)}` },
          ms: [['A1', `$h = ${h}$`], ['A1', `$k = ${k}$`]], working: [`$x^{2}${tm(-2 * h, 'x')}${sgn(m)} = (${xm(h)})^{2} - ${h * h}${sgn(m)} = (${xm(h)})^{2}${sgn(k)}$`], hint: 'Halve the coefficient of x, then correct the constant.',
          errors: [{ value: [-h, k], tag: 'vertex-sign', fb: '(x − h)²: the sign inside is opposite to the vertex.' }], verify: `(${h}, (${m})-(${h})**2)` },
        { command: 'Write down', prompt: 'the least value of $a$ for which $f^{-1}$ exists.', marks: 1, answer: { kind: 'num', value: h, int: true, display: `a = ${h}` },
          ms: [['A1', `$a = ${h}$`]], working: [`$f$ is one-to-one on each side of the vertex $x = ${h}$.`], hint: 'Where does the parabola turn?', verify: `${h}` },
        { command: 'Find', prompt: `$f^{-1}(${k + t * t})$, using this value of $a$.`, marks: 2, answer: { kind: 'num', value: h + t, int: true, display: String(h + t) },
          ms: [['M1', `$(x${sgn(-h)})^{2}${sgn(k)} = ${k + t * t}$ or $f^{-1}(x) = ${h} + \\sqrt{x${sgn(-k)}}$`], ['A1', `$${h + t}$`]], working: [`$(${xm(h)})^{2} = ${t * t} \\Rightarrow x = ${h} \\pm ${t}$`, `$x \\ge ${h}$, so $f^{-1}(${k + t * t}) = ${h + t}$`],
          hint: 'Solve f(x) = value and keep the solution in the domain.', errors: [{ value: h - t, tag: 'ignored-restriction', fb: `x must be at least ${h}.` }], verify: `${h}+sqrt(${k + t * t}-(${k}))` },
        { command: 'Solve', prompt: '$f(x) = f^{-1}(x)$.', marks: 3, answer: { kind: 'num', value: r2, int: true, display: `x = ${r2}` },
          ms: [['R1', 'for increasing $f$, the graphs meet on $y = x$'], ['M1', `$x^{2}${tm(-2 * h - 1, 'x')}${sgn(m)} = 0$`], ['A1', `$x = ${r2}$ only (reject $x = ${r1}$, as $${r1} < ${h}$)`]],
          working: ['$f$ is increasing on its domain, so $f(x) = f^{-1}(x)$ where $f(x) = x$.', `$x^{2}${tm(-2 * h - 1, 'x')}${sgn(m)} = 0 \\Rightarrow (x${sgn(-r1)})(x${sgn(-r2)}) = 0$`, `$x = ${r1}$ is not in the domain $x \\ge ${h}$, so $x = ${r2}$`],
          hint: 'Graphs of f and f⁻¹ are reflections in y = x.', errors: [{ value: r1, tag: 'extraneous-root', fb: `x = ${r1} is outside the domain x ≥ ${h}.` }], verify: `[s for s in solve(x**2-(${2 * h + 1})*x+(${m}), x) if s >= ${h}][0]` }
      ]
    };
  });

  /* 2.2 Absolute value: equation, hence inequality (Paper 1) */
  reg('hlx2.absineq', Object.assign({ skill: 'HL-2.2c', title: 'Modulus equation, hence inequality', paper: 1, challenge: true }, X), (R, o) => {
    let a, x1, x2, b, c;
    do { a = R.pick([2, 3, 4]); x2 = R.int(-3, 3); x1 = x2 + R.int(2, 6); b = (x1 * (a - 1) + x2 * (a + 1)) / 2; c = (x1 * (a - 1) - x2 * (a + 1)) / 2; } while (!Number.isInteger(b) || !Number.isInteger(c) || b === 0 || c === 0);
    const L = `\\left|${a}x${sgn(-b)}\\right|`, Rt = lin(1, c);
    return {
      stem: `Consider the functions $f(x) = ${L}$ and $g(x) = ${Rt}$, for $x \\in \\mathbb{R}$.`,
      parts: [
        { command: 'Solve', prompt: '$f(x) = g(x)$.', marks: 4, answer: { kind: 'list', value: [x1, x2], exact: true, display: `${x2},\\ ${x1}` },
          ms: [['M1', `$${a}x${sgn(-b)} = ${Rt}$`], ['M1', `$${a}x${sgn(-b)} = -(${Rt})$`], ['A1', `$x = ${x1}$`], ['A1', `$x = ${x2}$`]],
          working: [`Case 1: $${a}x${sgn(-b)} = ${Rt} \\Rightarrow ${a - 1}x = ${b + c} \\Rightarrow x = ${x1}$`, `Case 2: $${a}x${sgn(-b)} = -${Rt.includes(' ') ? '(' + Rt + ')' : Rt} \\Rightarrow ${a + 1}x = ${b - c} \\Rightarrow x = ${x2}$`, `Check: $g(${x1}) = ${x1 + c} \\ge 0$ and $g(${x2}) = ${x2 + c} \\ge 0$, both valid.`],
          hint: 'Split into two cases: the inside equals +g(x) or −g(x). Check each answer.', errors: [{ value: [x1], tag: 'missing-negative-root', fb: 'There is a second case: the inside equals −g(x).' }], verify: `solve(Abs(${a}*xr-(${b}))-(xr+(${c})), xr)` },
        { command: 'Hence', prompt: '$\\text{solve } f(x) < g(x)$. Write your answer as $p < x < q$ and give $p$ and $q$.', marks: 2, dep: true, answer: { kind: 'tuple', labels: ['p', 'q'], value: [x2, x1], exact: true, display: `${x2} < x < ${x1}` },
          ms: [['M1', 'the V-shaped graph lies below the line between the intersections'], ['A1', `$${x2} < x < ${x1}$`]], working: [`$y = f(x)$ is steeper than $y = g(x)$, so $f(x) < g(x)$ between the two intersections.`, `$${x2} < x < ${x1}$`],
          hint: 'Sketch both graphs and look where the V is below the line.', errors: [{ value: [x1, x2], tag: 'swapped', fb: 'p is the smaller value.' }], verify: `(${x2}, ${x1})` }
      ]
    };
  });

  /* 2.3 Odd and even functions (Paper 1) */
  reg('hlx2.oddeven', Object.assign({ skill: 'HL-2.3', title: 'Prove odd; combine odd and even functions', paper: 1, challenge: true }, X), (R, o) => {
    const s = R.int(1, 4), p = s * s, q = R.int(1, 6), t = R.int(2, 4), M = t ** 3 - p * t, t0 = p === 4 ? 1 : 2;
    const combo = R.pick([['f(x)g(x)', `(x**3-${p}*x)*(x**2+${q})`], ['(f \\circ g)(x)', `(x**2+${q})**3-${p}*(x**2+${q})`], ['f(x) + g(x)', `x**3-${p}*x+x**2+${q}`], ['(g \\circ f)(x)', `(x**3-${p}*x)**2+${q}`]]);
    const key = { 'f(x)g(x)': 'odd', '(f \\circ g)(x)': 'even', 'f(x) + g(x)': 'neither', '(g \\circ f)(x)': 'even' }[combo[0]];
    const choice = mc(R, [{ tex: 'odd', key: 'odd' }, { tex: 'even', key: 'even' }, { tex: 'neither odd nor even', key: 'neither' }], key);
    return {
      stem: `Let $f(x) = x^{3} - ${p === 1 ? '' : p}x$ and $g(x) = x^{2} + ${q}$, for $x \\in \\mathbb{R}$.`,
      parts: [
        { command: 'Show that', prompt: '$f$ is an odd function.', marks: 2, answer: { kind: 'open' },
          ms: [['M1', `$f(-x) = (-x)^{3} - ${p === 1 ? '' : p}(-x)$`], ['A1', `$= -x^{3} + ${p === 1 ? '' : p}x = -(x^{3} - ${p === 1 ? '' : p}x) = -f(x)$`], ['AG', '']],
          working: [`$f(-x) = (-x)^{3} - ${p === 1 ? '' : p}(-x) = -x^{3} + ${p === 1 ? '' : p}x$`, `$= -\\left(x^{3} - ${p === 1 ? '' : p}x\\right) = -f(x)$, so $f$ is odd.`], hint: 'Work out f(−x) and compare it with f(x).', verify: `parity(x**3-${p}*x) == 'odd'` },
        { command: 'Write down', prompt: `the value of $f(-${t})$, given that $f(${t}) = ${M}$.`, marks: 1, answer: { kind: 'num', value: -M, int: true, display: String(-M) },
          ms: [['A1', `$-${M < 0 ? '(' + M + ')' : M} = ${-M}$`]], working: [`$f$ is odd, so $f(-${t}) = -f(${t}) = ${-M}$`], hint: 'Odd: f(−x) = −f(x).', errors: [{ value: M, tag: 'sign', fb: 'For an odd function the sign changes.' }], verify: `-(${t}**3-${p}*${t})` },
        { command: 'Determine', prompt: `whether $h(x) = ${combo[0]}$ is odd, even, or neither.`, marks: 2, answer: choice,
          ms: [['M1', `considering $h(-x)$ using $f(-x) = -f(x)$, $g(-x) = g(x)$`], ['A1', key === 'neither' ? 'neither (e.g. compare $h(1)$ and $h(-1)$)' : `$h(-x) = ${key === 'odd' ? '-' : ''}h(x)$, so ${key}`]],
          working: [`$f$ is odd and $g$ is even.`, key === 'odd' ? '$h(-x) = f(-x)g(-x) = -f(x)g(x) = -h(x)$: odd' : key === 'neither' ? `$h(${t0}) = ${t0 ** 3 - p * t0 + t0 * t0 + q}$, $h(-${t0}) = ${-(t0 ** 3) + p * t0 + t0 * t0 + q}$: neither equal nor opposite, so neither` : combo[0].startsWith('(f') ? '$h(-x) = f(g(-x)) = f(g(x)) = h(x)$: even' : '$h(-x) = g(f(-x)) = g(-f(x)) = g(f(x)) = h(x)$: even'],
          hint: 'Replace x with −x and use what you know about f and g.', verify: `parity(${combo[1]})` },
        { command: 'Solve', prompt: '$f(x) = 0$.', marks: 2, answer: { kind: 'list', value: [0, s, -s], exact: true, display: `0,\\ \\pm ${s}` },
          ms: [['M1', `$x(x^{2} - ${p}) = 0$`], ['A1', `$x = 0, \\pm ${s}$`]], working: [`$x(x^{2} - ${p}) = 0 \\Rightarrow x = 0$ or $x = \\pm ${s}$`], hint: 'Factor out x first.', errors: [{ value: [s, -s], tag: 'did-not-factor', fb: 'Do not divide by x: x = 0 is a solution too.' }], verify: `solve(x**3-${p}*x, x)` }
      ]
    };
  });

  /* 2.2 Partial fractions, hence a telescoping sum (Paper 1) */
  reg('hlx2.telescope', Object.assign({ skill: 'HL-2.2b', title: 'Partial fractions, hence a telescoping series', paper: 1, challenge: true }, X), (R, o) => {
    const a = R.int(0, 3), c = R.pick([1, 2, 3, 4, 6]), n = R.int(o.challenge ? 15 : 5, o.challenge ? 40 : 12);
    const S = fr(c, a + 1).sub(fr(c, n + a + 1)), xa = v => v === 0 ? 'x' : `x + ${v}`, ra = v => v === 0 ? 'r' : `r + ${v}`;
    return {
      stem: `Let $f(x) = \\frac{${c}}{(${xa(a)})(${xa(a + 1)})}$, for $x \\ge 1$.`,
      parts: [
        { command: 'Express', prompt: `$f(x)$ in partial fractions, as $\\frac{A}{${xa(a)}} + \\frac{B}{${xa(a + 1)}}$. Give $A$ and $B$.`, marks: 3, answer: { kind: 'tuple', labels: ['A', 'B'], value: [c, -c], exact: true, markEach: true, display: `\\frac{${c}}{${xa(a)}} - \\frac{${c}}{${xa(a + 1)}}` },
          ms: [['M1', `$${c} = A(${xa(a + 1)}) + B(${xa(a)})$`], ['A1', `$A = ${c}$`], ['A1', `$B = -${c}$`]], working: [`$${c} = A(${xa(a + 1)}) + B(${xa(a)})$`, `$x = ${-a}$: $A = ${c}$; $x = ${-a - 1}$: $-B = ${c} \\Rightarrow B = -${c}$`],
          hint: 'Multiply through by the denominator, then substitute values of x that make a bracket zero.', errors: [{ value: [c, c], tag: 'sign', fb: `Substituting x = ${-a - 1} gives −B = ${c}.` }], verify: `(limit((x+${a})*${c}/((x+${a})*(x+${a + 1})), x, -${a}), limit((x+${a + 1})*${c}/((x+${a})*(x+${a + 1})), x, -${a + 1}))` },
        { command: 'Hence', prompt: `find the exact value of $\\sum_{r=1}^{${n}} \\frac{${c}}{(${ra(a)})(${ra(a + 1)})}$.`, marks: 3, dep: true, answer: { kind: 'num', value: S.val(), exact: true, display: S.tex() },
          ms: [['M1', `writing out terms: $\\left(\\frac{${c}}{${a + 1}} - \\frac{${c}}{${a + 2}}\\right) + \\left(\\frac{${c}}{${a + 2}} - \\frac{${c}}{${a + 3}}\\right) + \\cdots$`], ['M1', 'cancellation of all middle terms'], ['A1', `$${S.tex()}$`]],
          working: [`$\\sum_{r=1}^{${n}} \\left(\\frac{${c}}{${ra(a)}} - \\frac{${c}}{${ra(a + 1)}}\\right)$`, `$= \\frac{${c}}{${a + 1}} - \\frac{${c}}{${n + a + 1}}$ (all middle terms cancel)`, `$= ${S.tex()}$`],
          hint: 'Write out the first few and the last terms. What cancels?', errors: [{ value: fr(c, a + 1).sub(fr(c, n + a)).val(), tag: 'telescoping', fb: `The last surviving term is ${c} ÷ ${n + a + 1}.` }], verify: `summation(${c}/((r+${a})*(r+${a + 1})), (r, 1, ${n}))` },
        { command: 'Write down', prompt: 'the value of the infinite sum as the number of terms tends to infinity.', marks: 1, dep: true, answer: { kind: 'num', value: c / (a + 1), exact: true, display: fr(c, a + 1).tex() },
          ms: [['A1', `$${fr(c, a + 1).tex()}$`]], working: [`$\\frac{${c}}{n + ${a + 1}} \\to 0$, so the sum tends to $${fr(c, a + 1).tex()}$`], hint: 'What happens to the last term as n grows?', verify: `limit(Rational(${c},${a + 1}) - ${c}/(n+${a + 1}), n, oo)` }
      ]
    };
  });

  /* 2.5 Transformations: order matters (Paper 1) */
  reg('hlx2.transform', Object.assign({ skill: 'HL-2.5a', title: 'Sequences of transformations and images of points', paper: 1, challenge: true }, X), (R, o) => {
    const x0 = R.nz(-4, 5), y0 = R.nz(-5, 6), p = R.pick([2, 3, 4]), h = R.nz(-4, 4), k = R.nz(-5, 5), q = R.pick([2, 3, 4]);
    return {
      stem: `The point $P(${x0}, ${y0})$ lies on the graph of $y = f(x)$.`,
      parts: [
        { command: 'Find', prompt: `the coordinates of the image of $P$ on the graph of $y = ${p}f(${xm(h)})${sgn(k)}$.`, marks: 2, answer: { kind: 'tuple', labels: ['x', 'y'], value: [x0 + h, p * y0 + k], exact: true, markEach: true, display: `(${x0 + h}, ${p * y0 + k})` },
          ms: [['A1', `$x = ${x0 + h}$`], ['A1', `$y = ${p * y0 + k}$`]], working: [`Horizontal translation by $${h}$: $x = ${x0} + (${h}) = ${x0 + h}$`, `Vertical stretch by $${p}$, then up $${k}$: $y = ${p}(${y0})${sgn(k)} = ${p * y0 + k}$`],
          hint: 'f(x − h) moves the graph h to the RIGHT.', errors: [{ value: [x0 - h, p * y0 + k], tag: 'translation-direction', fb: 'f(x − h) is a translation of +h in the x-direction.' }], verify: `(${x0}+(${h}), ${p}*(${y0})+(${k}))` },
        { command: 'Find', prompt: `the image of $P$ when the graph of $y = f(x)$ is first translated by $\\begin{pmatrix} ${h} \\\\ ${k} \\end{pmatrix}$ and then stretched vertically with scale factor $${p}$.`, marks: 2, answer: { kind: 'tuple', labels: ['x', 'y'], value: [x0 + h, p * (y0 + k)], exact: true, markEach: true, display: `(${x0 + h}, ${p * (y0 + k)})` },
          ms: [['A1', `$x = ${x0 + h}$`], ['A1', `$y = ${p}(${y0}${sgn(k)}) = ${p * (y0 + k)}$`]], working: [`Translate: $(${x0 + h}, ${y0 + k})$`, `Then stretch: $(${x0 + h}, ${p * (y0 + k)})$`],
          hint: 'Do the transformations in the order given: the stretch now acts on the translated point.', errors: [{ value: [x0 + h, p * y0 + k], tag: 'stretch-order', fb: 'The stretch comes second, so it also stretches the translation.' }], verify: `(${x0}+(${h}), ${p}*((${y0})+(${k})))` },
        { command: 'Write down', prompt: `the coordinates of the image of $P$ on the graph of $y = f(${q}x)$.`, marks: 1, answer: { kind: 'tuple', labels: ['x', 'y'], value: [x0 / q, y0], exact: true, markEach: true, display: `\\left(${fr(x0, q).tex()}, ${y0}\\right)` },
          ms: [['A1', `$\\left(${fr(x0, q).tex()}, ${y0}\\right)$`]], working: [`$f(${q}x)$ is a horizontal stretch with scale factor $\\frac{1}{${q}}$: $x = ${fr(x0, q).tex()}$`], hint: 'f(qx) squashes the graph towards the y-axis.',
          errors: [{ value: [q * x0, y0], tag: 'horizontal-stretch-factor', fb: `f(${q}x) divides x-coordinates by ${q}.` }], verify: `(Rational(${x0},${q}), ${y0})` },
        { command: 'Find', prompt: `$a$, $b$ and $c$ such that $${p}f(${xm(h)})${sgn(k)} = ax^{2} + bx + c$ in the case $f(x) = x^{2}$.`, marks: 2, answer: { kind: 'tuple', labels: ['a', 'b', 'c'], value: [p, -2 * p * h, p * h * h + k], exact: true, markEach: true, display: `${p}x^{2}${tm(-2 * p * h, 'x')}${sgn(p * h * h + k)}` },
          ms: [['M1', `$${p}(${xm(h)})^{2}${sgn(k)}$`], ['A1', `$${p}x^{2}${tm(-2 * p * h, 'x')}${sgn(p * h * h + k)}$`]], working: [`$g(x) = ${p}(${xm(h)})^{2}${sgn(k)} = ${p}(x^{2}${tm(-2 * h, 'x')} + ${h * h})${sgn(k)}$`, `$= ${p}x^{2}${tm(-2 * p * h, 'x')}${sgn(p * h * h + k)}$`],
          hint: 'Expand the bracket, then multiply by the stretch factor.', verify: `tuple(Poly(${p}*(x-(${h}))**2+(${k}), x).all_coeffs())` }
      ]
    };
  });

  /* 2.4 Composite functions with a square root: domain and solving (Paper 1) */
  reg('hlx2.compsqrt', Object.assign({ skill: 'HL-2.4a', title: 'Composite with a square root: value, domain, solve', paper: 1, challenge: true }, X), (R, o) => {
    const [c, s, v] = R.pick([[5, 3, 4], [5, 4, 3], [10, 6, 8], [13, 5, 12], [13, 12, 5], [10, 8, 6], [17, 8, 15]]), a = R.int(2, 9), b = a - s * s, t = R.int(1, 8), K = b + t;
    return {
      stem: `Let $f(x) = \\sqrt{x - ${a}}$, for $x \\ge ${a}$, and $g(x) = x^{2}${sgn(b)}$, for $x \\in \\mathbb{R}$.`,
      parts: [
        { command: 'Find', prompt: `$(f \\circ g)(${c})$.`, marks: 2, answer: { kind: 'num', value: v, int: true, display: String(v) },
          ms: [['(M1)', `$g(${c}) = ${c * c + b}$`], ['A1', `$\\sqrt{${c * c + b - a}} = ${v}$`]], working: [`$g(${c}) = ${c * c}${sgn(b)} = ${c * c + b}$`, `$f(${c * c + b}) = \\sqrt{${c * c + b} - ${a}} = \\sqrt{${v * v}} = ${v}$`], hint: 'Inside first: g, then f.', verify: `sqrt(${c}**2+(${b})-${a})` },
        { command: 'Find', prompt: 'the domain of $f \\circ g$. It has the form $|x| \\ge m$: give $m$.', marks: 3, answer: { kind: 'num', value: s, int: true, display: `|x| \\ge ${s}` },
          ms: [['M1', `$g(x) \\ge ${a}$`], ['A1', `$x^{2} \\ge ${s * s}$`], ['A1', `$x \\le -${s}$ or $x \\ge ${s}$`]], working: [`Need $g(x)$ in the domain of $f$: $x^{2}${sgn(b)} \\ge ${a}$`, `$x^{2} \\ge ${s * s} \\Rightarrow |x| \\ge ${s}$`],
          hint: 'The output of g must be a valid input for f.', errors: [{ value: s * s, tag: 'forgot-root', fb: 'x² ≥ m² means |x| ≥ m.' }], verify: `sqrt(${a}-(${b}))` },
        { command: 'Solve', prompt: `$(g \\circ f)(x) = ${K}$.`, marks: 2, answer: { kind: 'num', value: K - b + a, int: true, display: String(K - b + a) },
          ms: [['M1', `$(g \\circ f)(x) = (x - ${a})${sgn(b)}$`], ['A1', `$x = ${K - b + a}$`]], working: [`$(g \\circ f)(x) = \\left(\\sqrt{x - ${a}}\\right)^{2}${sgn(b)} = x - ${a}${sgn(b)} = x${sgn(b - a)}$`, `$x${sgn(b - a)} = ${K} \\Rightarrow x = ${K - b + a}$ (valid, as $${K - b + a} \\ge ${a}$)`],
          hint: 'Squaring a square root undoes it — but remember the domain of f.', verify: `solve(x-${a}+(${b})-${K}, x)[0]` },
        { command: 'Write down', prompt: 'the range of $g \\circ f$. Give its least value.', marks: 1, answer: { kind: 'num', value: b, int: true, display: `(g \\circ f)(x) \\ge ${b}` },
          ms: [['A1', `$(g \\circ f)(x) \\ge ${b}$`]], working: [`$x \\ge ${a}$, so $x${sgn(b - a)} \\ge ${b}$`], hint: 'Use the domain of f.', errors: [{ value: 0, tag: 'endpoints-only', fb: `The least value is at x = ${a}.` }], verify: `${b}` }
      ]
    };
  });

  /* ================= Unit 1 ================= */
  /* 1.3 Conjecture and prove divisibility by induction (Paper 1) */
  reg('hlx1.divinduct', Object.assign({ skill: 'HL-1.3b', title: 'Conjecture a divisor, then prove it by induction', paper: 1, challenge: true }, X), (R, o) => {
    let a, m; do { a = R.pick(o.challenge ? [7, 9, 11, 13] : [5, 6, 7, 9]); m = R.int(1, 4); } while (gcd(1 + m, a) !== 1);
    const d = a - 1, c = d * m - 1, f = n => a ** n + c;
    return {
      stem: `Let $f(n) = ${a}^{n} + ${c}$, for $n \\in \\mathbb{Z}^{+}$.`,
      parts: [
        { command: 'Find', prompt: '$f(1)$ and $f(2)$.', marks: 2, answer: { kind: 'tuple', labels: ['f(1)', 'f(2)'], value: [f(1), f(2)], exact: true, markEach: true, display: `${f(1)},\\ ${f(2)}` },
          ms: [['A1', `$f(1) = ${f(1)}$`], ['A1', `$f(2) = ${f(2)}$`]], working: [`$f(1) = ${a} + ${c} = ${f(1)}$`, `$f(2) = ${a * a} + ${c} = ${f(2)}$`], hint: 'Substitute n = 1 and n = 2.', verify: `(${a}+${c}, ${a}**2+${c})` },
        { command: 'Write down', prompt: 'the largest positive integer $d$ that divides both $f(1)$ and $f(2)$.', marks: 1, answer: { kind: 'num', value: d, int: true, display: String(d) },
          ms: [['A1', `$d = ${d}$`]], working: [`$${f(1)} = ${d} \\times ${f(1) / d}$ and $${f(2)} = ${d} \\times ${f(2) / d}$; the highest common factor is $${d}$.`], hint: 'Find the highest common factor.', verify: `gcd(${f(1)}, ${f(2)})` },
        { command: 'Prove', prompt: `by mathematical induction that $f(n)$ is divisible by $${d}$ for all $n \\in \\mathbb{Z}^{+}$.`, marks: 7, answer: { kind: 'open' },
          ms: [['A1', `$n = 1$: $f(1) = ${f(1)} = ${d}(${f(1) / d})$, true`], ['M1', `assume true for $n = k$: $${a}^{k} + ${c} = ${d}N$, $N \\in \\mathbb{Z}$`], ['M1', `consider $f(k + 1) = ${a}^{k+1} + ${c}$`],
            ['M1', `$= ${a}\\left(${a}^{k} + ${c}\\right) - ${a * c - c}$ (or $${a}(${d}N - ${c}) + ${c}$)`], ['A1', `$= ${a}(${d}N) - ${d}(${c}) = ${d}\\left(${a}N - ${c}\\right)$`], ['R1', 'divisible by ' + d + ' since $' + a + 'N - ' + c + ' \\in \\mathbb{Z}$'],
            ['R1', 'true for $n = 1$, and true for $n = k$ implies true for $n = k + 1$, so true for all $n \\in \\mathbb{Z}^{+}$']],
          working: [`Base: $f(1) = ${f(1)} = ${d} \\times ${f(1) / d}$ ✓`, `Assume $${a}^{k} + ${c} = ${d}N$ for some integer $N$`, `$f(k+1) = ${a}\\cdot ${a}^{k} + ${c} = ${a}(${d}N - ${c}) + ${c}$`, `$= ${a * d}N - ${a * c - c} = ${d}(${a}N - ${c})$`, 'Divisible by ' + d + '. By induction, true for all positive integers $n$.'],
          hint: 'Write aᵏ⁺¹ as a × aᵏ and use your assumption to replace aᵏ.', verify: `simplify(${a}*(${a}**k+${c}) - ${d}*${c} - (${a}**(k+1)+${c})) == 0` }
      ]
    };
  });

  /* 1.4 Counting: arrangements with restrictions and "at least one" (Paper 1) */
  reg('hlx1.counting', Object.assign({ skill: 'HL-1.4a', title: 'Arrangements together/apart and committees with at least one', paper: 1, challenge: true }, X), (R, o) => {
    const n = R.int(5, 7), p = R.int(4, 7), q = R.int(3, 5), k = R.int(3, 4), [A, B] = R.pick([['Ana', 'Ben'], ['Kai', 'Lena'], ['Sami', 'Tara']]);
    const tot = factorial(n), tog = 2 * factorial(n - 1), apart = tot - tog, com = comb(p + q, k) - comb(p, k);
    return {
      stem: `${n} students, including ${A} and ${B}, stand in a line for a photograph.`,
      parts: [
        { command: 'Find', prompt: 'the number of different arrangements.', marks: 1, answer: { kind: 'num', value: tot, int: true, display: String(tot) }, ms: [['A1', `$${n}! = ${tot}$`]], working: [`$${n}! = ${tot}$`], hint: 'Fill the places one at a time.', verify: `factorial(${n})` },
        { command: 'Find', prompt: `the number of arrangements in which ${A} and ${B} stand next to each other.`, marks: 2, answer: { kind: 'num', value: tog, int: true, display: String(tog) },
          ms: [['M1', `treating them as one unit: $${n - 1}!$`], ['A1', `$2 \\times ${n - 1}! = ${tog}$`]], working: [`Glue ${A} and ${B} together: $${n - 1}$ units, $${n - 1}! = ${factorial(n - 1)}$ ways`, `They can swap: $2 \\times ${factorial(n - 1)} = ${tog}$`],
          hint: 'Treat the pair as one block — and remember the pair can swap.', errors: [{ value: factorial(n - 1), tag: 'forgot-internal-arrangement', fb: `${A} and ${B} can stand either way round: × 2.` }], verify: `2*factorial(${n - 1})` },
        { command: 'Find', prompt: `the number of arrangements in which ${A} and ${B} are not next to each other.`, marks: 2, dep: true, answer: { kind: 'num', value: apart, int: true, display: String(apart) },
          ms: [['M1', `$${tot} - ${tog}$`], ['A1', `$${apart}$`]], working: [`All arrangements minus "together": $${tot} - ${tog} = ${apart}$`], hint: 'Use the complement.', errors: [{ value: tot - factorial(n - 1), tag: 'forgot-internal-arrangement', fb: 'Subtract ALL the "together" arrangements (×2).' }], verify: `factorial(${n})-2*factorial(${n - 1})` },
        { command: 'Find', prompt: `the number of ways of choosing a committee of $${k}$ from $${p}$ boys and $${q}$ girls that includes at least one girl.`, marks: 3, answer: { kind: 'num', value: com, int: true, display: String(com) },
          ms: [['M1', `total $\\binom{${p + q}}{${k}} = ${comb(p + q, k)}$`], ['M1', `no girls: $\\binom{${p}}{${k}} = ${comb(p, k)}$`], ['A1', `$${com}$`]], working: [`$\\binom{${p + q}}{${k}} - \\binom{${p}}{${k}} = ${comb(p + q, k)} - ${comb(p, k)} = ${com}$`],
          hint: '"At least one" = all − none.', errors: [{ value: q * comb(p + q - 1, k - 1), tag: 'at-least-one-overcount', fb: 'Choosing "one girl, then anyone" counts some committees more than once. Use total − no girls.' }], verify: `binomial(${p + q},${k})-binomial(${p},${k})` }
      ]
    };
  });

  /* 1.4 Binomial theorem with a rational power, validity, product (Paper 1) */
  reg('hlx1.binneg', Object.assign({ skill: 'HL-1.4b', title: 'Extended binomial: expansion, validity, coefficient in a product', paper: 1, challenge: true }, X), (R, o) => {
    const N = R.pick(o.challenge ? [fr(-1, 2), fr(1, 3), fr(-3, 2), fr(-1, 3)] : [fr(-1), fr(-2), fr(1, 2), fr(-1, 2)]), p = R.pick([2, 3, 4, -2, -3, -4]), qv = R.nz(-3, 3);
    const c1 = N.mul(p), c2 = N.mul(N.sub(1)).div(2).mul(p * p), co = c2.add(c1.mul(qv));
    const pw = N.tex(), br = `(1${tm(p, 'x')})`, cf = c => c.n === c.d ? '' : -c.n === c.d ? '-' : c.tex();
    const cx = (c, v) => `${c.n < 0 ? '-' : '+'} ${c.n === c.d || -c.n === c.d ? '' : T(c.n < 0 ? c.neg() : c)}${v}`, poly2 = `1 ${cx(c1, 'x')} ${cx(c2, 'x^{2}')}`;
    return {
      stem: `Consider $f(x) = ${br}^{${pw}}$.`,
      parts: [
        { command: 'Find', prompt: 'the first three terms of the binomial expansion of $f(x)$ in ascending powers of $x$, as $1 + ax + bx^{2}$. Give $a$ and $b$.', marks: 3, answer: { kind: 'tuple', labels: ['a', 'b'], value: [c1.val(), c2.val()], exact: true, markEach: true, display: poly2 },
          ms: [['M1', `$1 + (${pw})(${p}x) + \\frac{(${pw})(${N.sub(1).tex()})}{2!}(${p}x)^{2}$`], ['A1', `$a = ${c1.tex()}$`], ['A1', `$b = ${c2.tex()}$`]],
          working: [`$(1 + u)^{n} = 1 + nu + \\frac{n(n-1)}{2!}u^{2} + \\cdots$ with $n = ${pw}$, $u = ${p}x$`, `$= 1 + (${pw})(${p}x) + \\frac{(${pw})(${N.sub(1).tex()})}{2}(${p * p}x^{2}) + \\cdots$`, `$= ${poly2} + \\cdots$`],
          hint: 'Use the formula-booklet expansion of (1 + u)ⁿ with u = the whole term in x.', errors: [{ value: [c1.val(), N.mul(N.sub(1)).div(2).mul(p).val()], tag: 'power-on-coefficient', fb: `Square the whole of (${p}x).` }],
          verify: `(series((1+(${p})*x)**Rational(${N.n},${N.d}), x, 0, 3).removeO().coeff(x,1), series((1+(${p})*x)**Rational(${N.n},${N.d}), x, 0, 3).removeO().coeff(x,2))` },
        { command: 'Write down', prompt: 'the values of $x$ for which the expansion is valid, in the form $|x| < k$. Give $k$.', marks: 1, answer: { kind: 'num', value: 1 / Math.abs(p), exact: true, display: `|x| < ${fr(1, Math.abs(p)).tex()}` },
          ms: [['A1', `$|${p}x| < 1 \\Rightarrow |x| < ${fr(1, Math.abs(p)).tex()}$`]], working: [`Valid when $|${p}x| < 1$, so $|x| < ${fr(1, Math.abs(p)).tex()}$`], hint: 'The expansion of (1 + u)ⁿ is valid for |u| < 1.',
          errors: [{ value: Math.abs(p), tag: 'inverted-validity', fb: `|${p}x| < 1 gives |x| < 1 ÷ ${Math.abs(p)}.` }], verify: `Rational(1, ${Math.abs(p)})` },
        { command: 'Hence', prompt: `find the coefficient of $x^{2}$ in the expansion of $(1${tm(qv, 'x')})f(x)$.`, marks: 3, dep: true, answer: { kind: 'num', value: co.val(), exact: true, display: co.tex() },
          ms: [['M1', 'two $x^{2}$ terms considered'], ['A1', `$${c2.tex()} + (${qv})(${c1.tex()})$`], ['A1', `$${co.tex()}$`]], working: [`$x^{2}$: $1 \\times \\left(${cf(c2)}x^{2}\\right)$ and $(${qv === 1 ? '' : qv === -1 ? '-' : qv}x)(${cf(c1)}x)$`, `$${c2.tex()} + (${T(c1.mul(qv))}) = ${co.tex()}$`],
          hint: 'Multiply the brackets and collect only the x² terms.', errors: [{ value: c2.val(), tag: 'forgot-cross-terms', fb: `There is also an x² term from (${qv === 1 ? '' : qv === -1 ? '-' : qv}x)(${c1.tex()}x).` }],
          verify: `series((1+(${qv})*x)*(1+(${p})*x)**Rational(${N.n},${N.d}), x, 0, 3).removeO().coeff(x,2)` }
      ]
    };
  });

  /* 1.2 Geometric series in x: convergence interval and solving S∞ = N (Paper 1) */
  reg('hlx1.sinfx', Object.assign({ skill: 'HL-1.2b', title: 'Geometric series in x: convergence and S∞', paper: 1, challenge: true }, X), (R, o) => {
    const p = R.int(1, 5), q = R.int(2, 5), a = R.int(2, 6), x0 = p + R.nz(-q + 1, q - 1), Nn = R.int(a + 1, a + 9);
    const S0 = fr(a * q, q - x0 + p), xs = fr(p + q).sub(fr(a * q, Nn));
    const r = `\\left(\\frac{${xm(p)}}{${q}}\\right)`;
    return {
      stem: `Consider the infinite geometric series $${a} + ${a}${r} + ${a}${r}^{2} + \\cdots$`,
      parts: [
        { command: 'Find', prompt: 'the values of $x$ for which the series converges. Write your answer as $m < x < n$ and give $m$ and $n$.', marks: 3, answer: { kind: 'tuple', labels: ['m', 'n'], value: [p - q, p + q], exact: true, markEach: true, display: `${p - q} < x < ${p + q}` },
          ms: [['M1', `$\\left|\\frac{${xm(p)}}{${q}}\\right| < 1$`], ['A1', `$-${q} < ${xm(p)} < ${q}$`], ['A1', `$${p - q} < x < ${p + q}$`]], working: [`Converges when $|r| < 1$: $\\left|\\frac{${xm(p)}}{${q}}\\right| < 1$`, `$-${q} < ${xm(p)} < ${q} \\Rightarrow ${p - q} < x < ${p + q}$`],
          hint: 'A geometric series converges when |r| < 1.', errors: [{ value: [-q, q], tag: 'validity', fb: `Add ${p} to every part of the inequality.` }], verify: `(${p}-${q}, ${p}+${q})` },
        { command: 'Find', prompt: `the sum to infinity when $x = ${x0}$.`, marks: 2, answer: { kind: 'num', value: S0.val(), exact: true, display: S0.tex() },
          ms: [['M1', `$\\frac{${a}}{1 - ${fr(x0 - p, q).tex()}}$`], ['A1', `$${S0.tex()}$`]], working: [`$r = \\frac{${x0} - ${p}}{${q}} = ${fr(x0 - p, q).tex()}$`, `$S_\\infty = \\frac{${a}}{1 - \\left(${fr(x0 - p, q).tex()}\\right)} = ${S0.tex()}$`],
          hint: 'S∞ = u₁ ÷ (1 − r).', errors: [{ value: a / (1 + (x0 - p) / q), tag: 'sinf-sign', fb: 'The denominator is 1 − r.' }], verify: `${a}/(1-Rational(${x0 - p},${q}))` },
        { command: 'Find', prompt: `the value of $x$ for which the sum to infinity is $${Nn}$.`, marks: 3, answer: { kind: 'num', value: xs.val(), exact: true, display: xs.tex() },
          ms: [['M1', `$\\frac{${a}}{1 - \\frac{${xm(p)}}{${q}}} = ${Nn}$`], ['A1', `$\\frac{${a * q}}{${p + q} - x} = ${Nn}$`], ['A1', `$x = ${xs.tex()}$ (in the interval, so valid)`]],
          working: [`$\\frac{${a}}{1 - \\frac{${xm(p)}}{${q}}} = \\frac{${a * q}}{${q} - (${xm(p)})} = \\frac{${a * q}}{${p + q} - x}$`, `$\\frac{${a * q}}{${p + q} - x} = ${Nn} \\Rightarrow ${p + q} - x = ${fr(a * q, Nn).tex()} \\Rightarrow x = ${xs.tex()}$`],
          hint: 'Simplify 1 − r into a single fraction first.', verify: `solve(${a}/(1-(x-${p})/${q})-${Nn}, x)[0]` }
      ]
    };
  });

  /* 1.2 Car loan with monthly repayments (Paper 2, NumWorks finance) */
  reg('hlx1.loan', Object.assign({ skill: 'HL-1.2c', title: 'Loan repayments, total interest and outstanding balance', paper: 2, challenge: true }, X), (R, o) => {
    const PV = R.pick([12000, 18000, 24000, 30000]), i = R.pick([4.5, 5.4, 6, 6.6]), y = R.int(4, 6), m = R.int(1, y - 1), r = i / 1200, N = 12 * y;
    const PMT = PV * r / (1 - (1 + r) ** -N), P2 = round(PMT, 2), INT = round(P2 * N - PV, 2), B = PV * (1 + r) ** (12 * m) - PMT * ((1 + r) ** (12 * m) - 1) / r, $ = v => `\\$${v.toFixed(2)}`;
    return {
      stem: `Zara borrows $\\$${PV}$ to buy a car. The loan is repaid with equal monthly payments over $${y}$ years, at a nominal annual interest rate of $${i}\\%$ compounded monthly.`,
      parts: [
        { command: 'Find', prompt: 'the monthly payment, correct to two decimal places.', marks: 3, answer: { kind: 'num', value: P2, dp: 2, display: $(P2) },
          ms: [['(M1)', `$N = ${N}$, $I\\% = ${i}$, $PV = ${PV}$, $FV = 0$, 12 payments and compoundings per year`], ['(A1)', 'payment entered as unknown'], ['A1', `$${$(P2)}$`]], working: [`NumWorks finance solver: $N = ${N}$, $I\\% = ${i}$, $PV = ${PV}$, $FV = 0$`, `$PMT = -${P2.toFixed(2)}$, so $${$(P2)}$ per month`],
          hint: 'Use the finance solver. The loan is money received (PV positive); payments are money paid (negative).', numworks: { app: 'Finance', lines: [[`N=${N}, I%=${i}, PV=${PV}, FV=0, payments and compoundings per year = 12`, `PMT=−${P2.toFixed(2)}`]] },
          errors: [{ value: round(PV * (1 + i / 100) ** y / N, 2), tag: 'annual-not-compounded', fb: 'Interest is charged monthly on the falling balance; use the finance solver with 12 periods per year.' }], verify: `${PV}*Rational(${Math.round(i * 10)},12000)/(1-(1+Rational(${Math.round(i * 10)},12000))**(-${N}))` },
        { command: 'Calculate', prompt: 'the total interest Zara pays.', marks: 2, dep: true, answer: { kind: 'num', value: INT, dp: 2, display: $(INT) },
          ms: [['M1', `$${N} \\times ${P2.toFixed(2)} - ${PV}$`], ['A1', `$${$(INT)}$ (FT)`]], working: [`Total paid $= ${N} \\times ${P2.toFixed(2)} = ${(P2 * N).toFixed(2)}$`, `Interest $= ${(P2 * N).toFixed(2)} - ${PV} = ${INT.toFixed(2)}$`], hint: 'Total paid minus the amount borrowed.',
          errors: [{ value: round(P2 * N, 2), tag: 'term-off', fb: 'Subtract the amount borrowed.' }], verify: `Rational(${Math.round(P2 * 100)},100)*${N}-${PV}` },
        { command: 'Find', prompt: `the amount Zara still owes after $${m}$ year${m > 1 ? 's' : ''}, correct to the nearest dollar.`, marks: 2, answer: { kind: 'num', value: Math.round(B), dp: 0, display: `\\$${Math.round(B)}` },
          ms: [['M1', `$N = ${12 * m}$ with the same $PMT$; solve for $FV$`], ['A1', `$\\$${Math.round(B)}$`]], working: [`Finance solver: $N = ${12 * m}$, $I\\% = ${i}$, $PV = ${PV}$, $PMT = -${P2.toFixed(2)}$`, `$FV = -${Math.round(B)}$: she still owes about $\\$${Math.round(B)}$`],
          hint: 'Run the solver for the payments made so far and find FV.', numworks: { app: 'Finance', lines: [[`N=${12 * m}, I%=${i}, PV=${PV}, PMT=−${P2.toFixed(2)}`, `FV=−${Math.round(B)}`]] },
          verify: `(lambda rr, P: ${PV}*(1+rr)**${12 * m} - P*((1+rr)**${12 * m}-1)/rr)(Rational(${Math.round(i * 10)},12000), ${PV}*Rational(${Math.round(i * 10)},12000)/(1-(1+Rational(${Math.round(i * 10)},12000))**(-${N})))` }
      ]
    };
  });

  /* Paper 3 style: investigate a series, conjecture, prove, apply */
  reg('hlx1.p3series', Object.assign({ skill: 'HL-1.3b', title: 'Paper 3 investigation: a series, a conjecture and a proof', paper: 3, challenge: true }, X), (R, o) => {
    const fac = R.bool(), k = R.int(6, 8), m = R.int(3, 5), n = m + R.int(2, 4);
    const S = fac ? t => factorial(t + 1) - 1 : t => (t - 1) * 2 ** (t + 1) + 2, term = fac ? 'r \\cdot r!' : 'r \\cdot 2^{r}';
    const part = fac ? factorial(n + 1) - factorial(m) : (n - 1) * 2 ** (n + 1) - (m - 2) * 2 ** m;
    const formula = fac ? '(n + 1)! - 1' : '(n - 1)2^{n+1} + 2', Tk = fac ? '(r + 1)! - r!' : '(r - 1)2^{r+1} - (r - 2)2^{r}';
    return {
      stem: `This question investigates the series $S_n = \\sum_{r=1}^{n} ${term}$.`,
      parts: [
        { command: 'Find', prompt: 'the values of $S_1$, $S_2$, $S_3$ and $S_4$.', marks: 2, answer: { kind: 'tuple', labels: ['S_1', 'S_2', 'S_3', 'S_4'], value: [S(1), S(2), S(3), S(4)], exact: true, markEach: true, display: [S(1), S(2), S(3), S(4)].join(',\\ ') },
          ms: [['A1', 'two correct'], ['A1', 'all four correct']], working: [`$S_1 = ${S(1)}$, $S_2 = ${S(2)}$, $S_3 = ${S(3)}$, $S_4 = ${S(4)}$`], hint: 'Add one more term each time.', verify: `tuple(summation(${fac ? 'r*factorial(r)' : 'r*2**r'}, (r,1,t)) for t in (1,2,3,4))` },
        { command: 'Show that', prompt: `$${term} = ${Tk}$.`, marks: 2, answer: { kind: 'open' },
          ms: fac ? [['M1', '$(r + 1)! = (r + 1)r!$'], ['A1', '$(r+1)r! - r! = r \\cdot r!$'], ['AG', '']] : [['M1', '$(r-1)2^{r+1} = 2(r-1)2^{r}$'], ['A1', '$2^{r}\\left(2r - 2 - r + 2\\right) = r \\cdot 2^{r}$'], ['AG', '']],
          working: fac ? ['$(r+1)! - r! = (r+1)r! - r! = r! \\left(r + 1 - 1\\right) = r \\cdot r!$'] : ['$(r-1)2^{r+1} - (r-2)2^{r} = 2^{r}\\left(2(r-1) - (r-2)\\right) = 2^{r}(r) = r \\cdot 2^{r}$'],
          hint: fac ? 'Write (r + 1)! as (r + 1) × r!.' : 'Take out a factor of 2ʳ.', verify: fac ? `gammasimp(factorial(x+1)-factorial(x)-x*factorial(x)) == 0` : `simplify((x-1)*2**(x+1)-(x-2)*2**x-x*2**x) == 0` },
        { command: 'Hence', prompt: `find a formula for $S_n$ and use it to find $S_{${k}}$.`, marks: 3, dep: true, answer: { kind: 'num', value: S(k), int: true, display: String(S(k)) },
          ms: [['M1', 'writing the sum of differences so that middle terms cancel'], ['A1', `$S_n = ${formula}$`], ['A1', `$S_{${k}} = ${S(k)}$`]],
          working: [`$S_n = \\sum_{r=1}^{n} \\left(${Tk}\\right)$: every term cancels except the first and the last.`, `$S_n = ${formula}$`, `$S_{${k}} = ${S(k)}$`], hint: 'Write out the first few differences: what cancels?', verify: `summation(${fac ? 'r*factorial(r)' : 'r*2**r'}, (r,1,${k}))` },
        { command: 'Prove', prompt: `by mathematical induction that $S_n = ${formula}$ for all $n \\in \\mathbb{Z}^{+}$.`, marks: 6, answer: { kind: 'open' },
          ms: [['A1', `$n = 1$: LHS $= ${S(1)}$, RHS $= ${S(1)}$`], ['M1', `assume $S_k = ${formula.replace(/n/g, 'k')}$`], ['M1', `$S_{k+1} = S_k + (k + 1)${fac ? '(k + 1)!' : '2^{k+1}'}$`], ['A1', fac ? '$= (k + 1)! - 1 + (k + 1)(k + 1)! = (k + 2)(k + 1)! - 1$' : '$= (k - 1)2^{k+1} + 2 + (k + 1)2^{k+1} = 2k \\cdot 2^{k+1} + 2$'],
            ['A1', fac ? '$= (k + 2)! - 1$' : '$= k \\cdot 2^{k+2} + 2$'], ['R1', 'true for $n = 1$ and true for $k$ ⇒ true for $k + 1$, so true for all $n \\in \\mathbb{Z}^{+}$']],
          working: [`Base case: $S_1 = ${S(1)}$ and the formula gives $${S(1)}$ ✓`, `Assume $S_k = ${formula.replace(/n/g, 'k')}$`, fac ? '$S_{k+1} = (k+1)! - 1 + (k+1)(k+1)! = (k+1)!(1 + k + 1) - 1 = (k+2)! - 1$' : '$S_{k+1} = (k-1)2^{k+1} + 2 + (k+1)2^{k+1} = 2k \\cdot 2^{k+1} + 2 = k \\cdot 2^{k+2} + 2$', 'This is the formula with $n = k + 1$. By induction, true for all $n \\in \\mathbb{Z}^{+}$.'],
          hint: 'Add the (k + 1)th term to your assumed formula and factorise.', verify: fac ? `gammasimp(factorial(k+1)-1+(k+1)*factorial(k+1)-(factorial(k+2)-1)) == 0` : `simplify((k-1)*2**(k+1)+2+(k+1)*2**(k+1)-(k*2**(k+2)+2)) == 0` },
        { command: 'Hence', prompt: `find the value of $\\sum_{r=${m}}^{${n}} ${term}$.`, marks: 2, dep: true, answer: { kind: 'num', value: part, int: true, display: String(part) },
          ms: [['M1', `$S_{${n}} - S_{${m - 1}}$`], ['A1', `$${part}$`]], working: [`$S_{${n}} - S_{${m - 1}} = ${S(n)} - ${S(m - 1)} = ${part}$`], hint: `Sum to ${n} minus sum to ${m - 1}.`,
          errors: [{ value: S(n) - S(m), tag: 'off-by-one-terms', fb: `Subtract S${m - 1}, not S${m}: the term r = ${m} is included.` }], verify: `summation(${fac ? 'r*factorial(r)' : 'r*2**r'}, (r,${m},${n}))` }
      ]
    };
  });
})(window.Hub = window.Hub || {});
