/* Shared UI pieces: question rendering (student/teacher/feedback), NumWorks screens, chips, modals. */
(function (Hub) {
  'use strict';
  const { esc, $, $$ } = Hub.core, M = t => Hub.math.render(t);
  const C = () => Hub.curriculum;

  const pill = (text, cls = '') => `<span class="pill ${cls}">${text}</span>`;
  const skillName = id => (C().SKILL[id] ? C().SKILL[id].name : id);
  const skillLabel = id => { const s = C().SKILL[id]; return s ? (s.ox ? `<span class="ox">${s.ox}</span> ` : '') + esc(s.name) : esc(id); };
  const unitColour = u => ['u1', 'u2', 'u3', 'u4', 'u5'][(u - 1) % 5];
  const skillChip = (id, extra = '') => { const s = C().SKILL[id]; return `<span class="chip ${s ? unitColour(s.unit) : ''}" title="${esc(skillName(id))}">${skillLabel(id)}${extra}</span>`; };
  function statusChip(st) { const S = Hub.mastery.STATUS[st.status]; const val = st.pct !== null && !['not-taught'].includes(st.status) ? st.pct + '%' : S.short; return `<span class="st ${S.cls}" title="${esc(S.label)}${st.marks ? ` · ${st.marks} marks of evidence` : ''}${st.last ? ` · last ${Hub.core.fmtDate(st.last)}` : ''}">${val}</span>`; }
  const bar = (p, cls = '') => `<div class="bar ${cls}" role="img" aria-label="${p ?? 0}%"><i style="width:${Math.max(0, Math.min(100, p || 0))}%"></i></div>`;
  const paperBadge = paper => paper === 2 ? '<span class="paper p2" title="Calculator allowed">Paper 2 · NumWorks</span>' : paper === 3 ? '<span class="paper p3">Paper 3 style</span>' : '<span class="paper p1" title="No calculator">Paper 1 · No calculator</span>';
  const cmd = term => { const d = C().COMMAND_TERMS[term]; return `<b class="cmd" ${d ? `tabindex="0" data-tip="${esc(d)}" aria-label="${esc(term)}: ${esc(d)}"` : ''}>${esc(term)}</b>`; };
  const ibLogo = () => `<img class="iblogo" src="${Hub.LOGO}" alt="" aria-hidden="true">`;

  /** NumWorks shows fractions in 2D ("pretty print"), so entries with a division are drawn stacked too. */
  function nwText(a) { if (a.includes('$')) return M(a); if (a.includes('/')) { const r = Hub.math.parse(a); if (!r.error) return Hub.math.texToMathML(r.tex, false); } return esc(a); }
  /** NumWorks screen mock: what students actually see (app header + entry/result rows). */
  function numworks(nw) {
    if (!nw) return '';
    return `<figure class="nw" aria-label="NumWorks screen"><div class="nw-head"><span>rad</span><b>${esc(nw.app)}</b><span>▮▮▮</span></div><div class="nw-body">${nw.lines.map(([a, b]) => `<div class="nw-row"><span class="nw-in">${nwText(a)}</span>${b ? `<span class="nw-out">${esc(b)}</span>` : ''}</div>`).join('')}</div><figcaption>NumWorks · ${esc(nw.app)} app</figcaption></figure>`;
  }
  /** Marks a markscheme line is worth: "A1A1" → 2, "(M1)" → 1, "AG" → 0. */
  const msValue = m => (String(m).match(/[MAR](\d)/g) || []).reduce((s, x) => s + Number(x.slice(1)), 0);

  /* ---------- answer inputs ---------- */
  function inputFor(q, p, resp, opts) {
    const a = p.answer, base = `${q.id}__${p.id}`, dis = opts.disabled ? 'disabled' : '';
    if (a.kind === 'open') return `<p class="note open-note">✍️ Show this on paper — it is marked by Miss Badmus from your uploaded working.</p>`;
    if (a.kind === 'mc') return `<fieldset class="mc"><legend class="sr">Choose one answer</legend>${a.choices.map((c, i) => `<label class="mc-opt"><input type="radio" name="${base}" value="${i}" ${String(resp) === String(i) ? 'checked' : ''} ${dis}><span class="mc-letter">${'ABCDEF'[i]}</span><span class="mc-text">${M(c)}</span></label>`).join('')}</fieldset>`;
    const n = a.kind === 'num' ? 1 : a.kind === 'list' ? (a.boxes || a.value.length) : a.value.length;
    const vals = a.kind === 'num' ? [resp] : (Array.isArray(resp) ? resp : []);
    const lab = i => a.kind === 'tuple' ? M(`$${a.labels[i]} =$`) : a.kind === 'list' ? M(`$x =$`) : 'Answer';
    return `<div class="ans-row">${Array.from({ length: n }, (_, i) => `<label class="ans"><span class="ans-lab">${lab(i)}</span><input class="ans-in" data-q="${q.id}" data-p="${p.id}" data-i="${i}" autocomplete="off" spellcheck="false" inputmode="text" value="${esc(vals[i] ?? '')}" ${dis} aria-describedby="pv-${base}-${i}"><output class="ans-pv" id="pv-${base}-${i}" aria-live="polite">${vals[i] ? Hub.math.preview(vals[i]) : ''}</output></label>`).join('')}</div>${a.kind === 'list' && (a.boxes || 0) > a.value.length ? '<p class="note">Leave a box empty if you need fewer.</p>' : ''}<p class="note tiny">Type fractions as 3/4, roots as sqrt(5), π as pi. Your answer appears as maths underneath.</p>`;
  }
  /** Read responses from a rendered question form. */
  function readResponses(root, questions) {
    const out = {};
    questions.forEach(q => { out[q.id] = {}; q.parts.forEach(p => {
      const a = p.answer;
      if (a.kind === 'mc') { const r = root.querySelector(`input[name="${q.id}__${p.id}"]:checked`); out[q.id][p.id] = r ? Number(r.value) : ''; }
      else if (a.kind === 'num') { const el = root.querySelector(`.ans-in[data-q="${q.id}"][data-p="${p.id}"]`); out[q.id][p.id] = el ? el.value : ''; }
      else if (a.kind !== 'open') out[q.id][p.id] = $$(`.ans-in[data-q="${q.id}"][data-p="${p.id}"]`, root).map(el => el.value);
    }); });
    return out;
  }
  function bindPreviews(root, onChange) {
    root.addEventListener('input', e => { const el = e.target.closest('.ans-in'); if (el) { const out = el.parentElement.querySelector('.ans-pv'); if (out) out.innerHTML = Hub.math.preview(el.value); } if (onChange) onChange(e); });
    if (onChange) root.addEventListener('change', onChange);
  }

  /* ---------- questions ---------- */
  /** mode: 'answer' (inputs), 'preview' (read-only student view), 'teacher' (with key + markscheme), 'feedback' (with results). */
  function question(q, i, opts = {}) {
    const mode = opts.mode || 'preview', responses = (opts.responses || {})[q.id] || {}, results = opts.results || {};
    const head = `<div class="q-head"><span class="q-num">${opts.number || i + 1}</span><div class="q-meta">${skillChip(q.skill)} ${paperBadge(q.paper)} ${q.challenge ? pill('Challenge', 'gold') : ''} ${q.preview ? pill('Preview · does not count', 'blue') : ''} ${opts.slot ? pill(opts.slot, 'pink') : ''}${q.paper === 2 && (mode === 'answer' || opts.calc) ? '<button type="button" class="btn small ghost calc-q" data-calc title="Open the NumWorks calculator">▦ NumWorks</button>' : ''}</div><span class="q-marks">[${q.marks} mark${q.marks > 1 ? 's' : ''}]</span></div>`;
    const stem = q.stem ? `<div class="q-stem">${M(q.stem)}</div>` : '';
    const parts = q.parts.map(p => {
      const r = results[q.id + '|' + p.id], fin = opts.final ? opts.final[q.id + '|' + p.id] : undefined;
      let body = `<div class="part" data-part="${p.id}"><div class="part-q"><span class="part-l">(${p.label})</span><div class="part-text">${cmd(p.command)} ${M(p.prompt)}</div><span class="part-m">[${p.marks}]</span></div>`;
      if (mode === 'answer') body += inputFor(q, p, responses[p.id], opts) + (opts.hints && p.hint ? `<details class="hint" data-hint="${q.id}|${p.id}"><summary>💡 Need a hint?</summary><p>${M(p.hint)}</p>${numworks(p.numworks)}</details>` : '');
      if (mode === 'teacher') body += teacherKey(p);
      if (mode === 'feedback') body += feedback(q, p, responses[p.id], r, fin, opts);
      return body + '</div>';
    }).join('');
    return `<article class="q-card ${opts.cls || ''}" id="q-${q.id}">${head}${stem}${parts}${opts.footer || ''}</article>`;
  }
  function answerDisplay(p) { const a = p.answer; if (a.kind === 'mc') return `${'ABCDEF'[a.correct]} · ${M(a.choices[a.correct])}`; if (a.kind === 'open') return 'See markscheme'; return M('$' + (a.display || (Array.isArray(a.value) ? a.value.join(', ') : a.value)) + '$'); }
  const accuracyText = a => a.kind === 'mc' ? 'Multiple choice' : a.kind === 'open' ? 'Teacher-marked from working' : a.int ? 'Whole number' : a.dp !== undefined ? `Correct to ${a.dp} d.p.` : a.exact ? 'Exact value' : 'Correct to 3 s.f.';
  function teacherKey(p) {
    return `<div class="key"><div class="key-row"><span class="key-lab">Answer</span><span>${answerDisplay(p)}</span><span class="tiny muted">${accuracyText(p.answer)}</span></div>
      <div class="ms"><span class="key-lab">Markscheme</span>${p.ms.map(([m, t]) => `<div class="ms-line"><b class="ms-mark">${esc(m)}</b> ${M(t)}</div>`).join('')}</div>
      <details class="working"><summary>Worked solution</summary><div class="hand">${p.working.map(w => `<div>${M(w)}</div>`).join('')}</div>${numworks(p.numworks)}</details>
      ${p.errors && p.errors.length ? `<div class="tiny muted">Detects: ${p.errors.map(e => esc(Hub.mastery.tagText(e.tag))).join(' · ')}</div>` : ''}</div>`;
  }
  function respText(p, resp) {
    const a = p.answer; if (a.kind === 'open') return '<i>On your uploaded working</i>';
    if (a.kind === 'mc') return resp === '' || resp === undefined ? '<i>blank</i>' : `${'ABCDEF'[resp]} · ${M(a.choices[resp])}`;
    const vals = a.kind === 'num' ? [resp] : (resp || []); const shown = vals.filter(v => v !== undefined && String(v).trim() !== '');
    return shown.length ? shown.map(v => Hub.math.preview(v) || esc(v)).join(', ') : '<i>blank</i>';
  }
  const VERDICT = { correct: ['Correct', 'ok'], partial: ['Partly right', 'part'], inexact: ['Not exact', 'part'], wrong: ['Not yet', 'no'], invalid: ['Couldn’t read', 'no'], blank: ['Blank', 'no'], teacher: ['Marked by teacher', 'wait'] };
  function feedback(q, p, resp, r, fin, opts) {
    if (!r) return '';
    const earned = fin !== undefined ? fin : r.earned, [vt, vc] = r.verdict === 'teacher' && fin !== undefined ? ['Marked', 'ok'] : VERDICT[r.verdict] || ['', ''];
    const showKey = opts.released !== false;
    return `<div class="fb fb-${vc}"><div class="fb-top"><span class="verdict ${vc}">${vt}</span><span class="fb-marks">${opts.released === false && r.verdict === 'teacher' ? '–' : earned}/${p.marks}</span></div>
      <div class="fb-row"><span class="key-lab">Your answer</span><span>${respText(p, resp)}</span></div>
      ${showKey ? `<div class="fb-row"><span class="key-lab">Answer</span><span>${answerDisplay(p)}</span></div>` : ''}
      ${r.feedback ? `<div class="sticky"><b>Spotted:</b> ${M(r.feedback)}</div>` : ''}
      ${r.error && r.verdict === 'invalid' ? `<div class="tiny muted">${esc(r.error)}</div>` : ''}
      ${showKey ? `<details class="working" ${r.verdict !== 'correct' ? 'open' : ''}><summary>Worked solution</summary><div class="hand">${p.working.map(w => `<div>${M(w)}</div>`).join('')}</div>${numworks(p.numworks)}</details>` : ''}
      ${opts.teacher ? `<div class="ms small">${p.ms.map(([m, t]) => `<div class="ms-line"><b class="ms-mark">${esc(m)}</b> ${M(t)}</div>`).join('')}</div>` : ''}</div>`;
  }

  /* ---------- modal (no native alert/confirm) ---------- */
  function modal(html, { onClose, wide } = {}) {
    const wrap = document.createElement('div'); wrap.className = 'modal-wrap'; wrap.innerHTML = `<div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true" tabindex="-1">${html}<button class="modal-x" aria-label="Close">×</button></div>`;
    document.body.appendChild(wrap); const prev = document.activeElement; const box = wrap.querySelector('.modal');
    const close = () => { wrap.remove(); document.removeEventListener('keydown', key); if (prev && prev.focus) prev.focus(); if (onClose) onClose(); };
    const key = e => { if (e.key === 'Escape') close(); if (e.key === 'Tab') { const f = $$('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])', box).filter(x => !x.disabled); if (!f.length) return; if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); } else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); } } };
    document.addEventListener('keydown', key); wrap.addEventListener('click', e => { if (e.target === wrap || e.target.classList.contains('modal-x')) close(); });
    setTimeout(() => { const first = box.querySelector('input, button:not(.modal-x), select, textarea'); (first || box).focus(); }, 30);
    return { el: box, close };
  }
  function confirmBox(message, okText = 'Yes, continue', { danger } = {}) {
    return new Promise(res => { let done = false; const m = modal(`<h2 class="modal-title">Please confirm</h2><p>${message}</p><div class="actions"><button class="btn ${danger ? 'danger' : 'primary'}" data-ok>${esc(okText)}</button><button class="btn ghost" data-no>Cancel</button></div>`, { onClose: () => { if (!done) res(false); } });
      m.el.querySelector('[data-ok]').onclick = () => { done = true; m.close(); res(true); }; m.el.querySelector('[data-no]').onclick = () => { done = true; m.close(); res(false); }; });
  }
  const groupOptions = (sel, course) => Object.values(C().GROUPS).filter(g => !course || g.course === course).map(g => `<option value="${g.id}" ${g.id === sel ? 'selected' : ''}>${g.label}</option>`).join('');
  const empty = (text, cta = '') => `<div class="empty"><img src="${Hub.LOGO}" alt="" aria-hidden="true"><p>${text}</p>${cta}</div>`;
  const heading = (kicker, title, sub = '', right = '') => `<header class="page-head"><div><p class="kicker">${kicker}</p><h1>${title}</h1>${sub ? `<p class="lead">${sub}</p>` : ''}</div>${right ? `<div class="page-head-r">${right}</div>` : ''}</header>`;
  const eq = (text) => `<div class="eq-strip"><span class="eq-tag">Essential question</span> ${text}</div>`;

  /** Tooltip for command terms (keyboard + mouse). */
  document.addEventListener('focusin', e => { const t = e.target.closest && e.target.closest('[data-tip]'); if (t) t.classList.add('tip-on'); });
  document.addEventListener('focusout', e => { const t = e.target.closest && e.target.closest('[data-tip]'); if (t) t.classList.remove('tip-on'); });

  Hub.ui = { pill, skillChip, skillLabel, skillName, statusChip, bar, paperBadge, cmd, numworks, msValue, question, readResponses, bindPreviews, answerDisplay, accuracyText, modal, confirmBox, groupOptions, empty, heading, eq, unitColour, ibLogo, respText };
})(window.Hub = window.Hub || {});
