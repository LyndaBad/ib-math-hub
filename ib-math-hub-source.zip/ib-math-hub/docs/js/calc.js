/* NumWorks calculator panel.
   Uses NumWorks' own free online simulator (numworks.com). The panel docks on the right on a laptop or Chromebook
   and goes full screen on a phone. It is created only when first opened, so pages load as fast as before.
   It stays open while you move between pages. During work that is all Paper 1 (no calculator) it is hidden. */
(function (Hub) {
  'use strict';
  const EMBED = 'https://www.numworks.com/simulator/embed/';
  const FULL = 'https://www.numworks.com/simulator/';
  let panel = null, allowed = true, loaded = false;
  const launchers = () => document.querySelectorAll('[data-calc]');

  function build() {
    panel = document.createElement('aside');
    panel.id = 'calc-panel'; panel.className = 'calc-panel'; panel.setAttribute('aria-label', 'NumWorks calculator'); panel.hidden = true;
    panel.innerHTML = `<header class="calc-head"><b>NumWorks calculator</b><span class="calc-tools"><a class="btn small ghost" href="${FULL}" target="_blank" rel="noopener">Open in a new tab ↗</a><button class="btn small ghost" type="button" data-calc-close aria-label="Close the calculator">×</button></span></header>
      <div class="calc-frame"><p class="calc-wait tiny muted">Loading the NumWorks simulator…</p></div>
      <p class="calc-note tiny muted">Free online NumWorks from numworks.com — the same calculator you use in class. If it does not appear, use <b>Open in a new tab</b>.</p>`;
    document.body.appendChild(panel);
    panel.querySelector('[data-calc-close]').onclick = () => toggle(false);
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && panel && !panel.hidden && panel.contains(document.activeElement)) toggle(false); });
  }
  function load() {
    if (loaded) return; loaded = true;
    const box = panel.querySelector('.calc-frame');
    const f = document.createElement('iframe');
    f.src = EMBED; f.title = 'NumWorks graphing calculator simulator'; f.loading = 'lazy';
    f.setAttribute('allow', 'clipboard-write; fullscreen'); f.setAttribute('referrerpolicy', 'strict-origin-when-cross-origin');
    f.onload = () => { const w = box.querySelector('.calc-wait'); if (w) w.remove(); };
    box.appendChild(f);
  }
  /** Open (true), close (false) or flip (no argument) the panel. */
  function toggle(open) {
    if (!panel) build();
    const show = open === undefined ? panel.hidden : !!open;
    if (show && !allowed) { Hub.core.toast('No calculator for this one — it is Paper 1 style.', 'error'); return; }
    panel.hidden = !show; document.body.classList.toggle('calc-open', show);
    launchers().forEach(b => b.setAttribute('aria-expanded', String(show)));
    if (show) { load(); panel.querySelector('[data-calc-close]').focus(); }
  }
  /** Pages call this: false hides the launcher and closes the panel (e.g. a Paper 1 quiz). Reset to true on every page change. */
  function setAllowed(v) {
    allowed = !!v; document.body.classList.toggle('no-calc', !allowed);
    if (!allowed && panel && !panel.hidden) toggle(false);
  }
  Hub.calc = { toggle, setAllowed, EMBED, FULL, get open() { return !!panel && !panel.hidden; } };
})(window.Hub = window.Hub || {});
