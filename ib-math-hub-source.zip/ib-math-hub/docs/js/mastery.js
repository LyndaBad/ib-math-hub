/* Mastery model (transparent, explainable):
   - Evidence rows: {sid, skill, earned, max, date, source, preview?, superseded?}
   - Weight = source weight × recency (half-life, default 21 days) × 0.5 if superseded by a later retake.
   - Mastery % = Σ w·earned / Σ w·max. "Evidence" = Σ w·max (weighted marks seen).
   - Status: not taught yet · no evidence · too little evidence (< minEvidence weighted marks) · revisit (<60) · developing (60–79) · secure (≥80).
   These are classroom indicators, not IB grade boundaries. Preview (bridge) questions never count. */
(function (Hub) {
  'use strict';
  const SOURCE_W = { 'Unit test': 1, 'Retest': 1, 'Quiz': 1, 'Exit Ticket': 0.8, 'Do Now': 0.7, 'Homework': 0.6, 'Practice': 0.5 };
  const STATUS = {
    'not-taught': { label: 'Not taught yet', short: '—', cls: 'st-nt' },
    'no-evidence': { label: 'No evidence yet', short: '?', cls: 'st-ne' },
    'low-evidence': { label: 'Too little evidence', short: '?', cls: 'st-le' },
    'revisit': { label: 'Revisit', short: 'R', cls: 'st-r' },
    'developing': { label: 'Developing', short: 'D', cls: 'st-d' },
    'secure': { label: 'Secure', short: 'S', cls: 'st-s' }
  };
  const S = () => Hub.store.state;
  const asOf = () => S().settings.asOf || Hub.core.todayISO();

  function rows(sid, skill) { const d = asOf(); return S().evidence.filter(e => e.sid === sid && e.skill === skill && !e.preview && e.date <= d); }
  function weight(e, today, half) { const age = Math.max(0, Hub.core.daysBetween(e.date, today)); return (SOURCE_W[e.source] ?? 0.6) * Math.pow(0.5, age / half) * (e.superseded ? 0.5 : 1) * (e.hinted ? 0.6 : 1); }

  /** Full statistics for one student × skill. */
  function stat(sid, skill) {
    const st = S(), today = asOf(), half = st.settings.halfLifeDays || 21, minEv = st.settings.minEvidence || 3;
    const student = Hub.roster.byId(sid), group = student ? student.group : null;
    const R = rows(sid, skill);
    let we = 0, wm = 0, re = 0, rm = 0, raw = 0, rawMax = 0, last = null; const recentCut = Hub.core.addDays(today, -21);
    for (const e of R) {
      const w = weight(e, today, half); we += w * e.earned; wm += w * e.max; raw += e.earned; rawMax += e.max;
      if (e.date >= recentCut) { re += e.earned; rm += e.max; }
      if (!last || e.date > last) last = e.date;
    }
    const taught = group ? Hub.curriculum.isTaught(skill, group, today) : true;
    const p = wm > 0 ? Math.round(100 * we / wm) : null;
    let status;
    if (!R.length) status = taught ? 'no-evidence' : 'not-taught';
    else if (wm < minEv * 0.5 || rawMax < minEv) status = 'low-evidence';
    else status = p < 60 ? 'revisit' : p < 80 ? 'developing' : 'secure';
    const tags = {}; R.forEach(e => (e.tags || []).forEach(t => (tags[t] = (tags[t] || 0) + 1)));
    return { sid, skill, pct: p, cumulative: rawMax ? Math.round(100 * raw / rawMax) : null, recent: rm ? Math.round(100 * re / rm) : null, evidence: Math.round(wm * 10) / 10, marks: rawMax, n: R.length, last, taught, status, tags };
  }
  const studentSkills = sid => { const s = Hub.roster.byId(sid); return s ? Hub.curriculum.skillsFor(s.course).map(k => stat(sid, k.id)) : []; };
  /** Average over students in a group for a skill (only students with enough evidence). */
  function groupSkill(groupId, skill) {
    const st = Hub.roster.inGroup(groupId).map(s => stat(s.id, skill)), solid = st.filter(x => !['not-taught', 'no-evidence', 'low-evidence'].includes(x.status));
    const avg = solid.length ? Math.round(solid.reduce((a, x) => a + x.pct, 0) / solid.length) : null;
    const counts = {}; st.forEach(x => (counts[x.status] = (counts[x.status] || 0) + 1));
    return { skill, avg, n: solid.length, counts, taught: st.length ? st[0].taught : false };
  }
  function overall(sid) { const xs = studentSkills(sid).filter(x => x.pct !== null && x.status !== 'low-evidence'); return xs.length ? Math.round(xs.reduce((a, x) => a + x.pct, 0) / xs.length) : null; }
  /** Misconception counts across a group (optionally within the last N days). */
  function misconceptions(groupId, days = 28) {
    const ids = new Set(Hub.roster.inGroup(groupId).map(s => s.id)), cut = Hub.core.addDays(asOf(), -days), out = {};
    S().evidence.forEach(e => { if (ids.has(e.sid) && e.date >= cut) (e.tags || []).forEach(t => { const k = e.skill + '|' + t; out[k] = out[k] || { skill: e.skill, tag: t, n: 0, students: new Set() }; out[k].n++; out[k].students.add(e.sid); }); });
    return Object.values(out).map(o => Object.assign(o, { students: o.students.size })).sort((a, b) => b.students - a.students || b.n - a.n);
  }
  const TAG_TEXT = {
    'term-not-sum': 'Used uₙ instead of Sₙ', 'n-minus-1': 'Off by one in (n − 1)', 'not-checking-both': 'Did not check both neighbouring values', 'constant-once': 'Added the constant once in Σ', 'off-by-one-terms': 'Miscounted terms in Σ',
    'count-terms': 'Number of terms: forgot + 1', 'round-down': 'Rounded n down instead of up', 'sinf-sign': 'S∞ denominator sign', 'missing-ncr': 'Missing binomial coefficient', 'power-on-coefficient': 'Did not raise the coefficient to the power',
    'sign': 'Sign error', 'forgot-square': 'Forgot to square root at the end', 'order-of-composition': 'Composite in the wrong order', 'reciprocal-not-inverse': 'Confused f⁻¹ with the reciprocal of f', 'applied-f': 'Applied f instead of f⁻¹',
    'parallel-not-perpendicular': 'Used the parallel gradient', 'reciprocal-no-sign': 'Reciprocal without the sign change', 'translation-direction': 'Horizontal translation direction', 'horizontal-stretch-factor': 'Horizontal stretch factor inverted',
    'axis-sign': 'Axis of symmetry sign', 'root-signs': 'Root signs from factors', 'vertex-sign': 'Vertex form sign', 'forgot-4ac': 'Discriminant: forgot 4ac', 'missing-negative-root': 'Missed the negative root',
    'annual-not-compounded': 'Ignored compounding periods', 'simple-interest': 'Used simple growth', 'truncated': 'Truncated instead of rounding', 'pct-wrong-denominator': 'Percentage error over the estimate', 'standard-form-sign': 'Standard form power sign',
    'not-exact': 'Gave a decimal where exact was required', 'geometric-from-r-0': 'Geometric sum started at r = 0', 'extraneous-root': 'Kept an extraneous root', 'extra-solution': 'Gave an extra (invalid) solution', 'swapped': 'Values swapped',
    'did-not-rearrange': 'Did not rearrange before Δ', 'endpoints-only': 'Range from end-points only', 'i-squared': 'Treated i² as +1', 'vieta-sign': 'Sign of the sum or product of roots', 'forgot-cross-terms': 'Forgot cross terms when squaring',
    'chain-rule-inside': 'Chain rule: missed the inner derivative', 'product-of-derivatives': 'Multiplied derivatives (product rule)', 'quotient-order': 'Quotient rule order', 'product-rule-missing': 'Implicit: missed product rule on xy',
    'did-not-differentiate': 'Did not differentiate before chain rule', 'sd-shifted': 'Shifted the SD by the constant', 'repeats-not-divided': 'Did not divide by repeats', 'ignored-restriction': 'Ignored the restriction', 'forgot-internal-arrangement': 'Forgot the pair can swap',
    'sign-of-negative-term': 'Lost the negative sign in the general term', 'did-not-factor': 'Did not factor out the constant first', 'inverted-validity': 'Validity interval inverted', 'did-not-take-reciprocal': 'Did not take the reciprocal', 'domain-of-f-not-composite': 'Domain of f, not of f∘g',
    'domain-not-range': 'Confused domain and range of the inverse', 'term-off': 'Wrong term', 'time-not-height': 'Gave the time, not the height', 'ignored-start-height': 'Ignored the starting height', 'inverted-gradient': 'Gradient upside down', 'forgot-root': 'Forgot the square root',
    'negative-squared': 'Squared a negative without brackets', 'difference-sign': 'Subtracted the wrong way round', 'steps-count': 'Counted steps between terms wrongly', 'power-count': 'Wrong number of ratio steps', 'multiplied-not-divided': 'Multiplied instead of dividing',
    'perm-not-comb': 'Used permutations not combinations', 'terms-n': 'Number of terms: n not n + 1', 'forgot-constant-power': 'Forgot to raise the constant to r', 'halved': 'Halved instead of square rooting', 'multiplied': 'Multiplied instead of dividing',
    'constants-not-leading': 'Used constants, not leading coefficients', 'power-rule-negative': 'Power rule sign for x⁻¹', 'x-not-area': 'Gave x, not the area', 'forgot-q3': 'Fence not added to Q3', 'square-of-sum': 'Missed the middle term when squaring',
    'inverse-sign': 'Inverse: undid + with +', 'sd-negative': 'Negative SD', 'variance-scale': 'Variance scaled by |a| not a²', 'added-not-multiplied': 'Added instead of multiplying', 'powers-swapped': 'Powers swapped in the general term', 'substituted-0-over-0': 'Treated zero over zero as 0', 'last-term-only': 'Used only the last term', 'leading-zeros': 'Counted leading zeros'
  };
  const tagText = t => TAG_TEXT[t] || t.replace(/-/g, ' ');
  Hub.mastery = { stat, studentSkills, groupSkill, overall, misconceptions, STATUS, SOURCE_W, tagText, asOf };
})(window.Hub = window.Hub || {});
