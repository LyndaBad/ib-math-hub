/* App shell: sign-in, navigation, routing (#/page/param?query), preview banner, re-rendering. */
(function (Hub) {
  'use strict';
  const { $, $$, esc, initials, toast } = Hub.core, U = Hub.ui, C = () => Hub.curriculum;
  const TEACHER_NAV = [['home', '⌂', 'Dashboard'], ['lessons', '▣', 'Lessons & notebooks'], ['studio', '✎', 'Assessment studio'], ['marking', '✓', 'Marking queue'], ['donow', '☀', 'Personalised Do Now'], ['mastery', '▦', 'Mastery'], ['ia', '◇', 'IA overview'], ['course', '▤', 'Course & pacing'], ['settings', '⚙', 'Data & settings']];
  const STUDENT_NAV = [['home', '⌂', 'My day'], ['notebook', '▣', 'My notebook'], ['donow', '☀', 'Do Now'], ['practice', '∞', 'Practice'], ['progress', '▦', 'My progress'], ['ia', '◇', 'My IA studio'], ['course', '▤', 'My calendar']];
  const ART = Hub.HOST === 'artifact'; let current = '#/home';
  const currentHash = () => (ART ? current : location.hash);
  /** Navigate. In the claude.ai preview frame the URL hash is not used (only plain #names pass through), so routes live in memory there. */
  function nav(h) { if (ART) { current = h; render(); const m = $('#main'); if (m) m.focus({ preventScroll: true }); window.scrollTo(0, 0); } else if (location.hash === h) render(); else location.hash = h; }
  function parse() {
    const h = currentHash().replace(/^#\/?/, '') || 'home'; const [path, qs] = h.split('?'); const [page, id] = path.split('/');
    const params = Object.fromEntries(new URLSearchParams(qs || '')); if (id) params.id = decodeURIComponent(id); return { page: page || 'home', params };
  }
  const ROUTES = {
    teacher: { lessons: (m, p) => Hub.lessons.list(m, p), lesson: (m, p) => Hub.lessons.edit(m, p), preview: (m, p) => Hub.teacher.preview(m, p), print: (m, p) => Hub.print.view(m, p), home: m => Hub.teacher.dashboard(m), studio: (m, p) => Hub.teacher.studio(m, p), edit: (m, p) => Hub.teacher.edit(m, p), analysis: (m, p) => Hub.teacher.analysis(m, p), marking: m => Hub.teacher.marking(m), mark: (m, p) => Hub.teacher.mark(m, p), donow: (m, p) => Hub.teacher.donow(m, p), 'donow-print': (m, p) => Hub.teacher.donowPrint(m, p), mastery: (m, p) => Hub.teacher.mastery(m, p), student: (m, p) => Hub.teacher.student(m, p), ia: (m, p) => Hub.shared.iaTeacher(m, p), course: (m, p) => Hub.shared.course(m, p), settings: m => Hub.shared.settings(m) },
    student: { notebook: (m, p) => Hub.lessons.student(m, p), home: m => Hub.student.home(m), donow: m => Hub.student.donow(m), task: (m, p) => Hub.student.task(m, p), result: (m, p) => Hub.student.result(m, p), practice: (m, p) => Hub.student.practice(m, p), progress: m => Hub.student.progress(m), ia: m => Hub.shared.iaStudent(m), course: (m, p) => Hub.shared.course(m, p) }
  };
  function shell() {
    const sess = Hub.auth.current(), role = Hub.auth.role(), st = role === 'student' ? Hub.roster.byId(Hub.auth.sid()) : null;
    const navItems = role === 'teacher' ? TEACHER_NAV : STUDENT_NAV, q = role === 'teacher' ? Hub.assess.queue().length : 0;
    const name = role === 'student' ? (st ? st.name : '') : sess.name, sub = role === 'student' ? (st ? C().GROUPS[st.group].label : '') : 'Teacher · IB AA SL & HL';
    $('#app').innerHTML = `<div class="shell"><aside class="side" id="side"><a class="brand" href="#/home"><img src="${Hub.LOGO}" alt="Miss Badmus’ IB wolf logo"><span class="brand-text"><small>Miss Badmus’</small><b>IB Math Hub</b></span></a><p class="slogan">Inquirers. Thinkers. Reflective Learners.</p>
      <nav aria-label="Main">${navItems.map(([id, ic, label]) => `<a href="#/${id}" data-nav="${id}"><span class="ic" aria-hidden="true">${ic}</span>${label}${id === 'marking' && q ? `<span class="badge">${q}</span>` : ''}</a>`).join('')}</nav>
      <button class="calc-launch" type="button" data-calc aria-controls="calc-panel"><span class="ic" aria-hidden="true">▦</span>NumWorks calculator</button>
      <div class="side-foot"><span class="demo-badge">PRIVATE CLASSROOM</span><span class="tiny">Saved in Supabase</span></div></aside>
      <div class="main-col"><header class="top"><button class="menu-btn" id="menu" aria-label="Open menu" aria-expanded="false" aria-controls="side">☰</button><span class="top-title">${role === 'teacher' ? 'IB Mathematics: Analysis & Approaches' : esc(sub)}</span><span id="save-status" class="save-status" aria-live="polite"></span>
        <div class="user"><span class="avatar" aria-hidden="true">${esc(initials(name || 'MB'))}</span><span class="user-t"><b>${esc(name)}</b><small>${esc(sub)}</small></span><button class="btn small ghost" id="refresh-cloud">Refresh</button><button class="btn small ghost" id="signout">Sign out</button></div></header>
        ${Hub.auth.isPreview() ? `<div class="banner preview" role="status">👁 Previewing as <b>${esc(name)}</b> — answers you submit are not saved and never change their record. <button class="btn small" id="end-preview">Back to teacher view</button></div>` : ''}
        <div class="banner conflict" id="conflict-banner" role="alert" hidden><span><b>Not saved:</b> this item was also changed somewhere else (another tab or device).</span><button class="btn small primary" id="keep-mine">Keep my changes</button><button class="btn small ghost" id="load-cloud">Load the cloud copy</button></div>
        <main id="main" tabindex="-1"></main><footer class="foot">Miss Badmus’ IB Math Hub · Secure sign-in · cloud storage · Canvas link ready</footer></div></div>`;
    const showConflict = () => { const b = $('#conflict-banner'); if (b) b.hidden = !Hub.store.blocked; };
    showConflict();
    $('#keep-mine').onclick = async () => { try { await Hub.store.keepMine(); toast('Saved — your changes were applied on top of the latest cloud copy.'); } catch (e) { toast(e.message, 'error'); } showConflict(); };
    $('#load-cloud').onclick = async () => { if (await U.confirmBox('Load the cloud copy? Edits made here since the last save will be discarded.', 'Load cloud copy', { danger: true })) { try { await Hub.store.reload(); toast('Cloud copy loaded.'); } catch (e) { toast(e.message, 'error'); } } };
    $('#refresh-cloud').onclick=async()=>{try{await Hub.store.refresh();toast('Latest classroom updates loaded.');}catch(e){toast(e.message,'error')}};
    $('#signout').onclick = async () => {try {await Hub.auth.signOut();shellFor=null;nav('#/home');}catch(e){toast(e.message,'error')}};
    const ep = $('#end-preview'); if (ep) ep.onclick = () => { const sid = Hub.auth.sid(); Hub.auth.viewAs(null); shellFor = null; nav('#/student/' + sid); };
    $('#menu').onclick = () => { const s = $('#side'), open = !s.classList.contains('open'); s.classList.toggle('open', open); $('#menu').setAttribute('aria-expanded', open); };
  }
  let shellFor = null;
  function render() {
    const sess = Hub.auth.current();
    if (!sess || (sess.role === 'student' && !Hub.roster.byId(sess.sid))) { shellFor = null; signIn(); return; }
    if (sess.role === 'teacher' && !Hub.auth.isPreview() && Hub.store.state) Hub.assess.autoClose();
    const key = sess.email + '|' + Hub.auth.role() + '|' + (Hub.auth.sid() || '') + '|' + Hub.assess.queue().length;
    if (shellFor !== key || !$('#main')) { shell(); shellFor = key; }
    const { page, params } = parse(), role = Hub.auth.role(), routes = ROUTES[role], fn = routes[page] || routes.home;
    $$('[data-nav]').forEach(a => { const on = a.dataset.nav === page || (['edit', 'preview', 'print', 'analysis'].includes(page) && a.dataset.nav === 'studio') || (page === 'lesson' && a.dataset.nav === 'lessons') || (page === 'mark' && a.dataset.nav === 'marking') || (['task', 'result'].includes(page) && a.dataset.nav === 'home'); a.classList.toggle('active', on); if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
    const main = $('#main');
    if (Hub.calc) Hub.calc.setAllowed(true);
    try { fn(main, params); } catch (e) { console.error(e); main.innerHTML = U.empty('Something went wrong showing this page. Your data is safe.', `<pre class="tiny">${esc(e.message)}</pre><a class="btn" href="#/home">Go home</a>`); }
    (S => { const n = S.notices; if (n && n.length) { const x = n.shift(); toast(x.text, x.kind); Hub.store.save(); } })(Hub.store.state);
    $('#side') && $('#side').classList.remove('open');
  }
  /* ---------- real sign-in ---------- */
  function signIn() {
    $('#app').innerHTML = `<main class="signin" id="main"><section class="signin-card"><img class="signin-wolf" src="${Hub.LOGO}" alt="Miss Badmus’ wolf logo"><p class="kicker">MISS BADMUS’</p><h1>IB Math Hub</h1><p class="slogan big">Inquirers. Thinkers. Reflective Learners.</p><form id="login-form"><label>Email<input id="login-email" type="email" autocomplete="username" required></label><label>Password<input id="login-password" type="password" autocomplete="current-password" required></label><button class="btn primary" id="login-button">Sign in</button></form><p id="login-error" role="alert" class="small"></p><button class="btn small ghost" id="owner-setup" type="button">First-time teacher setup</button><button class="btn small ghost" id="owner-reset" type="button">Teacher password reset</button><p class="tiny muted">Use the account activated by your teacher. Need access or a password reset? Ask Miss Badmus for a new activation link.</p></section></main>`;
    $('#owner-setup').onclick=()=>{
      $('#app').innerHTML=`<main class="signin"><section class="signin-card"><h1>Teacher setup</h1><p>Activate badmuslyn@gmail.com as the owner. Choose your password, then confirm the message sent to that email.</p><form id="owner-form"><label>Password (12 characters minimum)<input id="owner-password" type="password" autocomplete="new-password" minlength="12" required></label><button class="btn primary">Create my teacher account</button><p id="owner-message" role="status"></p></form><button class="btn ghost" id="back-login">Back to sign in</button></section></main>`;
      $('#back-login').onclick=signIn;
      $('#owner-form').onsubmit=async e=>{e.preventDefault();const {error}=await Hub.cloud.client.auth.signUp({email:'badmuslyn@gmail.com',password:$('#owner-password').value,options:{emailRedirectTo:'https://missbadmusibmath.com/'}});$('#owner-message').textContent=error?error.message:'Check badmuslyn@gmail.com for the confirmation link. If this account already exists, use Teacher password reset.';};
    };
    $('#owner-reset').onclick=async()=>{const {error}=await Hub.cloud.client.auth.resetPasswordForEmail('badmuslyn@gmail.com',{redirectTo:'https://missbadmusibmath.com/'});$('#login-error').textContent=error?error.message:'Check badmuslyn@gmail.com for your password reset link.';};
    $('#login-form').onsubmit=async e=>{e.preventDefault();$('#login-button').disabled=true;try {await Hub.auth.signIn($('#login-email').value.trim(),$('#login-password').value);shellFor=null;nav('#/home');}catch(e){$('#login-error').textContent=e.message;$('#login-button').disabled=false;}};
  }
  function passwordSetup(){
    $('#app').innerHTML=`<main class="signin"><section class="signin-card"><img class="signin-wolf" src="${Hub.LOGO}" alt="Wolf logo"><h1>Make this space yours</h1><p>Choose a password for your Hub account.</p><form id="setup-password"><label>New password<input id="new-password" type="password" autocomplete="new-password" minlength="12" required></label><label>Confirm password<input id="repeat-password" type="password" autocomplete="new-password" minlength="12" required></label><button class="btn primary">Save password & continue</button><p id="setup-error" role="alert"></p></form></section></main>`;
    $('#setup-password').onsubmit=async e=>{e.preventDefault();if($('#new-password').value!==$('#repeat-password').value){$('#setup-error').textContent='Passwords do not match.';return;}const {error}=await Hub.cloud.client.auth.updateUser({password:$('#new-password').value});if(error){$('#setup-error').textContent=error.message;return;}location.hash='#/home';location.reload();};
  }
  async function boot() {
    const activation=Hub.cloud.activation;
    try {
      await Hub.cloud.client.auth.getSession();
      if(activation){passwordSetup();return;}
      await Hub.auth.init();
    }catch(e){signIn();$('#login-error').textContent=e.message;return;}
    Hub.store.onExternal(() => { shellFor = null; render(); });
    window.addEventListener('hub-conflict', () => { const b = $('#conflict-banner'); if (b) b.hidden = !Hub.store.blocked; });
    // A link to the page that is already showing (e.g. "Back to the editor" after a preview drawn in place) must still re-render.
    document.addEventListener('click', e => { const a = e.target.closest && e.target.closest('a[href^="#/"]'); if (!ART && a && !e.defaultPrevented && a.getAttribute('href') === location.hash) { e.preventDefault(); render(); window.scrollTo(0, 0); } });
    document.addEventListener('click', e => { const c = e.target.closest && e.target.closest('[data-calc]'); if (c) { e.preventDefault(); Hub.calc.toggle(true); } });
    if (ART) document.addEventListener('click', e => { const a = e.target.closest && e.target.closest('a[href^="#/"]'); if (a && !e.defaultPrevented) { e.preventDefault(); nav(a.getAttribute('href')); } });
    else window.addEventListener('hashchange', () => { render(); const m = $('#main'); if (m) { m.focus({ preventScroll: true }); window.scrollTo(0, 0); } });
    render();
  }
  Hub.app = { render, boot, nav, currentHash };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})(window.Hub = window.Hub || {});
