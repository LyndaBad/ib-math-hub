/* Server-backed state. No roster, marks or IA content are cached to localStorage.
   Optimistic entity merging on the server prevents silent cross-device overwrites.
   v3.1: Postgres jsonb stores object keys re-ordered (by length, then bytes). The server compares items as JSON text,
   so everything we send is put in that same canonical key order first. Without this, the second edit of any
   newly created item was reported as a "Conflict". A conflict can now be resolved in place (keep mine / load cloud). */
(function(Hub){
 'use strict';const clone=x=>JSON.parse(JSON.stringify(x));
 const enc=new TextEncoder();
 /** Same key order as Postgres jsonb: shorter keys first, then byte order. */
 function keyOrder(a,b){if(a.length!==b.length||!/^[\x00-\x7f]*$/.test(a+b)){const x=enc.encode(a),y=enc.encode(b);if(x.length!==y.length)return x.length-y.length;for(let i=0;i<x.length;i++)if(x[i]!==y[i])return x[i]-y[i];return 0;}return a<b?-1:a>b?1:0;}
 const canon=v=>Array.isArray(v)?v.map(canon):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort(keyOrder).map(k=>[k,canon(v[k])])):v;
 const same=(a,b)=>JSON.stringify(canon(a===undefined?null:a))===JSON.stringify(canon(b===undefined?null:b));
 let state=null,base=null,timer=null,pending=Promise.resolve(),dirty=false,edit=0,blocked=false,conflictMsg='';const listeners=[];
 const blank=()=>({schema:2,settings:{asOf:null,halfLifeDays:21,minEvidence:3},roster:{source:'imported',students:[]},assessments:[],attempts:[],evidence:[],progress:{},donow:{},ia:{},log:[],notices:[]});
 function accept(s){state=clone(s);base=canon(clone(s));dirty=false;blocked=false;conflictMsg='';announce();}
 function status(text,kind){Hub.core.saveStatus(text,kind)}
 function announce(){window.dispatchEvent(new CustomEvent('hub-conflict',{detail:{blocked,message:conflictMsg}}));}
 async function persist(){
  if(!dirty||!state||!Hub.auth.current())return true;if(blocked)throw Error('Resolve the save conflict before continuing.');
  const next=canon(clone(state)),before=canon(clone(base)),version=edit;
  status('Saving to cloud…','pending');
  try{await Hub.cloud.call('save',{base:before,state:next});base=next;
   // Keep live form references stable; refresh explicitly to receive other devices' changes.
   dirty=edit!==version;
   status(dirty?'Changes pending…':'Saved to cloud','ok');return true;
  }catch(e){blocked=/^Conflict:/.test(e.message);if(blocked){conflictMsg=e.message;announce();}status('Not saved — '+(blocked?'this item was changed somewhere else':e.message),'error');Hub.core.toast(e.message,'error');throw e;}
 }
 function flush(){clearTimeout(timer);pending=pending.catch(()=>{}).then(async()=>{while(dirty){await persist();}return true});return pending;}
 function save(immediate){if(Hub.auth?.isPreview())return;dirty=true;edit++;if(!blocked)status('Changes pending…','pending');clearTimeout(timer);if(blocked)return;if(immediate){flush().catch(()=>{});}else timer=setTimeout(()=>flush().catch(()=>{}),800);}
 async function refresh(){await flush();const r=await Hub.cloud.call('load');accept(r.state);listeners.forEach(fn=>fn('external'));}
 function log(what,who){state.log.push({at:new Date().toISOString(),who:who||Hub.auth.who(),what});state.log=state.log.slice(-400);}
 async function reload(){const r=await Hub.cloud.call('load');accept(r.state);listeners.forEach(fn=>fn('external'));}
 /** Conflict resolution: take the latest cloud copy and re-apply every item I changed on top of it. */
 function applyMine(old,mine,server){
  const out=clone(server);
  const byId=a=>Object.fromEntries((a||[]).map(x=>[x.id,x]));
  const list=(o,m,s)=>{const O=byId(o),Mi=byId(m),R=byId(s);for(const id of new Set([...Object.keys(O),...Object.keys(Mi)]))if(!same(O[id],Mi[id])){if(Mi[id]===undefined)delete R[id];else R[id]=clone(Mi[id]);}return Object.values(R);};
  const map=(o={},m={},s={})=>{const R=clone(s||{});for(const k of new Set([...Object.keys(o||{}),...Object.keys(m||{})]))if(!same(o[k],m[k])){if(m[k]===undefined)delete R[k];else R[k]=clone(m[k]);}return R;};
  for(const k of ['assessments','attempts','evidence'])out[k]=list(old[k],mine[k],server[k]);
  for(const k of ['progress','donow','ia','settings'])out[k]=map(old[k],mine[k],server[k]);
  if(out.roster&&mine.roster)out.roster.students=list(old.roster.students,mine.roster.students,server.roster.students);
  out.log=[...(server.log||[]),...(mine.log||[]).slice((old.log||[]).length)].slice(-400);
  return out;
 }
 async function keepMine(){
  const r=await Hub.cloud.call('load'),server=canon(r.state);
  const merged=applyMine(base,state,server);
  base=server;state=merged;blocked=false;conflictMsg='';dirty=true;edit++;announce();
  await flush();listeners.forEach(fn=>fn('external'));
 }
 window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
 window.addEventListener('online',()=>{if(dirty&&!blocked)flush().catch(()=>{});});
 Hub.store={get state(){return state},get dirty(){return dirty},get blocked(){return blocked},get conflict(){return conflictMsg},blank,accept,save,flush,refresh,reload,keepMine,applyMine,canon,log,clear(){state=null;base=null;dirty=false;blocked=false;conflictMsg='';clearTimeout(timer)},onExternal:fn=>listeners.push(fn),
 exportBackup:()=>JSON.stringify({app:'badmus-ib-math-hub',exportedAt:new Date().toISOString(),state},null,2),v1Raw:()=>null};
})(window.Hub=window.Hub||{});
