/* Server-backed state. No roster, marks or IA content are cached to localStorage.
   Optimistic entity merging on the server prevents silent cross-device overwrites. */
(function(Hub){
 'use strict';const clone=x=>JSON.parse(JSON.stringify(x));
 let state=null,base=null,timer=null,pending=Promise.resolve(),dirty=false,edit=0,blocked=false;const listeners=[];
 const blank=()=>({schema:2,settings:{asOf:null,halfLifeDays:21,minEvidence:3},roster:{source:'imported',students:[]},assessments:[],attempts:[],evidence:[],progress:{},donow:{},ia:{},log:[],notices:[]});
 function accept(s){state=clone(s);base=clone(s);dirty=false;blocked=false;}
 function status(text,kind){Hub.core.saveStatus(text,kind)}
 async function persist(){
  if(!dirty||!state||!Hub.auth.current())return true;if(blocked)throw Error('Resolve the save conflict before continuing.');
  const next=clone(state),before=clone(base),version=edit;
  status('Saving to cloud…','pending');
  try{const r=await Hub.cloud.call('save',{base:before,state:next});base=next;
   // Keep live form references stable; refresh explicitly to receive other devices' changes.
   dirty=edit!==version;
   status(dirty?'Changes pending…':'Saved to cloud','ok');return true;
  }catch(e){blocked=/^Conflict:/.test(e.message);status('Not saved — '+e.message,'error');Hub.core.toast(e.message,'error');throw e;}
 }
 function flush(){clearTimeout(timer);pending=pending.catch(()=>{}).then(async()=>{while(dirty){await persist();}return true});return pending;}
 function save(immediate){if(Hub.auth?.isPreview())return;dirty=true;edit++;status('Changes pending…','pending');clearTimeout(timer);if(immediate){flush().catch(()=>{});}else timer=setTimeout(()=>flush().catch(()=>{}),800);}
 async function refresh(){await flush();const r=await Hub.cloud.call('load');accept(r.state);listeners.forEach(fn=>fn('external'));}
 function log(what,who){state.log.push({at:new Date().toISOString(),who:who||Hub.auth.who(),what});state.log=state.log.slice(-400);}
 async function reload(){const r=await Hub.cloud.call('load');accept(r.state);listeners.forEach(fn=>fn('external'));}
 window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
 window.addEventListener('online',()=>{if(dirty&&!blocked)flush().catch(()=>{});});
 Hub.store={get state(){return state},get dirty(){return dirty},blank,accept,save,flush,refresh,reload,log,clear(){state=null;base=null;dirty=false;blocked=false;clearTimeout(timer)},onExternal:fn=>listeners.push(fn),
 exportBackup:()=>JSON.stringify({app:'badmus-ib-math-hub',exportedAt:new Date().toISOString(),state},null,2),v1Raw:()=>null};
})(window.Hub=window.Hub||{});
