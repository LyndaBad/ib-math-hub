/* Curriculum map: four teaching groups (A/B day), lesson-level skills with prerequisites, the 2026–27
   pacing calendars (pacing.js), IA checkpoints and Oxford 2019 section references (mapping only). */
(function (Hub) {
  'use strict';
  const GROUPS = {
    'SL-A': { id: 'SL-A', course: 'SL', day: 'A', block: 'Block 1', label: 'AA SL · A day', size: 24 },
    'SL-B': { id: 'SL-B', course: 'SL', day: 'B', block: 'Block 1', label: 'AA SL · B day', size: 22 },
    'HL-A': { id: 'HL-A', course: 'HL', day: 'A', block: 'Block 4', label: 'AA HL · A day', size: 26 },
    'HL-B': { id: 'HL-B', course: 'HL', day: 'B', block: 'Block 4', label: 'AA HL · B day', size: 22 }
  };
  const COURSES = { SL: 'IB Mathematics: Analysis & Approaches SL', HL: 'IB Mathematics: Analysis & Approaches HL' };
  const pacingKey = c => (c === 'SL' ? 'AA SL' : 'AA HL');

  /* Units — numbering follows the Oxford chapter order used in Miss Badmus' Drive folders. */
  const UNITS = {
    SL: [[1, 'Sequences & Series'], [2, 'Introducing Functions'], [3, 'Linear & Quadratic Functions'], [4, 'Rational Functions'], [5, 'Differentiation'], [6, 'Univariate Statistics'], [7, 'Bivariate Statistics'], [8, 'Probability'], [9, 'Exponentials & Logarithms'], [10, 'Integration'], [11, 'Geometry & Trigonometry'], [12, 'Trigonometric Functions'], [13, 'Further Calculus']],
    HL: [[1, 'Sequences, Series & Proof'], [2, 'Functions'], [3, 'Complex Numbers & Algebra'], [4, 'Differentiation'], [5, 'Statistics & Probability'], [6, 'Geometry & Trigonometry'], [7, 'Exponents, Logarithms & Integration'], [8, 'Further Calculus — Modelling Change'], [9, 'Vectors'], [10, 'Further Complex Numbers'], [11, 'Probability Distributions']]
  };
  /* Oxford 2019 section references (title + first page) — curriculum mapping only. */
  const OXFORD = {
    SL: { '1.1': ['Number patterns and sigma notation', 4], '1.2': ['Arithmetic and geometric sequences', 13], '1.3': ['Arithmetic and geometric series', 22], '1.4': ['Applications of arithmetic and geometric patterns', 36], '1.5': ['The binomial theorem', 44], '1.6': ['Proofs', 55], '2.1': ['What is a function?', 65], '2.2': ['Functional notation', 69], '2.3': ['Drawing graphs of functions', 75], '2.4': ['The domain and range of a function', 77], '2.5': ['Composite functions', 85], '2.6': ['Inverse functions', 92], '3.1': ['Gradient of a linear function', 110], '3.2': ['Linear functions', 115], '3.3': ['Transformations of functions', 131], '3.4': ['Graphing quadratic functions', 142], '3.5': ['Solving quadratic equations by factorization and completing the square', 155], '3.6': ['The quadratic formula and the discriminant', 164], '3.7': ['Applications of quadratics', 173], '4.1': ['The reciprocal function', 186], '4.2': ['Transforming the reciprocal function', 196], '4.3': ['Rational functions of the form (ax + b)/(cx + d)', 201], '5.1': ['Limits and convergence', 216], '5.2': ['The derivative function', 222], '5.3': ['Differentiation rules', 234], '5.4': ['Graphical interpretation of first and second derivatives', 240], '5.5': ['Application of differential calculus: optimization and kinematics', 260], '6.3': ['Measures of central tendency', 287], '6.4': ['Measures of dispersion', 296], '7.4': ['Least squares regression', 332] },
    HL: { '1.1': ['Sequences, series and sigma notation', 4], '1.2': ['Arithmetic and geometric sequences and series', 10], '1.3': ['Proof', 33], '1.4': ['Counting principles and the binomial theorem', 51], '2.1': ['Functional relationships', 75], '2.2': ['Special functions and their graphs', 81], '2.3': ['Classification of functions', 102], '2.4': ['Operations with functions', 108], '2.5': ['Function transformations', 117], '3.1': ['Quadratic equations and inequalities', 149], '3.2': ['Complex numbers', 161], '3.3': ['Polynomial equations and inequalities', 175], '3.4': ['The fundamental theorem of algebra', 184], '3.5': ['Solving equations and inequalities', 195], '3.6': ['Solving systems of linear equations', 200], '4.1': ['Limits, continuity and convergence', 220], '4.2': ['The derivative of a function', 236], '4.3': ['Differentiation rules', 249], '4.4': ['Graphical interpretation of the derivatives', 262], '4.5': ['Applications of differential calculus', 278], '4.6': ['Implicit differentiation and related rates', 288], '5.2': ['Descriptive statistics', 317], '5.4': ['Correlation, causation and linear regression', 347] }
  };

  /* Lesson-level skills. match: regex on the calendar activity text that marks the lesson where it is taught.
     taughtBefore: skills covered by the previous teacher before the calendar rows begin. gens: question generators. */
  const S = (id, unit, ox, name, prereq, match, gens, extra = {}) => Object.assign({ id, course: id.slice(0, 2), unit, ox, name, prereq, match, gens }, extra);
  const SKILLS = [
    S('SL-0.1', 1, null, 'Rounding, standard form & percentage error', [], /Number Systems and Rounding/i, ['sl.round']),
    S('SL-1.1', 1, '1.1', 'Sigma notation & number patterns', ['SL-0.1'], /\b1\.1\b/, ['sl.sigma']),
    S('SL-1.2a', 1, '1.2', 'Arithmetic sequences', ['SL-1.1'], /\b1\.2\b/, ['sl.arith']),
    S('SL-1.2b', 1, '1.2', 'Geometric sequences', ['SL-1.1'], /\b1\.2\b/, ['sl.geo']),
    S('SL-1.3a', 1, '1.3', 'Arithmetic series', ['SL-1.2a'], /\b1\.3\b/, ['sl.arseries']),
    S('SL-1.3b', 1, '1.3', 'Geometric series & sum to infinity', ['SL-1.2b'], /\b1\.3\b/, ['sl.geoseries']),
    S('SL-1.4', 1, '1.4', 'Compound interest & depreciation', ['SL-1.2b', 'SL-0.1'], /\b1\.4\b/, ['sl.finance']),
    S('SL-1.5a', 1, '1.5', 'Binomial expansion & coefficients', ['SL-1.1'], /1\.5 The binomial theorem \(Day 1/, ['sl.binom1']),
    S('SL-1.5b', 1, '1.5', 'General term: constant term & working backwards', ['SL-1.5a'], /1\.5 The binomial theorem \(Day 2/, ['sl.binom2']),
    S('SL-1.6', 1, '1.6', 'Simple deductive proof (LHS to RHS)', ['SL-1.5a'], /1\.6 Proofs/, ['sl.proof']),
    S('SL-2.1', 2, '2.1', 'Relations & functions', [], /2\.1 What is a function/, ['sl.function']),
    S('SL-2.2', 2, '2.2', 'Function notation & graphs', ['SL-2.1'], /2\.2 Functional notation/, ['sl.notation']),
    S('SL-2.4', 2, '2.4', 'Domain & range', ['SL-2.2'], /2\.4 The domain/, ['sl.domain']),
    S('SL-2.5', 2, '2.5', 'Composite functions', ['SL-2.2'], /2\.5 Composite/, ['sl.composite']),
    S('SL-2.6', 2, '2.6', 'Inverse functions', ['SL-2.5', 'SL-2.4'], /2\.6 Inverse/, ['sl.inverse']),
    S('SL-3.1', 3, '3.2', 'Gradient & linear functions', ['SL-2.2'], /3\.1 Gradient|3\.2 Linear/, ['sl.lines']),
    S('SL-3.3', 3, '3.3', 'Transformations of functions', ['SL-2.2'], /3\.3 Transformations/, ['sl.transform']),
    S('SL-3.4', 3, '3.4', 'Graphing quadratics', ['SL-3.3'], /3\.4 Graphing/, ['sl.vertex']),
    S('SL-3.5', 3, '3.5', 'Solving quadratics', ['SL-3.4'], /3\.5 Solving/, ['sl.solvequad']),
    S('SL-3.6', 3, '3.6', 'Quadratic formula & discriminant', ['SL-3.5'], /3\.6 The quadratic formula/, ['sl.discriminant']),
    S('SL-3.7', 3, '3.7', 'Applications of quadratics', ['SL-3.6'], /3\.7 Applications/, ['sl.quadapp']),
    S('SL-4.1', 4, '4.3', 'Reciprocal & rational functions', ['SL-2.4', 'SL-3.3'], /\b4\.[123]\b/, ['sl.rational']),
    S('SL-5.2', 5, '5.2', 'Derivatives, tangents & normals', ['SL-3.1'], /\b5\.[12]\b/, ['sl.deriv']),
    S('SL-5.4', 5, '5.4', 'Stationary points & concavity', ['SL-5.2'], /\b5\.[34]\b/, ['sl.stationary']),
    S('SL-5.5', 5, '5.5', 'Optimisation & kinematics', ['SL-5.4'], /\b5\.5\b/, ['sl.optim']),
    S('SL-6.3', 6, '6.3', 'Central tendency & dispersion', [], /\b6\.[1-4]\b/, ['sl.stats']),
    S('SL-7.4', 7, '7.4', 'Correlation & regression', ['SL-3.1'], /\b7\.[1-4]\b/, ['sl.regression']),

    S('HL-1.1', 1, '1.1', 'Sigma notation & series', [], null, ['hl.sigma'], { taughtBefore: '2026-10-09' }),
    S('HL-1.2a', 1, '1.2', 'Arithmetic & geometric sequences', ['HL-1.1'], null, ['hl.arithgeo'], { taughtBefore: '2026-10-09' }),
    S('HL-1.2b', 1, '1.2', 'Convergence & sum to infinity', ['HL-1.2a'], null, ['hl.convergence'], { taughtBefore: '2026-10-09' }),
    S('HL-1.2c', 1, '1.2', 'Financial applications', ['HL-1.2a'], null, ['hl.finance'], { taughtBefore: '2026-10-09' }),
    S('HL-1.3a', 1, '1.3', 'Proof: counterexample, contradiction, direct', [], /Proof by contradiction/, ['hl.proof']),
    S('HL-1.3b', 1, '1.3', 'Proof by induction', ['HL-1.1', 'HL-1.3a'], /induction/i, ['hl.induction']),
    S('HL-1.4a', 1, '1.4', 'Counting principles', [], null, ['hl.counting'], { taughtBefore: '2026-10-09' }),
    S('HL-1.4b', 1, '1.4', 'Binomial theorem incl. fractional & negative powers', ['HL-1.4a'], null, ['hl.binomial'], { taughtBefore: '2026-10-09' }),
    S('HL-2.1', 2, '2.1', 'Functional relationships: domain & range', [], /2\.1 Functional/, ['hl.funcrel']),
    S('HL-2.2a', 2, '2.2', 'Quadratic, rational & radical functions', ['HL-2.1'], /2\.2 Special functions and their graphs \(Day 1/, ['hl.special']),
    S('HL-2.2b', 2, '2.2', 'Partial fractions', ['HL-2.2a'], /2\.2 Special functions \(Day 2/, ['hl.partialfrac']),
    S('HL-2.2c', 2, '2.2', 'Absolute value & piecewise functions', ['HL-2.2a'], /2\.2 Special functions \(Day 2/, ['hl.abspiece']),
    S('HL-2.3', 2, '2.3', 'One-to-one, odd & even functions', ['HL-2.1'], /2\.3 Classification/, ['hl.classify']),
    S('HL-2.4a', 2, '2.4', 'Composite functions', ['HL-2.1'], /2\.4 .*composite/, ['hl.composite']),
    S('HL-2.4b', 2, '2.4', 'Inverse & self-inverse functions', ['HL-2.4a', 'HL-2.3'], /2\.4 .*inverse/, ['hl.inverse']),
    S('HL-2.5a', 2, '2.5', 'Transformations: translations, stretches, reflections', ['HL-2.2a'], /2\.5 Function transformations \(Day 1/, ['hl.transform']),
    S('HL-2.5b', 2, '2.5', 'Modulus & reciprocal graphs', ['HL-2.5a', 'HL-2.2c'], /2\.5 Function transformations \(Day 2/, ['hl.modrecip']),
    S('HL-3.1', 3, '3.1', 'Quadratic equations & inequalities', ['HL-2.2a'], /3\.1 Quadratic/, ['hl.quadineq']),
    S('HL-3.2', 3, '3.2', 'Complex numbers (Cartesian form)', ['HL-3.1'], /3\.2 Complex/, ['hl.complex']),
    S('HL-3.3', 3, '3.3', 'Factor & remainder theorems', ['HL-3.1'], /3\.3 Polynomial/, ['hl.factorrem']),
    S('HL-3.4', 3, '3.4', 'Sum & product of roots', ['HL-3.3', 'HL-3.2'], /3\.4 The fundamental/, ['hl.vieta']),
    S('HL-3.6', 3, '3.6', 'Systems of linear equations', ['HL-2.1'], /3\.6 Systems/, ['hl.systems']),
    S('HL-4.1', 4, '4.1', 'Limits & continuity', ['HL-2.2a'], /4\.1 Limits/, ['hl.limits']),
    S('HL-4.3', 4, '4.3', 'Chain, product & quotient rules', ['HL-4.1'], /4\.[23] /, ['hl.chain']),
    S('HL-4.5', 4, '4.5', 'Optimisation & kinematics', ['HL-4.3'], /4\.[45] /, ['hl.optim']),
    S('HL-4.6', 4, '4.6', 'Implicit differentiation & related rates', ['HL-4.3'], /4\.6 /, ['hl.implicit']),
    S('HL-5.2', 5, '5.2', 'Descriptive statistics', [], /5\.[12] /, ['hl.statsT']),
    S('HL-5.4', 5, '5.4', 'Correlation & regression', ['HL-5.2'], /5\.4 /, ['hl.regression'])
  ];
  const SKILL = Object.fromEntries(SKILLS.map(s => [s.id, s]));
  const skillsFor = course => SKILLS.filter(s => s.course === course);

  /* Calendar rows for a group (A or B day), annotated with the skills each lesson introduces. */
  const cache = {};
  function lessons(groupId) {
    if (cache[groupId]) return cache[groupId];
    const g = GROUPS[groupId], rows = ((window.PACING || {})[pacingKey(g.course)] || []).filter(r => r.day === g.day);
    const out = rows.map(r => {
      const sk = skillsFor(g.course).filter(s => s.match && s.match.test(r.activity)).map(s => s.id);
      const a = r.activity;
      const ia = /IA (Lesson|Checkpoint|work|year)/.test(a);
      const kind = /NO CLASS/i.test(a) ? 'none'
        : /(^|; )(UNIT \d+ TEST|Unit [\d–]+ Test|Semester Exams|End-of-Year Exam)/.test(a) && !/walk-through/i.test(a) ? 'test'
        : sk.length ? 'lesson' : ia ? 'ia' : 'review';
      return { date: r.date, day: r.day, activity: r.activity, skills: sk, kind, ia };
    });
    return (cache[groupId] = out);
  }
  /** First date the skill is taught to this group (or the taughtBefore date for previously taught content). */
  function taughtDate(skillId, groupId) {
    const s = SKILL[skillId]; if (!s) return null;
    if (s.taughtBefore) return s.taughtBefore;
    const row = lessons(groupId).find(l => l.skills.includes(skillId));
    return row ? row.date : null;
  }
  const isTaught = (skillId, groupId, asOf) => { const d = taughtDate(skillId, groupId); return !!d && d < asOf; };
  /** Next lesson on/after asOf (today's lesson counts), skipping no-class rows. */
  function nextLesson(groupId, asOf) { return lessons(groupId).find(l => l.date >= asOf && l.kind !== 'none') || null; }
  /** Next lesson that actually introduces new skills (for Do Now bridging). */
  function nextTeachingLesson(groupId, asOf) { return lessons(groupId).find(l => l.date >= asOf && l.skills.some(id => !isTaught(id, groupId, asOf))) || null; }
  function upcoming(groupId, asOf, n = 8) { return lessons(groupId).filter(l => l.date >= asOf).slice(0, n); }

  /* IA checkpoints (both calendars use the same names); dates differ for A and B days. */
  const IA_STEPS = [
    { id: 'cp1', match: /IA Lesson 1/, title: 'Checkpoint 1 · From an interest to a title', short: 'Topic & working title', focus: 'Choose a topic in your sweet spot and draft a working title.', criteria: ['C'] },
    { id: 'cp2', match: /Checkpoint 2/, title: 'Checkpoint 2 · Final title + introduction plan', short: 'Title + intro plan', focus: 'Final title that passes the checklist; plan Why me? · Aim · Plan · Key terms.', criteria: ['A', 'C'] },
    { id: 'cp3', match: /Checkpoint 3/, title: 'Checkpoint 3 · Research question & outline', short: 'RQ & outline', focus: 'A focused research question and a section-by-section outline.', criteria: ['A', 'E'] },
    { id: 'cp4', match: /Checkpoint 4/, title: 'Checkpoint 4 · Introduction paragraph draft', short: 'Intro draft', focus: 'Your own first draft of the introduction.', criteria: ['A', 'B', 'C'] },
    { id: 'cp5', match: /Checkpoint 5/, title: 'Checkpoint 5 · Introduction peer review', short: 'Peer review', focus: 'Give and receive criterion-referenced feedback.', criteria: ['A', 'B', 'D'] },
    { id: 'cp6', match: /Checkpoint 6/, title: 'Checkpoint 6 · Final introduction paragraph', short: 'Final intro', focus: 'Act on feedback; submit the final introduction.', criteria: ['A', 'B', 'C', 'D'] },
    { id: 'ws', match: /IA work session/, title: 'Work session · Maths plan & data', short: 'Maths plan & data', focus: 'Decide the mathematics and collect or source data.', criteria: ['E', 'B'] },
    { id: 'y1', match: /IA year 1 checkpoint/, title: 'Year 1 checkpoint · Exploration plan', short: 'Exploration plan', focus: 'Submit the full exploration plan for feedback.', criteria: ['A', 'B', 'C', 'D', 'E'] }
  ];
  function iaSchedule(groupId) { const L = lessons(groupId); return IA_STEPS.map(st => { const row = L.find(l => st.match.test(l.activity)); return Object.assign({}, st, { date: row ? row.date : null }); }); }
  const IA_CRITERIA = [
    ['A', 'Presentation', 4, 'Well organised, coherent and concise: a reader can follow it without re-reading.'],
    ['B', 'Mathematical communication', 4, 'Correct notation, symbols and terminology; key terms defined; graphs and tables labelled.'],
    ['C', 'Personal engagement', 3, 'Your own thinking: genuine interest, independent decisions, creativity.'],
    ['D', 'Reflection', 3, 'Critical reflection on results, methods and limitations, all the way through.'],
    ['E', 'Use of mathematics', 6, 'Relevant mathematics at the level of the course, correct and demonstrating understanding.']
  ];
  const COMMAND_TERMS = {
    'Write down': 'Little or no working is needed — the answer can be read off or obtained quickly.',
    'Find': 'Get the answer and show the relevant stages of your working.',
    'Calculate': 'Get a numerical answer, showing the relevant working.',
    'Show that': 'Reach the given result using correct steps; the answer is given, so the working is the point.',
    'Hence': 'Use the previous part to reach the answer.',
    'Solve': 'Find the value(s) using algebraic, numerical and/or graphical methods.',
    'Prove': 'A formal sequence of logical steps leading to the result.',
    'Determine': 'Find the only possible answer.',
    'State': 'Give a specific name, value or short answer without explanation.',
    'Verify': 'Give evidence that confirms the statement is true.',
    'Explain': 'Give a detailed account including reasons or causes.',
    'Write': 'Present the expression in the form requested.',
    'Use': 'Apply the given method or result.'
  };

  Hub.curriculum = { GROUPS, COURSES, UNITS, OXFORD, SKILLS, SKILL, skillsFor, lessons, taughtDate, isTaught, nextLesson, nextTeachingLesson, upcoming, iaSchedule, IA_STEPS, IA_CRITERIA, COMMAND_TERMS };
})(window.Hub = window.Hub || {});
