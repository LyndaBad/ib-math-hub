# Miss Badmus’ IB Math Hub
Inquirers. Thinkers. Reflective Learners.

Live site: https://missbadmusibmath.com/

This version preserves the supplied Claude v2.1 classroom design and adds verified Supabase sign-in, private cloud persistence, roster import and CSV exports. The classroom starts empty. No demonstration accounts or simulated marks are loaded.

## Getting started
The owner is badmuslyn@gmail.com. Choose First-time teacher setup, set your own password, then confirm the message sent to badmuslyn@gmail.com. Use Teacher password reset if you already activated this account. In Data & settings, import a CSV with name,email,group columns (groups: SL-A, SL-B, HL-A, HL-B). Review the import before saving. Reimport matches by email and preserves student work. Deactivation blocks access without deleting work.

Create an activation/reset link for each roster student and give that link privately to that student. Links grant account access: do not post them in a shared Canvas announcement. Students choose their own password. Email delivery is not required.

Create and review assessments before approving and publishing. Student attempts are marked on the server; teacher marking and release remain available. Personalised Do Now plans use recorded topic performance and require teacher publication. IA notebooks, responses, evidence, assessments and settings save to Supabase. Photo/PDF working is in a private storage bucket.

Wait for “Saved to cloud” before closing. Use Refresh to receive work from another device. If a save conflict appears, export your pending backup and reload before editing that item again. The app requires an internet connection and does not cache classroom records for offline use. Your sign-in session is retained in this browser; sign out on shared devices.

Data & settings exports roster, results and evidence CSVs and a full JSON data backup. The JSON contains attachment references; download individual files separately from marking. Add the live URL to Canvas as an external link. There is no Canvas grade sync or school integration.

## What's new in v3.1 (2 Nov 2026)
- **Save conflicts fixed.** The database re-orders the keys inside each saved item, so the second edit of a new item was reported as a "Conflict". The Hub now saves in the database's own key order. If a real conflict ever happens (two tabs editing the same item), a red bar offers *Keep my changes* or *Load the cloud copy*.
- **One tick for every question.** "I have checked all N questions, answers and markschemes" at the top of the editor (and a *tick them all* button in the Approve box). Ticking one by one still works.
- **Brackets.** `\left( … \right)` now stretches both brackets together and a power applies to the whole bracket; plain brackets around a fraction do the same. Column vectors and matrices (`pmatrix`) now render.
- **Back to the editor** works: the student preview has its own address (`#/preview/<id>`).
- **Print any assessment** (Exit Ticket, Quiz, Homework, Unit test, Retest): 🖨 *Print worksheet* / *Answer key* in the editor and the library. Title on one line, then Name · Block · A day / B day · Date. Working boxes sized by marks. Homework prints as written questions (tick to include the Canvas multiple-choice options). Exit Tickets print two per page. Unit tests and retests get the cover page (badge, numbered instructions, Section / Marks / Score table) with Sections A/B (and C for Paper 3). Answer keys show the answer, the M/A/R markscheme, handwritten working and NumWorks screens. *Save as PDF* in the print window keeps a PDF.
- **Delete anything.** Every assignment can be deleted at any stage. A published one is unpublished first; its submissions, marks and mastery evidence go with it (after a clear warning).
- **Automatic closing.** Published work closes 10 days after its due date (it disappears from students' To do and can no longer be submitted). *Close now* closes it any time before that.
- **Lesson notebooks** (Lessons & notebooks): one per calendar lesson, A and B days paired. Slide deck (Google Slides, a PowerPoint/PDF in Google Drive, PowerPoint online embed code or Canva), Do Now link, guided notes with `[[blanks]]` that students self-check, worked examples revealed one line at a time, "Your turn" self-check questions (never graded), the lesson's Exit Ticket, homework and a reflection (confidence, one thing learned, a question). Release per day: now, or "open on lesson day" (7:00). Students' notebooks save to the cloud; the Responses tab shows confidence, notes and questions.
- **NumWorks calculator.** The free official online NumWorks simulator opens in a side panel (sidebar button, and a NumWorks button on every Paper 2 question). Hidden on all-Paper-1 tasks.
- **IB exam-style question bank.** 25 new multi-part families (12 SL, 13 HL incl. a Paper 3 investigation), modelled on the types of exam-style questions in the Oxford SL/HL chapter reviews but original and randomised. Studio option *Question style*: Mixed, IB exam-style only, or skill practice only.

Checks: `node tests/smoke_generators.cjs 40`, `node tests/slash_sweep.cjs`, `node tests/dump_questions.cjs 25 > q.json && python3 tests/verify_answers.py q.json` (SymPy re-derivation, 11,950 answer parts, 0 problems), `npm test`, and the browser suite against a local copy of the server: `node tests/mock/server.mjs 4310 src` then `node tests/mock/e2e_v31.cjs` (40 checks).

Optional server update: redeploy the `hub` Edge Function with the new `engine.js` so that server-side practice includes the exam-style questions and the server also refuses submissions after the 10-day close. Everything else works without redeploying. Lesson notebooks are stored in settings, so a student's data download contains notebook titles before release (the app only shows released ones).

## Source and deployment
- `src/`: frontend source, original question generators, curriculum and pacing data.
- `docs/`: built multi-file preview. The public repository hosts an equivalent bundled `index.html` at its root and a complete source ZIP.
- `supabase/functions/hub/`: authenticated server API and server maths engine.
- `supabase/migrations/`: database tables, RLS and private storage bucket.
- `tests/backend.mjs`: authorization, answer privacy, merge, roster and CSV checks.
- `tools/build-engine.cjs` and `tools/build-live.cjs`: reproducible build.

Requires Node 20+ to build/test. Run `npm run build`, `npm test`, then `npm run serve`. Deploy the `hub` Edge Function with all three source files. It verifies bearer tokens itself, so platform verify_jwt is false. The service-role key is read only from Supabase environment variables; it is never part of the site. Frontend configuration contains only the intended public publishable key.

Supabase project: `innufzhtrttxecgainwo` in LyndaBad’s Org. Auth site URL must be `https://missbadmusibmath.com/`. Owner access is held in `hub_teachers`; student access is checked against active roster emails. Direct database reads/writes by anonymous and authenticated clients are revoked. The Edge Function filters student responses and uses optimistic revision checks to protect concurrent saves.

## Scope and operating limits
This is a small-classroom release using a single versioned classroom document. It is not intended for district-scale usage. It has no paid AI service. Question banks are original generators from the supplied project; no Oxford textbook pages or questions are shipped. Pacing comes from the supplied Claude project and can be reviewed in Course & pacing.

Hosting uses GitHub Pages and the existing Supabase Free organization. Usage limits still apply; a free project may pause when inactive. No paid add-ons were enabled. Export backups regularly; an independent production security review and school approval are outside this implementation.

The vendored Supabase JavaScript client is pinned to 2.95.3 (MIT). Original local font licenses remain with the assets. The supplied branding and project content remain the owner's materials.
