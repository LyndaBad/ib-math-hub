# Source note (updated 4 November 2026)

The live site is the single bundled `index.html` at the root of the GitHub repository. It is the source of truth,
and an exact copy is included here as `index.html`.

`src/js/*.js` were refreshed from that live file: each module is exactly the code between the
`/* ---- js/name.js ---- */` markers in the live page. `src/css/hub-live.css` holds the live page's styles.

Not refreshed: `supabase/` (the deployed Edge Function and database setup) is the copy from 1 November.
Server actions added since then (class-code join, reset password, delete student) are deployed on Supabase but
are not in this archive. `docs/`, `tools/` and `tests/` are also from 1 November.

Edit the root `index.html` (or these modules, then paste them back between the same markers).
