-- Hub data is private. Only the authenticated Edge Function can read/write it.
-- No service-role key is ever shipped in the frontend.
create table if not exists public.hub_teachers (
  email text primary key check (email = lower(email)),
  created_at timestamptz not null default now()
);
create table if not exists public.hub_state (
  id integer primary key check (id = 1),
  revision bigint not null default 0,
  data jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.hub_teachers enable row level security;
alter table public.hub_state enable row level security;
revoke all on public.hub_teachers, public.hub_state from anon, authenticated;
grant all on public.hub_teachers, public.hub_state to service_role;
insert into public.hub_teachers(email) values ('badmuslyn@gmail.com') on conflict do nothing;
insert into public.hub_state(id,data) values (1,'{"schema":2,"settings":{"asOf":null,"halfLifeDays":21,"minEvidence":3},"roster":{"source":"imported","students":[]},"assessments":[],"attempts":[],"evidence":[],"progress":{},"donow":{},"ia":{},"log":[],"notices":[]}') on conflict do nothing;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('hub-work','hub-work',false,10485760,array['image/jpeg','image/png','application/pdf'])
on conflict(id) do update set public=false,file_size_limit=10485760,allowed_mime_types=excluded.allowed_mime_types;
-- Storage is accessed exclusively through authorized, short-lived signed URLs.
-- There are deliberately no anon/authenticated table or storage policies.
