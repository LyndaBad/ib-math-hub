import { createClient } from 'npm:@supabase/supabase-js@2.95.3';
import {createEngine} from './engine.js';
import {identity,studentState,mergeTeacher,mergeStudent,allowedFile,safeQuestion} from './policy.js';
const admin=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
const headers={'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST, OPTIONS','Cache-Control':'no-store'};
const response=(data:unknown,status=200)=>new Response(JSON.stringify(data),{status,headers});
const err=(m:string)=>{throw Error(m)};
async function read(){const {data,error}=await admin.from('hub_state').select('*').eq('id',1).single();if(error)throw error;return data}
async function teacher(email:string){const {data,error}=await admin.from('hub_teachers').select('email').eq('email',email.toLowerCase()).maybeSingle();if(error)throw error;return !!data}
async function transact(fn:(state:any)=>any){for(let i=0;i<6;i++){const row=await read(),state=structuredClone(row.data);const result=await fn(state);const {data,error}=await admin.from('hub_state').update({data:result.state,revision:row.revision+1,updated_at:new Date().toISOString()}).eq('id',1).eq('revision',row.revision).select('revision');if(error)throw error;if(data?.length)return result;}throw Error('Busy: please try again. Your changes were not committed.')}
Deno.serve(async(req)=>{
 if(req.method==='OPTIONS')return new Response('ok',{headers});
 if(req.method!=='POST')return response({error:'POST required'},405);
 try{
 const token=(req.headers.get('Authorization')||'').replace(/^Bearer /i,'');
 const {data:{user},error:authError}=await admin.auth.getUser(token);
 if(authError||!user)return response({error:'Sign in to continue.'},401);
 const text=await req.text();if(text.length>16*1024*1024)return response({error:'Request too large.'},413);
 const body=JSON.parse(text),initial=await read(),sess=identity(initial.data,user,await teacher(user.email||''));
 const filter=(state:any)=>sess.role==='teacher'?state:studentState(state,sess);
 if(body.action==='load')return response({session:sess,state:filter(initial.data)});
 if(body.action==='save'){
 const result=await transact(state=>{identity(state,user,sess.role==='teacher');return {state:sess.role==='teacher'?mergeTeacher(body.base,body.state,state):mergeStudent(body.base,body.state,state,sess.sid)}});
 return response({state:filter(result.state)});
 }
 if(body.action==='practice'){
 if(sess.role!=='student')err('Student sign-in required.');
 const H=createEngine(initial.data,sess),st=H.roster.byId(sess.sid),sk=H.curriculum.SKILL[body.skill];
 if(!sk||sk.course!==st.course)err('Skill unavailable.');
 const gen=sk.gens[crypto.getRandomValues(new Uint32Array(1))[0]%sk.gens.length];
 const q=H.qcore.build(gen,crypto.getRandomValues(new Uint32Array(1))[0]%1000000+1,{});
 q.parts=q.parts.filter((p:any)=>p.answer.kind!=='open');q.marks=q.parts.reduce((n:number,p:any)=>n+p.marks,0);q.preview=!H.curriculum.isTaught(sk.id,st.group,H.mastery.asOf());
 const a={id:'practice-'+crypto.randomUUID(),title:sk.name+' · Practice',type:'Practice',course:st.course,release:'auto',questions:[q]};
 await transact(state=>{state.progress[sess.sid+'|'+a.id]={_serverAssessment:a,createdAt:new Date().toISOString()};return {state}});
 // Independent practice may show hints; server keeps the official key.
 const visible={...a,questions:a.questions.map(q=>({...safeQuestion(q),parts:q.parts.map(p=>({...safeQuestion(q).parts.find(x=>x.id===p.id),hint:p.hint}))}))};
 return response({assessment:visible});
 }
 if(body.action==='submit'){
 if(sess.role!=='student')err('Student sign-in required.');
 const result=await transact(async state=>{
 identity(state,user,false); const d=body.data||{};
 if(!d.token||typeof d.token!=='string')err('Submission token missing.');
 const existing=state.attempts.find((t:any)=>t.sid===sess.sid&&t.token===sess.sid+'|'+d.token);if(existing)return {state,attempt:existing};
const H=createEngine(state,sess);let a=H.assess.byId(body.aid),opts:any={};
 if(body.kind==='donow'){const d=H.donow.forStudent(sess.sid);if(!d)err('No Do Now is open.');if(d.done)return {state,attempt:d.done};a=d.assessment;opts.assessment=a;}
 else if(body.kind==='practice'){a=state.progress[sess.sid+'|'+body.aid]?._serverAssessment;if(!a)err('Practice session expired. Start a new one.');opts.assessment=a;}
 if(!a)err('Assessment not available.');
 if(a.type==='Retest'&&!H.assess.forStudent(sess.sid).some((x:any)=>x.id===a.id))err('Retest not available.');
 // Client supplies only responses and work, never marks, a role, or an answer key.
 const input={token:sess.sid+'|'+d.token,responses:d.responses||{},uploads:[],reflection:String(d.reflection||'').slice(0,20000),proof:d.proof===true,hints:d.hints||{}};
 for(const f of (d.uploads||[]).slice(0,20)){
 if(!allowedFile(state,sess,f.id))err('Invalid upload owner.');
 const split=f.id.lastIndexOf('/');const {data:items,error}=await admin.storage.from('hub-work').list(f.id.slice(0,split),{search:f.id.slice(split+1)});
 if(error||!items?.some(x=>x.name===f.id.slice(split+1)))err('Upload has not completed.');
 (input.uploads as any[]).push({id:f.id,name:String(f.name).slice(0,200),type:f.type,size:f.size});
 }
 const r=H.assess.submit(a.id,sess.sid,input,opts);if(!r.ok)err(r.error);
 if(body.kind==='donow')r.attempt.donowKey=H.roster.byId(sess.sid).group+'|'+H.donow.forStudent(sess.sid).rec.lessonDate;
 return {state,attempt:r.attempt};
 });const safe=filter(result.state);return response({state:safe,attempt:safe.attempts.find((t:any)=>t.id===result.attempt.id)});
 }
 if(body.action==='file-upload'){
 if(!['image/jpeg','image/png','application/pdf'].includes(body.type)||!(body.size>0)||body.size>10485760)err('Choose a photo or PDF under 10 MB.');
 const path=user.id+'/'+crypto.randomUUID();const {data,error}=await admin.storage.from('hub-work').createSignedUploadUrl(path);if(error)throw error;return response({path,...data});
 }
 if(body.action==='file-read'){
 if(!allowedFile(initial.data,sess,body.path))err('File access refused.');
 const {data,error}=await admin.storage.from('hub-work').createSignedUrl(body.path,300);if(error)throw error;return response(data);
 }
 if(body.action==='invite'){
 if(sess.role!=='teacher')err('Teacher only.');
 const st=initial.data.roster.students.find((s:any)=>s.id===body.sid&&s.active!==false);if(!st)err('Student not on the roster.');
 const redirectTo='https://missbadmusibmath.com/';
 let {data,error}=await admin.auth.admin.generateLink({type:'invite',email:st.email,options:{redirectTo}});
 if(error&&/already.*registered|already.*exists/i.test(error.message))({data,error}=await admin.auth.admin.generateLink({type:'recovery',email:st.email,options:{redirectTo}}));
 if(error)throw error;return response({link:data.properties.action_link});
 }
 return response({error:'Unknown action'},400);
 }catch(e){const message=e instanceof Error?e.message:'Request failed';return response({error:message},message.startsWith('Conflict:')?409:400)}
});
