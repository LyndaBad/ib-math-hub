const clone=x=>JSON.parse(JSON.stringify(x));
const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const own=(o,k)=>Object.prototype.hasOwnProperty.call(o||{},k);
const fail=m=>{throw new Error(m)};
export function identity(state,user,teacher){
 if(!user.email_confirmed_at)fail('Verify your email before signing in.');
 const email=(user.email||'').toLowerCase();
 if(teacher)return {email,role:'teacher',name:'Miss Badmus',uid:user.id};
 const s=state.roster.students.find(s=>s.email.toLowerCase()===email&&s.active!==false);
 if(!s)fail('This verified account is not on the active roster. Ask Miss Badmus to add you.');
 return {email,role:'student',sid:s.id,name:s.name,uid:user.id};
}
export function safeQuestion(q,released=false){
 if(released)return clone(q);
 // Allowlist: never include seeds, generator metadata, keys, error rules, markschemes or solutions.
 return {id:q.id,stem:q.stem,skill:q.skill,marks:q.marks,paper:q.paper,preview:q.preview,slot:q.slot,
 parts:q.parts.map(p=>({id:p.id,label:p.label,command:p.command,prompt:p.prompt,marks:p.marks,dep:p.dep,
 answer:{kind:p.answer.kind,choices:p.answer.choices,labels:p.answer.labels,boxes:p.answer.boxes,int:p.answer.int,dp:p.answer.dp,exact:p.answer.exact,
 ...(Array.isArray(p.answer.value)?{value:p.answer.value.map(()=>null)}:{})}}))};
}
export function studentState(state,sess){
 const out=clone(state),sid=sess.sid,st=state.roster.students.find(s=>s.id===sid);
 out.roster={source:'imported',students:[clone(st)]};out.log=[];out.notices=[];
 out.attempts=state.attempts.filter(t=>t.sid===sid).map(t=>{let x=clone(t);if(t.status!=='released'){x.auto={earned:0,max:t.max,parts:{}};x.final=null;x.comment='';}if(x.inline)x.inline.questions=x.inline.questions.map(q=>safeQuestion(q,t.status==='released'));return x});
 const released=new Set(out.attempts.filter(t=>t.status==='released').map(t=>t.aid));
 out.assessments=state.assessments.filter(a=>['published','closed','archived'].includes(a.status)&&a.groups.includes(st.group)).map(a=>{let x=clone(a);x.questions=x.questions.map(q=>safeQuestion(q,released.has(a.id)));delete x.history;delete x.reviewed;return x});
 out.evidence=state.evidence.filter(e=>e.sid===sid);
 out.progress=Object.fromEntries(Object.entries(state.progress).filter(([k])=>k.startsWith(sid+'|')).map(([k,v])=>{const x=clone(v);delete x._serverAssessment;return [k,x]}));
 out.ia=own(state.ia,sid)?{[sid]:clone(state.ia[sid])}:{};out.donow={};
 const d=state.donow[st.group];if(d&&d.status==='published'&&d.plans[sid]){out.donow[st.group]={...clone(d),plans:{[sid]:d.plans[sid].map(it=>({slot:it.slot,skill:it.skill,reason:it.reason,preview:it.preview,challenge:it.challenge,question:it.question?safeQuestion(it.question):null}))}};}
 return out;
}
function mergeField(base,next,current,label){
 if(equal(base,next))return current;
 if(!equal(base,current)&&!equal(next,current))fail('Conflict: '+label+'. Reload before editing this item again.');
 return next===undefined?undefined:clone(next);
}
function mergeMap(base={},next={},current={},label){
 const result=clone(current);for(const k of new Set([...Object.keys(base),...Object.keys(next)])){
 if(['__proto__','constructor','prototype'].includes(k))fail('Invalid key');
 const v=mergeField(base[k],next[k],current[k],label+' '+k);if(v===undefined)delete result[k];else result[k]=v;
 }return result;
}
function mergeList(base,next,current,label){
 const keyed=arr=>Object.fromEntries(arr.map(x=>[x.id,x]));
 for(const list of [base,next,current])if(list.some(x=>!x.id)||new Set(list.map(x=>x.id)).size!==list.length)fail('Invalid '+label+' identifiers');
 return Object.values(mergeMap(keyed(base),keyed(next),keyed(current),label));
}
export function mergeTeacher(base,next,current){
 if(!base||!next||next.schema!==2)fail('Invalid state');const out=clone(current);
 for(const k of ['assessments','attempts','evidence'])out[k]=mergeList(base[k],next[k],current[k],k);
 for(const k of ['progress','donow','ia','settings'])out[k]=mergeMap(base[k],next[k],current[k],k);
 out.roster={source:'imported',students:mergeList(base.roster.students,next.roster.students,current.roster.students,'roster')};
 const emails=new Set();for(const s of out.roster.students){if(!s.name||!/^\S+@\S+\.\S+$/.test(s.email)||!['HL-A','HL-B','SL-A','SL-B'].includes(s.group)||s.course!==s.group.slice(0,2))fail('Invalid roster');let e=s.email.toLowerCase();if(emails.has(e))fail('Duplicate roster email');emails.add(e);}
 out.log=[...current.log,...next.log.slice(base.log.length)].slice(-400);
 out.updatedAt=new Date().toISOString();return out;
}
export function mergeStudent(base,next,current,sid){
 const out=clone(current),prefix=sid+'|';
 const filter=o=>Object.fromEntries(Object.entries(o||{}).filter(([k])=>k.startsWith(prefix)).map(([k,v])=>[k,Object.fromEntries(['responses','uploads','reflection','updatedAt','createdAt'].filter(f=>own(v,f)).map(f=>[f,v[f]]))]));
 const merged=mergeMap(filter(base.progress),filter(next.progress),filter(current.progress),'saved answers');
 for(const k of Object.keys(out.progress))if(k.startsWith(prefix)){const server=out.progress[k]._serverAssessment;if(server)merged[k]={...(merged[k]||{}),_serverAssessment:server};delete out.progress[k];}Object.assign(out.progress,merged);
 const b=base.ia?.[sid]||{},n=next.ia?.[sid]||{},c=current.ia?.[sid]||{};
 if(!equal(b,n)){
 const v=clone(c);
 for(const k of ['fields','titleCheck','self'])v[k]=mergeMap(b[k],n[k],c[k],'IA '+k);
 for(const k of ['sources','versions','log'])v[k]=mergeField(b[k],n[k],c[k],'IA '+k)||[];
 v.status={...(c.status||{})};for(const [k,value] of Object.entries(n.status||{})){
 if(value===b.status?.[k])continue;
 if(!['submitted','in-progress'].includes(value)||c.status?.[k]==='signed-off')fail('Only the teacher can sign off or reopen an IA checkpoint.');
 v.status[k]=mergeField(b.status?.[k],value,c.status?.[k],'IA status');}
 v.updatedAt=new Date().toISOString();out.ia[sid]=v;
 }
 return out;
}
export function allowedFile(state,sess,path){
 if(typeof path!=='string'||path.includes('..'))return false;
 if(sess.role==='teacher')return true;
 return path.startsWith(sess.uid+'/');
}
