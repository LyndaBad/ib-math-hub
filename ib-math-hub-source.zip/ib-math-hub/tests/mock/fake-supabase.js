// Test double for the Supabase browser client (auth + signed-URL storage), used only by tests/mock/server.mjs.
window.supabase = { createClient(url) {
  const KEY = 'mock-session', get = () => { try { return JSON.parse(localStorage.getItem(KEY)); } catch (e) { return null; } };
  return {
    auth: {
      async getSession() { return { data: { session: get() }, error: null }; },
      async signInWithPassword({ email, password }) { if (password !== 'password123!') return { error: { message: 'Invalid login credentials' } }; localStorage.setItem(KEY, JSON.stringify({ access_token: 'tok:' + email.toLowerCase() })); return { error: null }; },
      async signOut() { localStorage.removeItem(KEY); return { error: null }; },
      async updateUser() { return { error: null }; }, async signUp() { return { error: null }; }, async resetPasswordForEmail() { return { error: null }; }
    },
    storage: { from() { return { async uploadToSignedUrl(path, token, blob, o) { const r = await fetch(url + '/storage/' + path, { method: 'PUT', body: blob, headers: { 'content-type': o.contentType } }); return { error: r.ok ? null : { message: 'upload failed' } }; } }; } }
  };
} };
