// Shared helpers for the v3.1 browser tests against the mock live server (tests/mock/server.mjs).
const { chromium } = require('playwright');
const fs = require('fs');
const BASE = process.env.HUB_URL || 'http://localhost:4310';
const OUT = process.env.E2E_OUT || '/tmp/claude-0/e2e';
fs.mkdirSync(OUT, { recursive: true });
const results = [];
function check(name, ok, info = '') { results.push([name, !!ok, info]); console.log((ok ? 'PASS ' : 'FAIL ') + name + (info ? ' — ' + info : '')); return !!ok; }
const iso = d => d.toISOString().slice(0, 10);
const today = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
const addDays = (s, n) => { const d = new Date(s + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return iso(d); };
const STUDENTS = [
  { id: 'sa1', name: 'Amara Okafor', email: 'amara@example.org', group: 'SL-A', course: 'SL', active: true },
  { id: 'sa2', name: 'Theo Lindqvist', email: 'theo@example.org', group: 'SL-A', course: 'SL', active: true },
  { id: 'sb1', name: 'Priya Raman', email: 'priya@example.org', group: 'SL-B', course: 'SL', active: true },
  { id: 'ha1', name: 'Mateo Rossi', email: 'mateo@example.org', group: 'HL-A', course: 'HL', active: true },
  { id: 'hb1', name: 'Zainab Hassan', email: 'zainab@example.org', group: 'HL-B', course: 'HL', active: true }
];
const blank = (extra = {}) => Object.assign({ schema: 2, settings: { asOf: null, halfLifeDays: 21, minEvidence: 3 }, roster: { source: 'imported', students: STUDENTS }, assessments: [], attempts: [], evidence: [], progress: {}, donow: {}, ia: {}, log: [], notices: [] }, extra);
async function reset(state) { await fetch(BASE + '/__reset', { method: 'POST', body: JSON.stringify(state || blank()) }); }
async function server() { return (await fetch(BASE + '/__state')).json(); }
let browser;
async function start() { browser = await chromium.launch(); return browser; }
async function stop() { if (browser) await browser.close(); }
/** New signed-in page. Collects console errors, page errors and API status codes. */
async function open(email, { width = 1300, height = 900 } = {}) {
  const ctx = await browser.newContext({ viewport: { width, height } });
  const page = await ctx.newPage();
  page.errors = []; page.api = [];
  page.on('pageerror', e => page.errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource|numworks|docs\.google|net::ERR/.test(m.text())) page.errors.push('console: ' + m.text()); });
  page.on('response', r => { if (r.url().includes('/functions/')) page.api.push(r.status()); });
  await page.goto(BASE + '/');
  await page.waitForSelector('#login-email');
  await page.fill('#login-email', email); await page.fill('#login-password', 'password123!'); await page.click('#login-button');
  await page.waitForSelector('#main .page-head, #main .hero, #main .empty', { timeout: 15000 });
  return page;
}
async function go(page, hash) { await page.evaluate(h => { if (location.hash === h) Hub.app.render(); else location.hash = h; }, hash); await page.waitForTimeout(250); }
/** Wait until every change is saved to the (mock) cloud. */
async function saved(page, ms = 12000) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    const s = await page.evaluate(() => ({ dirty: Hub.store.dirty, blocked: Hub.store.blocked, text: (document.querySelector('#save-status') || {}).textContent || '' }));
    if (s.blocked) return 'blocked: ' + s.text;
    if (!s.dirty && /Saved to cloud|^$/.test(s.text)) { await page.waitForTimeout(150); const again = await page.evaluate(() => Hub.store.dirty); if (!again) return s.text || 'clean'; }
    await page.waitForTimeout(200);
  }
  return 'timeout: ' + (await page.textContent('#save-status'));
}
async function confirm(page) { await page.waitForSelector('.modal [data-ok]'); await page.click('.modal [data-ok]'); await page.waitForTimeout(300); }
async function noSideScroll(page) { return page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1); }
function summary() { const bad = results.filter(r => !r[1]); console.log(`\n${results.length - bad.length}/${results.length} checks passed`); bad.forEach(r => console.log('  FAILED:', r[0], r[2])); return bad.length; }
module.exports = { BASE, OUT, check, results, reset, server, start, stop, open, go, saved, confirm, noSideScroll, summary, blank, STUDENTS, today, addDays };
