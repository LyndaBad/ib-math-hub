// Reproduces the "Conflict: assessments …" save error: create a draft, then tick a review box.
const { chromium } = require('playwright');
(async () => {
  const roster = { schema: 2, settings: { asOf: '2026-11-03', halfLifeDays: 21, minEvidence: 3 }, roster: { source: 'imported', students: [{ id: 'st1', name: 'Test Student', email: 'stu@example.org', group: 'SL-A', course: 'SL', active: true }] }, assessments: [], attempts: [], evidence: [], progress: {}, donow: {}, ia: {}, log: [], notices: [] };
  await fetch('http://localhost:4310/__reset', { method: 'POST', body: JSON.stringify(roster) });
  const b = await chromium.launch(), p = await (await b.newContext({ viewport: { width: 1300, height: 900 } })).newPage(); const errs = [];
  p.on('pageerror', e => errs.push(e.message)); p.on('console', m => console.log('console', m.type(), m.text().slice(0,200))); p.on('response', r => { if (r.url().includes('/functions/')) r.text().then(t => console.log('api', r.status(), t.slice(0, 160))).catch(()=>{}); });
  await p.goto('http://localhost:4310/'); await p.waitForTimeout(400);
  await p.fill('#login-email', 'badmuslyn@gmail.com'); await p.fill('#login-password', 'password123!'); await p.click('#login-button'); await p.waitForTimeout(800);
  await p.evaluate(() => { location.hash = '#/studio?group=SL-A'; }); await p.waitForTimeout(500);
  await p.selectOption('#b-type', 'Homework'); await p.$$eval('#b-skills input', els => els.forEach(e => (e.checked = e.value === 'SL-1.5b')));
  await p.click('#build button[type=submit]'); await p.waitForTimeout(1800);
  const ids = await p.$$eval('[data-review]', els => els.map(e => e.dataset.review));
  for (const id of ids) { await p.check(`[data-review="${id}"]`); await p.waitForTimeout(1500); }
  await p.waitForTimeout(3000); console.log('save status after reviewing:', await p.textContent('#save-status'));
  await p.fill('#e-title', 'Renamed homework'); await p.waitForTimeout(3000); console.log('after title edit:', await p.textContent('#save-status'));
  const ap = await p.$('#approve'); if (ap && !(await ap.isDisabled())) { await ap.click(); await p.waitForTimeout(3000); console.log('after approve:', await p.textContent('#save-status')); }
  await b.close(); console.log(errs.join('\n'));
})();
