// Builds a throw-away server engine for the mock server from the CURRENT src (same recipe as tools/build-engine.cjs),
// skipping any q_*_exam*.js file that does not parse yet. Usage: node tests/mock/build-test-engine.cjs <out.js>
const fs = require('fs'), path = require('path'), { execFileSync } = require('child_process');
const root = path.join(__dirname, '..', '..'), out = process.argv[2];
const recipe = fs.readFileSync(path.join(root, 'tools/build-engine.cjs'), 'utf8');
const files = JSON.parse(recipe.match(/const files=(\[[^\]]+\])/)[1].replace(/'/g, '"')).filter(f => {
  if (!/exam/.test(f)) return true; if (!process.env.WITH_EXAM) return false; const p = path.join(root, 'src/js', f + '.js'); if (!fs.existsSync(p)) return false;
  try { execFileSync(process.execPath, ['--check', p], { stdio: 'ignore' }); return true; } catch (e) { return false; } });
let code = `export function createEngine(state, session) {\nconst document={querySelector:()=>null,querySelectorAll:()=>[]};\nconst window={Hub:{},HUB_CONFIG:{}};\n`;
code += fs.readFileSync(path.join(root, 'src/js/pacing.js'), 'utf8') + '\n';
for (const file of files) {
  if (file === 'roster') code += `window.Hub.store={state,save(){},log(what){state.log.push({at:new Date().toISOString(),who:session.name,what});state.log=state.log.slice(-400)}};window.Hub.auth={who:()=>session.name,isPreview:()=>false,isTeacher:()=>session.role==='teacher'};\n`;
  code += fs.readFileSync(path.join(root, 'src/js/' + file + '.js'), 'utf8') + '\n';
}
fs.writeFileSync(out, code + 'return window.Hub;\n}\n'); console.log('test engine:', files.join(','));
