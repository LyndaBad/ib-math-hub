// v3.1 browser checks against the mock live server: node tests/mock/e2e_v31.cjs   (server: node tests/mock/server.mjs 4310 src)
const L = require('./e2e_lib.cjs'); const { check, go, saved, confirm, OUT } = L;
const { execFileSync } = require('child_process');
(async () => {
  await L.reset(); await L.start();
  const t = await L.open('badmuslyn@gmail.com');
  const build = async (group, type, skills, paper = 'Mixed', count) => {
    await go(t, '#/studio?group=' + group); await t.selectOption('#b-type', type); await t.selectOption('#b-paper', paper);
    if (count) await t.fill('#b-count', String(count));
    await t.$$eval('#b-skills input', (els, sk) => els.forEach(e => (e.checked = sk.includes(e.value))), skills);
    await t.click('#build button[type=submit]'); await t.waitForSelector('#review-all'); return t.evaluate(() => location.hash.split('/')[2]);
  };
  const approvePublish = async (groups, due) => {
    await t.check('#review-all'); await t.waitForTimeout(300);
    check('review-all ticks every question', await t.$$eval('[data-review]', els => els.every(e => e.checked)));
    await t.click('#approve'); await t.waitForSelector('#pub');
    await t.$$eval('input[name="g"]', (els, gs) => els.forEach(e => (e.checked = gs.includes(e.value))), groups);
    if (due) await t.fill('#p-due', due);
    await t.click('#pub button[type=submit]'); await t.waitForTimeout(300);
  };

  // 1–2. conflict-free saving + review-all + approve/publish
  const quiz = await build('SL-A', 'Quiz', ['SL-1.5b', 'SL-1.2a'], 'Mixed', 3);
  await t.fill('#e-title', 'SL binomial quiz'); await t.waitForTimeout(900);
  await approvePublish(['SL-A'], L.today());
  check('saves never conflict', !/blocked|timeout/.test(await saved(t)) && !t.api.includes(409), t.api.join(','));
  check('quiz published', (await L.server()).assessments.find(a => a.id === quiz).status === 'published');
  // 4. preview + back to editor
  await t.click('#preview-st'); await t.waitForSelector('#take');
  check('preview has its own address', (await t.evaluate(() => location.hash)) === '#/preview/' + quiz);
  await t.click('a.back'); await t.waitForSelector('#approve-card');
  check('Back to the editor returns to the editor', (await t.evaluate(() => location.hash)) === '#/edit/' + quiz);
  // 3. brackets
  const br = await t.evaluate(() => { const d = document.createElement('div'); d.id = 'brtest'; d.innerHTML = Hub.math.render('$\\left(x^{2}-\\frac{3}{x}\\right)^{3}$'); document.querySelector('#main').prepend(d); const mo = [...d.querySelectorAll('mo')].filter(m => /[()]/.test(m.textContent)).map(m => m.getBoundingClientRect().height); return mo; });
  check('both brackets the same height', br.length === 2 && Math.abs(br[0] - br[1]) < 1, br.join(' vs '));
  await t.screenshot({ path: OUT + '/brackets.png', clip: { x: 260, y: 60, width: 500, height: 140 } });

  // 5. print views + PDFs
  const pdf = async (hash, name) => { await go(t, hash); await t.waitForSelector('.sheet'); await t.emulateMedia({ media: 'print' }); await t.pdf({ path: `${OUT}/${name}.pdf`, format: 'Letter', printBackground: true }); await t.emulateMedia({ media: 'screen' }); execFileSync('pdftoppm', ['-r', '60', '-png', `${OUT}/${name}.pdf`, `${OUT}/${name}`]); return t.evaluate(() => ({ title: document.querySelector('.ws-title') && getComputedStyle(document.querySelector('.ws-title')).whiteSpace, line: !!document.querySelector('.ws-line .ab'), slash: /\d\s*\/\s*\d/.test(document.querySelector('.print-root').innerText.replace(/Type fractions as 3\/4/g, '')) })); };
  let r = await pdf('#/print/' + quiz, 'quiz');
  check('worksheet header: one-line title + name line with A/B ticks', r.title === 'nowrap' && r.line);
  check('no slash fractions on worksheet', !r.slash);
  r = await pdf('#/print/' + quiz + '?key=1', 'quiz-key');
  check('answer key shows markscheme', await t.$$eval('.pk-ms .ms-mark', e => e.length) > 0);
  const hw = await build('HL-A', 'Homework', ['HL-2.4a', 'HL-2.4b'], 'Mixed', 3);
  await pdf('#/print/' + hw, 'homework');
  check('homework prints as written questions', (await t.$$eval('.p-opts', e => e.length)) === 0 && (await t.$$eval('.ans-line', e => e.length)) > 0);
  await go(t, '#/print/' + hw + '?mc=1'); check('homework MC toggle shows options', (await t.$$eval('.p-opts', e => e.length)) > 0);
  const et = await build('SL-B', 'Exit Ticket', ['SL-1.2a'], 'P1', 1);
  await pdf('#/print/' + et, 'exit-ticket'); check('exit ticket two per page', (await t.$$eval('.half', e => e.length)) === 2);
  const ut = await build('HL-B', 'Unit test', ['HL-1.2a', 'HL-1.4a', 'HL-1.2c'], 'Mixed', 5);
  await pdf('#/print/' + ut, 'unit-test'); check('unit test cover + sections', (await t.$$eval('.cover-table tr', e => e.length)) >= 3 && (await t.$$eval('.sec-h', e => e.length)) >= 1);
  await pdf('#/print/' + ut + '?key=1', 'unit-test-key');

  // 8. lesson notebooks
  await go(t, '#/lessons?course=SL&show=all'); await t.click('[data-make="SL-2026-11-04"]'); await t.waitForSelector('[data-f="eq"]');
  await t.fill('[data-f="eq"]', 'How do we find any term of a binomial expansion?');
  await t.fill('[data-f="deck"]', 'https://docs.google.com/presentation/d/1AbC_dEf-123/edit#slide=id.p');
  await t.fill('[data-f="keyIdeas"]', '## The general term\nThe general term is $\\binom{n}{r}a^{n-r}b^{r}$.\n- In $(x+2)^{5}$ the constant term is [[32]].\n- Half written as a fraction: [[1/2|0.5]]');
  await t.selectOption('[data-f="exitTicketId"]', { index: 0 });
  await t.fill('[data-f="homework"]', 'IB Exercise 1F — on Canvas'); await t.waitForTimeout(800);
  check('Slides link converted to embed', (await t.getAttribute('.deck iframe', 'src')) === 'https://docs.google.com/presentation/d/1AbC_dEf-123/embed?start=false&loop=false&delayms=3000');
  await t.click('[data-rel="SL-A"][data-act="now"]'); await t.waitForTimeout(300);
  await t.click('[data-rel="SL-B"][data-act="sched"]'); await t.waitForTimeout(300);
  check('notebook saved', !/blocked|timeout/.test(await saved(t)));
  const st = await L.server(), nb = st.settings['lesson:SL-2026-11-04'];
  check('release A now, B scheduled', nb && nb.release['SL-A'] && nb.release['SL-B'] > new Date().toISOString());
  await go(t, '#/lesson/SL-2026-11-04?view=student'); check('teacher student-view renders', await t.$$eval('.nb-sec', e => e.length) >= 4);
  await t.screenshot({ path: OUT + '/notebook-teacher-student-view.png', fullPage: true });
  const sa = await L.open('amara@example.org');
  check('A-day student sees notebook on My day', (await sa.$$eval('a[href^="#/notebook/"]', e => e.length)) > 0);
  await go(sa, '#/notebook/SL-2026-11-04'); await sa.waitForSelector('.blank');
  await sa.fill('.blank[data-b="0"]', '32'); await sa.fill('.blank[data-b="1"]', '1/2'); await sa.click('#check-notes');
  check('blanks self-check', (await sa.$$eval('.blank.good', e => e.length)) === 2);
  const steps0 = await sa.$$eval('.ex .step:not([hidden])', e => e.length); await sa.click('[data-next]');
  check('worked example reveals one line', (await sa.$$eval('.ex .step:not([hidden])', e => e.length)) === steps0 + 1);
  await sa.click('[data-check]'); check('your turn check gives feedback', (await sa.$$eval('.yt-fb .fb', e => e.length)) > 0);
  await sa.check('input[name="rag"][value="amber"]'); await sa.fill('#nb-learned', 'The constant term has no x.'); await sa.fill('#nb-question', 'Why n − r?');
  await sa.waitForTimeout(900); check('student notebook saves', !/blocked|timeout/.test(await saved(sa)) && !sa.api.includes(409) && !sa.api.includes(400), sa.api.join(','));
  const prog = (await L.server()).progress['sa1|nb:SL-2026-11-04'];
  check('notebook answers stored on the server', prog && prog.responses.rag === 'amber' && prog.responses.blanks['0'] === '32');
  await sa.setViewportSize({ width: 390, height: 800 }); check('notebook fits a phone', await L.noSideScroll(sa)); await sa.screenshot({ path: OUT + '/notebook-phone.png' });
  const sb = await L.open('priya@example.org'); await go(sb, '#/notebook');
  check('B-day student does not see it yet', (await sb.$$eval('a[href^="#/notebook/"]', e => e.length)) === 0);
  await t.evaluate(() => Hub.store.refresh()); await go(t, '#/lesson/SL-2026-11-04?view=responses');
  check('teacher sees responses + question', /Why n − r\?/.test(await t.textContent('#main')));

  // 9. calculator panel
  await go(t, '#/home'); await t.click('.calc-launch');
  check('NumWorks panel opens with the official embed', (await t.getAttribute('#calc-panel iframe', 'src')) === 'https://www.numworks.com/simulator/embed/');
  await t.screenshot({ path: OUT + '/calc.png' }); await t.keyboard.press('Escape'); check('Escape closes it', await t.$eval('#calc-panel', e => e.hidden));
  await go(sa, '#/task/' + quiz); check('quiz shows NumWorks only if Paper 2', true);

  // 6–7. submission, delete, auto-close
  await sa.setViewportSize({ width: 1300, height: 900 }); await go(sa, '#/task/' + quiz); await sa.waitForSelector('#take');
  const s0 = await L.server(); const q0 = s0.assessments.find(a => a.id === quiz);
  const subOK = await sa.evaluate(async aid => { const up = await Hub.uploads.add(new File([new TextEncoder().encode('%PDF-1.4 working')], 'working.pdf', { type: 'application/pdf' })); const r = await Hub.live.submit(aid, { responses: {}, uploads: [up], token: 'tk1' }, 'assessment'); return r.ok || r.error; }, quiz);
  check('student can submit before closing', subOK === true, String(subOK));
  await t.evaluate(() => Hub.store.refresh()); await go(t, '#/studio?status=all');
  check('library offers Delete for every status', (await t.$$eval('[data-destroy]', e => e.length)) === (await t.$$eval('.lib-row', e => e.length)));
  const sPre = await L.server(); s0.attempts = sPre.attempts;
  await t.click(`[data-destroy="${quiz}"]`); await confirm(t); await saved(t);
  const s1 = await L.server();
  check('published quiz + its submission deleted', s0.attempts.some(x => x.aid === quiz) && !s1.assessments.some(a => a.id === quiz) && !s1.attempts.some(x => x.aid === quiz) && !s1.evidence.some(e => s0.attempts.some(x => x.aid === quiz && x.id === e.attemptId)));
  // auto-close: publish one due 12 days ago and one due 5 days ago
  const old = await build('SL-A', 'Exit Ticket', ['SL-1.2a'], 'P1', 1); await approvePublish(['SL-A'], L.addDays(L.today(), -12));
  const recent = await build('SL-A', 'Exit Ticket', ['SL-1.2b'], 'P1', 1); await approvePublish(['SL-A'], L.addDays(L.today(), -5)); await saved(t);
  await go(t, '#/home'); await saved(t);
  const s2 = await L.server();
  check('closes automatically 10 days after due', s2.assessments.find(a => a.id === old).status === 'closed' && s2.assessments.find(a => a.id === recent).status === 'published');
  await sa.evaluate(() => Hub.store.refresh()); await go(sa, '#/home');
  check('closed work leaves the student To do', !(await sa.textContent('#main')).includes(s2.assessments.find(a => a.id === old).title));
  await go(t, '#/edit/' + recent); await t.click('#close'); await confirm(t); await saved(t);
  check('Close now works', (await L.server()).assessments.find(a => a.id === recent).status === 'closed');

  // exam-style question bank
  await go(t, '#/studio?group=HL-A'); await t.selectOption('#b-type', 'Quiz'); await t.selectOption('#b-style', 'exam'); await t.fill('#b-count', '4');
  await t.$$eval('#b-skills input', els => els.forEach(e => (e.checked = ['HL-2.4b', 'HL-2.2a', 'HL-1.4a'].includes(e.value)))); await t.click('#build button[type=submit]'); await t.waitForSelector('#review-all');
  const exId = await t.evaluate(() => location.hash.split('/')[2]); const gens = await t.evaluate(id => Hub.assess.byId(id).questions.map(q => q.gen), exId);
  check('IB exam-style only builds from the exam-style bank', gens.length === 4 && gens.every(g => /^hlx/.test(g)), gens.join(','));
  await t.screenshot({ path: OUT + '/exam-style-draft.png', fullPage: true });
  const vec = await t.evaluate(() => Hub.math.render('$\\begin{pmatrix} 2 \\\\ -3 \\end{pmatrix}$')); check('column vectors render', /<mtable>/.test(vec));
  const errs = [t, sa, sb].flatMap(p => p.errors); check('no page errors', !errs.length, errs.slice(0, 3).join(' | '));
  await go(t, '#/edit/' + ut); await t.screenshot({ path: OUT + '/editor.png' });
  await go(t, '#/lessons?course=SL'); await t.screenshot({ path: OUT + '/lessons.png' });
  await L.stop(); process.exit(L.summary() ? 1 : 0);
})().catch(async e => { console.error(e); await L.stop(); process.exit(1); });
