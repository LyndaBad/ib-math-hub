// Local stand-in for the live Supabase backend: the REAL policy.js and engine.js, an in-memory "hub_state" row
// stored the way Postgres jsonb stores it (object keys re-ordered by length, then bytes), and signed-URL storage.
// Usage: node tests/mock/server.mjs [port] [srcDir]   → http://localhost:<port>/
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
const { createEngine } = await import(process.env.HUB_ENGINE || '../../supabase/functions/hub/engine.js');
import { identity, studentState, mergeTeacher, mergeStudent, allowedFile, safeQuestion } from '../../supabase/functions/hub/policy.js';
const PORT = Number(process.argv[2] || 4310), ROOT = path.resolve(process.argv[3] || 'src'), HERE = path.dirname(new URL(import.meta.url).pathname);
const TEACHERS = new Set(['badmuslyn@gmail.com']);
const jsonbOrder = v => Array.isArray(v) ? v.map(jsonbOrder) : v && typeof v === 'object' ? Object.fromEntries(Object.keys(v).sort((a, b) => Buffer.byteLength(a) - Buffer.byteLength(b) || Buffer.compare(Buffer.from(a), Buffer.from(b))).map(k => [k, jsonbOrder(v[k])])) : v;
let row = { revision: 0, text: '' };
const seedPath = process.env.HUB_SEED;
const blank = { schema: 2, settings: { asOf: process.env.HUB_ASOF || null, halfLifeDays: 21, minEvidence: 3 }, roster: { source: 'imported', students: [] }, assessments: [], attempts: [], evidence: [], progress: {}, donow: {}, ia: {}, log: [], notices: [] };
const write = s => { row = { revision: row.revision + 1, text: JSON.stringify(process.env.HUB_NO_JSONB ? s : jsonbOrder(s)) }; };
write(seedPath ? JSON.parse(fs.readFileSync(seedPath, 'utf8')) : blank);
const read = () => ({ revision: row.revision, data: JSON.parse(row.text) });
const files = new Map();
const fail = m => { throw Error(m); };
async function transact(fn) { for (let i = 0; i < 6; i++) { const r = read(), state = structuredClone(r.data); const result = await fn(state); if (row.revision === r.revision) { write(result.state); return result; } } fail('Busy'); }
async function api(body, email, uid) {
  const user = { email, email_confirmed_at: 'now', id: uid };
  const initial = read(), sess = identity(initial.data, user, TEACHERS.has(email));
  const filter = st => sess.role === 'teacher' ? st : studentState(st, sess);
  if (body.action === 'load') return { session: sess, state: filter(initial.data) };
  if (body.action === 'save') { const result = await transact(state => { identity(state, user, sess.role === 'teacher'); return { state: sess.role === 'teacher' ? mergeTeacher(body.base, body.state, state) : mergeStudent(body.base, body.state, state, sess.sid) }; }); return { state: filter(result.state) }; }
  if (body.action === 'practice') {
    if (sess.role !== 'student') fail('Student sign-in required.');
    const H = createEngine(initial.data, sess), st = H.roster.byId(sess.sid), sk = H.curriculum.SKILL[body.skill]; if (!sk || sk.course !== st.course) fail('Skill unavailable.');
    const q = H.qcore.build(sk.gens[0], crypto.randomInt(1, 1e6), {}); q.parts = q.parts.filter(p => p.answer.kind !== 'open'); q.marks = q.parts.reduce((n, p) => n + p.marks, 0);
    const a = { id: 'practice-' + crypto.randomUUID(), title: sk.name + ' · Practice', type: 'Practice', course: st.course, release: 'auto', questions: [q] };
    await transact(state => { state.progress[sess.sid + '|' + a.id] = { _serverAssessment: a, createdAt: new Date().toISOString() }; return { state }; });
    return { assessment: { ...a, questions: a.questions.map(q => ({ ...safeQuestion(q), parts: q.parts.map(p => ({ ...safeQuestion(q).parts.find(x => x.id === p.id), hint: p.hint })) })) } };
  }
  if (body.action === 'submit') {
    if (sess.role !== 'student') fail('Student sign-in required.');
    const result = await transact(async state => {
      identity(state, user, false); const d = body.data || {}; if (!d.token) fail('Submission token missing.');
      const existing = state.attempts.find(t => t.sid === sess.sid && t.token === sess.sid + '|' + d.token); if (existing) return { state, attempt: existing };
      const H = createEngine(state, sess); let a = H.assess.byId(body.aid), opts = {};
      if (body.kind === 'donow') { const dn = H.donow.forStudent(sess.sid); if (!dn) fail('No Do Now is open.'); if (dn.done) return { state, attempt: dn.done }; a = dn.assessment; opts.assessment = a; }
      else if (body.kind === 'practice') { a = state.progress[sess.sid + '|' + body.aid]?._serverAssessment; if (!a) fail('Practice session expired.'); opts.assessment = a; }
      if (!a) fail('Assessment not available.');
      const input = { token: sess.sid + '|' + d.token, responses: d.responses || {}, uploads: [], reflection: String(d.reflection || ''), proof: d.proof === true, hints: d.hints || {} };
      for (const f of (d.uploads || []).slice(0, 20)) { if (!allowedFile(state, sess, f.id) || !files.has(f.id)) fail('Upload has not completed.'); input.uploads.push({ id: f.id, name: f.name, type: f.type, size: f.size }); }
      const r = H.assess.submit(a.id, sess.sid, input, opts); if (!r.ok) fail(r.error);
      if (body.kind === 'donow') r.attempt.donowKey = H.roster.byId(sess.sid).group + '|' + H.donow.forStudent(sess.sid).rec.lessonDate;
      return { state, attempt: r.attempt };
    });
    const safe = filter(result.state); return { state: safe, attempt: safe.attempts.find(t => t.id === result.attempt.id) };
  }
  if (body.action === 'file-upload') { const p = uid + '/' + crypto.randomUUID(); return { path: p, token: 't', signedUrl: '/storage/' + p }; }
  if (body.action === 'file-read') { if (!allowedFile(initial.data, sess, body.path)) fail('File access refused.'); return { signedUrl: 'http://localhost:' + PORT + '/storage/' + body.path }; }
  if (body.action === 'invite') { if (sess.role !== 'teacher') fail('Teacher only.'); return { link: 'http://localhost:' + PORT + '/#type=invite&mock=' + body.sid }; }
  return { error: 'Unknown action' };
}
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.woff2': 'font/woff2', '.json': 'application/json' };
http.createServer(async (req, res) => {
  const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, PUT, GET, OPTIONS' };
  if (req.method === 'OPTIONS') { res.writeHead(200, cors); return res.end(); }
  const url = new URL(req.url, 'http://x');
  if (url.pathname === '/__state') { res.writeHead(200, { 'content-type': 'application/json', ...cors }); return res.end(row.text); }
  if (url.pathname === '/__reset' && req.method === 'POST') { let b = ''; for await (const c of req) b += c; write(b ? JSON.parse(b) : blank); res.writeHead(200, cors); return res.end('ok'); }
  if (url.pathname.startsWith('/storage/')) {
    const key = decodeURIComponent(url.pathname.slice(9));
    if (req.method === 'PUT') { const chunks = []; for await (const c of req) chunks.push(c); files.set(key, { type: req.headers['content-type'], data: Buffer.concat(chunks) }); res.writeHead(200, cors); return res.end('{}'); }
    const f = files.get(key); if (!f) { res.writeHead(404); return res.end(); } res.writeHead(200, { 'content-type': f.type }); return res.end(f.data);
  }
  if (url.pathname === '/functions/v1/hub') {
    let b = ''; for await (const c of req) b += c;
    const tok = (req.headers.authorization || '').replace(/^Bearer tok:/, ''); const email = tok.toLowerCase();
    try { if (!email.includes('@')) { res.writeHead(401, cors); return res.end(JSON.stringify({ error: 'Sign in to continue.' })); }
      const out = await api(JSON.parse(b), email, 'uid-' + crypto.createHash('md5').update(email).digest('hex').slice(0, 8)); res.writeHead(200, { 'content-type': 'application/json', ...cors }); res.end(JSON.stringify(out)); }
    catch (e) { res.writeHead(e.message.startsWith('Conflict:') ? 409 : 400, { 'content-type': 'application/json', ...cors }); res.end(JSON.stringify({ error: e.message })); }
    return;
  }
  let p = url.pathname === '/' ? '/index.html' : url.pathname;
  if (p === '/vendor/supabase.js') p = null;
  const file = p === null ? path.join(HERE, 'fake-supabase.js') : path.join(ROOT, p);
  if (p === '/config.js') { res.writeHead(200, { 'content-type': 'text/javascript' }); return res.end(`window.HUB_CONFIG={mode:'live',supabaseUrl:'http://localhost:${PORT}',supabaseKey:'test',aiAnalysis:{enabled:false}};`); }
  fs.readFile(file, (e, d) => { if (e) { res.writeHead(404); return res.end('not found'); } res.writeHead(200, { 'content-type': TYPES[path.extname(file)] || 'application/octet-stream' }); res.end(d); });
}).listen(PORT, () => console.log('mock hub on http://localhost:' + PORT + ' serving ' + ROOT));
