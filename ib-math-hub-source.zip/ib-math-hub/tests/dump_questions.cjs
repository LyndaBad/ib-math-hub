// Dumps generated questions (all generators × seeds × standard/challenge) as JSON for SymPy verification.
const path = require('path'), fs = require('fs');
global.window = {};
const src = path.join(__dirname, '..', 'src', 'js');
['math.js', 'qcore.js', ...require('fs').readdirSync(path.join(__dirname, '..', 'src', 'js')).filter(f => /^q_.*\.js$/.test(f)).sort((a, b) => (/exam/.test(a) - /exam/.test(b)) || (a.startsWith('q_sl') ? -1 : 1) - (b.startsWith('q_sl') ? -1 : 1) || a.localeCompare(b))].forEach(f => { if (fs.existsSync(path.join(src, f))) require(path.join(src, f)); });
const H = window.Hub, seeds = Number(process.argv[2] || 25), out = [];
const ONLY = process.argv[3] ? new RegExp(process.argv[3]) : null;
for (const id in H.qcore.registry) if (!ONLY || ONLY.test(id)) for (let s = 1; s <= seeds; s++) for (const ch of [false, true]) {
  const q = H.qcore.build(id, s, { challenge: ch });
  q.parts.forEach(p => out.push({ gen: id, seed: s, ch, part: p.label, kind: p.answer.kind, value: p.answer.value, exact: !!p.answer.exact, sf: p.answer.sf, dp: p.answer.dp, int: !!p.answer.int, key: p.answer.kind === 'mc' ? p.answer.keys[p.answer.correct] : null, verify: p.verify, errors: (p.errors || []).map(e => e.value) }));
}
process.stdout.write(JSON.stringify(out));
