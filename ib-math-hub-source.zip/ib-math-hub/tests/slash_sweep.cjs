// Sweeps every generator's rendered teacher view (question, key, markscheme, worked solution, hints, feedback)
// for slash fractions. Allowed: the typing tip "3/4", URLs, and words like "above/below".
const H = require('./env.cjs'); require('../src/js/ui.js');
let bad = 0, n = 0;
const ONLY = process.argv[2] ? new RegExp(process.argv[2]) : null;
for (const id in H.qcore.registry) if (!ONLY || ONLY.test(id)) for (let s = 1; s <= 12; s++) {
  const q = H.qcore.build(id, s, {}); n++; const stemOnly = H.math.render(q.stem);
  const html = H.ui.question(q, 0, { mode: 'teacher' }) + q.parts.map(p => H.math.render(p.hint) + p.errors.map(e => H.math.render(e.fb || '')).join('')).join('');
  if (/(<mi>[a-zA-Z]<\/mi>){8,}/.test(html)) { bad++; console.log('TEXT SWALLOWED INTO MATHS', id, s); }
  const text = html.replace(/<mo>\/<\/mo>/g, ' SLASHMO ').replace(/<[^>]+>/g, ' ').replace(/Type fractions as 3\/4/g, '');
  const hits = text.match(/SLASHMO|[0-9a-zA-Z)\]]\s*\/\s*[0-9a-zA-Z(]/g);
  if (hits && hits.some(h => !/above\s*\/\s*below|and\s*\/\s*or/.test(h))) { const ctx = text.slice(Math.max(0, text.search(/SLASHMO|[0-9a-zA-Z)\]]\s*\/\s*[0-9a-zA-Z(]/) - 60)).slice(0, 140); if (!/above\/below/.test(ctx)) { bad++; if (bad < 12) console.log('SLASH', id, s, '…' + ctx.replace(/\s+/g, ' ')); } }
}
console.log(`Slash-fraction sweep: ${n} questions, ${bad} with a slash fraction.`); process.exit(bad ? 1 : 0);
