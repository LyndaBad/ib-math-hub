// Builds every generator for many seeds (standard + challenge) and checks answers/text are well-formed.
const path = require('path'); global.window = {};
['math.js', 'qcore.js', ...require('fs').readdirSync(path.join(__dirname, '..', 'src', 'js')).filter(f => /^q_.*\.js$/.test(f)).sort((a, b) => (/exam/.test(a) - /exam/.test(b)) || (a.startsWith('q_sl') ? -1 : 1) - (b.startsWith('q_sl') ? -1 : 1) || a.localeCompare(b))].forEach(f => require(path.join(__dirname, '..', 'src', 'js', f)));
const ONLY = process.argv[3] ? new RegExp(process.argv[3]) : null;
const H = window.Hub; let n = 0; const seeds = Number(process.argv[2] || 60);
const badText = /NaN|Infinity|\$undefined|undefined\$|\{undefined|undefined\}|\(undefined|\[object/;
for (const id in H.qcore.registry) if (!ONLY || ONLY.test(id)) for (let s = 1; s <= seeds; s++) for (const ch of [false, true]) {
  try {
    const q = H.qcore.build(id, s, { challenge: ch }); n++;
    q.parts.forEach(p => { const a = p.answer;
      if (a.kind === 'num' && !Number.isFinite(a.value)) throw Error('bad num ' + a.value);
      if (['tuple', 'list'].includes(a.kind) && !a.value.every(Number.isFinite)) throw Error('bad list ' + a.value);
      if (a.kind === 'mc' && !(a.correct >= 0)) throw Error('mc has no correct option');
      if (!p.hint || !p.ms.length || !p.working.length) throw Error('part missing hint/markscheme/working');
      if (!(p.marks > 0)) throw Error('part has no marks'); });
    [q.stem, ...q.parts.flatMap(p => [p.prompt, p.answer.display || '', ...p.working, ...p.ms.map(m => m[1]), ...(p.answer.choices || [])])].forEach(t => { H.math.render(t); if (badText.test(t)) throw Error('text: ' + t.slice(0, 160)); });
  } catch (e) { console.log('FAIL', id, 'seed', s, 'challenge', ch, e.message); process.exit(1); }
}
console.log(`Smoke test passed: ${n} questions from ${Object.keys(H.qcore.registry).length} generators.`);
