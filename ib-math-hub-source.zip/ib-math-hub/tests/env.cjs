// Minimal browser-like environment for running the Hub's logic in Node (no DOM rendering).
const path = require('path');
function mkStorage() { const m = new Map(); return { getItem: k => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: k => m.delete(k), clear: () => m.clear(), get length() { return m.size; } }; }
global.window = global; global.localStorage = mkStorage(); global.sessionStorage = mkStorage();
global.document = { querySelector: () => null, querySelectorAll: () => [], addEventListener() {}, createElement: () => ({ style: {} }) };
global.addEventListener = () => {};
const Q = require('fs').readdirSync(path.join(__dirname, '..', 'src', 'js')).filter(f => /^q_.*\.js$/.test(f)).sort((a, b) => (/exam/.test(a) - /exam/.test(b)) || (a.startsWith('q_sl') ? -1 : 1) - (b.startsWith('q_sl') ? -1 : 1) || a.localeCompare(b)).map(f => 'js/' + f);
const files = ['config.js', 'js/pacing.js', 'js/core.js', 'js/math.js', 'js/qcore.js', ...Q, 'js/curriculum.js', 'js/store.js', 'js/roster.js', 'js/auth.js', 'js/uploads.js', 'js/mastery.js', 'js/assess.js', 'js/donow.js', 'js/seed.js'];
files.forEach(f => { const p = path.join(__dirname, '..', 'src', f); if (require('fs').existsSync(p)) require(p); });
module.exports = global.Hub;
