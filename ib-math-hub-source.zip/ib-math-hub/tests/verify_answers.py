"""Re-derives every generated answer with SymPy, independently of the JavaScript arithmetic.
Usage: node tests/dump_questions.cjs 25 > /tmp/q.json && python3 tests/verify_answers.py /tmp/q.json"""
import json, sys, math
from decimal import Decimal, ROUND_HALF_UP
from sympy import *
from sympy.calculus.util import minimum, maximum
x, y, r, n, k, t, z = symbols('x y r n k t z')
xr = symbols('xr', real=True)
from sympy import is_strictly_increasing, is_increasing, is_monotonic

def sf(v, s=3):
    v = float(v)
    if v == 0: return 0.0
    e = math.floor(math.log10(abs(v)))
    q = Decimal(1).scaleb(e - s + 1)
    return float(Decimal(repr(v)).quantize(q, rounding=ROUND_HALF_UP))
def median(lst):
    s = sorted(lst); m = len(s)
    return Rational(s[m//2 - 1] + s[m//2], 2) if m % 2 == 0 else s[m//2]
def parity(expr):
    e = sympify(expr)
    if simplify(e.subs(x, -x) - e) == 0: return 'even'
    if simplify(e.subs(x, -x) + e) == 0: return 'odd'
    return 'neither'
NS = {k_: v_ for k_, v_ in globals().items() if not k_.startswith('_')}

def close(a, b, rec):
    a = float(N(a)); b = float(b)
    if rec.get('dp') is not None: return abs(a - b) <= 0.5 * 10 ** (-rec['dp']) + 1e-9
    if rec.get('sf') and not rec.get('exact'): return abs(a - b) <= 0.5 * 10 ** (math.floor(math.log10(abs(a))) - 2) + 1e-9 if a != 0 else abs(b) < 1e-9
    return abs(a - b) <= 1e-7 * max(1, abs(a))

def main(fn):
    data = json.load(open(fn)); bad = 0; counts = {}
    for rec in data:
        g = rec['gen']; counts[g] = counts.get(g, 0) + 1
        v = rec['verify']
        if not v: bad += 1; print('NO VERIFY', g, rec['seed'], rec['part']); continue
        try:
            res = eval(v, dict(NS))
        except Exception as e:
            bad += 1; print('ERROR', g, rec['seed'], rec['ch'], rec['part'], v[:120], e); continue
        kind = rec['kind']; ok = True
        if res is None: ok = False
        elif kind == 'num': ok = close(res, rec['value'], rec)
        elif kind == 'tuple':
            res = list(res); ok = len(res) == len(rec['value']) and all(close(a, b, rec) for a, b in zip(res, rec['value']))
        elif kind == 'list':
            res = sorted(float(N(a)) for a in res); exp = sorted(rec['value'])
            ok = len(res) == len(exp) and all(close(a, b, rec) for a, b in zip(res, exp))
        elif kind == 'mc': ok = res == rec['key']
        elif kind == 'open': ok = bool(res) is True
        if ok and kind in ('num',) and rec['errors']:
            for ev in rec['errors']:
                if ev is not None and not isinstance(ev, list) and close(res, ev, dict(rec, sf=None, dp=None, exact=True)) and abs(float(ev) - float(rec['value'])) < 1e-9:
                    print('WARN misconception value equals answer', g, rec['seed'], rec['part'])
        if not ok:
            bad += 1; print('MISMATCH', g, 'seed', rec['seed'], 'ch', rec['ch'], 'part', rec['part'], 'js=', rec.get('value'), rec.get('key'), 'sympy=', res)
    print(f"Checked {len(data)} answer parts from {len(counts)} generators; problems: {bad}")
    sys.exit(1 if bad else 0)
main(sys.argv[1])
