/* Maths keys — clickable maths buttons for students, so nobody has to type code.
   A bar appears at the bottom of the screen while a maths-friendly box has the cursor:
   - Answer boxes (.ans-in): fraction, √, powers, π, e, ln, log, brackets — inserted in the form the answer checker reads;
     the box already shows the typeset maths underneath.
   - Note editors (textareas turned into rich editors by richify): symbols go straight in, and the Fraction / Root /
     Power / Subscript keys open a small builder that drops a typeset maths chip into the note (stored as $tex$).
   - Small boxes marked data-mathpad="symbols" (blanks in guided notes, builder boxes): symbols only. */
(function (Hub) {
  'use strict';
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const SYMS = ['π', 'θ', '²', '³', '√', '≤', '≥', '≠', '±', '×', '÷', '∞', 'Σ', 'Δ', '→', '°'];
  // [key, label, aria, before, after, caret-back-from-end-when-wrapping]
  const ANSWER = [['frac', 'a/b', 'Fraction', '(', ')/()', 1], ['sqrt', '√', 'Square root', '√(', ')'], ['sq', 'x²', 'Squared', '²', ''], ['pow', 'xⁿ', 'Power', '^(', ')'],
    ['pi', 'π', 'Pi', 'π', ''], ['e', 'e', 'e', 'e', ''], ['ln', 'ln', 'Natural log', 'ln(', ')'], ['log', 'log', 'Log base 10', 'log(', ')'], ['par', '( )', 'Brackets', '(', ')'], ['neg', '−', 'Minus', '-', '']];
  const BUILD = {
    frac: { label: 'Fraction', title: 'Fraction', fields: ['Top', 'Bottom'], tex: (a, b) => `\\frac{${a}}{${b}}` },
    sqrt: { label: '√ Root', title: 'Square root', fields: ['Inside the root'], tex: a => `\\sqrt{${a}}` },
    pow: { label: 'xⁿ Power', title: 'Power', fields: ['Base', 'Power'], tex: (a, b) => `{${a}}^{${b}}` },
    sub: { label: 'xₙ Subscript', title: 'Subscript', fields: ['Letter', 'Subscript'], tex: (a, b) => `{${a}}_{${b}}` }
  };
  const U2T = { 'π': '\\pi ', 'θ': '\\theta ', '×': '\\times ', '÷': '\\div ', '≤': '\\le ', '≥': '\\ge ', '≠': '\\ne ', '±': '\\pm ', '∞': '\\infty ', 'Σ': '\\Sigma ', 'Δ': '\\Delta ', '→': '\\to ', '²': '^{2}', '³': '^{3}', '−': '-' };

  /** Plain text typed in a builder box → TeX (numbers and fractions typed as 3/4 come out stacked). */
  function fieldTex(s) {
    s = String(s || '').trim(); if (!s) return '';
    const r = Hub.math.parse(s); if (!r.error) return r.tex;
    return s.replace(/[\\{}$%&#]/g, '')
      .replace(/(?:sqrt|√)\s*\(([^()]*)\)/g, (m, a) => `\\sqrt{${a}}`).replace(/√\s*([\w.]+)/g, (m, a) => `\\sqrt{${a}}`)
      .replace(/([\w.]+)\s*\/\s*([\w.]+)/g, (m, a, b) => `\\frac{${a}}{${b}}`)
      .replace(/\*/g, '×').replace(/./gu, ch => U2T[ch] ?? ch);
  }
  const chipHTML = tex => `<span class="mchip" contenteditable="false" data-tex="${esc(tex)}" title="Maths · Backspace removes it">${Hub.math.texToMathML(tex, false)}</span>`;

  /* ---------- rich note editor (keeps the original textarea as the saved value) ---------- */
  function toHTML(text) {
    const s = String(text || '').replace(/\\\$/g, '\u0001'); let out = '', i = 0;
    const txt = t => esc(t).replace(/\u0001/g, '$').replace(/\n/g, '<br>');
    while (i < s.length) {
      if (s[i] === '$') { const j = s.indexOf('$', i + 1); if (j < 0) { out += txt(s.slice(i)); break; } const tex = s.slice(i + 1, j).replace(/\u0001/g, '\\$'); if (tex.trim()) out += chipHTML(tex); i = j + 1; continue; }
      let j = i; while (j < s.length && s[j] !== '$') j++; out += txt(s.slice(i, j)); i = j;
    }
    return out;
  }
  function serialize(node) {
    let s = '';
    node.childNodes.forEach(n => {
      if (n.nodeType === 3) s += n.nodeValue.replace(/ /g, ' ').replace(/​/g, '').replace(/\$/g, '\\$');
      else if (n.nodeName === 'BR') s += '\n';
      else if (n.classList && n.classList.contains('mchip')) s += '$' + n.dataset.tex + '$';
      else if (/^(DIV|P)$/.test(n.nodeName)) { if (s && !s.endsWith('\n')) s += '\n'; s += serialize(n); }
      else if (n.nodeType === 1) s += serialize(n);
    });
    return s;
  }
  let uid = 0;
  function richify(ta) {
    if (!ta || ta.dataset.rich) return null; ta.dataset.rich = '1';
    const ed = document.createElement('div');
    ed.className = 'mnote'; ed.contentEditable = 'true'; ed.spellcheck = true;
    ed.setAttribute('role', 'textbox'); ed.setAttribute('aria-multiline', 'true'); ed.dataset.placeholder = ta.placeholder || 'Type here…';
    const lab = ta.closest('.mfld') && ta.closest('.mfld').querySelector('.mfld-lab'); if (lab) { lab.id = lab.id || 'mfl' + (++uid); ed.setAttribute('aria-labelledby', lab.id); }
    ed.innerHTML = toHTML(ta.value); ed.classList.toggle('empty', !ta.value.trim());
    ta.hidden = true; ta.after(ed);
    ed.addEventListener('input', () => { ta.value = serialize(ed).replace(/\s+$/, ''); ed.classList.toggle('empty', !ed.textContent.trim() && !ed.querySelector('.mchip')); ta.dispatchEvent(new Event('input', { bubbles: true })); });
    ed.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); document.execCommand('insertLineBreak'); } });
    ed.addEventListener('paste', e => { e.preventDefault(); const t = (e.clipboardData || window.clipboardData).getData('text/plain'); document.execCommand('insertText', false, t); });
    return ed;
  }
  const richifyAll = root => { if (root) root.querySelectorAll('textarea[data-rich-ok]').forEach(richify); };

  /* ---------- the bar ---------- */
  let bar, builder, target = null, mode = null, bState = null;
  function ensure() {
    if (bar) return;
    bar = document.createElement('div'); bar.id = 'mathpad'; bar.className = 'mathpad no-print'; bar.hidden = true;
    bar.setAttribute('role', 'toolbar'); bar.setAttribute('aria-label', 'Maths keys');
    builder = document.createElement('div'); builder.id = 'mp-builder'; builder.className = 'mp-builder no-print'; builder.hidden = true;
    builder.setAttribute('role', 'dialog'); builder.setAttribute('aria-label', 'Add maths');
    document.body.append(builder, bar);
    bar.addEventListener('mousedown', e => { if (e.target.closest('.mp-key')) e.preventDefault(); }); // keep the cursor where it is
    bar.addEventListener('click', e => { const k = e.target.closest('.mp-key'); if (k) press(k.dataset.k, k.dataset.v); });
    builder.addEventListener('mousedown', e => { if (e.target.closest('[data-bins], [data-bcancel]')) e.preventDefault(); });
  }
  const modeOf = el => !el || !el.matches ? null
    : el.matches('.ans-in:not([disabled]):not([readonly])') ? 'answer'
    : el.matches('.mnote[contenteditable="true"]') ? 'text'
    : el.matches('[data-mathpad="symbols"]:not([disabled])') ? 'symbols' : null;
  function keysFor(m) {
    const show = { '²': 'x²', '³': 'x³' }, name = { '²': 'squared', '³': 'cubed' };
    const sym = SYMS.map(s => `<button type="button" class="mp-key" data-k="sym" data-v="${s}" aria-label="${name[s] || s}">${show[s] || s}</button>`).join('');
    if (m === 'answer') return ANSWER.map(([k, l, a]) => `<button type="button" class="mp-key${l.length > 2 ? ' wide' : ''}" data-k="${k}" aria-label="${a}" title="${a}">${k === 'frac' ? Hub.math.texToMathML('\\frac{a}{b}', false) : esc(l)}</button>`).join('');
    if (m === 'text') return Object.entries(BUILD).map(([k, b]) => `<button type="button" class="mp-key wide build" data-k="b-${k}" title="${b.title}">${k === 'frac' ? Hub.math.texToMathML('\\frac{a}{b}', false) + ' Fraction' : esc(b.label)}</button>`).join('') + '<span class="mp-sep"></span>' + sym;
    return sym;
  }
  function show(m, el) {
    ensure(); target = el;
    if (mode !== m) { bar.innerHTML = `<span class="mp-lab">Maths keys</span><div class="mp-keys">${keysFor(m)}</div>`; mode = m; }
    bar.hidden = false; document.body.classList.add('mp-on');
  }
  function hide() { if (!bar) return; bar.hidden = true; builder.hidden = true; bState = null; document.body.classList.remove('mp-on'); target = null; }
  document.addEventListener('focusin', e => {
    const el = e.target, m = modeOf(el);
    if (m) return show(m, el);
    if (bar && (bar.contains(el) || builder.contains(el))) return;
    hide();
  });
  document.addEventListener('focusout', () => setTimeout(() => {
    const a = document.activeElement;
    if (!bar || bar.hidden) return;
    if (a && (modeOf(a) || bar.contains(a) || builder.contains(a))) return;
    hide();
  }, 150));
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && builder && !builder.hidden) { closeBuilder(true); } });

  /* ---------- inserting ---------- */
  function intoInput(el, before, after, back) {
    const s = el.selectionStart ?? el.value.length, e = el.selectionEnd ?? s, sel = el.value.slice(s, e);
    const txt = before + sel + after;
    el.setRangeText(txt, s, e, 'end');
    const caret = sel || !after ? s + txt.length - (sel ? (back || 0) : 0) : s + before.length;
    el.focus(); el.setSelectionRange(caret, caret);
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }
  function caretIn(ed) {
    const sel = window.getSelection();
    if (sel.rangeCount && ed.contains(sel.anchorNode)) return sel.getRangeAt(0);
    const r = document.createRange(); r.selectNodeContents(ed); r.collapse(false); sel.removeAllRanges(); sel.addRange(r); return r;
  }
  function intoEditor(ed, text) {
    ed.focus(); caretIn(ed);
    if (!document.execCommand('insertText', false, text)) { const r = caretIn(ed); r.deleteContents(); const t = document.createTextNode(text); r.insertNode(t); r.setStartAfter(t); r.collapse(true); ed.dispatchEvent(new Event('input', { bubbles: true })); }
  }
  function press(k, v) {
    const el = target; if (!el || !document.body.contains(el)) return;
    if (k === 'sym') { if (mode === 'text') intoEditor(el, v); else intoInput(el, v, '', 0); return; }
    if (k.startsWith('b-')) return openBuilder(k.slice(2), el);
    const key = ANSWER.find(x => x[0] === k); if (key) intoInput(el, key[3], key[4], key[5]);
  }

  /* ---------- builder for fractions, roots, powers and subscripts in notes ---------- */
  function openBuilder(kind, ed) {
    const B = BUILD[kind]; if (!B) return;
    const sel = window.getSelection();
    bState = { kind, ed, range: sel.rangeCount && ed.contains(sel.anchorNode) ? sel.getRangeAt(0).cloneRange() : null };
    builder.innerHTML = `<div class="row-between"><b class="mp-b-title">${esc(B.title)}</b><span class="tiny muted">Fill in the boxes, then Add.</span></div>
      <div class="mp-b-row">${B.fields.map((f, i) => `<label>${esc(f)}<input data-mathpad="symbols" data-bf="${i}" autocomplete="off" spellcheck="false"></label>`).join('')}</div>
      <div class="mp-b-pv" aria-live="polite"></div>
      <div class="actions"><button type="button" class="btn small primary" data-bins>Add to my note</button><button type="button" class="btn small ghost" data-bcancel>Cancel</button></div>`;
    builder.hidden = false;
    const ins = [...builder.querySelectorAll('[data-bf]')], pv = builder.querySelector('.mp-b-pv');
    const texNow = () => B.tex(...ins.map(i => fieldTex(i.value)));
    const upd = () => { pv.innerHTML = ins.some(i => i.value.trim()) ? Hub.math.texToMathML(texNow(), true) : '<span class="tiny muted">Your maths shows here.</span>'; };
    ins.forEach((i, n) => { i.addEventListener('input', upd); i.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); if (n < ins.length - 1) ins[n + 1].focus(); else add(); } }); });
    const add = () => {
      if (ins.some(i => !i.value.trim())) { const empty = ins.find(i => !i.value.trim()); empty.focus(); if (Hub.core && Hub.core.toast) Hub.core.toast('Fill in every box first.'); return; }
      insertChip(texNow());
    };
    builder.querySelector('[data-bins]').onclick = add;
    builder.querySelector('[data-bcancel]').onclick = () => closeBuilder(true);
    upd(); ins[0].focus();
  }
  function closeBuilder(back) {
    const st = bState; builder.hidden = true; bState = null;
    if (back && st && document.body.contains(st.ed)) { st.ed.focus(); if (st.range) { const s = window.getSelection(); s.removeAllRanges(); s.addRange(st.range); } }
  }
  function insertChip(tex) {
    const st = bState; if (!st || !document.body.contains(st.ed)) return closeBuilder(false);
    const ed = st.ed; ed.focus();
    const sel = window.getSelection(); sel.removeAllRanges();
    let r = st.range; if (!r || !ed.contains(r.startContainer)) { r = document.createRange(); r.selectNodeContents(ed); r.collapse(false); }
    sel.addRange(r); r.deleteContents();
    const tmp = document.createElement('div'); tmp.innerHTML = chipHTML(tex); const chip = tmp.firstChild, sp = document.createTextNode(' ');
    r.insertNode(sp); r.insertNode(chip);
    const after = document.createRange(); after.setStartAfter(sp); after.collapse(true); sel.removeAllRanges(); sel.addRange(after);
    builder.hidden = true; bState = null;
    ed.dispatchEvent(new Event('input', { bubbles: true }));
  }

  Hub.mathpad = { richify, richifyAll, serialize, toHTML, fieldTex, hide };
})(window.Hub = window.Hub || {});
