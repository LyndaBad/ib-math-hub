/* CSV import merges by email, or by name + class when there is no email (students join later with the class code); existing work is preserved. */
(function(Hub){
 'use strict';const S=()=>Hub.store.state;
 const all=()=>S().roster.students.filter(s=>s.active!==false),byId=id=>S().roster.students.find(s=>s.id===id),byEmail=e=>e?all().find(s=>(s.email||'').toLowerCase()===String(e).toLowerCase()):null,inGroup=(g,withTest)=>all().filter(s=>s.group===g&&(withTest||!s.test)),inCourse=(c,withTest)=>all().filter(s=>s.course===c&&(withTest||!s.test));
 const GROUPS=['HL-A','HL-B','SL-A','SL-B'],toGroup=x=>{const v=String(x||'').toUpperCase().replace(/[\s_]+/g,'-').replace(/^(SL|HL)-?(A|B)(-?DAY)?$/,'$1-$2');return GROUPS.includes(v)?v:'';};
 /** Roster text → rows. Only names are needed: "First Last" or "Last, First", one student per line, or a CSV/TSV with
     first name / last name (or name) columns. Email and class columns are optional; without a class column the chosen class is used. */
 function parseImport(text,defGroup){
 const records=[],errors=[];let row=[],cell='',quoted=false;text=String(text||'').replace(/^﻿/,'');const first=text.split(/\r?\n/).find(l=>l.trim())||'',sep=first.includes('\t')?'\t':',';
 for(let i=0;i<=text.length;i++){const c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++;}else quoted=!quoted;}
 else if((c===sep||c==='\n'||c===undefined)&&!quoted){row.push(cell.trim());cell='';if(c!==sep){if(row.some(Boolean))records.push(row);row=[];}}else if(c!=='\r')cell+=c||'';}
 if(quoted)errors.push('Unclosed quotation mark.');
 const HEAD=/^(e-?mail( address)?|(student )?name|full name|student|group|class|block|first( name)?|given name|preferred( first)?( name)?|last( name)?|surname|family name)$/i;
 let cols=null;if(records[0]&&records[0].filter(x=>HEAD.test(x.trim())).length>=1&&records[0].every(x=>!x.trim()||HEAD.test(x.trim())||!/@|\d/.test(x))&&records[0].some(x=>/^(first|last|surname|name|full name|student name|e-?mail)/i.test(x.trim())))cols=records.shift().map(x=>x.toLowerCase().trim());
 const col=re=>cols?cols.findIndex(c=>re.test(c)):-1;
 const fi=col(/^(first( name)?|given name|preferred( first)?( name)?)$/),li=col(/^(last( name)?|surname|family name)$/),ni=col(/^((student )?name|full name|student)$/),ei=col(/^e-?mail/),gi=col(/^(group|class|block)$/);
 const rows=[],seen=new Set(),seenName=new Set(),dg=toGroup(defGroup);
 records.forEach((r,i)=>{
  let name='',email='',group='',parts=null;
  if(cols){if(fi>=0||li>=0)parts={first:(r[fi]||'').trim(),last:(r[li]||'').trim()};name=parts?[parts.first,parts.last].filter(Boolean).join(' '):(r[ni]||'').trim();email=ei>=0?(r[ei]||'').trim():'';group=gi>=0?toGroup(r[gi]):'';}
  else{const g=r.findIndex(x=>toGroup(x)),e=r.findIndex(x=>/@/.test(x));group=g>=0?toGroup(r[g]):'';email=e>=0?r[e].trim():'';const rest=r.filter((x,k)=>k!==g&&k!==e&&x.trim()).map(x=>x.trim());
   // two name parts in a comma list are "Last, First" (the school roster style); a single field is the whole name
   name=rest.length===2&&sep===','?rest[0]+', '+rest[1]:rest.join(' ');}
  email=email.toLowerCase();group=group||dg;
  const where='Line '+(i+1+(cols?1:0))+': ';
  if(!name){errors.push(where+'no name.');return;}
  if(email&&!/^\S+@\S+\.\S+$/.test(email)){errors.push(where+'that email does not look right ('+email+'). Leave it empty if you like.');return;}
  if(!group){errors.push(where+'choose the class above (or add a class column: SL-A, SL-B, HL-A, HL-B).');return;}
  if(email&&seen.has(email)){errors.push('Duplicate email: '+email);return;}if(email)seen.add(email);
  const nk=group+'|'+nameKey(name);if(seenName.has(nk)){errors.push(where+name+' is in the list twice.');return;}seenName.add(nk);
  rows.push(Object.assign({name,email,group,course:group.slice(0,2)},parts&&parts.first&&parts.last?parts:{}));
 });
 return {rows,errors};
 }
 /** Same person? Same class and the same name ignoring order ("Okafor, Amara J" = "Amara J Okafor"), case and accents. */
 function nameKey(n){let s=String(n||'').trim();const i=s.indexOf(',');if(i>0)s=s.slice(i+1)+' '+s.slice(0,i);return s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/['’`.]/g,'').replace(/[^a-z\s-]/g,' ').split(/[\s-]+/).filter(x=>x.length>1).join(' ');}
 const findExisting=r=>{const st=S();return (r.email&&st.roster.students.find(s=>(s.email||'').toLowerCase()===r.email))||st.roster.students.find(s=>s.group===r.group&&nameKey(s.name)===nameKey(r.name))||null;};
 function applyImport(rows){const st=S();for(const r of rows){const existing=findExisting(r);if(existing){const keep=existing.email;Object.assign(existing,r,{active:true});if(!r.email&&keep)existing.email=keep;}else st.roster.students.push({...r,id:crypto.randomUUID(),active:true});}st.roster.source='imported';Hub.store.log('Merged '+rows.length+' roster rows; existing work preserved');Hub.store.save(true);}
 const joined=s=>!!(s&&s.email);
 Hub.roster={all,byId,byEmail,inGroup,inCourse,parseImport,applyImport,findExisting,nameKey,joined};
})(window.Hub=window.Hub||{});
