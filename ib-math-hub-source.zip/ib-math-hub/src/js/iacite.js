/* IA Studio · References: a citation builder for APA (7th), MLA (9th) and Harvard (Cite Them Right) — Miss Badmus picks the style.
   Looks up DOIs (Crossref) and ISBNs (Open Library) in the browser and web pages through the Hub's server. Whatever a
   lookup cannot find stays empty: the Hub never invents an author, a date or a title. The student fills it in from the
   source or ticks “not given on the source”, and confirms looked-up details before they count as complete.
   Data: ia[sid].cites = { list: [reference…], tutorial: { done, at, score } } — not tied to a stage. */
(function (Hub) {
  'use strict';
  const { esc, $, $$, fmtDate, fmtDateTime, toast, debounce } = Hub.core;
  const U = Hub.ui, S = () => Hub.store.state;
  const STYLES = { APA: 'APA 7th edition', MLA: 'MLA 9th edition', Harvard: 'Harvard (Cite Them Right)' };
  const style = () => ((S().settings || {}).iaconfig || {}).citeStyle || 'APA';
  const styleName = () => STYLES[style()];
  const MON = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const MLAMON = ['Jan.', 'Feb.', 'Mar.', 'Apr.', 'May', 'June', 'July', 'Aug.', 'Sept.', 'Oct.', 'Nov.', 'Dec.'];
  /* ---------- the kinds of source ---------- */
  const F = { authors: 'Author(s) — people, or an organisation', year: 'Year published', month: 'Month', day: 'Day', title: 'Title', container: 'Published in', publisher: 'Publisher', edition: 'Edition (number)', volume: 'Volume', issue: 'Issue', pages: 'Pages (e.g. 45–60)', doi: 'DOI', isbn: 'ISBN', url: 'Web address (URL)', accessed: 'Date you accessed it', version: 'Version', prompt: 'The prompt you gave the AI tool', used: 'Date the AI tool generated the text' };
  const TYPES = {
    book: { label: 'Book', req: ['authors', 'year', 'title', 'publisher'], opt: ['edition', 'isbn', 'doi', 'url'] },
    journal: { label: 'Journal article', req: ['authors', 'year', 'title', 'container', 'volume'], opt: ['issue', 'pages', 'doi', 'url'], c: 'Journal name' },
    web: { label: 'Web page', req: ['title', 'container', 'url', 'accessed', 'authors', 'year'], opt: ['month', 'day'], c: 'Website name' },
    news: { label: 'News or magazine article', req: ['authors', 'year', 'title', 'container'], opt: ['month', 'day', 'url', 'accessed'], c: 'Newspaper or magazine' },
    report: { label: 'Report or document from an organisation', req: ['authors', 'year', 'title'], opt: ['publisher', 'url', 'accessed'] },
    data: { label: 'Data set', req: ['authors', 'year', 'title', 'url', 'accessed'], opt: ['publisher', 'version'] },
    software: { label: 'Software or app (Desmos, GeoGebra, a spreadsheet…)', req: ['authors', 'title', 'url'], opt: ['year', 'version', 'accessed'] },
    video: { label: 'Video', req: ['authors', 'year', 'title', 'container', 'url'], opt: ['month', 'day', 'accessed'], c: 'Platform (e.g. YouTube)' },
    ai: { label: 'AI tool (only if Miss Badmus allows it)', req: ['authors', 'title', 'version', 'prompt', 'used', 'url'], opt: ['year'], hint: 'Author = the company that makes it; Title = the tool’s name.' }
  };
  /* ---------- formatting ---------- */
  const people = r => (r.authors || []).filter(a => a && (a.family || a.org));
  const initials = g => String(g || '').trim().split(/\s+/).filter(Boolean).map(w => w.split('-').map(p => p[0].toUpperCase() + '.').join('-')).join(' ');
  const ord = e => { const n = parseInt(e, 10); if (!n) return e; const s = n % 100 > 10 && n % 100 < 14 ? 'th' : ['th', 'st', 'nd', 'rd'][n % 10] || 'th'; return n + s; };
  const pages = p => String(p || '').replace(/\s*[-–—]\s*/g, '–');
  const noHttp = u => String(u || '').replace(/^https?:\/\//, '');
  const doiUrl = d => d ? 'https://doi.org/' + String(d).replace(/^https?:\/\/(dx\.)?doi\.org\//, '') : '';
  const dmy = (iso, mla) => { if (!iso) return ''; const [y, m, d] = String(iso).slice(0, 10).split('-').map(Number); return `${d} ${(mla ? MLAMON : MON)[m - 1]} ${y}`; };
  const mdy = iso => { if (!iso) return ''; const [y, m, d] = String(iso).slice(0, 10).split('-').map(Number); return `${MON[m - 1]} ${d}, ${y}`; };
  const end = t => /[.?!]$/.test(t) ? t : t + '.';
  const nameAPA = a => a.org ? a.org : `${a.family}${a.given ? ', ' + initials(a.given) : ''}`;
  const nameH = a => a.org ? a.org : `${a.family}${a.given ? ', ' + initials(a.given).replace(/ /g, '') : ''}`;
  function authorsAPA(L) { const n = L.map(nameAPA); if (n.length === 1) return n[0]; if (n.length === 2) return `${n[0]}, & ${n[1]}`; if (n.length <= 20) return n.slice(0, -1).join(', ') + ', & ' + n[n.length - 1]; return n.slice(0, 19).join(', ') + ', … ' + n[n.length - 1]; }
  function authorsMLA(L) { const f = a => a.org ? a.org : `${a.family}${a.given ? ', ' + a.given : ''}`, g = a => a.org ? a.org : `${a.given ? a.given + ' ' : ''}${a.family}`; if (L.length === 1) return f(L[0]); if (L.length === 2) return `${f(L[0])}, and ${g(L[1])}`; return `${f(L[0])}, et al`; }
  function authorsH(L) { const n = L.map(nameH); if (n.length === 1) return n[0]; if (n.length <= 3) return n.slice(0, -1).join(', ') + ' and ' + n[n.length - 1]; return n[0] + ' et al.'; }
  const fam = a => a.org || a.family;
  /** A reference as segments: [text, italic?]. */
  function format(r, st = style()) {
    const L = people(r), T = r.type, segs = [], add = (t, i) => { if (t) segs.push([t, !!i]); };
    const yr = r.year || '', nd = st === 'APA' ? 'n.d.' : st === 'Harvard' ? 'no date' : '', u = r.doi ? doiUrl(r.doi) : r.url || '';
    const datePart = () => { if (!yr) return nd; if (st === 'APA' && ['web', 'news', 'video'].includes(T) && r.month) return `${yr}, ${MON[r.month - 1]}${r.day ? ' ' + r.day : ''}`; return yr; };
    const promptTail = () => T === 'ai' ? ` Prompt: ${st === 'Harvard' ? '‘' : '“'}${r.prompt || ''}${st === 'Harvard' ? '’' : '”'}. Generated ${st === 'APA' ? mdy(r.used) : dmy(r.used, st === 'MLA')}.` : '';
    const italicTitle = !['journal', 'news', 'web'].includes(T) || (T === 'web' && st !== 'MLA');
    if (st === 'APA') {
      const lead = L.length ? end(authorsAPA(L)) : '';
      if (lead) add(lead + ' '); const dateS = `(${datePart()}). `;
      const tt = r.title ? r.title.replace(/\.$/, '') : '';
      const bracket = { data: ' [Data set]', software: ' [Computer software]', video: ' [Video]', ai: ' [Large language model]' }[T] || '';
      const ver = r.version ? ` (${T === 'ai' ? '' : 'Version '}${r.version})` : '', ed = T === 'book' && r.edition && parseInt(r.edition, 10) !== 1 ? ` (${ord(r.edition)} ed.)` : '';
      if (!lead) { add(tt, italicTitle); add(ver + ed + bracket + '. '); add(dateS); }
      else { add(dateS); if (italicTitle) { add(tt, true); add(ver + ed + bracket + '. '); } else add(end(tt) + ' '); }
      if (T === 'journal') { add(r.container, true); if (r.volume) { add(', '); add(r.volume, true); } if (r.issue) add(`(${r.issue})`); if (r.pages) add(', ' + pages(r.pages)); add('. '); }
      else if (['web', 'news', 'video'].includes(T)) { if (r.container && !(L.length === 1 && fam(L[0]) === r.container)) { add(r.container, T === 'news'); add('. '); } }
      else if (r.publisher && !(L.length === 1 && fam(L[0]) === r.publisher)) add(end(r.publisher) + ' ');
      if (T === 'ai') add(promptTail().trim() + ' ');
      if (u) add(!r.year && ['web', 'data'].includes(T) && r.accessed && !r.doi ? `Retrieved ${mdy(r.accessed)}, from ${u}` : u);
    } else if (st === 'MLA') {
      if (T === 'ai') { add(`“${r.prompt || ''}” prompt. `); add(r.title, true); add(`, ${r.version ? r.version + ', ' : ''}${L.length ? L.map(fam).join(', ') : ''}, ${dmy(r.used, true)}${r.url ? ', ' + noHttp(r.url) : ''}.`); return segs; }
      if (L.length) add(end(authorsMLA(L)) + ' ');
      if (italicTitle) { add(r.title, true); add('. '); } else add(`“${end(r.title || '')}” `);
      const parts = [];
      if (r.container && T !== 'book') parts.push(['C', r.container]);
      if (T === 'book' && r.edition && parseInt(r.edition, 10) !== 1) parts.push(['', ord(r.edition) + ' ed.']);
      if (r.version) parts.push(['', 'version ' + r.version]);
      if (r.volume) parts.push(['', 'vol. ' + r.volume]); if (r.issue) parts.push(['', 'no. ' + r.issue]);
      if (r.publisher && !(L.length === 1 && fam(L[0]) === r.publisher)) parts.push(['', r.publisher]);
      if (yr) parts.push(['', r.month ? `${r.day ? r.day + ' ' : ''}${MLAMON[r.month - 1]} ${yr}` : yr]);
      if (r.pages) parts.push(['', (String(r.pages).includes('-') || String(r.pages).includes('–') ? 'pp. ' : 'p. ') + pages(r.pages)]);
      if (u) parts.push(['', r.doi ? u : noHttp(u)]);
      parts.forEach(([k, t], i) => { add(t, k === 'C'); add(i < parts.length - 1 ? ', ' : '. '); });
      if (r.accessed && ['web', 'data', 'news', 'video', 'software'].includes(T) && !r.year) add(`Accessed ${dmy(r.accessed, true)}.`);
    } else {
      const lead = L.length ? authorsH(L) : '';
      if (lead) add(`${lead} (${datePart()}) `);
      if (italicTitle || !lead) { add(r.title, true); if (!lead) add(` (${datePart()})`); }
      else add(`‘${r.title}’`);
      const ver = r.version ? ` (${T === 'ai' ? '' : 'Version '}${r.version})` : '', bracket = { data: ' [Data set]', software: ' [Computer program]', video: ' [Video]', ai: ' [Large language model]' }[T] || '';
      add(ver + bracket);
      if (T === 'journal') { add(', '); add(r.container, true); add(`${r.volume ? ', ' + r.volume : ''}${r.issue ? '(' + r.issue + ')' : ''}${r.pages ? ', pp. ' + pages(r.pages) : ''}`); }
      else if (T === 'news') { add(', '); add(r.container, true); if (r.month) add(`, ${r.day ? r.day + ' ' : ''}${MON[r.month - 1]}`); }
      add('. ');
      if (T === 'book' && r.edition && parseInt(r.edition, 10) !== 1) add(ord(r.edition) + ' edn. ');
      if (r.publisher && T !== 'journal' && !(L.length === 1 && fam(L[0]) === r.publisher)) add(end(r.publisher) + ' ');
      if (T === 'ai') add(promptTail().trim() + ' ');
      if (u) add(`Available at: ${u}${r.accessed && !r.doi ? ` (Accessed: ${dmy(r.accessed)})` : ''}.`);
    }
    return segs;
  }
  const toHTML = segs => segs.map(([t, i]) => i ? `<i>${esc(t)}</i>` : esc(t)).join('').replace(/\s+/g, ' ').trim();
  const toText = segs => segs.map(x => x[0]).join('').replace(/\s+/g, ' ').trim();
  /** The in-text citation, optionally with a page. */
  function inText(r, page, st = style()) {
    const L = people(r), yr = r.year || (st === 'APA' ? 'n.d.' : st === 'Harvard' ? 'no date' : '');
    let who;
    if (r.type === 'ai' && st === 'MLA' && r.prompt) who = `“${r.prompt.split(/\s+/).slice(0, 4).join(' ')}”`;
    else if (!L.length) who = st === 'MLA' ? `“${(r.title || '').split(/\s+/).slice(0, 4).join(' ')}”` : (r.title || '').split(/\s+/).slice(0, 5).join(' ');
    else if (st === 'APA') who = L.length === 1 ? fam(L[0]) : L.length === 2 ? `${fam(L[0])} & ${fam(L[1])}` : `${fam(L[0])} et al.`;
    else if (st === 'MLA') who = L.length === 1 ? fam(L[0]) : L.length === 2 ? `${fam(L[0])} and ${fam(L[1])}` : `${fam(L[0])} et al.`;
    else who = L.length === 1 ? fam(L[0]) : L.length <= 3 ? L.slice(0, -1).map(fam).join(', ') + ' and ' + fam(L[L.length - 1]) : `${fam(L[0])} et al.`;
    if (st === 'MLA') return `(${who}${page ? ' ' + page : ''})`;
    return `(${who}, ${yr}${page ? ', p. ' + page : ''})`;
  }
  /* ---------- completeness and checks ---------- */
  function missingOf(r) { const t = TYPES[r.type]; if (!t) return []; return t.req.filter(f => !(f === 'authors' ? people(r).length : r[f]) && !(r.missing || {})[f]); }
  const textOf = n => { const w = n.write || {}; return Object.keys(w).filter(k => k !== 'bodyCount').map(k => w[k]).join('\n') + '\n' + ((n.gdoc || {}).check ? ((n.gdoc.check.cites || []).join('\n')) : ''); };
  const norm = t => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  function citedIn(r, text) {
    const T = norm(text), L = people(r), key = L.length ? norm(fam(L[0])) : norm((r.title || '').split(/\s+/).slice(0, 2).join(' '));
    if (!key || key.length < 2) return false; let i = T.indexOf(key);
    while (i >= 0) { const win = T.slice(i, i + 90); if (style() === 'MLA' || !r.year || win.includes(String(r.year)) || win.includes('n.d') || win.includes('no date')) return true; i = T.indexOf(key, i + 1); }
    return false;
  }
  /** “(Name, 2020)”-style citations in the writing that match no reference. */
  function strays(n) {
    const text = textOf(n), list = list0(n), out = new Set(), re = /\(([A-Z][\p{L}'’\-]+(?: (?:et al\.|and|&) ?[A-Z]?[\p{L}'’\-]*)*),? ((?:19|20)\d\d|n\.d\.|no date)[^)]{0,20}\)/gu; let m;
    while ((m = re.exec(text))) { const name = norm(m[1].split(/ et al| and | & /)[0]), yr = m[2]; if (!list.some(r => people(r).some(a => norm(fam(a)).startsWith(name)) && (String(r.year) === yr || (!r.year && /n\.d|no date/.test(yr))))) out.add(m[0]); }
    return [...out];
  }
  const list0 = n => ((n.cites || {}).list || []);
  function flagsOf(r, n) {
    const f = [], miss = missingOf(r), text = textOf(n);
    if (miss.length) f.push(['incomplete', 'Missing: ' + miss.map(k => F[k].split(' (')[0].split(' —')[0].toLowerCase()).join(', ')]);
    if (r.auto && !r.confirmed) f.push(['unconfirmed', 'Looked up automatically — check it against the source and tick “checked”.']);
    if (!citedIn(r, text)) f.push(['uncited', 'Not cited in your writing yet']);
    if (r.type === 'ai' && style() && !r.prompt) f.push(['incomplete', 'Add the prompt and the date — the IB requires both for AI tools.']);
    return f;
  }
  function summary(n) {
    const L = list0(n), all = L.map(r => flagsOf(r, n)), c = k => all.filter(f => f.some(x => x[0] === k)).length, st = strays(n);
    return { count: L.length, incomplete: c('incomplete'), unconfirmed: c('unconfirmed'), uncited: c('uncited'), strays: st.length, flags: c('incomplete') + c('unconfirmed') + c('uncited') + st.length, tutorial: !!(((n.cites || {}).tutorial) || {}).done };
  }
  const sorted = n => list0(n).slice().sort((a, b) => { const k = r => norm(people(r).length ? fam(people(r)[0]) : r.title); return k(a) < k(b) ? -1 : k(a) > k(b) ? 1 : 0; });
  const bibliographyHTML = n => `<div class="bib">${sorted(n).map(r => `<p class="bib-i">${toHTML(format(r))}</p>`).join('')}</div>`;
  const bibliographySegs = n => sorted(n).map(r => format(r));
  const count = n => list0(n).length;
  function badge(s) { const n = (S().ia || {})[s.id]; if (!n || !count(n)) return ''; const f = summary(n).flags; return f ? ` <span class="pill amber">${f}</span>` : ''; }

  /* ---------- looking things up (never inventing) ---------- */
  const clean = t => String(t || '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
  function splitName(full) { const f = clean(full); if (f.includes(',')) { const [a, b] = f.split(','); return { family: a.trim(), given: b.trim() }; } const p = f.split(' '); if (p.length < 2) return { org: f }; return { family: p[p.length - 1], given: p.slice(0, -1).join(' ') }; }
  async function byDOI(doi) {
    const d = String(doi).trim().replace(/^https?:\/\/(dx\.)?doi\.org\//i, '').replace(/^doi:\s*/i, '');
    const res = await fetch('https://api.crossref.org/works/' + encodeURIComponent(d)); if (!res.ok) throw Error(res.status === 404 ? 'No record found for that DOI. Check it, or enter the details by hand.' : 'The DOI service did not answer. Try again, or enter the details by hand.');
    const m = (await res.json()).message || {}, dp = ((m['published-print'] || m['published-online'] || m.issued || {})['date-parts'] || [[]])[0] || [];
    const type = { 'journal-article': 'journal', 'proceedings-article': 'journal', book: 'book', monograph: 'book', 'edited-book': 'book', 'reference-book': 'book', report: 'report', dataset: 'data', 'posted-content': 'report' }[m.type] || 'report';
    const r = { type, authors: (m.author || []).map(a => a.family ? { family: clean(a.family), given: clean(a.given) } : a.name ? { org: clean(a.name) } : null).filter(Boolean), title: clean((m.title || [])[0]), doi: d };
    if (dp[0]) r.year = String(dp[0]); if (dp[1] && type !== 'journal') r.month = dp[1]; if (dp[2] && type !== 'journal') r.day = dp[2];
    const ct = clean((m['container-title'] || [])[0]); if (ct) r.container = ct; ['volume', 'issue'].forEach(k => { if (m[k]) r[k] = clean(m[k]); }); if (m.page) r.pages = pages(m.page).replace(/^(\d+)–\1$/, '$1');
    if (m.publisher && type !== 'journal') r.publisher = clean(m.publisher); if ((m.ISBN || [])[0]) r.isbn = m.ISBN[0];
    r.auto = { source: 'Crossref', at: new Date().toISOString(), fields: Object.keys(r).filter(k => !['type', 'auto'].includes(k) && (k !== 'authors' || r.authors.length)) };
    if (type === 'report' && !['report', 'posted-content'].includes(m.type)) r.auto.note = `Crossref calls this a “${m.type}”. Check the kind of source is right.`;
    return r;
  }
  async function byISBN(isbn) {
    const i = String(isbn).replace(/[^0-9Xx]/g, ''); if (![10, 13].includes(i.length)) throw Error('An ISBN has 10 or 13 digits.');
    const res = await fetch(`https://openlibrary.org/api/books?bibkeys=ISBN:${i}&format=json&jscmd=data`); if (!res.ok) throw Error('The book service did not answer. Try again, or enter the details by hand.');
    const b = (await res.json())['ISBN:' + i]; if (!b) throw Error('No book found for that ISBN. Check it, or enter the details by hand.');
    const r = { type: 'book', title: clean(b.title + (b.subtitle ? ': ' + b.subtitle : '')), authors: (b.authors || []).map(a => splitName(a.name)), isbn: i };
    const y = String(b.publish_date || '').match(/\b(1[5-9]|20)\d\d\b/); if (y) r.year = y[0]; if ((b.publishers || [])[0]) r.publisher = clean(b.publishers[0].name);
    r.auto = { source: 'Open Library', at: new Date().toISOString(), fields: Object.keys(r).filter(k => !['type', 'auto'].includes(k) && (k !== 'authors' || r.authors.length)), note: r.authors.length ? 'Check that each author’s first and last names were split correctly.' : '' };
    return r;
  }
  async function byURL(url) {
    if (!/^https?:\/\/[^\s]+\.[^\s]+/.test(url)) throw Error('Paste the full web address, starting with https://');
    const m = await Hub.cloud.call('cite-url', { url });
    if (m.doi) { try { const r = await byDOI(m.doi); r.url = url; return r; } catch (e) { /* fall back to the page’s own details */ } }
    const r = { type: 'web', url, title: clean(m.title), accessed: new Date().toISOString().slice(0, 10) };
    if (m.site) r.container = clean(m.site); if ((m.authors || []).length) r.authors = m.authors.map(splitName); else r.authors = [];
    const d = String(m.published || '').match(/^(\d{4})(?:-(\d{2})(?:-(\d{2}))?)?/); if (d) { r.year = d[1]; if (d[2]) r.month = Number(d[2]); if (d[3]) r.day = Number(d[3]); }
    r.auto = { source: 'the web page', at: new Date().toISOString(), fields: Object.keys(r).filter(k => !['type', 'auto', 'accessed'].includes(k) && (k !== 'authors' || r.authors.length)), note: 'Web pages often hide the author or date. If you cannot find them on the page, tick “not given on the source” — never guess.' };
    return r;
  }
  function lookup(q) { q = String(q || '').trim(); if (/^(https?:\/\/(dx\.)?doi\.org\/|doi:|10\.\d{4,})/i.test(q)) return byDOI(q); if (/^https?:\/\//i.test(q)) return byURL(q); if (/^[0-9][0-9\-\sXx]{8,}$/.test(q)) return byISBN(q); return Promise.reject(Error('Paste a DOI (10.…), an ISBN, or a web address starting with https://')); }

  /* ---------- the References page ---------- */
  let draft = null, editId = null;
  function page(el, s, n, ro, teacher) {
    const L = sorted(n), sm = summary(n), st = strays(n), sty = style(), C = n.cites || {};
    el.innerHTML = `<section class="card"><div class="row-between"><h2 class="bar-head blue">References</h2><span class="pill">${esc(styleName())}${teacher ? ' · change it in IA settings' : ' · chosen by Miss Badmus'}</span></div>
      <p class="small">The IB does not insist on one referencing style, but it does insist that every source you use is acknowledged <b>where you use it</b> (an in-text citation) and in your <b>reference list</b>, in one consistent style. That includes data, images, software and any AI tool you were allowed to use — for AI, give the prompt and the date it generated the text.</p>
      ${L.length ? `<p class="small">${L.length} reference${L.length === 1 ? '' : 's'} · ${sm.flags ? `<b>${sm.flags} thing${sm.flags === 1 ? '' : 's'} to fix</b>` : '✓ no problems found'}</p>` : ''}</section>
      ${ro ? '' : `<section class="card" id="cite-add"><h2 class="bar-head green">${editId ? 'Edit a reference' : 'Add a source'}</h2>
        ${editId ? '' : `<div class="lookup"><label>Paste a DOI, an ISBN or a web address<input id="ct-q" placeholder="10.1080/… · 978-0-19-… · https://…"></label><button class="btn small primary" id="ct-look" type="button">Look it up</button><button class="btn small ghost" id="ct-hand" type="button">Enter by hand</button></div><p class="tiny muted" id="ct-msg">Lookups use Crossref (DOIs), Open Library (ISBNs) or the web page itself. Anything they cannot find is left empty for you to fill in from the source.</p>`}
        <div id="ct-form">${draft ? formHTML(draft) : ''}</div></section>`}
      <section class="card"><h2 class="bar-head pink">My reference list</h2>${L.length ? L.map(r => itemHTML(r, n, ro)).join('') : '<p class="muted">No references yet. Add every source as soon as you use it.</p>'}
        ${st.length ? `<div class="sticky"><b>Cited in your writing but not in your list:</b> ${st.map(esc).join(' · ')} — add the source, or correct the citation.</div>` : ''}</section>
      ${L.length ? `<section class="card"><h2 class="bar-head amber">Reference list in ${esc(styleName())}</h2>${bibliographyHTML(n)}<div class="actions"><button class="btn small" id="bib-copy" type="button">📋 Copy the list</button>${!ro && Hub.iagdoc && Hub.iagdoc.canInsert(n) ? '<button class="btn small" id="bib-gdoc" type="button">Insert at the end of my Google Doc</button>' : ''}<span class="tiny muted" id="bib-msg"></span></div><p class="tiny muted">Sorted alphabetically. In your document, use a hanging indent and the same font as the rest of your exploration.</p></section>` : ''}
      ${(n.sources || []).length ? `<section class="card"><h2 class="bar-head grey">From my older sources log</h2><p class="small">These were saved before the reference builder. Turn each one into a full reference.</p>${n.sources.map((x, i) => `<div class="row-between small"><span>${esc(x.title)}${x.url ? ' · ' + esc(x.url) : ''}</span>${ro ? '' : `<button class="btn small ghost" data-convert="${i}" type="button">Make a full reference</button>`}</div>`).join('')}</section>` : ''}
      ${tutorialHTML(C.tutorial, ro)}`;
    bind(el, s, n, ro, teacher);
  }
  function itemHTML(r, n, ro) {
    const fl = flagsOf(r, n);
    return `<div class="cite-i ${fl.length ? 'warn' : 'ok'}" data-cid="${esc(r.id)}"><p class="cite-ref">${toHTML(format(r))}</p>
      <div class="cite-meta tiny"><span class="pill">${esc((TYPES[r.type] || {}).label || r.type)}</span> In-text: <code>${esc(inText(r))}</code> <button class="btn small ghost" type="button" data-copyin="${esc(r.id)}">Copy</button>
      <label>page <input class="pg" data-pg="${esc(r.id)}" size="4"></label>${r.auto ? ` · looked up from ${esc(r.auto.source)}` : ''}</div>
      ${fl.map(([k, t]) => `<span class="pill ${k === 'uncited' ? 'amber' : 'red'}">${esc(t)}</span>`).join(' ')}${r.auto && r.auto.note && !r.confirmed ? `<p class="tiny warn-line">${esc(r.auto.note)}</p>` : ''}
      ${ro ? '' : `<div class="actions">${r.auto ? `<label class="inline-check tiny"><input type="checkbox" data-confirm="${esc(r.id)}" ${r.confirmed ? 'checked' : ''}> I have checked these details against the source</label>` : ''}<button class="btn small ghost" type="button" data-edit="${esc(r.id)}">Edit</button><button class="btn small ghost danger" type="button" data-del="${esc(r.id)}">Delete</button></div>`}</div>`;
  }
  function formHTML(r) {
    const t = TYPES[r.type] || TYPES.web, fields = [...t.req, ...t.opt], auto = new Set((r.auto || {}).fields || []), miss = r.missing || {};
    const lab = f => (f === 'container' && t.c ? t.c : F[f]) + (t.req.includes(f) ? ' *' : '');
    const tag = f => auto.has(f) ? ' <span class="pill blue">looked up</span>' : '';
    const nd = f => t.req.includes(f) ? `<label class="inline-check tiny nd"><input type="checkbox" data-miss="${f}" ${miss[f] ? 'checked' : ''}> not given on the source</label>` : '';
    const field = f => {
      if (f === 'authors') return `<div class="span2 ct-authors"><span class="mfld-lab">${lab(f)}${tag(f)}</span>${(r.authors && r.authors.length ? r.authors : [{}]).map((a, i) => `<div class="au-row"><select data-au-kind="${i}"><option value="p" ${a.org ? '' : 'selected'}>Person</option><option value="o" ${a.org ? 'selected' : ''}>Organisation</option></select>${a.org !== undefined ? `<input data-au="${i}" data-k="org" value="${esc(a.org || '')}" placeholder="Organisation name">` : `<input data-au="${i}" data-k="given" value="${esc(a.given || '')}" placeholder="First name(s)"><input data-au="${i}" data-k="family" value="${esc(a.family || '')}" placeholder="Last name">`}<button class="btn small ghost" type="button" data-au-rm="${i}" aria-label="Remove author">×</button></div>`).join('')}<button class="btn small ghost" type="button" id="au-add">+ Another author</button>${nd(f)}</div>`;
      const typ = ['accessed', 'used'].includes(f) ? 'date' : ['year', 'day', 'month', 'volume', 'issue', 'edition'].includes(f) ? 'text' : f === 'url' ? 'url' : 'text';
      if (f === 'month') return `<label>${lab(f)}${tag(f)}<select data-f="month"><option value="">—</option>${MON.map((m, i) => `<option value="${i + 1}" ${Number(r.month) === i + 1 ? 'selected' : ''}>${m}</option>`).join('')}</select></label>`;
      if (f === 'prompt') return `<label class="span2">${lab(f)}<textarea data-f="prompt" rows="2">${esc(r.prompt || '')}</textarea>${nd(f)}</label>`;
      return `<label class="${['title', 'url', 'container', 'publisher'].includes(f) ? 'span2' : ''}">${lab(f)}${tag(f)}<input type="${typ}" data-f="${f}" value="${esc(r[f] || '')}" ${f === 'year' ? 'inputmode="numeric" maxlength="4"' : ''}>${nd(f)}</label>`;
    };
    return `<div class="form-grid"><label class="span2">Kind of source<select id="ct-type">${Object.entries(TYPES).map(([k, x]) => `<option value="${k}" ${r.type === k ? 'selected' : ''}>${esc(x.label)}</option>`).join('')}</select></label>${t.hint ? `<p class="tiny span2">${esc(t.hint)}</p>` : ''}
      ${fields.map(field).join('')}</div>${r.auto && r.auto.note ? `<p class="tiny warn-line">${esc(r.auto.note)}</p>` : ''}
      <p class="tiny muted">* needed for a complete reference. If the source does not give it, tick “not given on the source” — the Hub uses the style’s rule (for example “n.d.” for no date). Never guess.</p>
      <div class="preview-ref"><span class="key-lab">Preview</span><p id="ct-prev">${toHTML(format(r))}</p></div>
      <div class="actions"><button class="btn small primary" id="ct-save" type="button">${editId ? 'Save changes' : 'Add to my references'}</button><button class="btn small ghost" id="ct-cancel" type="button">Cancel</button></div>`;
  }
  function readForm(el) {
    const r = draft, ty = $('#ct-type', el); if (!r || !ty) return null; r.type = ty.value;
    $$('[data-f]', el).forEach(i => { const k = i.dataset.f, v = i.value.trim(); if (k === 'month') { if (v) r.month = Number(v); else delete r.month; return; } if (v) r[k] = k === 'year' ? v.replace(/\D/g, '').slice(0, 4) : v.slice(0, 1000); else delete r[k]; });
    const au = []; $$('.au-row', el).forEach((row, i) => { const kind = $(`[data-au-kind="${i}"]`, row).value; if (kind === 'o') { const o = ($('[data-k="org"]', row) || {}).value || ''; if (o.trim()) au.push({ org: o.trim().slice(0, 200) }); } else { const g = ($('[data-k="given"]', row) || {}).value || '', f = ($('[data-k="family"]', row) || {}).value || ''; if (f.trim()) au.push({ family: f.trim().slice(0, 100), given: g.trim().slice(0, 100) }); } });
    r.authors = au; r.missing = Object.fromEntries($$('[data-miss]', el).filter(c => c.checked).map(c => [c.dataset.miss, true]));
    return r;
  }
  function bind(el, s, n, ro) {
    const C = () => (n.cites = n.cites || {}), Lst = () => (C().list = C().list || []);
    const copy = async (text, html) => { try { if (html && window.ClipboardItem) await navigator.clipboard.write([new ClipboardItem({ 'text/html': new Blob([html], { type: 'text/html' }), 'text/plain': new Blob([text], { type: 'text/plain' }) })]); else await navigator.clipboard.writeText(text); toast('Copied.'); } catch (e) { toast('Copy did not work here — select the text and copy it.', 'error'); } };
    $$('[data-copyin]', el).forEach(b => (b.onclick = () => { const r = list0(n).find(x => x.id === b.dataset.copyin), pg = $(`[data-pg="${b.dataset.copyin}"]`, el).value.trim(); copy(inText(r, pg)); }));
    const bc = $('#bib-copy', el); if (bc) bc.onclick = () => copy(sorted(n).map(r => toText(format(r))).join('\n'), bibliographyHTML(n));
    const bg = $('#bib-gdoc', el); if (bg) bg.onclick = async () => { const m = $('#bib-msg', el); bg.disabled = true; m.textContent = 'Adding to your Google Doc…'; try { await Hub.iagdoc.insertBibliography(s, n, bibliographySegs(n)); m.textContent = `Added at the end of your Google Doc at ${fmtDateTime(new Date().toISOString())}.`; } catch (e) { m.textContent = e.message; } bg.disabled = false; };
    bindTutorial(el, n, ro);
    if (ro) return;
    const showForm = () => { $('#ct-form', el).innerHTML = draft ? formHTML(draft) : ''; bindForm(); };
    const look = $('#ct-look', el); if (look) look.onclick = async () => { const q = $('#ct-q', el).value, m = $('#ct-msg', el); look.disabled = true; m.textContent = 'Looking it up…'; try { draft = await lookup(q); draft.id = 'ref-' + Date.now().toString(36); m.textContent = `Found on ${draft.auto.source}. Check every detail against the source, fill any gaps, then add it.`; showForm(); } catch (e) { m.textContent = e.message; } look.disabled = false; };
    const hand = $('#ct-hand', el); if (hand) hand.onclick = () => { draft = { id: 'ref-' + Date.now().toString(36), type: 'web', authors: [], accessed: new Date().toISOString().slice(0, 10) }; showForm(); };
    function bindForm() {
      const f = $('#ct-form', el); if (!draft) return; const prev = () => { if (!draft || !$('#ct-prev', f)) return; readForm(f); $('#ct-prev', f).innerHTML = toHTML(format(draft)); };
      f.oninput = debounce(prev, 200); f.onchange = e => { if (e.target.id === 'ct-type' || e.target.dataset.auKind !== undefined) { readForm(f); if (e.target.dataset.auKind !== undefined) { const i = Number(e.target.dataset.auKind); draft.authors[i] = e.target.value === 'o' ? { org: '' } : { family: '', given: '' }; } showForm(); } else prev(); };
      const add = $('#au-add', f); if (add) add.onclick = () => { readForm(f); draft.authors.push({ family: '', given: '' }); showForm(); };
      $$('[data-au-rm]', f).forEach(b => (b.onclick = () => { readForm(f); draft.authors.splice(Number(b.dataset.auRm), 1); showForm(); }));
      $('#ct-cancel', f).onclick = () => { draft = null; editId = null; Hub.app.render(); };
      $('#ct-save', f).onclick = () => { readForm(f); if (!draft.title) return toast('Every reference needs a title.', 'error'); const r = JSON.parse(JSON.stringify(draft)); r.updated = new Date().toISOString(); const L = Lst(), i = L.findIndex(x => x.id === r.id); if (i >= 0) L[i] = r; else { r.created = r.updated; L.push(r); } draft = null; editId = null; Hub.ia.stamp(n); Hub.store.save(true); toast(missingOf(r).length ? 'Saved — some details are still missing.' : 'Reference saved.'); Hub.app.render(); };
    }
    if (draft) bindForm();
    $$('[data-confirm]', el).forEach(c => (c.onchange = () => { const r = Lst().find(x => x.id === c.dataset.confirm); r.confirmed = c.checked; Hub.store.save(true); Hub.app.render(); }));
    $$('[data-edit]', el).forEach(b => (b.onclick = () => { draft = JSON.parse(JSON.stringify(Lst().find(x => x.id === b.dataset.edit))); editId = draft.id; Hub.app.render(); setTimeout(() => { const a = $('#cite-add'); if (a) a.scrollIntoView({ behavior: 'smooth' }); }, 30); }));
    $$('[data-del]', el).forEach(b => (b.onclick = async () => { if (!(await U.confirmBox('Delete this reference?', 'Delete', { danger: true }))) return; C().list = Lst().filter(x => x.id !== b.dataset.del); Hub.store.save(true); Hub.app.render(); }));
    $$('[data-convert]', el).forEach(b => (b.onclick = () => { const x = n.sources[Number(b.dataset.convert)]; draft = { id: 'ref-' + Date.now().toString(36), type: 'web', authors: [], title: x.title, url: x.url, accessed: x.accessed }; editId = null; Hub.app.render(); setTimeout(() => { const a = $('#cite-add'); if (a) a.scrollIntoView({ behavior: 'smooth' }); }, 30); }));
  }

  /* ---------- academic honesty: a short tutorial and check ---------- */
  const CARDS = [['Why reference?', 'A reference shows the reader which ideas, words, data and pictures came from someone else — so everything else can be credited to you. In the IB, presenting someone else’s work as your own is academic misconduct, even by accident.'],
    ['Two places, every time', 'Each source appears twice: an in-text citation where you use it — (Author, Year) — and a full entry in your reference list at the end.'],
    ['Paraphrasing still needs a citation', 'Putting an idea in your own words does not make it yours. Cite the source of the idea. Exact words go in quotation marks as well.'],
    ['Data, graphs, images and software', 'A data set, a graph or image you did not make, and the software you used (Desmos, GeoGebra, a spreadsheet) are all sources.'],
    ['Common knowledge in mathematics', 'Standard results from the formula booklet do not need a citation. A derivation, explanation or example you followed from a book or website does.'],
    ['AI tools', 'Use AI tools only as Miss Badmus allows. If you use one, cite it in the text (with quotation marks around any text it generated) and in your reference list, with the prompt you gave and the date. AI text is never your own writing.']];
  const QUIZ = [['You explain logistic growth in your own words, but you learned it from a website. Do you need a citation?', ['Yes — in the text and in the reference list', 'No — it is in my own words', 'Only in the reference list'], 0, 'Paraphrasing still uses someone else’s ideas, so it needs an in-text citation and a reference.'],
    ['You use the quadratic formula from the IB formula booklet. Do you cite it?', ['No — it is standard mathematics', 'Yes — cite the formula booklet', 'Yes — cite a textbook'], 0, 'Standard results that every student of the course knows are common knowledge in mathematics.'],
    ['You used Desmos to fit a curve to your data. What should you do?', ['Cite Desmos as software', 'Nothing — it is only a calculator', 'Copy the Desmos graph without a caption'], 0, 'Software that produced results or graphs is a source and is cited.'],
    ['Miss Badmus allowed you to ask an AI tool to explain a method. What must your reference include?', ['The tool, the prompt you gave and the date', 'Just the name of the tool', 'Nothing, if you rewrote the explanation'], 0, 'The IB asks for the prompt and the date the AI generated the text, in the reference and with an in-text citation.'],
    ['A classmate shares their measurements with you. What do you do?', ['Acknowledge them as the source of the data', 'Nothing — data cannot be owned', 'Pretend you measured it'], 0, 'Data you did not collect yourself must be acknowledged.']];
  function tutorialHTML(t, ro) {
    t = t || {};
    return `<details class="card tut" ${t.done ? '' : 'open'}><summary><h2 class="bar-head green">Academic honesty — a 5-minute tutorial${t.done ? ` <span class="pill green">done ${fmtDate(String(t.at).slice(0, 10))} · ${t.score}/5</span>` : ''}</h2></summary>
      <div class="tut-cards">${CARDS.map(([h, b], i) => `<div class="tut-c"><b>${i + 1} · ${esc(h)}</b><p class="small">${esc(b)}</p></div>`).join('')}</div>
      <h3>Check your understanding</h3>${QUIZ.map(([q, opts, ok, why], i) => `<fieldset class="tq" data-q="${i}"><legend>${i + 1}. ${esc(q)}</legend>${opts.map((o, j) => `<label class="inline-check"><input type="radio" name="tq${i}" value="${j}" ${ro ? 'disabled' : ''}> ${esc(o)}</label>`).join('')}<p class="tiny tq-fb" hidden data-ok="${ok}">${esc(why)}</p></fieldset>`).join('')}
      ${ro ? '' : '<button class="btn small primary" id="tq-check" type="button">Check my answers</button> <span class="small" id="tq-res"></span>'}</details>`;
  }
  function bindTutorial(el, n, ro) {
    const b = $('#tq-check', el); if (!b || ro) return;
    b.onclick = () => { let score = 0, answered = 0; $$('.tq', el).forEach(f => { const c = $('input:checked', f), fb = $('.tq-fb', f); if (c) { answered++; const right = c.value === fb.dataset.ok; if (right) score++; fb.hidden = false; fb.className = 'tiny tq-fb ' + (right ? 'ok-line' : 'warn-line'); fb.textContent = (right ? '✓ ' : '✗ ') + fb.textContent.replace(/^[✓✗] /, ''); } });
      if (answered < QUIZ.length) return toast('Answer every question first.', 'error');
      $('#tq-res', el).textContent = `${score}/5.${score === 5 ? ' Well done — tutorial complete.' : ' Read the feedback and try again — you need 5/5 to complete it.'}`;
      if (score === 5) { n.cites = n.cites || {}; n.cites.tutorial = { done: true, at: new Date().toISOString(), score }; Hub.store.save(true); }
    };
  }

  Hub.iacite = { page, format, inText, toHTML, toText, summary, flagsOf, strays, bibliographyHTML, bibliographySegs, count, badge, style, styleName, STYLES, TYPES, lookup, byDOI, byISBN, citedIn, missingOf };
})(window.Hub = window.Hub || {});
