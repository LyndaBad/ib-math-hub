/* AA HL — book-exercise questions. NEW questions written for each Oxford AA HL (2019) exercise: same skills,
   style and level, different numbers, contexts and wording. Labelled with the exercise name only. */
(function (Hub) {
  'use strict';
  const B = Hub.qcore.bx, plot = Hub.qcore.plot, R = String.raw;
  const mcv = ok => `'k0' if ${ok} else 'bad'`;
  const neg = v => String(v).replace('-', '−');
  const pt = (x, y, pos) => [x, y, `(${neg(x)}, ${neg(y)})`, pos];

  /* ===== 2.2 Quadratic functions ===== */
  // [f, a, h, k, tex, plot window, step]
  const QF = [
    [x => x * x - 8 * x + 12, 1, 4, -4, R`y = x^{2} - 8x + 12`, [-1, 9], [-6, 14], [1, 2], 'x**2-8*x+12'],
    [x => 6 + 4 * x - x * x, -1, 2, 10, R`y = 6 + 4x - x^{2}`, [-3, 7], [-6, 12], [1, 2], '6+4*x-x**2'],
    [x => 2 * x * x + 12 * x + 7, 2, -3, -11, R`y = 2x^{2} + 12x + 7`, [-8, 2], [-14, 10], [1, 2], '2*x**2+12*x+7'],
    [x => 5 - 6 * x - 3 * x * x, -3, -1, 8, R`y = 5 - 6x - 3x^{2}`, [-4, 2], [-8, 10], [1, 2], '5-6*x-3*x**2']
  ];
  const q1parts = QF.flatMap(([f, a, h, k, tex, xr, yr, st, py], i) => {
    const L = 'abcd'[i], up = a > 0, b = -2 * a * h, rng = up ? R`y \ge ${k}` : R`y \le ${k}`;
    const ineq = up ? R`\ge` : R`\le`, wrongIneq = up ? R`\le` : R`\ge`;
    return [
      { l: `${L}(i)`, c: 'Find', p: R`for $${tex}$, the equation of the axis of symmetry.`, m: 2, a: { n: h, d: R`x = ${h}` },
        ms: [['(M1)', R`$x = -\frac{b}{2a} = -\frac{${b}}{2(${a})}$`], ['A1', R`$x = ${h}$`]], w: [R`$x = -\frac{b}{2a} = -\frac{${b}}{2(${a})} = ${h}$`],
        h: 'The axis of symmetry passes through the vertex: x = −b ÷ 2a.', e: [{ value: -h, fb: 'Check the sign: x = −b ÷ 2a.' }], v: `solve(diff(${py},x),x)[0]` },
      { l: `${L}(ii)`, c: 'Find', p: 'the coordinates of the vertex.', m: 2, h: 'Substitute your x from part (i) into the function.', a: { t: [h, k], l: ['x', 'y'] },
        ms: [['(M1)', R`substitutes $x = ${h}$`], ['A1', R`$(${h},\ ${k})$`]], w: [R`$y = ${tex.slice(4).replace(/x/g, `(${h})`)} = ${k}$`, R`Vertex $(${h},\ ${k})$`],
        kfig: plot({ x: xr, y: yr, step: st, f: [{ f }], vl: [h], pts: [pt(h, k, up ? 'b' : null)], alt: 'Sketch of the parabola with its vertex and axis of symmetry' }), v: `(solve(diff(${py},x),x)[0], (${py}).subs(x, solve(diff(${py},x),x)[0]))` },
      { l: `${L}(iii)`, c: 'State', p: 'its concavity, domain and range.', m: 2, h: 'The sign of a decides the concavity. The range starts or stops at the y-coordinate of the vertex.',
        a: { mc: [R`Concave ${up ? 'up' : 'down'}; domain $x \in \mathbb{R}$; range $${rng}$`, R`Concave ${up ? 'down' : 'up'}; domain $x \in \mathbb{R}$; range $y ${wrongIneq} ${k}$`, R`Concave ${up ? 'up' : 'down'}; domain $x ${ineq} ${h}$; range $y \in \mathbb{R}$`, R`Concave ${up ? 'up' : 'down'}; domain $x \in \mathbb{R}$; range $y ${ineq} ${h}$`] },
        ms: [['A1', R`concave ${up ? 'up' : 'down'} because $a ${up ? '>' : '<'} 0$`], ['A1', R`domain $x \in \mathbb{R}$, range $${rng}$`]],
        w: [R`$a = ${a} ${up ? '>' : '<'} 0$, so the graph is concave ${up ? 'up (it opens upwards)' : 'down (it opens downwards)'}.`, R`Domain: $x \in \mathbb{R}$. The vertex is a ${up ? 'minimum' : 'maximum'}, so the range is $${rng}$.`], v: mcv(`(Poly(${py},x).LC() > 0) == ${up ? 'True' : 'False'} and maximum(${py}, x) == ${k}`.replace(up ? 'maximum' : '#', 'minimum')) }
    ];
  });
  // [a, b, c, info TeX, best-form working, plot window, step, points]
  const QG = [
    [1, -6, 7, R`The vertex is $(3, -2)$ and the graph passes through $(0, 7)$.`, [R`Vertex form: $y = a(x - 3)^{2} - 2$`, R`$(0, 7)$: $7 = 9a - 2 \Rightarrow a = 1$`, R`$y = (x - 3)^{2} - 2 = x^{2} - 6x + 7$`], [-1, 7], [-4, 10], [1, 2], [pt(3, -2, 'b'), pt(0, 7)]],
    [2, -8, -10, R`The $x$-intercepts are $-1$ and $5$, and the $y$-intercept is $-10$.`, [R`Factorized form: $y = a(x + 1)(x - 5)$`, R`$(0, -10)$: $-10 = a(1)(-5) \Rightarrow a = 2$`, R`$y = 2(x + 1)(x - 5) = 2x^{2} - 8x - 10$`], [-3, 7], [-20, 10], [1, 5], [pt(-1, 0, 'l'), pt(5, 0), pt(0, -10)]],
    [-2, -8, -3, R`The vertex is $(-2, 5)$ and the graph passes through $(1, -13)$.`, [R`Vertex form: $y = a(x + 2)^{2} + 5$`, R`$(1, -13)$: $-13 = 9a + 5 \Rightarrow a = -2$`, R`$y = -2(x + 2)^{2} + 5 = -2x^{2} - 8x - 3$`], [-6, 3], [-16, 8], [1, 2], [pt(-2, 5), pt(1, -13)]],
    [-2, 16, -24, R`The $x$-intercepts are $2$ and $6$, and the graph passes through $(4, 8)$.`, [R`Factorized form: $y = a(x - 2)(x - 6)$`, R`$(4, 8)$: $8 = a(2)(-2) \Rightarrow a = -2$`, R`$y = -2(x - 2)(x - 6) = -2x^{2} + 16x - 24$`], [-1, 9], [-8, 10], [1, 2], [pt(2, 0, 'b'), pt(6, 0, 'b'), pt(4, 8)]],
    [3, 18, 27, R`The graph touches the $x$-axis at $x = -3$ and passes through $(-1, 12)$.`, [R`A repeated root at $x = -3$: $y = a(x + 3)^{2}$`, R`$(-1, 12)$: $12 = 4a \Rightarrow a = 3$`, R`$y = 3(x + 3)^{2} = 3x^{2} + 18x + 27$`], [-7, 1], [-2, 16], [1, 2], [pt(-3, 0, 'b'), pt(-1, 12)]],
    [2, -3, 4, R`The graph passes through $(0, 4)$, $(1, 3)$ and $(2, 6)$.`, [R`General form: $y = ax^{2} + bx + c$; $(0, 4)$ gives $c = 4$`, R`$(1, 3)$: $a + b + 4 = 3$; $(2, 6)$: $4a + 2b + 4 = 6$`, R`$a + b = -1$ and $2a + b = 1 \Rightarrow a = 2,\ b = -3$`, R`$y = 2x^{2} - 3x + 4$`], [-2, 3], [-1, 9], [1, 1], [pt(0, 4, 'l'), pt(1, 3, 'b'), pt(2, 6)]]
  ];
  const q2parts = QG.map(([a, b, c, info, w, xr, yr, st, pts], i) => ({
    l: 'abcdef'[i], c: 'Find', h: 'Vertex given → y = a(x − h)² + k. Both x-intercepts given → y = a(x − p)(x − q). Then use another point to find a.', p: `the equation of the quadratic function shown. ${info} Choose the most suitable form, then give your answer in the form $y = ax^{2} + bx + c$.`, m: 3,
    fig: plot({ x: xr, y: yr, step: st, f: [{ f: x => a * x * x + b * x + c }], pts, alt: 'Graph of a parabola with labelled points' }),
    a: { t: [a, b, c], l: ['a', 'b', 'c'], d: R`y = ${a === 1 ? '' : a === -1 ? '-' : a}x^{2} ${b < 0 ? '-' : '+'} ${Math.abs(b)}x ${c < 0 ? '-' : '+'} ${Math.abs(c)}` },
    ms: [['M1', w[0]], ['M1', w[1]], ['A1', w[w.length - 1]]], w,
    v: `tuple(Poly(${a}*x**2+(${b})*x+(${c}),x).all_coeffs())` }));
  B('HL', '2B', { page: 85, sec: '2.2', title: 'Quadratic functions', skill: 'HL-2.2a', paper: 1 }, [
    { stem: 'For each quadratic function, find (i) the equation of the axis of symmetry and (ii) the coordinates of the vertex, and (iii) state its concavity, domain and range.', parts: q1parts },
    { stem: 'Use the information shown on each graph to write the equation of the quadratic function it represents.', parts: q2parts }
  ]);

  /* ===== 2.2 Rational functions (ax + b)/(cx + d) ===== */
  // [tex, f, VA [num, den], HA [num, den], plot window]
  const RF = [
    [R`y = \frac{x + 1}{x - 3}`, x => (x + 1) / (x - 3), [3, 1], [1, 1], [-4, 10], [-6, 8], '(x+1)/(x-3)'],
    [R`y = \frac{2x - 5}{x + 4}`, x => (2 * x - 5) / (x + 4), [-4, 1], [2, 1], [-12, 4], [-6, 10], '(2*x-5)/(x+4)'],
    [R`y = \frac{1 - 3x}{2x - 6}`, x => (1 - 3 * x) / (2 * x - 6), [3, 1], [-3, 2], [-4, 10], [-8, 5], '(1-3*x)/(2*x-6)'],
    [R`y = \frac{4}{5 - 2x}`, x => 4 / (5 - 2 * x), [5, 2], [0, 1], [-4, 9], [-6, 6], '4/(5-2*x)'],
    [R`y = \frac{3x + 2}{4 - x}`, x => (3 * x + 2) / (4 - x), [4, 1], [-3, 1], [-4, 12], [-12, 6], '(3*x+2)/(4-x)'],
    [R`y = 3 + \frac{x - 1}{2x + 1}`, x => 3 + (x - 1) / (2 * x + 1), [-1, 2], [7, 2], [-7, 6], [-3, 9], '3+(x-1)/(2*x+1)']
  ];
  const frx = ([n, d]) => d === 1 ? String(n) : (n < 0 ? R`-\frac{${-n}}{${d}}` : R`\frac{${n}}{${d}}`);
  const rfQ = ([tex, f, va, ha, xr, yr, py], i) => {
    const V = frx(va), H = frx(ha), vx = va[0] / va[1], hy = ha[0] / ha[1];
    const why = i === 5 ? [R`Write as one fraction: $3 + \frac{x - 1}{2x + 1} = \frac{3(2x + 1) + x - 1}{2x + 1} = \frac{7x + 2}{2x + 1}$`] : [];
    return { stem: R`Consider the function $${tex}$.`, parts: [
      { c: 'Write down', p: 'the equation of the vertical asymptote, $x = \\dots$, and the equation of the horizontal asymptote, $y = \\dots$, of the graph.', m: 2, h: 'Vertical: where the denominator is 0. Horizontal: what y approaches as x gets very large.', a: { t: [va, ha], l: ['x', 'y'], d: R`x = ${V},\ y = ${H}` },
        ms: [['A1', R`$x = ${V}$`], ['A1', R`$y = ${H}$`]],
        w: why.concat([R`Vertical asymptote where the denominator is $0$: $x = ${V}$.`, ha[0] === 0 ? R`The degree of the numerator is less than the degree of the denominator, so $y \to 0$: horizontal asymptote $y = 0$.` : R`Horizontal asymptote: ratio of the coefficients of $x$, $y = ${H}$.`]),
        kfig: plot({ x: xr, y: yr, step: [1, 1], f: [{ f, from: xr[0], to: vx - 1e-3 }, { f, from: vx + 1e-3, to: xr[1] }], vl: [vx], hl: [hy], alt: 'Graph with its vertical and horizontal asymptotes dashed' }),
        v: `(solve(fraction(together(${py}))[1], x)[0], limit(${py}, x, oo))` },
      { c: 'State', p: 'the domain and range of the function.', m: 2, h: 'Which x-value is not allowed? Which y-value is never reached?', a: { mc: [R`domain $x \neq ${V}$; range $y \neq ${H}$`, R`domain $x \neq ${H}$; range $y \neq ${V}$`, R`domain $x \in \mathbb{R}$; range $y \neq ${H}$`, R`domain $x \neq ${V}$; range $y \in \mathbb{R}$`] },
        ms: [['A1', R`domain $x \in \mathbb{R},\ x \neq ${V}$`], ['A1', R`range $y \in \mathbb{R},\ y \neq ${H}$`]],
        w: [R`The function is undefined at the vertical asymptote: domain $x \neq ${V}$.`, R`The graph never reaches the horizontal asymptote: range $y \neq ${H}$.`], v: mcv(`len(solve(Eq(${py}, limit(${py}, x, oo)), x)) == 0`) }
    ] };
  };
  B('HL', '2C', { page: 89, sec: '2.2', title: 'Rational functions', skill: 'HL-2.2a', paper: 1 }, RF.map(rfQ));
})(window.Hub = window.Hub || {});
