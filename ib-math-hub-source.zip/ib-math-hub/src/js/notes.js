/* Ready-made guided notes ("Key ideas") for each calendar lesson, written for the Hub (original wording; the Oxford
   books were used only to check which topics each section covers). Syntax: "## " heading, "- " bullet, [[answer]] blank
   (alternatives separated by |), maths in $…$ with blanks kept outside the $…$. Keyed by lesson id. */
(function (Hub) {
  'use strict';
  const N = {};
  N['SL-2026-10-29'] = String.raw`## The binomial theorem
- $(a + b)^{n}$ has [[n+1|n + 1]] terms.
- The coefficients come from row $n$ of [[Pascal's triangle|Pascal’s triangle|Pascals triangle|pascal's triangle]], or from $\binom{n}{r}$ (nCr on the NumWorks).
- In every term, the powers of $a$ and $b$ add up to [[n]].
## The general term
- The term containing $b^{r}$ is $\binom{n}{r}a^{n-r}b^{r}$ (formula booklet).
- $r$ starts at 0, so the term in $b^{r}$ is term number [[r+1|r + 1]].
- In $(x + 2)^{6}$ the term in $x^{4}$ has $r =$ [[2]], so its coefficient is $\binom{6}{2} \times 2^{2} =$ [[60]].
- Put the whole term in brackets before using a power: the coefficient of $(-3x)^{2}$ is [[9]].`;
  N['SL-2026-11-04'] = String.raw`## Finding a particular term
- Write the general term, collect the powers of $x$, then solve for [[r]].
- For the constant term (the term independent of $x$), the power of $x$ is [[0|zero]].
- In $\left(x^{2} + \frac{1}{x}\right)^{6}$ the power of $x$ is $2(6 - r) - r = 12 - 3r$, so the constant term has $r =$ [[4]].
## Working backwards
- If a coefficient is given, write an equation in the unknown and solve it.
- The coefficient of $x$ in $(1 + kx)^{5}$ is $5k$. If it equals 15, then $k =$ [[3]].
- An even root gives [[two|2]] possible answers: check conditions such as $k > 0$.
## Estimating with an expansion
- Match the bracket to the number: $(1.02)^{5} = (1 + x)^{5}$ with $x =$ [[0.02]].
- A few terms are enough because powers of a small $x$ quickly become [[very small|small|smaller|tiny]].
- $(1.02)^{5} \approx 1 + 5(0.02) + 10(0.02)^{2} =$ [[1.104]].`;
  N['SL-2026-11-06'] = String.raw`## What a proof does
- A proof shows a statement is true for [[all|every|all values]] values, not just a few examples.
- Trying numbers is not a proof, but one [[counterexample|counter-example|counter example]] is enough to show a statement is false.
## LHS to RHS
- Start from the left-hand side and work step by step until you reach the [[right-hand side|RHS|right hand side]].
- Work on [[one side|one]] at a time: never move terms across the equals sign.
- An even number can be written $2n$; an odd number can be written [[2n+1|2n + 1|2n-1|2n - 1]], where $n \in \mathbb{Z}$.
- The symbol $\equiv$ shows an [[identity]]: true for every value of the variable.
- End with a sentence such as "LHS = RHS, as required". In a markscheme this final line is marked [[AG]] (answer given).`;
  N['SL-2026-11-10'] = String.raw`## Relations and functions
- A relation links inputs to outputs. It is a function when every input has exactly [[one|1]] output.
- One-to-one and [[many-to-one|many to one]] relations are functions; one-to-many relations are not.
- Vertical line test: a graph shows a function if every vertical line meets it at most [[once|one time|1 time]].
## Domain and range
- The set of inputs is the [[domain]]; the set of outputs is the [[range]].
- $x^{2} + y^{2} = 25$ is [[not a function|not]], because $x = 3$ gives $y = 4$ and $y = -4$.`;
  N['SL-2026-11-13'] = String.raw`## Function notation
- $f(x) = 3x - 1$ means "apply $f$ to $x$". So $f(2) =$ [[5]].
- Replace every $x$: $f(a + 1) = 3(a + 1) - 1 =$ [[3a+2|3a + 2]].
- To solve $f(x) = 11$, write $3x - 1 = 11$, so $x =$ [[4]].
## Drawing graphs
- The $y$-intercept is found by putting $x =$ [[0]].
- The $x$-intercepts (zeros) are where $f(x) =$ [[0]].
- On the NumWorks Grapher, use Calculate for zeros, maximum, minimum and intersection points.
- "Draw" means an accurate graph with a scale; [[sketch]] means the shape and the key features, labelled.`;
  N['SL-2026-11-17'] = String.raw`## Natural domain
- You cannot divide by [[zero|0]]: $f(x) = \frac{1}{x - 3}$ has domain $x \ne$ [[3]].
- You cannot take the square root of a [[negative|negative number]]: $\sqrt{x + 2}$ needs $x \ge$ [[-2]].
## Range
- Read the range from the graph: which [[y-values|y values|outputs|y]] does it reach?
- $f(x) = (x - 2)^{2} + 5$ has range $f(x) \ge$ [[5]], because a square is never [[negative]].
- On a restricted domain, check both end points and any turning point between them.
- Write domains and ranges with inequalities, e.g. $-1 \le x < 4$.`;
  N['SL-2026-11-19'] = String.raw`## Composite functions
- $(f \circ g)(x) = f(g(x))$: apply [[g]] first, then $f$.
- With $f(x) = 2x + 1$ and $g(x) = x^{2}$: $(f \circ g)(3) = f(9) =$ [[19]] and $(g \circ f)(3) = g(7) =$ [[49]].
- So $f \circ g$ and $g \circ f$ are usually [[different|not the same|not equal]].
- To find $(f \circ g)(x)$, replace every $x$ in $f$ with the whole of [[g(x)]].
- The domain of $f \circ g$: inputs of $g$ whose outputs are allowed inputs of [[f]].`;
  N['SL-2026-11-30'] = String.raw`## Inverse functions
- $f^{-1}$ undoes $f$: if $f(a) = b$ then $f^{-1}(b) =$ [[a]].
- Only [[one-to-one|one to one]] functions have an inverse function.
- To find $f^{-1}(x)$: write $y = f(x)$, swap [[x and y|y and x]], then make $y$ the subject.
- The graph of $y = f^{-1}(x)$ is the reflection of $y = f(x)$ in the line [[y=x|y = x]].
- The domain of $f^{-1}$ is the [[range]] of $f$.
- $(f \circ f^{-1})(x) =$ [[x]].
- Careful: $f^{-1}(x)$ is not the same as $\frac{1}{f(x)}$.`;
  N['SL-2026-12-04'] = String.raw`## Gradient
- Gradient $m = \frac{y_{2} - y_{1}}{x_{2} - x_{1}}$ (formula booklet).
- The gradient of the line through $(1, 2)$ and $(4, 11)$ is [[3]].
- A positive gradient goes [[up|upwards]] from left to right.
- A horizontal line has gradient [[0|zero]]; the gradient of a vertical line is [[undefined|not defined]].
## Equations of lines
- Gradient–intercept form $y = mx + c$, where $c$ is the [[y-intercept|y intercept]].
- Point–gradient form $y - y_{1} = m(x - x_{1})$.
- General form $ax + by + d = 0$, usually with integer $a$, $b$ and $d$.
- The line through $(2, 5)$ with gradient 3 is $y - 5 = 3(x - 2)$, so $c =$ [[-1]].`;
  N['SL-2026-12-08'] = String.raw`## Parallel and perpendicular lines
- Parallel lines have [[equal|the same]] gradients.
- Perpendicular lines: $m_{1} \times m_{2} =$ [[-1]] (negative reciprocals).
- A line perpendicular to $y = 2x + 5$ has gradient [[-1/2|-0.5]].
## Linear models
- In the model $C = 3.5n + 20$, the gradient 3.5 is the rate of change, and 20 is the [[fixed cost|starting value|initial value|fixed]].
- Where two lines meet: solve simultaneously, or use the NumWorks [[intersection|Intersection]] tool.`;
  N['SL-2026-12-10'] = String.raw`## Translations
- $y = f(x) + k$ moves the graph [[up|upwards]] by $k$.
- $y = f(x - h)$ moves the graph [[right|to the right]] by $h$: watch the sign!
## Reflections
- $y = -f(x)$ reflects in the [[x-axis|x axis]]; $y = f(-x)$ reflects in the [[y-axis|y axis]].
## Stretches
- $y = pf(x)$: vertical stretch with scale factor [[p]].
- $y = f(qx)$: horizontal stretch with scale factor [[$\frac{1}{q}$|1/q|1 / q]].
- The point $(2, 3)$ on $y = f(x)$ moves to a point with $y$-coordinate [[6]] on $y = 2f(x)$.
- When you combine transformations in the same direction, the [[order]] matters.`;
  N['SL-2026-12-14'] = String.raw`## Three forms of a quadratic
- $y = ax^{2} + bx + c$: the $y$-intercept is [[c]], and the axis of symmetry is $x = -\frac{b}{2a}$.
- $y = a(x - h)^{2} + k$: the vertex is $(h, k)$.
- $y = a(x - p)(x - q)$: the $x$-intercepts are [[p and q|p, q|p,q]].
- If $a > 0$, the parabola opens [[upwards|up]] and the vertex is a [[minimum|min]].
- $y = (x - 3)^{2} + 4$ has axis of symmetry $x =$ [[3]].
- $y = 2x^{2} - 8x + 1$ has axis of symmetry $x =$ [[2]].`;
  N['SL-2026-12-16'] = String.raw`## Solving by factorisation
- First rearrange so that one side is [[0|zero]].
- If $AB = 0$ then $A = 0$ or $B =$ [[0]].
- $x^{2} - 5x + 6 = 0 \Rightarrow (x - 2)(x - 3) = 0$, so $x = 2$ or $x =$ [[3]].
- Never divide both sides by $x$: you would lose the solution $x =$ [[0]].
- $x^{2} - 9$ factorises as $(x - 3)$ times [[x+3|(x+3)|x + 3|(x + 3)]].
## Completing the square
- $x^{2} + 6x + 2 = (x + 3)^{2} -$ [[7]].`;
  N['SL-2026-12-18'] = String.raw`## The quadratic formula
- For $ax^{2} + bx + c = 0$: $x = \frac{-b \pm \sqrt{b^{2} - 4ac}}{2a}$ (formula booklet).
- The discriminant is [[b^2-4ac|b²-4ac|b^2 - 4ac|b² - 4ac]].
## The discriminant
- $\Delta > 0$: two distinct real roots. $\Delta = 0$: [[equal roots|two equal roots|one repeated root|repeated root|one root|equal]]. $\Delta < 0$: [[no real roots|none|no roots]].
- For $x^{2} + 4x + k = 0$ to have equal roots, $16 - 4k = 0$, so $k =$ [[4]].
- Always write the equation as $ax^{2} + bx + c = 0$ [[before|first]] finding $\Delta$.`;
  N['HL-2026-10-29'] = String.raw`## Functions
- A function maps every element of its domain to exactly [[one|1]] element of its range.
- Vertical line test: every vertical line meets the graph of a function at most [[once|one time|1 time]].
- $f: x \mapsto 2x + 1$ means $f(x) =$ [[2x+1|2x + 1]].
## Domain and range
- $x \in [2, 5)$ means $2 \le x$ and $x$ [[<|less than]] 5.
- $f(x) = \frac{1}{\sqrt{x - 1}}$ has domain $x >$ [[1]].
- $f(x) = x^{2} - 4$, $x \in \mathbb{R}$, has range $f(x) \ge$ [[-4]].`;
  N['HL-2026-11-04'] = String.raw`## Quadratic functions
- The vertex of $y = ax^{2} + bx + c$ is at $x = -\frac{b}{2a}$. The graph is concave up when $a$ is [[positive|>0|> 0]].
- $f(x) = 2(x + 1)^{2} - 3$ has range $f(x) \ge$ [[-3]].
## Rational functions
- For $f(x) = \frac{ax + b}{cx + d}$: vertical asymptote $x = -\frac{d}{c}$, horizontal asymptote $y = \frac{a}{c}$.
- $f(x) = \frac{2x + 1}{x - 3}$: vertical asymptote $x =$ [[3]], horizontal asymptote $y =$ [[2]].
- So the range of that function is $y \ne$ [[2]].
## Radical functions
- $y = \sqrt{x}$ needs $x \ge$ [[0]], and its outputs are never [[negative]].
- $y = 2\sqrt{x - 1} + 3$ starts at the point with $y$-coordinate [[3]].`;
  N['HL-2026-11-06'] = String.raw`## Absolute value
- $|x| = x$ when $x \ge 0$, and $|x| =$ [[-x]] when $x < 0$.
- $|x - 3|$ is the [[distance]] between $x$ and 3 on the number line.
- $|2x - 1| = 5$: solve $2x - 1 = 5$ and $2x - 1 =$ [[-5]], so $x = 3$ or $x =$ [[-2]].
- When the other side contains $x$ (e.g. $|x + 1| = 2x - 5$), [[check|substitute back|check your answers]] every answer: some fail.
- $|x| < a$ means $-a < x < a$; $|x| > a$ means $x < -a$ or $x >$ [[a]].
## Piecewise functions
- Different rules apply on different parts of the domain.
- The graph is continuous at a join when both pieces give the [[same|same value|same y-value]] there.
## Rational functions
- If the degree of the numerator is less than the degree of the denominator, the horizontal asymptote is $y =$ [[0]].`;
  N['HL-2026-11-10'] = String.raw`## One-to-one and many-to-one
- One-to-one: every output comes from exactly one input. Test with a [[horizontal|horizontal line]] line.
- $f(x) = x^{2}$, $x \in \mathbb{R}$, is [[many-to-one|many to one]].
- Only one-to-one functions have an [[inverse|inverse function]].
## Onto
- A function is onto when its range equals its [[codomain|co-domain]].
## Odd and even
- Even: $f(-x) =$ [[f(x)]]; the graph is symmetrical in the $y$-axis.
- Odd: $f(-x) =$ [[-f(x)]]; the graph has rotational symmetry of order 2 about the [[origin]].
- $x^{3} - 4x$ is [[odd]]; $x^{4} + x^{2}$ is [[even]]; $x^{2} + x$ is [[neither]].`;
  N['HL-2026-11-13'] = String.raw`## Composite functions
- $(f \circ g)(x) = f(g(x))$: $g$ acts [[first]].
- $f \circ g$ exists only where the range of $g$ lies inside the [[domain]] of $f$.
- With $f(x) = \sqrt{x}$ and $g(x) = x - 4$: $(f \circ g)(x) = \sqrt{x - 4}$, with domain $x \ge$ [[4]].
- $f \circ g$ and $g \circ f$ are usually [[different|not equal|not the same]].
- The identity function $I(x) = x$ leaves $f$ unchanged: $(f \circ I)(x) =$ [[f(x)]].`;
  N['HL-2026-11-17'] = String.raw`## Inverse functions
- $f^{-1}$ exists only when $f$ is [[one-to-one|one to one|bijective]]; restrict the domain if you need to.
- $(f \circ f^{-1})(x) = (f^{-1} \circ f)(x) =$ [[x]].
- Method: $y = f(x)$, interchange $x$ and $y$, then solve for [[y]].
- $f(x) = 2x - 3$ gives $f^{-1}(x) = \frac{x + 3}{2}$, so $f^{-1}(7) =$ [[5]].
- The domain of $f^{-1}$ is the [[range]] of $f$, and the range of $f^{-1}$ is the domain of $f$.
- The graphs of $f$ and $f^{-1}$ are reflections in the line [[y=x|y = x]].
- A self-inverse function has $f^{-1}(x) =$ [[f(x)]], for example $f(x) = \frac{1}{x}$.`;
  N['HL-2026-11-19'] = String.raw`## Translations
- $y = f(x) + k$: vertical translation by [[k]] units.
- $y = f(x - h) + k$ is a translation by the vector $\begin{pmatrix} h \\ k \end{pmatrix}$.
## Dilations
- $y = pf(x)$: vertical stretch with scale factor [[p]].
- $y = f(qx)$: horizontal stretch with scale factor [[$\frac{1}{q}$|1/q|1 / q]].
## Reflections
- $y = -f(x)$ reflects in the [[x-axis|x axis]]; $y = f(-x)$ reflects in the [[y-axis|y axis]].
- Changes inside the bracket act on $x$ "backwards": $(4, 2)$ on $y = f(x)$ goes to the point with $x$-coordinate [[2]] on $y = f(2x)$.`;
  N['HL-2026-11-30'] = String.raw`## The graph of $y = |f(x)|$
- Keep the parts on or above the $x$-axis; reflect the parts below it in the [[x-axis|x axis]].
- The graph of $y = |f(x)|$ never goes [[below the x-axis|below|negative]].
## The graph of $y = f(|x|)$
- Keep the graph for $x \ge 0$ and reflect it in the [[y-axis|y axis]]. The result is an [[even]] function.
## The graph of $y = \frac{1}{f(x)}$
- Zeros of $f$ become [[vertical asymptotes|vertical asymptote|asymptotes]].
- Where $f(x) = 1$ or $f(x) = -1$, the two graphs [[meet|intersect|cross|touch]].
- A positive maximum of $f$ becomes a [[minimum]] of $\frac{1}{f(x)}$.
- As $f(x) \to \pm\infty$, $\frac{1}{f(x)} \to$ [[0]].`;
  N['HL-2026-12-14'] = String.raw`## Quadratic equations
- Solve by factorising, completing the square, the quadratic formula, or the NumWorks [[Equations|equations|solver]] app.
- Two distinct real roots when $\Delta$ is [[positive|>0|> 0]]; equal roots when $\Delta = 0$; no real roots when $\Delta < 0$.
## Quadratic inequalities
- Solve the equation first to find the [[critical values|roots|zeros]], then sketch the parabola.
- $x^{2} - x - 6 < 0$: the roots are $-2$ and 3, and the parabola is below the axis between them, so [[-2<x<3|-2 < x < 3]].
- $x^{2} - x - 6 \ge 0$: $x \le -2$ or $x \ge$ [[3]].
- $kx^{2} + 4x + 1 = 0$ has no real roots when $16 - 4k < 0$, so $k >$ [[4]].`;
  N['HL-2026-12-16'] = String.raw`## The imaginary unit
- $i^{2} =$ [[-1]], so $\sqrt{-9} =$ [[3i]].
- In Cartesian form $z = a + bi$: the real part is $a$ and the imaginary part is [[b]] (not $bi$).
- $\text{Im}(3 - 4i) =$ [[-4]].
## Arithmetic with complex numbers
- Add and subtract the real parts and the imaginary parts [[separately]].
- $(2 + 3i)(1 - i) = 2 - 2i + 3i - 3i^{2} =$ [[5+i|5 + i]].
- The modulus $|a + bi| = \sqrt{a^{2} + b^{2}}$, so $|3 + 4i| =$ [[5]].
- Two complex numbers are equal when their real parts are equal and their [[imaginary parts|imaginary]] parts are equal.
- Powers of $i$ repeat every [[4]] powers: $i^{3} = -i$, $i^{4} = 1$.`;
  N['HL-2026-12-18'] = String.raw`## Conjugates
- The conjugate of $z = a + bi$ is $z^{*} = a - bi$.
- $zz^{*} = a^{2} + b^{2}$, which is always [[real|a real number]].
- $(3 + 2i)(3 - 2i) =$ [[13]].
## Division
- To divide, multiply the top and bottom by the conjugate of the [[denominator|bottom]].
- $\frac{5}{1 + 2i} = \frac{5(1 - 2i)}{5} =$ [[1-2i|1 - 2i]].
## Complex roots of quadratics
- When $\Delta < 0$, the roots are complex and come in [[conjugate pairs|conjugate pair|conjugates]].
- $x^{2} + 2x + 5 = 0$ gives $x = \frac{-2 \pm \sqrt{-16}}{2} = -1 \pm$ [[2i]].`;
  Hub.guidedNotes = { text: id => N[id] || '', has: id => !!N[id], ids: () => Object.keys(N) };
})(window.Hub = window.Hub || {});
