/* Shared views: Course & pacing, Data & settings. (The IA Studio is in js/ia.js.) */
(function (Hub) {
  'use strict';
  const { esc, $, $$, fmtDate, fmtDateTime, toast, download, debounce, daysBetween, todayISO } = Hub.core;
  const U = Hub.ui, C = () => Hub.curriculum, S = () => Hub.store.state, M = t => Hub.math.render(t);
  const go = h => Hub.app.nav(h);

  // The IA Studio lives in js/ia.js (Hub.ia).

  /* ================= Course & pacing ================= */
  function course(main, params) {
    const teacher = Hub.auth.role() === 'teacher', me = Hub.roster.byId(Hub.auth.sid());
    const group = teacher ? params.group || Hub.teacher.pref('group') || 'HL-A' : me.group, g = C().GROUPS[group], asOf = Hub.mastery.asOf(), view = params.view || 'upcoming';
    let rows = C().lessons(group); if (view === 'upcoming') rows = rows.filter(l => l.date >= asOf).slice(0, 20); if (view === 'tests') rows = rows.filter(l => l.kind === 'test'); if (view === 'ia') rows = rows.filter(l => l.ia || l.kind === 'ia');
    const ox = C().OXFORD[g.course];
    main.innerHTML = U.heading('YOUR COURSE COMPASS', teacher ? 'Course & pacing' : 'My calendar', `${C().COURSES[g.course]} · ${g.label} · ${g.block}`, teacher ? Hub.teacher.groupPick('c-group', group) : '') +
      `<div class="tabs">${[['upcoming', 'Upcoming'], ['all', 'Whole year'], ['tests', 'Tests'], ['ia', 'IA']].map(([k, l]) => `<a class="tab ${k === view ? 'on' : ''}" href="#/course?group=${group}&view=${k}">${l}</a>`).join('')}</div>
      <section class="card cal">${rows.map(l => `<div class="cal-row ${l.kind} ${l.date < asOf ? 'past' : ''} ${l.date === asOf ? 'today' : ''}"><div class="cal-date"><b>${fmtDate(l.date)}</b><span class="tiny">${l.day} day</span></div><div class="cal-body"><p>${esc(l.activity)}</p>${l.skills.length ? `<div class="chips">${l.skills.map(s => U.skillChip(s)).join('')}${l.kind !== 'test' ? l.skills.map(s => { const o = ox[C().SKILL[s].ox]; return o ? `<span class="tiny muted">Oxford ${C().SKILL[s].ox}, p.${o[1]}</span>` : ''; }).filter((v, i, a) => v && a.indexOf(v) === i).join(' ') : ''}</div>` : ''}</div>${l.kind !== 'lesson' ? `<span class="pill ${l.kind === 'test' ? 'red' : l.kind === 'ia' ? 'amber' : 'grey'}">${l.kind === 'test' ? 'Test' : l.kind === 'ia' ? 'IA' : l.kind === 'none' ? 'No class' : 'Review'}</span>` : l.ia ? '<span class="pill amber">+ IA</span>' : ''}</div>`).join('') || U.empty('No rows.')}</section>
      <p class="tiny muted">Source: 2026–27 ${g.course === 'HL' ? 'Analysis HL1 Pacing Calendar' : 'SL Year 1 Pacing Calendar'} (first sheet), ${g.day} day rows. “Today” is ${fmtDate(asOf, true)}${S().settings.asOf ? ' (planning date set in Data & settings)' : ''}.</p>
      ${teacher ? `<section class="card"><h2 class="bar-head green">Course map & question bank</h2><p class="small">Units follow the Oxford ${g.course} chapter order (mapping only — no textbook questions are reproduced). Each skill has original question families with markschemes.</p>${C().UNITS[g.course].map(([u, name]) => { const sk = C().skillsFor(g.course).filter(s => s.unit === u); return `<details class="unit-d" ${u <= 2 ? 'open' : ''}><summary class="unit-h ${U.unitColour(u)}">Unit ${u} · ${esc(name)} <span class="tiny">${sk.length ? sk.length + ' skills' : 'Year 2 / later'}</span></summary>${sk.map(s => { const gens = s.gens.map(id => Hub.qcore.registry[id]).filter(Boolean); const o = s.ox && ox[s.ox]; return `<div class="skill-row"><span>${U.skillLabel(s.id)}</span><span class="tiny muted">${o ? `Oxford ${s.ox} ${esc(o[0])}, p.${o[1]}` : ''}</span><span class="tiny">${gens.map(x => `${esc(x.title)} · P${x.paper}${x.challenge ? ' · challenge' : ''}`).join('<br>')}</span><span class="tiny muted">${C().taughtDate(s.id, group) ? (C().isTaught(s.id, group, asOf) ? 'taught ' : 'from ') + fmtDate(C().taughtDate(s.id, group)) : ''}</span></div>`; }).join('')}</details>`; }).join('')}</section>` : ''}`;
    const cg = $('#c-group'); if (cg) cg.onchange = e => { Hub.teacher.pref('group', e.target.value); go('#/course?group=' + e.target.value + '&view=' + view); };
  }

  /* ================= Data & settings ================= */
  function settings(main) { main.textContent="Loading cloud settings…"; }
  Hub.shared = Object.assign(Hub.shared || {}, { course, settings });
})(window.Hub = window.Hub || {});
