/* Verified Supabase sessions. Roles are returned by the backend, never chosen in the browser. */
(function(Hub){
 'use strict';let session=null;
 async function init(){const {data,error}=await Hub.cloud.client.auth.getSession();if(error)throw error;if(!data.session)return false;const r=await Hub.cloud.call('load');session=r.session;Hub.store.accept(r.state);return true;}
 async function signIn(email,password){const {error}=await Hub.cloud.client.auth.signInWithPassword({email:Hub.cloud.loginEmail(email),password});if(error)throw Error(/invalid login/i.test(error.message)?'That username (or email) and password do not match. Forgot your password? Ask Miss Badmus to reset your login.':error.message);await init();}
 async function signOut(){await Hub.store.flush();const {error}=await Hub.cloud.client.auth.signOut();if(error)throw error;session=null;Hub.store.clear();}
 const current=()=>session;
 const isTeacher=()=>session?.role==='teacher';
 const isPreview=()=>!!(isTeacher()&&session.viewAs);
 const sid=()=>isTeacher()?session.viewAs||null:session?.sid||null;
 const role=()=>isPreview()?'student':session?.role;
 function viewAs(id){if(isTeacher())session.viewAs=id||null;}
 Hub.auth={init,signIn,signOut,current,isTeacher,isPreview,sid,role,viewAs,who:()=>session?.name||'system'};
})(window.Hub=window.Hub||{});
