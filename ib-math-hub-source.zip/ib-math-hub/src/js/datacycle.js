/* Data cycle (#/datacycle): the PLC goal "at least 60% of students hold a predicted grade of 4+ on IB-aligned assessments".
   Predicted grade = average of a student's Tests, Quizzes, Retests and Exit Tickets so far (a retest replaces the original when higher),
   converted to an IB grade with the teacher's own SL / HL boundaries. Counted month by month, September to May,
   as "students at 4+ / students assessed" — the format of the school data sheet. Test students never count. */
(function (Hub) {
  'use strict';
  const { esc, $, $$, toast, fmtDate } = Hub.core;
  const U = Hub.ui, S = () => Hub.store.state;
  const COUNTED = ['Test', 'Quiz', 'Retest', 'Exit Ticket'];
  const COURSES = ['SL', 'HL'];
  const MONTHS = ['September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May'];
  const DEF_GOAL = 'By May 2027, at least 60% of IB Mathematics: Analysis & Approaches students (SL and HL) will hold a predicted grade of 4 or higher on BRHS IB DP-aligned assessments, measured monthly using the latest IB grade boundaries.';
  const DEF_ACTION = 'Each month, IB math teachers convert common assessment scores to IB grades, identify every student predicted below a 4, and give them targeted reteaching and a retest or personalised Do Now within two weeks. Results are logged on the PLC data sheet.';
  const cfg = () => { const st = S(); st.settings.dataCycle = st.settings.dataCycle || {}; const c = st.settings.dataCycle; c.bounds = c.bounds || { SL: {}, HL: {} }; return c; };
  const view0 = () => (S().settings || {}).dataCycle || {};
  const target = () => +(view0().target || 60), cut = () => +(view0().grade || 4);
  const bounds = c => ((view0().bounds || {})[c]) || {};
  const DEFW = { 'Test': 3, 'Retest': 3, 'Quiz': 2, 'Exit Ticket': 1 };
  const weight = type => { const w = (view0().weights || {})[type]; return w === undefined || w === null || isNaN(+w) ? DEFW[type] : Math.max(0, +w); };
  /** Boundaries are usable when grades 2–7 all have a cut-off and they go up. */
  function boundsOK(c) { const b = bounds(c), v = [2, 3, 4, 5, 6, 7].map(g => b[g]); return v.every(x => x !== '' && x !== undefined && x !== null && !isNaN(+x)) && v.every((x, i) => i === 0 || +x > +v[i - 1]); }
  function toGrade(pct, c) { const b = bounds(c); let g = 1; for (let k = 2; k <= 7; k++) if (pct >= +b[k]) g = k; return g; }

  /** The school year's months, with the date each is counted up to (month end, today for the current month, null for future months). */
  function months() {
    const today = Hub.mastery.asOf(), y = +today.slice(0, 4), m = +today.slice(5, 7), start = m >= 8 ? y : y - 1;
    return MONTHS.map((name, i) => { const mm = ((8 + i) % 12) + 1, yy = mm >= 8 ? start : start + 1, first = `${yy}-${String(mm).padStart(2, '0')}-01`;
      const last = new Date(Date.UTC(yy, mm, 0)).toISOString().slice(0, 10);
      return { name, short: name.slice(0, 3), first, upTo: first > today ? null : (last < today ? last : today), current: first <= today && last >= today };
    });
  }
  /** A student's counted scores up to a date: one per assessment (retest replaces the original when higher), each with its type's weight. */
  function scores(sid, upTo) {
    const best = {};
    for (const t of S().attempts) {
      if (t.sid !== sid || String(t.at || '').slice(0, 10) > upTo) continue;
      const a = Hub.assess.byId(t.aid) || t.inline; if (!a || !COUNTED.includes(a.type)) continue;
      const p = Hub.assess.score(t).capped; if (p === null || p === undefined || isNaN(p)) continue;
      const orig = a.retestOf ? Hub.assess.byId(a.retestOf) : null, w = weight(orig ? orig.type : a.type);
      const key = a.retestOf || a.id || t.aid; if (best[key] === undefined || p > best[key].p) best[key] = { p, w };
    }
    return Object.values(best).filter(x => x.w > 0);
  }
  function predicted(s, upTo) { const v = scores(s.id, upTo); if (!v.length) return null; const W = v.reduce((a, x) => a + x.w, 0); const pct = Math.round(v.reduce((a, x) => a + x.p * x.w, 0) / W); return { pct, n: v.length, grade: boundsOK(s.course) ? toGrade(pct, s.course) : null }; }
  /** Paper 1 (no calculator) vs Paper 2 (calculator): % of marks earned on counted work up to a date, by course. */
  function papers(course, upTo) {
    const ids = new Set(Hub.roster.inCourse(course).map(s => s.id)), out = { 1: { e: 0, m: 0, q: 0 }, 2: { e: 0, m: 0, q: 0 } };
    for (const t of S().attempts) {
      if (!ids.has(t.sid) || String(t.at || '').slice(0, 10) > upTo || !t.auto || !t.auto.parts) continue;
      const a = Hub.assess.byId(t.aid) || t.inline; if (!a || !COUNTED.includes(a.type)) continue;
      for (const q of a.questions || []) { const pp = +q.paper; if (pp !== 1 && pp !== 2) continue; let used = false;
        for (const part of q.parts || []) { const k = q.id + '|' + part.id, r = t.auto.parts[k]; if (!r) continue; const fin = t.final && t.final.parts ? t.final.parts[k] : undefined;
          if (r.verdict === 'teacher' && fin === undefined) continue; out[pp].e += +(fin ?? r.earned) || 0; out[pp].m += +part.marks || 0; used = true; }
        if (used) out[pp].q++; }
    }
    [1, 2].forEach(k => { out[k].pct = out[k].m ? Math.round(100 * out[k].e / out[k].m) : null; });
    return out;
  }
  function paperCard(upTo) {
    const row = (c) => { const r = papers(c, upTo), d = r[1].pct !== null && r[2].pct !== null ? r[1].pct - r[2].pct : null;
      return `<div class="pp-row"><b>AA ${c}</b>${[1, 2].map(k => `<div class="pp-cell"><span class="tiny">Paper ${k} ${k === 1 ? '· no calculator' : '· calculator'}</span><span class="pp-n">${r[k].pct === null ? '—' : r[k].pct + '%'}</span>${U.bar(r[k].pct, r[k].pct !== null && r[k].pct < 60 ? 'low' : '')}<span class="tiny muted">${r[k].q} question${r[k].q === 1 ? '' : 's'} answered</span></div>`).join('')}
        <p class="tiny pp-gap">${d === null ? 'Not enough marked work on both papers yet.' : Math.abs(d) < 5 ? 'About the same on both papers.' : d < 0 ? `<b>${-d} points weaker without a calculator.</b>` : `<b>${d} points weaker with the calculator.</b>`}</p></div>`; };
    return `<section class="card"><h2 class="bar-head amber">Paper 1 vs Paper 2</h2>${row('SL')}${row('HL')}<p class="tiny muted">% of marks earned on questions tagged Paper 1 or Paper 2 in marked Tests, Quizzes, Retests and Exit Tickets so far.</p></section>`;
  }
  /** {at, of, pct, below:[{s,p}], all:[{s,p}]} for a course ('SL', 'HL' or 'ALL') up to a date. */
  function count(course, upTo) {
    const studs = (course === 'ALL' ? COURSES.flatMap(c => Hub.roster.inCourse(c)) : Hub.roster.inCourse(course));
    const all = studs.map(s => ({ s, p: predicted(s, upTo) })).filter(x => x.p && x.p.grade !== null);
    const at = all.filter(x => x.p.grade >= cut()).length;
    return { at, of: all.length, pct: all.length ? Math.round(100 * at / all.length) : null, below: all.filter(x => x.p.grade < cut()), all, notAssessed: studs.length - studs.filter(s => predicted(s, upTo)).length };
  }
  const cell = r => r && r.of ? `${r.at}/${r.of}` : '';
  const tone = p => p === null ? '' : p >= target() ? 'green' : p >= target() - 15 ? 'amber' : 'red';

  function chart(rowsBy, ms) {
    const W = 560, H = 200, L = 34, B = 26, bw = (W - L - 10) / ms.length, y = v => H - B - (H - B - 10) * v / 100, ty = y(target());
    const cols = { SL: 'var(--orange)', HL: 'var(--blue, #9FC5E8)' };
    const bars = ms.map((m, i) => COURSES.map((c, j) => { const r = rowsBy[c][i]; if (!r || r.pct === null) return ''; const x = L + i * bw + 6 + j * ((bw - 12) / 2), w = (bw - 14) / 2; return `<rect x="${x}" y="${y(r.pct)}" width="${w}" height="${H - B - y(r.pct)}" rx="4" fill="${cols[c]}" stroke="var(--ink)" stroke-width="1.5"><title>${c} ${m.name}: ${r.pct}% (${cell(r)})</title></rect>`; }).join('')).join('');
    const labels = ms.map((m, i) => `<text x="${L + i * bw + bw / 2}" y="${H - 8}" text-anchor="middle" font-size="12" fill="var(--ink)">${m.short}</text>`).join('');
    const grid = [0, 50, 100].map(v => `<text x="${L - 6}" y="${y(v) + 4}" text-anchor="end" font-size="11" fill="var(--ink)">${v}%</text><line x1="${L}" x2="${W - 6}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line)"/>`).join('');
    return `<svg class="dc-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Percentage of students at grade ${cut()} or higher, by month">${grid}<line x1="${L}" x2="${W - 6}" y1="${ty}" y2="${ty}" stroke="#D93025" stroke-width="2" stroke-dasharray="6 4"/><text x="${W - 8}" y="${ty - 5}" text-anchor="end" font-size="11" fill="#D93025">target ${target()}%</text>${bars}${labels}</svg>
      <div class="dc-key tiny"><span><i style="background:var(--orange)"></i>SL</span><span><i style="background:var(--blue, #9FC5E8)"></i>HL</span></div>`;
  }


  const PLAN = ['Not started', 'Reteach planned', 'Retest set', 'Improved'];
  /** Intervention tab: every student predicted below the cut, what they struggled with, and a plan you can record. */
  function intervention(main, tabs, ok, ms, lastI) {
    const head = U.heading('PLC GOAL · ACTION STEP', 'Intervention', `Students predicted below a ${cut()}, the skills they are struggling with and the misconceptions their wrong answers show.`, `<button class="btn" id="iv-print" type="button">Print plan</button>`, ) + tabs;
    if (!ok || lastI < 0) { main.innerHTML = head + '<section class="card"><p>Enter your grade boundaries on the Overview tab first.</p></section>'; return; }
    const r = count('ALL', ms[lastI].upTo), list = r.below.slice().sort((p, q) => p.p.pct - q.p.pct), today = Hub.mastery.asOf(), since = Hub.core.addDays(today, -56);
    const plans = (view0().plans) || {}, fbOf = {};
    S().attempts.forEach(t => t.auto && t.auto.parts && Object.values(t.auto.parts).forEach(r => { if (r && r.tag && r.feedback && !fbOf[r.tag]) fbOf[r.tag] = r.feedback; }));
    const info = list.map(({ s, p }) => {
      const sk = Hub.mastery.studentSkills(s.id).filter(x => x.taught && x.pct !== null && x.status !== 'low-evidence').sort((a, b) => a.pct - b.pct);
      const weak = sk.filter(x => x.pct < 60).slice(0, 4), weakest = weak.length ? weak : sk.slice(0, 2);
      const mis = {}; S().evidence.forEach(e => { if (e.sid === s.id && !e.preview && e.date >= since) (e.tags || []).forEach(t => { const k = e.skill + '|' + t; mis[k] = mis[k] || { skill: e.skill, tag: t, n: 0 }; mis[k].n++; }); });
      const need = Math.max(0, Math.ceil(+bounds(s.course)[cut()] - p.pct));
      return { s, p, weakest, mis: Object.values(mis).sort((a, b) => b.n - a.n).slice(0, 4), need };
    });
    const agg = (pick, key) => { const o = {}; info.forEach(x => pick(x).forEach(it => { const k = key(it); o[k] = o[k] || { it, who: [] }; if (!o[k].who.includes(x.s)) o[k].who.push(x.s); })); return Object.values(o).sort((a, b) => b.who.length - a.who.length).slice(0, 8); };
    const skillGroups = agg(x => x.weakest.filter(k => k.pct < 60), k => k.skill), misGroups = agg(x => x.mis, m => m.skill + '|' + m.tag);
    const names = who => who.map(s => `<a href="#/student/${encodeURIComponent(s.id)}">${esc(s.name)}</a>`).join(', ');
    const card = x => { const pl = plans[x.s.id] || {};
      return `<section class="card iv-card"><div class="row-between"><h3 class="iv-name"><a href="#/student/${encodeURIComponent(x.s.id)}">${esc(x.s.name)}</a></h3><span class="tiny muted">${esc((Hub.curriculum.GROUPS[x.s.group] || {}).label || x.s.group)}</span></div>
        <div class="rd-stats"><div><b>${x.p.pct}%</b><span>average</span></div><div><b>${x.p.grade}</b><span>predicted</span></div><div><b>+${x.need}%</b><span>to reach a ${cut()}</span></div></div>
        <p class="small"><b>Struggling with</b></p>${x.weakest.length ? `<ul class="iv-list">${x.weakest.map(k => `<li>${esc(U.skillName(k.skill))} <span class="tiny muted">${k.pct}%</span>${U.bar(k.pct, k.pct < 60 ? 'low' : '')}</li>`).join('')}</ul>` : '<p class="tiny muted">Not enough marked work per skill yet.</p>'}
        <p class="small"><b>Misconceptions seen</b> <span class="tiny muted">(last 8 weeks)</span></p>${x.mis.length ? `<ul class="iv-list">${x.mis.map(m => `<li><b>${esc(Hub.mastery.tagText(m.tag))}</b> <span class="tiny muted">in ${esc(U.skillName(m.skill))}${m.n > 1 ? ` · ${m.n} times` : ''}</span>${fbOf[m.tag] ? `<br><span class="tiny">Fix: ${esc(fbOf[m.tag])}</span>` : ''}</li>`).join('')}</ul>` : '<p class="tiny muted">No known misconceptions matched — check their working in Marking.</p>'}
        <div class="iv-plan no-print-ctl"><label>Plan<select data-ivs="${esc(x.s.id)}">${PLAN.map(o => `<option${(pl.status || PLAN[0]) === o ? ' selected' : ''}>${o}</option>`).join('')}</select></label>
        <label>Notes<textarea data-ivn="${esc(x.s.id)}" rows="2" placeholder="e.g. small-group reteach Tue, retest Fri">${esc(pl.note || '')}</textarea></label>
        <div class="actions"><button class="btn small" data-ivsave="${esc(x.s.id)}" type="button">Save plan</button><a class="btn small ghost" href="#/student/${encodeURIComponent(x.s.id)}">Student record</a>${pl.at ? `<span class="tiny muted">saved ${fmtDate(String(pl.at).slice(0, 10))}</span>` : ''}</div></div></section>`; };
    main.innerHTML = head + `<div class="dc-bigs"><div class="dc-big ${list.length ? 'red' : 'green'}"><span class="key-lab">Below a ${cut()} · ${esc(ms[lastI].name)}</span><b>${list.length}</b><span class="small">of ${r.of} assessed students</span></div>
      <div class="dc-big"><span class="key-lab">Plans started</span><b>${list.filter(x => (plans[x.s.id] || {}).status && plans[x.s.id].status !== PLAN[0]).length}</b><span class="small">of ${list.length}</span></div>
      <div class="dc-big green"><span class="key-lab">Marked improved</span><b>${list.filter(x => (plans[x.s.id] || {}).status === 'Improved').length}</b><span class="small">still below on current data</span></div></div>
      ${list.length ? `<div class="grid g2"><section class="card"><h2 class="bar-head amber">Small groups: skills to reteach</h2>${skillGroups.length ? skillGroups.map(g => `<div class="miss-item"><b>${esc(U.skillName(g.it.skill))}</b> <span class="pill">${g.who.length}</span><p class="miss-names">${names(g.who)}</p></div>`).join('') : '<p class="tiny muted">No skill below 60% yet for these students.</p>'}</section>
      <section class="card"><h2 class="bar-head pink">Common misconceptions</h2>${misGroups.length ? misGroups.map(g => `<div class="miss-item"><b>${esc(Hub.mastery.tagText(g.it.tag))}</b> <span class="tiny muted">${esc(U.skillName(g.it.skill))}</span> <span class="pill">${g.who.length}</span><p class="miss-names">${names(g.who)}</p></div>`).join('') : '<p class="tiny muted">No known misconceptions matched for these students yet.</p>'}
        <p class="tiny muted">Detected automatically when a wrong answer matches a known error.</p></section></div>
      <h2 class="sub-h">Each student</h2><div class="grid g2 iv-grid">${info.map(card).join('')}</div>` : `<section class="card"><p class="gc-ok">✓ No students are predicted below a ${cut()} right now.</p></section>`}
      <p class="tiny muted">Skills and misconceptions use all marked work, homework included; the predicted grade uses Tests, Quizzes, Retests and Exit Tickets only.</p>`;
    $('#iv-print').onclick = () => window.print();
    $$('[data-ivsave]', main).forEach(b => (b.onclick = async () => { const id = b.dataset.ivsave, c = cfg(); c.plans = c.plans || {};
      c.plans[id] = { status: $(`[data-ivs="${id}"]`, main).value, note: $(`[data-ivn="${id}"]`, main).value.trim().slice(0, 2000), at: new Date().toISOString() };
      Hub.store.save(true); try { await Hub.store.flush(); toast('Plan saved.'); } catch (e) { toast(e.message, 'error'); } Hub.app.render(); }));
  }
  function view(main, params = {}) {
    if (Hub.donow && Hub.donow.relabel) Hub.donow.relabel();
    const ms = months(), ok = COURSES.every(boundsOK), C = view0();
    const rowsBy = {}; ['SL', 'HL', 'ALL'].forEach(c => { rowsBy[c] = ms.map(m => m.upTo && ok ? count(c, m.upTo) : null); });
    const nowI = ms.findIndex(m => m.current), lastI = nowI >= 0 ? nowI : ms.map(m => !!m.upTo).lastIndexOf(true), now = c => lastI >= 0 ? rowsBy[c][lastI] : null;
    const big = (label, r) => `<div class="dc-big ${r ? tone(r.pct) : ''}"><span class="key-lab">${label}</span><b>${r && r.pct !== null ? r.pct + '%' : '—'}</b><span class="small">${r && r.of ? `${r.at} of ${r.of} students at ${cut()}+` : 'no assessed students yet'}</span></div>`;
    const monthName = lastI >= 0 ? ms[lastI].name : '';
    const nBelow = ok && now('ALL') ? now('ALL').below.length : 0;
    const tabs = `<div class="tabs no-print"><a class="tab ${params.tab === 'intervention' ? '' : 'on'}" href="#/datacycle">Overview</a><a class="tab ${params.tab === 'intervention' ? 'on' : ''}" href="#/datacycle?tab=intervention">Intervention${nBelow ? ` (${nBelow})` : ''}</a></div>`;
    if (params.tab === 'intervention') return intervention(main, tabs, ok, ms, lastI);
    if (params.present) {
      main.innerHTML = `<div class="row-between no-print"><a class="back" href="#/datacycle">← Data cycle</a><button class="btn small" id="dc-print" type="button">Print / save as PDF</button></div>
        <section class="dc-present">${U.heading('IB MATH · PLC DATA CYCLE', 'IB Maths: Analysis & Approaches', esc(monthName ? `Predicted grades as of ${fmtDate(ms[lastI].upTo, true)}` : ''))}
        <div class="card dc-goal"><h2 class="bar-head pink">Goal</h2><p>${esc(C.goal || DEF_GOAL)}</p></div>
        <div class="dc-bigs">${big('AA SL', now('SL'))}${big('AA HL', now('HL'))}${big('All IB AA', now('ALL'))}</div>
        <div class="card"><h2 class="bar-head blue">Month by month</h2>${ok ? chart(rowsBy, ms) : '<p class="tiny muted">Grade boundaries not set yet.</p>'}</div>
        ${lastI >= 0 ? paperCard(ms[lastI].upTo) : ''}
        <div class="card"><h2 class="bar-head green">Action step</h2><p>${esc(C.action || DEF_ACTION)}</p>${ok && now('ALL') ? `<p class="small"><b>${now('ALL').below.length}</b> student${now('ALL').below.length === 1 ? '' : 's'} currently predicted below a ${cut()} (${now('SL').below.length} SL, ${now('HL').below.length} HL) for targeted reteaching and retests.</p>` : ''}</div></section>`;
      $('#dc-print').onclick = () => window.print(); return;
    }
    const brow = c => { const b = bounds(c); return `<tr><th>${c}</th>${[2, 3, 4, 5, 6, 7].map(g => `<td><input class="dc-b" data-c="${c}" data-g="${g}" type="number" min="0" max="100" inputmode="numeric" value="${b[g] ?? ''}" aria-label="${c} grade ${g} lowest %"></td>`).join('')}</tr>`; };
    const table = `<div class="scroll"><table class="tbl dc-tbl"><thead><tr><th></th>${ms.map(m => `<th>${m.short}</th>`).join('')}</tr></thead><tbody>${[['SL', 'AA SL'], ['HL', 'AA HL'], ['ALL', 'All IB AA']].map(([c, lab]) => `<tr class="${c === 'ALL' ? 'dc-all' : ''}"><th>${lab}</th>${rowsBy[c].map((r, i) => `<td class="${r && r.of ? 'dc-' + tone(r.pct) : ''}">${r && r.of ? `<b>${cell(r)}</b><span>${r.pct}%</span>` : ms[i].upTo ? '<span class="muted">—</span>' : ''}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
    const detail = c => { const r = now(c); if (!r) return ''; const list = r.all.slice().sort((p, q) => p.p.pct - q.p.pct);
      return `<details class="rd-list" ${c === 'SL' ? 'open' : ''}><summary><b>AA ${c}</b> · ${r.below.length} below a ${cut()}${r.notAssessed ? ` · ${r.notAssessed} not assessed yet` : ''}</summary>${list.length ? `<table class="tbl rd-tbl"><thead><tr><th>Student</th><th>Average</th><th>Predicted</th><th>Assessments</th></tr></thead><tbody>${list.map(({ s, p }) => `<tr class="${p.grade < cut() ? 'dc-below' : ''}"><td><a href="#/student/${encodeURIComponent(s.id)}">${esc(s.name)}</a></td><td>${p.pct}%</td><td><b>${p.grade}</b></td><td>${p.n}</td></tr>`).join('')}</tbody></table>` : '<p class="tiny muted">No marked work yet.</p>'}</details>`; };
    main.innerHTML = U.heading('PLC GOAL', 'Data cycle', `Predicted IB grades from Tests, Quizzes, Retests and Exit Tickets (not homework), weighted ${weight('Test')} : ${weight('Quiz')} : ${weight('Exit Ticket')}, counted each month as <b>students at ${cut()}+ / students assessed</b>.`, `<a class="btn primary" href="#/datacycle?present=1">Present to department →</a>`) + tabs +
      (ok ? '' : `<section class="card warn-card"><p><b>Enter your grade boundaries below first.</b> Copy the lowest % for each grade from the latest IB grade boundaries for SL and HL. The counts appear as soon as they are saved.</p></section>`) +
      `<div class="dc-bigs">${big('AA SL' + (monthName ? ' · ' + monthName : ''), now('SL'))}${big('AA HL' + (monthName ? ' · ' + monthName : ''), now('HL'))}${big('All IB AA' + (monthName ? ' · ' + monthName : ''), now('ALL'))}</div>
      <section class="card"><div class="row-between"><h2 class="bar-head amber">Your row for the data sheet</h2><button class="btn small" id="dc-copy" type="button" ${ok ? '' : 'disabled'}>Copy for the spreadsheet</button></div>${table}
        <p class="tiny muted">Each month counts every marked Test, Quiz, Retest and Exit Ticket (not homework) up to the end of that month (today for ${esc(ms[nowI] ? ms[nowI].name : 'this month')}). Tests count ${weight('Test')}×, quizzes ${weight('Quiz')}× and Exit Tickets ${weight('Exit Ticket')}×; a retest replaces the original when it is higher. Test students never count. Target: <b>${target()}%</b> at grade ${cut()}+.</p></section>
      <section class="card"><h2 class="bar-head blue">Month by month</h2>${ok ? chart(rowsBy, ms) : '<p class="tiny muted">Appears once boundaries are set.</p>'}</section>
      ${lastI >= 0 ? paperCard(ms[lastI].upTo) : ''}
      <section class="card"><h2 class="bar-head pink">Who is below a ${cut()}${monthName ? ' · ' + monthName : ''}</h2>${ok ? detail('SL') + detail('HL') : '<p class="tiny muted">Appears once boundaries are set.</p>'}<p class="tiny muted">Names stay on this page — the department view shows counts only.</p></section>
      <section class="card"><h2 class="bar-head green">Goal, action step and grade boundaries</h2>
        <label>PLC goal<textarea id="dc-goal" rows="3">${esc(C.goal || DEF_GOAL)}</textarea></label>
        <label>Action step<textarea id="dc-action" rows="3">${esc(C.action || DEF_ACTION)}</textarea></label>
        <div class="dc-nums"><label>Target %<input id="dc-target" type="number" min="1" max="100" value="${target()}"></label><label>Grade counted as on track<input id="dc-grade" type="number" min="2" max="7" value="${cut()}"></label></div>
        <p class="small"><b>Weights</b> — how much each kind of work counts in the predicted grade (0 leaves it out). A retest takes the weight of the test it replaces.</p>
        <div class="dc-nums">${Object.keys(DEFW).filter(k => k !== 'Retest').map(k => `<label>${k}<input class="dc-w" data-t="${k}" type="number" min="0" max="10" step="0.5" value="${weight(k)}"></label>`).join('')}</div>
        <p class="small"><b>Grade boundaries</b> — the lowest overall % for each grade.</p>
        <div class="scroll"><table class="tbl dc-btbl"><thead><tr><th></th>${[2, 3, 4, 5, 6, 7].map(g => `<th>Grade ${g}</th>`).join('')}</tr></thead><tbody>${brow('SL')}${brow('HL')}</tbody></table></div>
        <p id="dc-msg" class="tiny" role="status"></p><div class="actions"><button class="btn primary" id="dc-save" type="button">Save</button></div></section>`;
    $('#dc-save').onclick = async () => {
      const c = cfg(), nb = { SL: {}, HL: {} };
      $$('.dc-b', main).forEach(i => { if (i.value !== '') nb[i.dataset.c][i.dataset.g] = +i.value; });
      for (const k of COURSES) { const v = [2, 3, 4, 5, 6, 7].map(g => nb[k][g]); if (v.some(x => x !== undefined) && !v.every((x, i) => x !== undefined && (i === 0 || x > v[i - 1]))) { $('#dc-msg').textContent = `${k}: fill in grades 2 to 7, each higher than the one before.`; return; } }
      const nw = {}; $$('.dc-w', main).forEach(i => { nw[i.dataset.t] = i.value === '' ? DEFW[i.dataset.t] : Math.min(10, Math.max(0, +i.value)); }); nw.Retest = nw.Test;
      Object.assign(c, { weights: nw, bounds: nb, goal: $('#dc-goal').value.trim(), action: $('#dc-action').value.trim(), target: Math.min(100, Math.max(1, +$('#dc-target').value || 60)), grade: Math.min(7, Math.max(2, +$('#dc-grade').value || 4)) });
      Hub.store.log('Updated the data cycle settings'); Hub.store.save(true);
      try { await Hub.store.flush(); toast('Saved to cloud.'); } catch (e) { toast(e.message, 'error'); }
      Hub.app.render();
    };
    const cp = $('#dc-copy'); if (cp) cp.onclick = async () => {
      const txt = [['', ...MONTHS], ...[['SL', 'Badmus AA SL'], ['HL', 'Badmus AA HL'], ['ALL', 'Badmus (all IB AA)']].map(([c, lab]) => [lab, ...rowsBy[c].map(cell)])].map(r => r.join('\t')).join('\n');
      try { await navigator.clipboard.writeText(txt); toast('Copied — click the September cell in the sheet and paste.'); } catch (e) { toast('Could not copy here.', 'error'); }
    };
  }
  Hub.datacycle = { view, count, predicted, months, toGrade, boundsOK, papers, weight };
})(window.Hub = window.Hub || {});
