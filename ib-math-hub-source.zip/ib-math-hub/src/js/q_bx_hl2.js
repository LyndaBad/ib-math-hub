/* AA HL — book-exercise questions, Chapter 2 (2A, 2D–2G).
   NEW questions for each Oxford AA HL (2019) exercise: same skills, style and level; own numbers, contexts and wording. */
(function (Hub) {
  'use strict';
  const B = Hub.qcore.bx, plot = Hub.qcore.plot, R = String.raw;
  const mcv = ok => `'k0' if ${ok} else 'bad'`;
  const neg = v => String(v).replace('-', '−');
  const pt = (x, y, pos) => [x, y, `(${neg(x)}, ${neg(y)})`, pos];
  const set = a => '\\{' + a.join(',\\ ') + '\\}';
  /** One book question per prefix: parts labelled 'a(i)', 'a(ii)' become question a with parts (i)->a, (ii)->b. */
  const split = (stem, parts) => { const groups = []; parts.forEach(p => { const k = String(p.l || '').replace(/\(.*$/, ''); let g = groups.find(x => x.k === k); if (!g) groups.push(g = { k, parts: [] }); g.parts.push(p); });
    return groups.map(g => ({ stem, parts: g.parts.map((p, i) => Object.assign({}, p, { l: g.parts.length > 1 ? 'abcdefgh'[i] : undefined })) })); };


  /* ===== 2A · 2.1 Functional relationships ===== */
  const YES = 'Function — each input has exactly one output', NO = inp => `Not a function — the input ${inp} has more than one output`;
  const rel = (l, p, pairs, bad, fig) => {
    const xs = pairs.map(q => q[0]), ys = pairs.map(q => q[1]), dom = [...new Set(xs)], rng = [...new Set(ys)];
    const pyPairs = '[' + pairs.map(([a, b]) => `(${a},${b})`).join(',') + ']';
    const parts = [{ l: bad ? l : `${l}(i)`, c: 'Determine', p: `whether this relation is a function: ${p}`, m: 1, fig, a: { mc: bad ? [NO(`$${bad}$`), YES] : [YES, NO('$x$')] }, ms: [['A1', bad ? `not a function: $${bad}$ has more than one output` : 'function']], w: [bad ? `The input $${bad}$ is paired with more than one output, so it is not a function.` : 'No input is repeated with a different output, so it is a function.'], h: 'Look for an input that appears with two different outputs.', v: mcv(`(len({p[0] for p in ${pyPairs}}) == len({p for p in ${pyPairs}})) == ${bad ? 'False' : 'True'}`) }];
    if (!bad) parts.push(
      { l: `${l}(ii)`, c: 'Write down', p: 'its domain.', m: 1, a: { list: dom, d: set(dom.slice().sort((u, v) => u - v)) }, ms: [['A1', `$${set(dom.slice().sort((u, v) => u - v))}$`]], w: [`The inputs: $${set(dom.slice().sort((u, v) => u - v))}$`], h: 'The domain is the set of first coordinates.', v: `sorted({p[0] for p in ${pyPairs}})` },
      { l: `${l}(iii)`, c: 'Write down', p: 'its range.', m: 1, a: { list: rng, d: set(rng.slice().sort((u, v) => u - v)) }, ms: [['A1', `$${set(rng.slice().sort((u, v) => u - v))}$`]], w: [`The outputs, each listed once: $${set(rng.slice().sort((u, v) => u - v))}$`], h: 'The range is the set of second coordinates — list each value once.', v: `sorted({p[1] for p in ${pyPairs}})` });
    return parts;
  };
  const gr = (l, fig, yes, dr, w, v) => ({ l, c: 'Determine', p: yes ? 'whether the graph represents a function. If it does, choose its domain and range.' : 'whether the graph represents a function. If it does, choose its domain and range.', m: 2, fig, a: { mc: dr }, ms: yes ? [['A1', 'function (passes the vertical line test)'], ['A1', 'correct domain and range']] : [['A1', 'not a function'], ['R1', 'a vertical line meets the graph more than once']], w, h: 'Use the vertical line test first; then read the x-values (domain) and y-values (range) the graph covers.', v: mcv(v) });
  B('HL', '2A', { page: 80, sec: '2.1', title: 'Functional relationships', skill: 'HL-2.1', paper: 1 }, [
    { stem: 'Determine which of these relations are functions. For those that are functions, state the domain and range.', parts: [
      ...rel('a', R`$\{(2, 5),\ (3, 7),\ (4, 9),\ (5, 11)\}$`, [[2, 5], [3, 7], [4, 9], [5, 11]], null),
      ...rel('b', R`$\{(-3, 4),\ (-1, 4),\ (2, 4),\ (6, 4)\}$`, [[-3, 4], [-1, 4], [2, 4], [6, 4]], null),
      ...rel('c', R`$\{(5, -1),\ (5, 0),\ (5, 3),\ (5, 8)\}$`, [[5, -1], [5, 0], [5, 3], [5, 8]], '5'),
      { l: 'd', c: 'Determine', p: R`whether $\{(\sqrt{2}, 1),\ (-\sqrt{2}, 2),\ (\sqrt{2}, \sqrt{2})\}$ is a function.`, m: 1, a: { mc: [NO(R`$\sqrt{2}$`), YES] }, ms: [['A1', R`not a function: $\sqrt{2}$ has outputs $1$ and $\sqrt{2}$`]], w: [R`The input $\sqrt{2}$ is paired with $1$ and with $\sqrt{2}$.`], h: 'Compare the first coordinates carefully — two of them are equal.', v: mcv('len({sqrt(2), -sqrt(2), sqrt(2)}) < 3') },
      ...rel('e', R`A mapping diagram from $A$ to $B$ with arrows $1 \to 3$, $2 \to 5$, $3 \to 7$, $4 \to 3$, $5 \to 9$.`, [[1, 3], [2, 5], [3, 7], [4, 3], [5, 9]], null),
      ...rel('f', R`The table: $x$-values $2,\ -4,\ 9,\ -4,\ 15$ with $y$-values $1,\ 0,\ 3,\ 5,\ 2$ respectively.`, [[2, 1], [-4, 0], [9, 3], [-4, 5], [15, 2]], '-4'),
      ...rel('g', R`A mapping diagram with arrows $1 \to 6$, $4 \to 6$, $-2 \to -8$.`, [[1, 6], [4, 6], [-2, -8]], null),
      ...rel('h', R`A mapping diagram with arrows $0 \to 3$, $3 \to 5$, $3 \to 9$, $6 \to 1$.`, [[0, 3], [3, 5], [3, 9], [6, 1]], '3')
    ] },
    { stem: 'Determine which of the graphs represent functions. For those that are, state the domain and range; for those that are not, give a reason.', parts: [
      gr('a', plot({ x: [-3, 3], y: [-3, 3], vl: [], f: [], pts: [], alt: 'Vertical line x = 1.5' }).replace('</g>', `<line x1="${22 + (4.5 / 6) * 236}" y1="22" x2="${22 + (4.5 / 6) * 236}" y2="218" class="pf"/></g>`), false,
        ['Not a function — the vertical line through $x = 1.5$ meets it at every point', R`Function; domain $\{1.5\}$, range $y \in \mathbb{R}$`, R`Function; domain $x \in \mathbb{R}$, range $\{1.5\}$`], [R`The graph is the vertical line $x = 1.5$: one input with infinitely many outputs.`], 'True'),
      gr('b', plot({ x: [-3, 3], y: [-3, 3], f: [{ f: () => 2 }], alt: 'Horizontal line y = 2' }), true,
        [R`Function; domain $x \in \mathbb{R}$, range $\{2\}$`, R`Function; domain $\{2\}$, range $y \in \mathbb{R}$`, 'Not a function — every point has the same $y$-value'], [R`A horizontal line: every $x$ gives $y = 2$.`, R`Domain $\mathbb{R}$, range $\{2\}$`], 'True'),
      gr('c', plot({ x: [-4, 4], y: [-2, 7], f: [{ f: x => 2 * Math.abs(x) - 1 }], pts: [pt(0, -1, 'b')], alt: 'V-shape with vertex (0, −1)' }), true,
        [R`Function; domain $x \in \mathbb{R}$, range $y \ge -1$`, R`Function; domain $x \ge -1$, range $y \in \mathbb{R}$`, R`Function; domain $x \in \mathbb{R}$, range $y > -1$`, 'Not a function'], [R`Each vertical line meets the V once. Lowest point $(0,\ -1)$.`, R`Domain $\mathbb{R}$, range $y \ge -1$`], 'all((2*Abs(x)-1).subs(x,v) >= -1 for v in range(-5,6))'),
      gr('d', plot({ x: [-1, 6], y: [-4, 7], f: [{ f: x => x * x - 4 * x + 1, from: 0, to: 5 }], pts: [pt(0, 1, 'l'), pt(2, -3, 'b'), pt(5, 6)], alt: 'Parabola segment from x = 0 to x = 5' }), true,
        [R`Function; domain $0 \le x \le 5$, range $-3 \le y \le 6$`, R`Function; domain $0 \le x \le 5$, range $1 \le y \le 6$`, R`Function; domain $-3 \le x \le 6$, range $0 \le y \le 5$`, 'Not a function'], [R`The curve runs from $x = 0$ to $x = 5$ (filled end points).`, R`Lowest point $(2,\ -3)$, highest $(5,\ 6)$: range $-3 \le y \le 6$.`], '(x**2-4*x+1).subs(x,2) == -3 and (x**2-4*x+1).subs(x,5) == 6'),
      gr('e', plot({ x: [-4, 5], y: [-3, 5], pts: [[-3, -2], [-2, 1], [0, 2], [1, -1], [3, 2], [4, 4]], alt: 'Six separate points' }), true,
        [R`Function; domain $\{-3, -2, 0, 1, 3, 4\}$, range $\{-2, -1, 1, 2, 4\}$`, R`Function; domain $-3 \le x \le 4$, range $-2 \le y \le 4$`, R`Function; domain $\{-2, -1, 1, 2, 4\}$, range $\{-3, -2, 0, 1, 3, 4\}$`, 'Not a function'], [R`Separate points, one per $x$: a function.`, R`Domain $\{-3, -2, 0, 1, 3, 4\}$, range $\{-2, -1, 1, 2, 4\}$ (the output $2$ once).`], 'len({-2,1,2,-1,2,4}) == 5'),
      gr('f', plot({ x: [-4, 3], y: [-2, 4], f: [{ f: x => x < 0 ? -x - 1 : 2 * x - 1, from: -3, to: 2 }], pts: [pt(-3, 2, 'l'), pt(0, -1, 'b'), pt(2, 3)], alt: 'Two joined line segments' }), true,
        [R`Function; domain $-3 \le x \le 2$, range $-1 \le y \le 3$`, R`Function; domain $-3 \le x \le 2$, range $2 \le y \le 3$`, R`Function; domain $-1 \le x \le 3$, range $-3 \le y \le 2$`, 'Not a function'], [R`Domain from $-3$ to $2$; lowest point $(0,\ -1)$, highest $(2,\ 3)$.`], 'True'),
      gr('g', plot({ x: [-2, 4], y: [-2, 4], f: [{ f: x => 1 + Math.sqrt(Math.max(0, 4 - (x - 1) ** 2)), from: -1, to: 3 }, { f: x => 1 - Math.sqrt(Math.max(0, 4 - (x - 1) ** 2)), from: -1, to: 3 }], alt: 'A circle' }), false,
        ['Not a function — a vertical line meets the circle twice', R`Function; domain $-1 \le x \le 3$, range $-1 \le y \le 3$`, R`Function; domain $x \in \mathbb{R}$, range $y \in \mathbb{R}$`], [R`The line $x = 1$ meets the circle at $(1,\ 3)$ and $(1,\ -1)$.`], 'len(solve(((x-1)**2+(y-1)**2-4).subs(x,1), y)) == 2')
    ] }
  ]);

  /* ===== 2D · 2.2 Radical functions ===== */
  const rad = (l, tex, ok, d2, d3, d4, w, py) => ({ l, c: 'Determine', p: `the domain and range of $${tex}$.`, m: 2, a: { mc: [ok, d2, d3, d4] }, ms: [['A1', 'correct domain'], ['A1', 'correct range']], w, h: 'The expression under the square root must be at least 0. Then think about the smallest (or largest) value of y.', v: mcv(py) });
  B('HL', '2D', { page: 90, sec: '2.2', title: 'Special functions and their graphs', skill: 'HL-2.2a', paper: 1 }, [
    { stem: 'Radical functions.', parts: [
      rad('a', R`y = \sqrt{x + 3}`, R`domain $x \ge -3$, range $y \ge 0$`, R`domain $x \ge 3$, range $y \ge 0$`, R`domain $x \ge -3$, range $y \ge -3$`, R`domain $x \in \mathbb{R}$, range $y \ge 0$`, [R`$x + 3 \ge 0 \Rightarrow x \ge -3$`, R`$\sqrt{\ } \ge 0$, so $y \ge 0$`], 'solveset(x+3>=0, x, S.Reals) == Interval(-3, oo)'),
      rad('b', R`y = \sqrt{5x - 2}`, R`domain $x \ge \frac{2}{5}$, range $y \ge 0$`, R`domain $x \ge \frac{5}{2}$, range $y \ge 0$`, R`domain $x \ge \frac{2}{5}$, range $y \ge \frac{2}{5}$`, R`domain $x \ge -\frac{2}{5}$, range $y \ge 0$`, [R`$5x - 2 \ge 0 \Rightarrow x \ge \frac{2}{5}$`, R`$y \ge 0$`], 'solveset(5*x-2>=0, x, S.Reals) == Interval(Rational(2,5), oo)'),
      rad('c', R`y = 2 - \sqrt{6 - 3x}`, R`domain $x \le 2$, range $y \le 2$`, R`domain $x \ge 2$, range $y \le 2$`, R`domain $x \le 2$, range $y \ge 2$`, R`domain $x \le 6$, range $y \le 2$`, [R`$6 - 3x \ge 0 \Rightarrow x \le 2$`, R`$\sqrt{6 - 3x} \ge 0$, so $y = 2 - \sqrt{6 - 3x} \le 2$`], 'solveset(6-3*x>=0, x, S.Reals) == Interval(-oo, 2)'),
      rad('d', R`y = 4 + \sqrt{2x + 1}`, R`domain $x \ge -\frac{1}{2}$, range $y \ge 4$`, R`domain $x \ge -\frac{1}{2}$, range $y \ge 0$`, R`domain $x \ge \frac{1}{2}$, range $y \ge 4$`, R`domain $x \ge -\frac{1}{2}$, range $y \le 4$`, [R`$2x + 1 \ge 0 \Rightarrow x \ge -\frac{1}{2}$`, R`The root is at least $0$, so $y \ge 4$.`], 'solveset(2*x+1>=0, x, S.Reals) == Interval(-Rational(1,2), oo)'),
      rad('e', R`y = -3\sqrt{x + 2}`, R`domain $x \ge -2$, range $y \le 0$`, R`domain $x \ge -2$, range $y \ge 0$`, R`domain $x \ge 2$, range $y \le 0$`, R`domain $x \ge -2$, range $y \le -3$`, [R`$x + 2 \ge 0 \Rightarrow x \ge -2$`, R`$-3 \times (\text{something} \ge 0) \le 0$, so $y \le 0$`], 'solveset(x+2>=0, x, S.Reals) == Interval(-2, oo)'),
      rad('f', R`y = 1 + 2\sqrt{4 - x}`, R`domain $x \le 4$, range $y \ge 1$`, R`domain $x \ge 4$, range $y \ge 1$`, R`domain $x \le 4$, range $y \ge 0$`, R`domain $x \le 4$, range $y \le 1$`, [R`$4 - x \ge 0 \Rightarrow x \le 4$`, R`$2\sqrt{4 - x} \ge 0$, so $y \ge 1$`], 'solveset(4-x>=0, x, S.Reals) == Interval(-oo, 4)')
    ] }
  ]);

  /* ===== 2E · 2.2 Rational functions with quadratic denominators ===== */
  const qa = (l, tex, vas, py, w) => [
    { l: `${l}(i)`, c: 'Find', p: `the equations of the vertical asymptotes of $${tex}$, giving each value of $x$.`, m: 2, a: { list: vas.map(v => Array.isArray(v) ? v : v), d: vas.map(v => Array.isArray(v) ? (v[0] < 0 ? R`x = -\frac{${-v[0]}}{${v[1]}}` : R`x = \frac{${v[0]}}{${v[1]}}`) : `x = ${v}`).join(',\\ ') },
      ms: [['M1', 'sets the denominator equal to 0 and factorizes'], ['A1', 'both asymptotes (domain: $x$ not equal to these values)']], w, h: 'Factorize the denominator and set each factor to zero.', v: `solve(fraction(together(${py}))[1], x)` },
    { l: `${l}(ii)`, c: 'Write down', p: 'the equation of the horizontal asymptote.', m: 1, a: { n: 0, d: 'y = 0' }, ms: [['A1', R`$y = 0$`]], w: [R`The degree of the numerator is less than the degree of the denominator, so $y \to 0$: $y = 0$.`], h: 'Compare the degrees of the numerator and the denominator.', v: `limit(${py}, x, oo)` }
  ];
  B('HL', '2E', { page: 91, sec: '2.2', title: 'Special functions and their graphs', skill: 'HL-2.2a', paper: 1 }, split('Find the domain by finding the vertical asymptotes, and write down the horizontal asymptote. Check your answers with a graph.', [
      ...qa('a', R`y = \frac{3}{x^{2} - 4x}`, [0, 4], '3/(x**2-4*x)', [R`$x^{2} - 4x = x(x - 4) = 0 \Rightarrow x = 0,\ x = 4$`, R`Domain: $x \ne 0,\ x \ne 4$`]),
      ...qa('b', R`y = \frac{x}{x^{2} - 16}`, [-4, 4], 'x/(x**2-16)', [R`$(x - 4)(x + 4) = 0 \Rightarrow x = \pm 4$`, R`Domain: $x \ne \pm 4$`]),
      ...qa('c', R`y = \frac{2}{x^{2} + 2x - 15}`, [-5, 3], '2/(x**2+2*x-15)', [R`$(x + 5)(x - 3) = 0 \Rightarrow x = -5,\ x = 3$`]),
      { l: 'd(i)', c: 'Find', p: R`the equation of the vertical asymptote of $y = -\frac{1}{(x - 3)^{2}}$.`, m: 1, a: { n: 3, d: 'x = 3' }, ms: [['A1', R`$x = 3$`]], w: [R`$(x - 3)^{2} = 0 \Rightarrow x = 3$ (a repeated factor gives one asymptote). Domain $x \ne 3$.`], h: 'The denominator is a perfect square.', v: 'solve((x-3)**2, x)[0]' },
      { l: 'd(ii)', c: 'Write down', p: 'the equation of the horizontal asymptote.', m: 1, a: { n: 0, d: 'y = 0' }, ms: [['A1', R`$y = 0$`]], w: [R`$y \to 0$ as $x \to \pm\infty$.`], h: 'What happens for very large x?', v: 'limit(-1/(x-3)**2, x, oo)' },
      ...qa('e', R`y = \frac{4}{9x^{2} - 1}`, [[-1, 3], [1, 3]], '4/(9*x**2-1)', [R`$(3x - 1)(3x + 1) = 0 \Rightarrow x = \pm\frac{1}{3}$`]),
      ...qa('f', R`y = \frac{x + 1}{2x^{2} - 5x - 3}`, [[-1, 2], 3], '(x+1)/(2*x**2-5*x-3)', [R`$(2x + 1)(x - 3) = 0 \Rightarrow x = -\frac{1}{2},\ x = 3$`]),
      { l: 'g(i)', c: 'State', p: R`the domain of $y = \frac{5}{x^{2} + 4}$.`, m: 1, a: { mc: [R`$x \in \mathbb{R}$`, R`$x \ne \pm 2$`, R`$x \ne -4$`, R`$x \ne 2$`] }, ms: [['A1', R`$x \in \mathbb{R}$ (no vertical asymptotes)`]], w: [R`$x^{2} + 4 \ge 4 > 0$, so the denominator is never $0$: domain $\mathbb{R}$, no vertical asymptotes.`], h: 'Can x² + 4 ever be zero?', v: mcv('len(solve(x**2+4, x, domain=S.Reals) if False else [r for r in solve(x**2+4, x) if r.is_real]) == 0') },
      { l: 'g(ii)', c: 'Write down', p: 'the equation of the horizontal asymptote.', m: 1, a: { n: 0, d: 'y = 0' }, ms: [['A1', R`$y = 0$`]], w: [R`$y \to 0$ as $x \to \pm\infty$.`], h: 'Compare degrees.', v: 'limit(5/(x**2+4), x, oo)' },
      ...qa('h', R`y = -\frac{3}{2x^{2} + 7x + 3}`, [-3, [-1, 2]], '-3/(2*x**2+7*x+3)', [R`$(2x + 1)(x + 3) = 0 \Rightarrow x = -3,\ x = -\frac{1}{2}$`])
  ]));

  /* ===== 2F · 2.2 Partial fractions ===== */
  const pf = (l, tex, form, A, Bv, py, f1, f2, w) => ({ l, c: 'Express', p: `$${tex}$ in partial fractions, in the form $${form}$.`, m: 4, a: { t: [A, Bv], l: ['A', 'B'], d: R`A = ${Array.isArray(A) ? R`\frac{${A[0]}}{${A[1]}}` : A},\ B = ${Array.isArray(Bv) ? R`\frac{${Bv[0]}}{${Bv[1]}}` : Bv}` },
    ms: [['M1', 'factorizes the denominator'], ['M1', 'writes the numerator as $A(\\dots) + B(\\dots)$ and substitutes or compares coefficients'], ['A1', 'correct $A$'], ['A1', 'correct $B$']], w, h: 'Factorize the denominator, write the numerator as A(second factor) + B(first factor), then substitute the roots.', v: `(lambda d: (d[Symbol('A')], d[Symbol('B')]))(solve(Poly(expand(numer(together(Symbol('A')/(${f1})+Symbol('B')/(${f2})-(${py})))), x).all_coeffs(), [Symbol('A'), Symbol('B')]))` });
  B('HL', '2F', { page: 93, sec: '2.2', title: 'Partial fractions', skill: 'HL-2.2b', paper: 1 }, split('Express in partial fractions.', [
      pf('1', R`\frac{1}{x^{2} + 7x + 12}`, R`\frac{A}{x + 3} + \frac{B}{x + 4}`, 1, -1, '1/(x**2+7*x+12)', 'x+3', 'x+4', [R`$x^{2} + 7x + 12 = (x + 3)(x + 4)$`, R`$1 = A(x + 4) + B(x + 3)$`, R`$x = -3$: $1 = A$; $x = -4$: $1 = -B \Rightarrow B = -1$`, R`$\frac{1}{x + 3} - \frac{1}{x + 4}$`]),
      pf('2', R`\frac{3x + 4}{x^{2} + x - 6}`, R`\frac{A}{x - 2} + \frac{B}{x + 3}`, 2, 1, '(3*x+4)/(x**2+x-6)', 'x-2', 'x+3', [R`$x^{2} + x - 6 = (x - 2)(x + 3)$`, R`$3x + 4 = A(x + 3) + B(x - 2)$`, R`$x = 2$: $10 = 5A \Rightarrow A = 2$; $x = -3$: $-5 = -5B \Rightarrow B = 1$`, R`$\frac{2}{x - 2} + \frac{1}{x + 3}$`]),
      pf('3', R`\frac{5x - 12}{x^{2} - 4x}`, R`\frac{A}{x} + \frac{B}{x - 4}`, 3, 2, '(5*x-12)/(x**2-4*x)', 'x', 'x-4', [R`$x^{2} - 4x = x(x - 4)$`, R`$5x - 12 = A(x - 4) + Bx$`, R`$x = 0$: $-12 = -4A \Rightarrow A = 3$; $x = 4$: $8 = 4B \Rightarrow B = 2$`, R`$\frac{3}{x} + \frac{2}{x - 4}$`]),
      pf('4', R`\frac{x}{x^{2} - 9}`, R`\frac{A}{x - 3} + \frac{B}{x + 3}`, [1, 2], [1, 2], 'x/(x**2-9)', 'x-3', 'x+3', [R`$x = A(x + 3) + B(x - 3)$`, R`$x = 3$: $3 = 6A \Rightarrow A = \frac{1}{2}$; $x = -3$: $-3 = -6B \Rightarrow B = \frac{1}{2}$`, R`$\frac{1}{2(x - 3)} + \frac{1}{2(x + 3)}$`]),
      pf('5', R`\frac{7}{-x^{2} + 3x + 10}`, R`\frac{A}{x + 2} + \frac{B}{x - 5}`, 1, -1, '7/(-x**2+3*x+10)', 'x+2', 'x-5', [R`$-x^{2} + 3x + 10 = -(x - 5)(x + 2)$, so the function is $\frac{-7}{(x - 5)(x + 2)}$`, R`$-7 = A(x - 5) + B(x + 2)$`, R`$x = -2$: $-7 = -7A \Rightarrow A = 1$; $x = 5$: $-7 = 7B \Rightarrow B = -1$`, R`$\frac{1}{x + 2} - \frac{1}{x - 5}$`]),
      pf('6', R`\frac{7x + 1}{6x^{2} + x - 1}`, R`\frac{A}{3x - 1} + \frac{B}{2x + 1}`, 2, 1, '(7*x+1)/(6*x**2+x-1)', '3*x-1', '2*x+1', [R`$6x^{2} + x - 1 = (3x - 1)(2x + 1)$`, R`$7x + 1 = A(2x + 1) + B(3x - 1)$`, R`$x = \frac{1}{3}$: $\frac{10}{3} = \frac{5}{3}A \Rightarrow A = 2$; $x = -\frac{1}{2}$: $-\frac{5}{2} = -\frac{5}{2}B \Rightarrow B = 1$`, R`$\frac{2}{3x - 1} + \frac{1}{2x + 1}$`]),
      pf('7', R`\frac{13 - 3x}{6x^{2} - x - 12}`, R`\frac{A}{3x + 4} + \frac{B}{2x - 3}`, -3, 1, '(13-3*x)/(6*x**2-x-12)', '3*x+4', '2*x-3', [R`$6x^{2} - x - 12 = (3x + 4)(2x - 3)$`, R`$13 - 3x = A(2x - 3) + B(3x + 4)$`, R`$x = \frac{3}{2}$: $\frac{17}{2} = \frac{17}{2}B \Rightarrow B = 1$; $x = -\frac{4}{3}$: $17 = -\frac{17}{3}A \Rightarrow A = -3$`, R`$\frac{1}{2x - 3} - \frac{3}{3x + 4}$`])
  ]));

  /* ===== 2G · 2.2 Absolute value functions ===== */
  const ab = (l, tex, f, vx, vy, up, xr, yr, py, w, pts) => ({ l, c: 'Determine', p: `the domain and range of $${tex}$, and sketch its graph.`, m: 2,
    a: { mc: [R`domain $x \in \mathbb{R}$, range $y ${up ? '\\ge' : '\\le'} ${vy}$`, R`domain $x \in \mathbb{R}$, range $y ${up ? '\\le' : '\\ge'} ${vy}$`, R`domain $x ${up ? '\\ge' : '\\le'} ${vx}$, range $y \in \mathbb{R}$`, R`domain $x \in \mathbb{R}$, range $y ${up ? '\\ge' : '\\le'} ${-vy === 0 ? 1 : -vy}$`] },
    ms: [['A1', R`domain $\mathbb{R}$`], ['A1', R`range $y ${up ? '\\ge' : '\\le'} ${vy}$ (and a V-shaped sketch with vertex in the right place)`]], w,
    kfig: plot({ x: xr, y: yr, f: [{ f }], pts: pts || [pt(vx, vy, up ? 'b' : null)], alt: 'Graph of an absolute value function' }), h: 'Write it as y = a|x − h| + k: the vertex is (h, k) and the sign of a tells you whether it opens up or down.', v: mcv(py) });
  B('HL', '2G', { page: 95, sec: '2.2', title: 'Absolute value functions', skill: 'HL-2.2c', paper: 1 }, split('Determine the domain and range, and sketch the graph.', [
      ab('1', R`y = -|x| + 2`, x => -Math.abs(x) + 2, 0, 2, false, [-5, 5], [-4, 4], 'all((-Abs(x)+2).subs(x,v) <= 2 for v in range(-6,7))', [R`Vertex $(0,\ 2)$, opening down. Range $y \le 2$.`]),
      ab('2', R`y = |3x| - 2`, x => Math.abs(3 * x) - 2, 0, -2, true, [-3, 3], [-3, 6], 'all((Abs(3*x)-2).subs(x,v) >= -2 for v in range(-6,7))', [R`Vertex $(0,\ -2)$, opening up. Range $y \ge -2$.`]),
      ab('3', R`y = |x + 2| - 3`, x => Math.abs(x + 2) - 3, -2, -3, true, [-7, 4], [-4, 5], 'all((Abs(x+2)-3).subs(x,v) >= -3 for v in range(-8,8))', [R`Vertex $(-2,\ -3)$, opening up. Range $y \ge -3$.`]),
      ab('4', R`y = -|x - 1| + 4`, x => -Math.abs(x - 1) + 4, 1, 4, false, [-4, 6], [-2, 5], 'all((-Abs(x-1)+4).subs(x,v) <= 4 for v in range(-8,8))', [R`Vertex $(1,\ 4)$, opening down. Range $y \le 4$.`]),
      ab('5', R`y = \frac{1}{3}|x - 3| + 1`, x => Math.abs(x - 3) / 3 + 1, 3, 1, true, [-4, 10], [-1, 5], 'all((Abs(x-3)/3+1).subs(x,v) >= 1 for v in range(-8,12))', [R`Vertex $(3,\ 1)$, opening up (gentle slope $\frac{1}{3}$). Range $y \ge 1$.`]),
      ab('6', R`y = -3|2x - 4| + 5`, x => -3 * Math.abs(2 * x - 4) + 5, 2, 5, false, [-1, 5], [-8, 6], 'all((-3*Abs(2*x-4)+5).subs(x,v) <= 5 for v in range(-6,8))', [R`$|2x - 4| = 2|x - 2|$, so $y = -6|x - 2| + 5$.`, R`Vertex $(2,\ 5)$, opening down. Range $y \le 5$.`]),
      ab('7', R`y = -2|3 - x| - 1`, x => -2 * Math.abs(3 - x) - 1, 3, -1, false, [-1, 7], [-8, 2], 'all((-2*Abs(3-x)-1).subs(x,v) <= -1 for v in range(-6,10))', [R`$|3 - x| = |x - 3|$: vertex $(3,\ -1)$, opening down. Range $y \le -1$.`]),
      ab('8', R`y = -|4 - 2x| + 3`, x => -Math.abs(4 - 2 * x) + 3, 2, 3, false, [-2, 6], [-5, 4], 'all((-Abs(4-2*x)+3).subs(x,v) <= 3 for v in range(-6,8))', [R`$|4 - 2x| = 2|x - 2|$, so $y = -2|x - 2| + 3$.`, R`Vertex $(2,\ 3)$, opening down. Range $y \le 3$.`]),
      ab('9', R`y = |x^{2} - 2x - 3|`, x => Math.abs(x * x - 2 * x - 3), 1, 0, true, [-3, 5], [-1, 6], 'all((Abs(x**2-2*x-3)).subs(x,v) >= 0 for v in range(-6,8)) and (Abs(x**2-2*x-3)).subs(x,3) == 0', [R`$x^{2} - 2x - 3 = (x - 3)(x + 1)$ is negative between $-1$ and $3$; that part is reflected above the $x$-axis.`, R`The graph touches $y = 0$ at $x = -1$ and $x = 3$; range $y \ge 0$.`], [pt(-1, 0, 'l'), pt(3, 0, 'b'), pt(1, 4)]),
      ab('10', R`y = |5 - 4x - x^{2}| - 1`, x => Math.abs(5 - 4 * x - x * x) - 1, -5, -1, true, [-7, 3], [-2, 10], 'all((Abs(5-4*x-x**2)-1).subs(x,v) >= -1 for v in range(-9,6)) and (Abs(5-4*x-x**2)-1).subs(x,1) == -1', [R`$5 - 4x - x^{2} = (5 + x)(1 - x)$ is zero at $x = -5$ and $x = 1$.`, R`The absolute value is never negative, so the least value of $y$ is $0 - 1 = -1$ (at $x = -5$ and $x = 1$). Range $y \ge -1$.`], [pt(-5, -1, 'b'), pt(1, -1, 'b'), pt(-2, 8)])
  ]));
})(window.Hub = window.Hub || {});
