/* Class dashboards (#/class/<group>) and the "missing work" lists used on the main dashboard.
   Missing work = Homework and Exit Tickets published to the group whose due date FOR THAT GROUP has passed,
   with the active students in the group who have not submitted — ready to read out while taking the register. */
(function (Hub) {
  'use strict';
  const { esc, $, $$, fmtDate, fmtDateTime, toast, addDays } = Hub.core;
  const U = Hub.ui, C = () => Hub.curriculum, S = () => Hub.store.state;
  const TYPES = ['Homework', 'Exit Ticket'];
  const asOf = () => Hub.mastery.asOf();
  const firstName = n => String(n || '').split(' ')[0];

  /** [{a, due, missing:[students], done, total}] for work due before today (newest due first). days: how far back to look. */
  function missing(groupId, days = 21) {
    const today = asOf(), from = addDays(today, -days), studs = Hub.roster.inGroup(groupId);
    return S().assessments.filter(a => TYPES.includes(a.type) && ['published', 'closed'].includes(a.status) && a.groups.includes(groupId))
      .map(a => ({ a, due: Hub.assess.dueFor(a, groupId) })).filter(x => x.due && x.due < today && x.due >= from)
      .map(x => { const miss = studs.filter(s => !Hub.assess.attemptsFor(x.a.id, s.id).length); return Object.assign(x, { missing: miss, done: studs.length - miss.length, total: studs.length }); })
      .sort((p, q) => q.due.localeCompare(p.due));
  }
  /** Work due today or later for the group, with how many have submitted. */
  function upcoming(groupId) {
    const today = asOf(), studs = Hub.roster.inGroup(groupId);
    return S().assessments.filter(a => a.status === 'published' && a.groups.includes(groupId))
      .map(a => ({ a, due: Hub.assess.dueFor(a, groupId) })).filter(x => !x.due || x.due >= today)
      .map(x => Object.assign(x, { done: studs.filter(s => Hub.assess.attemptsFor(x.a.id, s.id).length).length, total: studs.length }))
      .sort((p, q) => String(p.due || '9').localeCompare(String(q.due || '9')));
  }
  /** Compact block for a dashboard group card. */
  function cardSnippet(groupId) {
    const m = missing(groupId, 14).filter(x => x.missing.length);
    if (!m.length) return '<p class="tiny gc-ok">✓ No missing homework or Exit Tickets</p>';
    return `<div class="gc-missing"><b>Missing work</b>${m.slice(0, 3).map(x => `<div class="tiny"><span class="pill ${x.a.type === 'Homework' ? 'amber' : 'pink'}">${x.a.type === 'Homework' ? 'HW' : 'ET'}</span> ${esc(x.a.title.replace(/^(SL|HL) · /, '').slice(0, 38))} <span class="muted">due ${fmtDate(x.due)}</span><br>${x.missing.map(s => esc(s.name)).join(', ')}</div>`).join('')}${m.length > 3 ? `<div class="tiny muted">+ ${m.length - 3} more</div>` : ''}</div>`;
  }
  const ragCounts = (L, studs) => { const c = { red: 0, amber: 0, green: 0, opened: 0 }; studs.forEach(s => { const p = S().progress[s.id + '|nb:' + L.id]; if (p) { c.opened++; const r = (p.responses || {}).rag; if (c[r] !== undefined) c[r]++; } }); return c; };

  function view(main, params) {
    const g = C().GROUPS[params.id] ? params.id : 'SL-A', G = C().GROUPS[g], studs = Hub.roster.inGroup(g), today = asOf();
    const nl = C().nextLesson(g, today), lid = nl && Hub.lessons ? Hub.lessons.idFor(g, nl.date) : null, nb = lid ? Hub.lessons.get(lid) : null;
    const miss = missing(g), up = upcoming(g), dn = S().donow[g], dnCur = dn && nl && dn.lessonDate === nl.date;
    const recentNb = Hub.lessons ? Hub.lessons.all().filter(L => L.course === G.course && Hub.lessons.visibleTo(L, g)).sort((a, b) => String(b.dates[G.day] || '').localeCompare(String(a.dates[G.day] || '')))[0] : null;
    const missBy = {}; miss.forEach(x => x.missing.forEach(s => { (missBy[s.id] = missBy[s.id] || []).push(x); }));
    const skills = C().skillsFor(G.course).filter(k => C().isTaught(k.id, g, today)).map(k => [k, Hub.mastery.groupSkill(g, k.id).avg]).filter(x => x[1] !== null).sort((a, b) => a[1] - b[1]).slice(0, 4);
    const ia = C().iaSchedule(g).find(s => s.date && s.date >= today);
    const tabs = `<div class="tabs">${Object.values(C().GROUPS).map(x => `<a class="tab ${x.id === g ? 'on' : ''}" href="#/class/${x.id}">${x.label.replace('AA ', '')}</a>`).join('')}</div>`;
    // the latest Exit Ticket / homework whose due date has passed (or, if none yet, the newest one still open)
    const pastDue = type => S().assessments.filter(a => a.type === type && ['published', 'closed'].includes(a.status) && a.groups.includes(g)).map(a => ({ a, due: Hub.assess.dueFor(a, g) }));
    const latest = type => { const all = pastDue(type), done = all.filter(x => x.due && x.due < today).sort((p, q) => q.due.localeCompare(p.due)); if (done.length) return Object.assign(done[0], { past: true }); const open = all.filter(x => x.a.status === 'published').sort((p, q) => String(p.due || '9').localeCompare(String(q.due || '9'))); return open[0] ? Object.assign(open[0], { past: false }) : null; };
    const rundown = (type, head, colour, empty) => { const x = latest(type);
      if (!x) return `<section class="card rundown"><h2 class="bar-head ${colour}">${head}</h2><p class="tiny muted">${empty}</p><div class="actions"><a class="btn small" href="#/studio?group=${g}">✎ Build one</a></div></section>`;
      const rows = studs.map(st => { const ts = Hub.assess.attemptsFor(x.a.id, st.id), t = ts[ts.length - 1]; return { st, t, sc: t ? Hub.assess.score(t) : null }; });
      const did = rows.filter(r => r.t), not = rows.filter(r => !r.t), pcts = did.map(r => r.sc.pct).filter(v => v !== null && v !== undefined), avg = pcts.length ? Math.round(pcts.reduce((a, b) => a + b, 0) / pcts.length) : null;
      const toMark = did.filter(r => r.t.status === 'submitted').length;
      return `<section class="card rundown"><h2 class="bar-head ${colour}">${head}</h2>
        <p class="rd-title"><a href="#/edit/${x.a.id}">${esc(x.a.title)}</a></p>
        <p class="tiny muted">${x.due ? (x.past ? 'Was due ' : 'Due ') + fmtDate(x.due, true) : 'No due date'}${x.past ? '' : ' · still open'}</p>
        <div class="rd-stats"><div><b>${did.length}/${studs.length}</b><span>done</span></div><div><b>${avg === null ? '—' : avg + '%'}</b><span>class average</span></div><div><b>${not.length}</b><span>not done</span></div></div>
        ${toMark ? `<p class="tiny"><span class="pill amber">${toMark} to mark</span> <a href="#/marking">Marking</a></p>` : ''}
        <details class="rd-list" open><summary><b>Not done (${not.length})</b></summary>${not.length ? `<p class="miss-names">${not.map(r => `<a href="#/student/${encodeURIComponent(r.st.id)}">${esc(r.st.name)}</a>`).join(', ')}</p>` : '<p class="tiny gc-ok">✓ Everyone has done it</p>'}</details>
        <details class="rd-list"><summary><b>Done (${did.length})</b></summary>${did.length ? `<table class="tbl rd-tbl"><tbody>${did.sort((p, q) => (q.sc.pct ?? -1) - (p.sc.pct ?? -1)).map(r => `<tr><td><a href="#/student/${encodeURIComponent(r.st.id)}">${esc(r.st.name)}</a></td><td>${r.sc.pct === null || r.sc.pct === undefined ? '—' : r.sc.pct + '%'}</td><td>${r.t.status === 'submitted' ? '<span class="pill amber">to mark</span>' : r.t.status === 'released' ? '<span class="tiny muted">released</span>' : ''}</td><td><a class="tiny" href="#/mark/${r.t.id}">open</a></td></tr>`).join('')}</tbody></table>` : '<p class="tiny muted">Nobody yet.</p>'}</details></section>`; };
    main.innerHTML = `<a class="back" href="#/home">← Dashboard</a>` + U.heading(`${G.block.toUpperCase()} · ${studs.length} STUDENTS`, esc(G.label), nl ? `Next lesson ${fmtDate(nl.date, true)} · ${esc(nl.activity)}` : '', tabs) +
      `<div class="grid g2">${rundown('Exit Ticket', 'Latest Exit Ticket', 'pink', 'No Exit Ticket has been set for this class yet.')}${rundown('Homework', 'Latest homework', 'amber', 'No homework has been set for this class yet.')}</div>
      <div class="grid g2">
      <section class="card"><h2 class="bar-head green">Lesson notebook</h2>${recentNb ? (() => { const c = ragCounts(recentNb, studs), qs = studs.map(s => [s, ((S().progress[s.id + '|nb:' + recentNb.id] || {}).responses || {}).question]).filter(x => x[1] && x[1].trim()), notOpen = studs.filter(s => !S().progress[s.id + '|nb:' + recentNb.id]); return `<p class="rd-title">${esc(recentNb.title.slice(0, 70))}</p><p class="tiny muted">Latest released notebook</p><div class="rd-stats"><div><b>${c.opened}/${studs.length}</b><span>opened</span></div><div><b class="rag-chip green">${c.green}</b><span>got it</span></div><div><b class="rag-chip amber">${c.amber}</b><span>getting there</span></div><div><b class="rag-chip red">${c.red}</b><span>stuck</span></div></div>${notOpen.length ? `<details class="rd-list"><summary><b>Not opened (${notOpen.length})</b></summary><p class="miss-names">${notOpen.map(s => `<a href="#/student/${encodeURIComponent(s.id)}">${esc(s.name)}</a>`).join(', ')}</p></details>` : ''}${qs.length ? `<div class="sticky"><b>Questions from students</b><ul>${qs.slice(0, 6).map(([s, q]) => `<li><b>${esc(firstName(s.name))}:</b> ${esc(q)}</li>`).join('')}</ul></div>` : ''}<div class="actions"><a class="btn small ghost" href="#/lesson/${encodeURIComponent(recentNb.id)}?view=responses">All responses</a></div>`; })() : '<p class="tiny muted">No notebook released to this class yet.</p>'}
        ${nl ? `<p class="tiny gc-next">Next lesson: ${nb ? `<b>${esc(nb.title)}</b> · ${Hub.lessons.visibleTo(nb, g) ? 'released' : 'not released yet'}` : 'no notebook yet'} ${lid ? `<a class="btn small" href="#/lesson/${encodeURIComponent(lid)}">${nb ? 'Open notebook' : '+ Create notebook'}</a>` : ''}</p>` : ''}</section>
      <section class="card"><h2 class="bar-head blue">Due next</h2>${up.length ? up.map(x => `<div class="row-between small"><span><span class="pill">${esc(x.a.type)}</span> <a href="#/edit/${x.a.id}">${esc(x.a.title)}</a></span><span class="tiny muted">${x.due ? 'due ' + fmtDate(x.due) : 'no due date'} · ${x.done}/${x.total} done</span></div>`).join('') : '<p class="tiny muted">Nothing open right now.</p>'}
        <div class="actions"><a class="btn small" href="#/studio?group=${g}">✎ Build an Exit Ticket or homework</a></div>
        ${miss.some(x => x.missing.length) ? `<details class="rd-list"><summary><b>All missing work, last 3 weeks</b></summary>${miss.filter(x => x.missing.length).map(x => `<div class="miss-item"><span class="pill ${x.a.type === 'Homework' ? 'amber' : 'pink'}">${x.a.type === 'Homework' ? 'HW' : 'ET'}</span> <a href="#/edit/${x.a.id}">${esc(x.a.title)}</a> <span class="tiny muted">due ${fmtDate(x.due)}</span><p class="miss-names">${x.missing.map(s => esc(s.name)).join(', ')}</p></div>`).join('')}<button class="btn small ghost" id="copy-missing" type="button">Copy list</button></details>` : ''}</section></div>
      <section class="card scroll"><h2 class="bar-head blue">Students</h2><table class="tbl"><thead><tr><th>Student</th><th>Missing (3 weeks)</th><th>Overall mastery</th><th>Latest notebook</th></tr></thead><tbody>${studs.map(s => { const m = missBy[s.id] || [], p = recentNb && S().progress[s.id + '|nb:' + recentNb.id], r = p && (p.responses || {}).rag;
        return `<tr><td><a href="#/student/${encodeURIComponent(s.id)}">${esc(s.name)}</a></td><td>${m.length ? `<span class="pill red">${m.length}</span> <span class="tiny">${m.map(x => esc(x.a.type === 'Homework' ? 'HW' : 'ET') + ' ' + fmtDate(x.due)).join(', ')}</span>` : '<span class="tiny muted">—</span>'}</td><td>${Hub.mastery.overall(s.id) ?? '—'}${Hub.mastery.overall(s.id) !== null ? '%' : ''}</td><td>${recentNb ? (p ? (r ? `<span class="rag-chip ${r}">${{ red: 'Stuck', amber: 'Getting there', green: 'Got it' }[r]}</span>` : 'opened') + ` <a class="tiny" href="#/lesson/${encodeURIComponent(recentNb.id)}?view=responses&sid=${encodeURIComponent(s.id)}">open</a>` : '<span class="tiny muted">not opened</span>') : ''}</td></tr>`; }).join('') || '<tr><td colspan="4">No students in this class yet.</td></tr>'}</tbody></table></section>
      <details class="card more-card"><summary><h2 class="bar-head amber">Personalised quizzes · skills · IA</h2><span class="tiny muted">optional — open when you want personalised tasks</span></summary>
        <div class="grid g2"><div><h3 class="sub-h">Personalised quizzes</h3><p class="tiny">A short task built for each student from their weakest skills.</p>
          <div class="pq-opt"><b>Do Now</b><span class="tiny">${dnCur ? (dn.status === 'published' ? '✓ published for the next lesson' : 'drafted — approve it') : 'none planned for the next lesson'}</span><a class="btn small ghost" href="#/donow?group=${g}">Do Now</a></div>
          <div class="pq-opt"><b>Exit Ticket</b><span class="tiny muted">personalised version not built yet</span></div>
          <div class="pq-opt"><b>Quiz</b><span class="tiny muted">personalised version not built yet</span></div></div>
        <div><h3 class="sub-h">Skills</h3>${skills.length ? `<p class="tiny"><b>Lowest class mastery:</b></p>${skills.map(([k, v]) => `<div class="snap"><span class="small">${esc(k.name)}</span><span>${v}%</span>${U.bar(v, v < 60 ? 'low' : '')}</div>`).join('')}` : '<p class="tiny muted">Not enough marked work yet for mastery.</p>'}<a class="btn small ghost" href="#/mastery?group=${g}">Mastery</a>
        <h3 class="sub-h">IA</h3>${Hub.ia ? Hub.ia.cardLine(g) : ia ? `<p class="tiny gc-ia">IA · <b>${esc(ia.short)}</b> due ${fmtDate(ia.date)}</p>` : ''}<a class="btn small ghost" href="#/ia?group=${g}">IA overview</a></div></div></details>`;
    const cp = $('#copy-missing'); if (cp) cp.onclick = async () => { const txt = miss.filter(x => x.missing.length).map(x => `${x.a.type} – ${x.a.title} (due ${fmtDate(x.due)}): ${x.missing.map(s => s.name).join(', ')}`).join('\n'); try { await navigator.clipboard.writeText(txt); toast('Copied.'); } catch (e) { toast('Could not copy here.', 'error'); } };
  }
  Hub.classdash = { view, missing, upcoming, cardSnippet };
})(window.Hub = window.Hub || {});
