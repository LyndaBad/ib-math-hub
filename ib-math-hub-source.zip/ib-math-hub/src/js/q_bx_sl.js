/* AA SL — book-exercise questions. NEW questions written for each Oxford AA SL (2019) exercise: same skills,
   style and level, different numbers, contexts and wording. Labelled with the exercise name only. */
(function (Hub) {
  'use strict';
  const B = Hub.qcore.bx, R = String.raw;
  const mcv = (ok) => `'k0' if ${ok} else 'bad'`;

  /* ===== 1.5 The binomial theorem ===== */
  B('SL', '1O', { page: 54, sec: '1.5', title: 'The binomial theorem', skill: 'SL-1.5b', paper: 1 }, [
    { paper: 2, stem: 'Find the indicated term in each expansion.', parts: [
      { c: 'Find', p: R`the fourth term of $(2x - 3)^{9}$.`, m: 3, a: { mc: [R`$-145152x^{6}$`, R`$326592x^{5}$`, R`$145152x^{6}$`, R`$-4536x^{6}$`] },
        ms: [['(M1)', R`the fourth term has $r = 3$`], ['(M1)', R`$\binom{9}{3}(2x)^{6}(-3)^{3}$`], ['A1', R`$-145152x^{6}$`]],
        w: [R`The fourth term has $r = 3$.`, R`$\binom{9}{3}(2x)^{6}(-3)^{3} = 84 \times 64x^{6} \times (-27)$`, R`$= -145152x^{6}$`], h: 'The term with r = 0 is the first term, so the fourth term has r = 3. Raise the whole of 2x and the whole of −3 to their powers.', v: mcv('expand(binomial(9,3)*(2*x)**6*(-3)**3) == -145152*x**6') },
      { c: 'Find', p: R`the seventh term of $(x + 4y)^{9}$.`, m: 3, a: { mc: [R`$344064x^{3}y^{6}$`, R`$86016x^{4}y^{5}$`, R`$336x^{3}y^{6}$`, R`$344064x^{6}y^{3}$`] },
        ms: [['(M1)', R`$r = 6$`], ['(M1)', R`$\binom{9}{6}x^{3}(4y)^{6}$`], ['A1', R`$344064x^{3}y^{6}$`]],
        w: [R`The seventh term has $r = 6$.`, R`$\binom{9}{6}x^{3}(4y)^{6} = 84 \times 4096\,x^{3}y^{6} = 344064x^{3}y^{6}$`], h: 'The seventh term has r = 6. Remember to raise 4 to the power too.', v: mcv('expand(binomial(9,6)*x**3*(4*y)**6) == 344064*x**3*y**6') },
      { c: 'Find', p: R`the middle term of $(3 - 2y)^{8}$.`, m: 3, a: { mc: [R`$90720y^{4}$`, R`$-90720y^{4}$`, R`$-72576y^{5}$`, R`$5670y^{4}$`] },
        ms: [['(M1)', R`there are 9 terms, so the middle term is the fifth, $r = 4$`], ['(M1)', R`$\binom{8}{4}3^{4}(-2y)^{4}$`], ['A1', R`$90720y^{4}$`]],
        w: [R`$(3 - 2y)^{8}$ has $9$ terms, so the middle term is the fifth term: $r = 4$.`, R`$\binom{8}{4}3^{4}(-2y)^{4} = 70 \times 81 \times 16y^{4} = 90720y^{4}$`], h: 'A power of 8 gives 9 terms. Which term is in the middle?', v: mcv('expand(binomial(8,4)*3**4*(-2*y)**4) == 90720*y**4') },
      { c: 'Find', p: R`the constant term of $\left(x^{2} - \frac{2}{x}\right)^{6}$.`, m: 3, a: 240,
        ms: [['(M1)', R`general term $\binom{6}{r}(x^{2})^{6-r}\left(-\frac{2}{x}\right)^{r}$`], ['(M1)', R`$12 - 3r = 0 \Rightarrow r = 4$`], ['A1', R`$240$`]],
        w: [R`General term: $\binom{6}{r}(x^{2})^{6-r}\left(-\frac{2}{x}\right)^{r} = \binom{6}{r}(-2)^{r}x^{12-3r}$`, R`Constant term when $12 - 3r = 0$, so $r = 4$.`, R`$\binom{6}{4}(-2)^{4} = 15 \times 16 = 240$`],
        e: [{ value: -160, fb: 'That is the term with r = 3 — check which power of x you need.' }, { value: 15, fb: 'Include (−2) to the power r, not just the binomial coefficient.' }], h: 'Write the general term and collect the powers of x. The constant term has x⁰.', v: 'expand(sum(binomial(6,r)*(x**2)**(6-r)*(-2/x)**r for r in range(7))).coeff(x,0)' },
      { c: 'Find', p: R`the last term of $\left(3x - \frac{1}{2x}\right)^{5}$.`, m: 2, a: { mc: [R`$-\frac{1}{32x^{5}}$`, R`$\frac{1}{32x^{5}}$`, R`$-\frac{5}{32x^{5}}$`, R`$-\frac{1}{2x^{5}}$`] },
        ms: [['(M1)', R`$r = 5$, $\left(-\frac{1}{2x}\right)^{5}$`], ['A1', R`$-\frac{1}{32x^{5}}$`]],
        w: [R`The last term has $r = 5$: $\binom{5}{5}(3x)^{0}\left(-\frac{1}{2x}\right)^{5} = -\frac{1}{32x^{5}}$`], h: 'The last term has r = n, so only the second part of the bracket appears.', v: mcv('simplify((-1/(2*x))**5 + 1/(32*x**5)) == 0') }
    ] },
    { stem: R`One row of Pascal’s triangle is $1,\ 5,\ 10,\ 10,\ 5,\ 1$.`, parts: [
      { c: 'Write down', p: 'the next row of the triangle.', m: 1, a: { t: [1, 6, 15, 20, 15, 6, 1], l: ['\\text{1st}', '\\text{2nd}', '\\text{3rd}', '\\text{4th}', '\\text{5th}', '\\text{6th}', '\\text{7th}'] },
        ms: [['A1', R`$1,\ 6,\ 15,\ 20,\ 15,\ 6,\ 1$`]], w: [R`Each entry is the sum of the two above it: $1,\ 1+5,\ 5+10,\ 10+10,\ 10+5,\ 5+1,\ 1$`], h: 'Each number is the sum of the two numbers above it. Every row starts and ends with 1.', v: 'tuple(binomial(6,i) for i in range(7))' },
      { c: 'Hence find', p: R`the coefficient of $x^{3}$ in the expansion of $(2x - 3)^{6}$.`, m: 3, a: -4320,
        ms: [['(M1)', R`uses $20$ from the row in (a)`], ['(M1)', R`$20(2x)^{3}(-3)^{3}$`], ['A1', R`$-4320$`]],
        w: [R`The $x^{3}$ term uses the coefficient $20$: $20(2x)^{3}(-3)^{3}$`, R`$= 20 \times 8x^{3} \times (-27) = -4320x^{3}$, so the coefficient is $-4320$`],
        e: [{ value: 4320, fb: 'Check the sign: (−3)³ is negative.' }, { value: -540, fb: 'Raise 2 to the power 3 as well as x.' }], h: 'The row 1, 6, 15, 20, 15, 6, 1 gives the coefficients for power 6. The x³ term uses the middle number.', v: 'expand((2*x-3)**6).coeff(x,3)' }
    ] },
    { stem: R`Consider the expansion of $(x + 2)^{7}$.`, parts: [
      { c: 'Find', p: R`the coefficient of $x^{4}$.`, m: 2, a: 280, ms: [['(M1)', R`$\binom{7}{3}x^{4}(2)^{3}$`], ['A1', R`$280$`]],
        w: [R`$\binom{7}{3}x^{4}2^{3} = 35 \times 8x^{4} = 280x^{4}$`], e: [{ value: 35, fb: 'Multiply by 2³ as well.' }, { value: 560, fb: 'Check r: the x⁴ term has 2³, not 2⁴.' }], h: 'For x⁴ you need x⁴ × 2³. Which binomial coefficient goes with it?', v: 'expand((x+2)**7).coeff(x,4)' },
      { c: 'Hence find', p: R`the coefficient of $x^{6}$ in the expansion of $3x^{2}(x + 2)^{7}$.`, m: 2, a: 840, ms: [['(M1)', R`$3x^{2} \times 280x^{4}$`], ['A1', R`$840$`]],
        w: [R`Only the $x^{4}$ term of $(x + 2)^{7}$ gives $x^{6}$ when multiplied by $3x^{2}$.`, R`$3x^{2} \times 280x^{4} = 840x^{6}$`], h: 'Which term of (x + 2)⁷ becomes x⁶ when you multiply it by 3x²?', v: 'expand(3*x**2*(x+2)**7).coeff(x,6)' }
    ] },
    { parts: [
      { c: 'Find', p: R`the coefficient of $x^{5}$ in the expansion of $\left(2x^{2} + \frac{1}{x}\right)^{7}$.`, m: 4, a: 560,
        ms: [['(M1)', R`general term $\binom{7}{r}(2x^{2})^{7-r}\left(\frac{1}{x}\right)^{r}$`], ['(M1)', R`$14 - 3r = 5$`], ['(A1)', R`$r = 3$`], ['A1', R`$560$`]],
        w: [R`General term: $\binom{7}{r}2^{7-r}x^{14-2r}x^{-r} = \binom{7}{r}2^{7-r}x^{14-3r}$`, R`$14 - 3r = 5 \Rightarrow r = 3$`, R`$\binom{7}{3}2^{4} = 35 \times 16 = 560$`],
        e: [{ value: 35, fb: 'Include 2 to the power (7 − r).' }, { value: 672, fb: 'That is the x⁸ term. Solve 14 − 3r = 5.' }], h: 'Write the general term with powers of x combined: x to the power (14 − 2r − r). Set it equal to 5.', v: 'expand((2*x**2+1/x)**7).coeff(x,5)' }
    ] },
    { parts: [
      { c: 'Find', p: R`the value of $k$, given that the constant term in the expansion of $\left(x + \frac{k}{x^{2}}\right)^{9}$ is $-672$.`, m: 5, a: -2,
        ms: [['(M1)', R`general term $\binom{9}{r}x^{9-r}\left(\frac{k}{x^{2}}\right)^{r}$`], ['(M1)', R`$9 - 3r = 0$`], ['(A1)', R`$r = 3$`], ['M1', R`$84k^{3} = -672$`], ['A1', R`$k = -2$`]],
        w: [R`General term: $\binom{9}{r}k^{r}x^{9-3r}$`, R`Constant term: $9 - 3r = 0 \Rightarrow r = 3$`, R`$\binom{9}{3}k^{3} = 84k^{3} = -672$`, R`$k^{3} = -8 \Rightarrow k = -2$`],
        e: [{ value: 2, fb: 'k³ = −8, so k is negative.' }, { value: -8, fb: 'That is k³. Take the cube root.' }], h: 'Find r for the constant term first, then set that term equal to −672.', v: '[s for s in solve(84*k**3+672,k) if s.is_real][0]' }
    ] },
    { parts: [
      { c: 'Find', p: R`the possible values of $k$, given that the third term in the expansion of $(3x - k)^{6}$ is $4860x^{4}$.`, m: 4, a: { list: [2, -2], d: R`k = \pm 2` },
        ms: [['(M1)', R`$\binom{6}{2}(3x)^{4}(-k)^{2}$`], ['(A1)', R`$1215k^{2}x^{4}$`], ['M1', R`$1215k^{2} = 4860$`], ['A1', R`$k = \pm 2$`]],
        w: [R`Third term ($r = 2$): $\binom{6}{2}(3x)^{4}(-k)^{2} = 15 \times 81k^{2}x^{4} = 1215k^{2}x^{4}$`, R`$1215k^{2} = 4860 \Rightarrow k^{2} = 4 \Rightarrow k = 2$ or $k = -2$`], h: 'The third term has r = 2. Write it in terms of k, then compare with 4860x⁴.', v: 'solve(1215*k**2-4860,k)' }
    ] },
    { parts: [
      { c: 'Find', p: R`the coefficient of $x^{6}y^{3}$ in the expansion of $(x^{2} - 2y)^{6}$.`, m: 3, a: -160,
        ms: [['(M1)', R`$r = 3$`], ['(M1)', R`$\binom{6}{3}(x^{2})^{3}(-2y)^{3}$`], ['A1', R`$-160$`]],
        w: [R`$y^{3}$ needs $r = 3$, which gives $(x^{2})^{3} = x^{6}$.`, R`$\binom{6}{3}(x^{2})^{3}(-2y)^{3} = 20 \times (-8)x^{6}y^{3} = -160x^{6}y^{3}$`],
        e: [{ value: 160, fb: 'Check the sign of (−2y)³.' }, { value: 20, fb: 'Multiply by (−2)³ as well.' }], h: 'y³ means r = 3. Check that this gives x⁶ too.', v: 'expand((x**2-2*y)**6).coeff(x,6).coeff(y,3)' }
    ] },
    { parts: [
      { c: 'Use', p: R`the binomial theorem to estimate $(1.98)^{5}$, giving your answer correct to three decimal places.`, m: 4, a: { n: 30.4316815968, dp: 3, d: '30.432' },
        ms: [['M1', R`writing $1.98 = 2 - 0.02$`], ['M1', R`expansion with at least three terms: $2^{5} - \binom{5}{1}2^{4}(0.02) + \binom{5}{2}2^{3}(0.02)^{2} - \dots$`], ['(A1)', R`$32 - 1.6 + 0.032 - 0.00032$`], ['A1', R`$30.432$`]],
        w: [R`$(1.98)^{5} = (2 - 0.02)^{5}$`, R`$= 2^{5} - 5(2^{4})(0.02) + 10(2^{3})(0.02)^{2} - 10(2^{2})(0.02)^{3} + \dots$`, R`$= 32 - 1.6 + 0.032 - 0.00032 + \dots = 30.43168\dots$`, R`$\approx 30.432$ (later terms are too small to change the third decimal place)`],
        h: 'Write 1.98 as 2 − 0.02.', v: 'Rational(198,100)**5' }
    ] },
    { parts: [
      { c: 'Expand', p: R`$(x + 3)^{4}$.`, m: 2, a: { mc: [R`$x^{4} + 12x^{3} + 54x^{2} + 108x + 81$`, R`$x^{4} + 4x^{3} + 6x^{2} + 4x + 81$`, R`$x^{4} + 12x^{3} + 18x^{2} + 36x + 81$`, R`$x^{4} + 81$`] },
        ms: [['(M1)', R`uses $1,\ 4,\ 6,\ 4,\ 1$`], ['A1', R`$x^{4} + 12x^{3} + 54x^{2} + 108x + 81$`]],
        w: [R`$x^{4} + 4x^{3}(3) + 6x^{2}(3^{2}) + 4x(3^{3}) + 3^{4}$`, R`$= x^{4} + 12x^{3} + 54x^{2} + 108x + 81$`], h: 'Use the row 1, 4, 6, 4, 1 and raise 3 to the powers 0 to 4.', v: mcv('expand((x+3)**4) == x**4+12*x**3+54*x**2+108*x+81') },
      { c: 'Hence find', p: R`the coefficient of $x^{3}$ in the expansion of $(2x - 5)(x + 3)^{4}$.`, m: 3, a: 48,
        ms: [['(M1)', R`$2x \times 54x^{2}$ and $-5 \times 12x^{3}$`], ['(A1)', R`$108x^{3} - 60x^{3}$`], ['A1', R`$48$`]],
        w: [R`$x^{3}$ terms: $2x \times 54x^{2} = 108x^{3}$ and $-5 \times 12x^{3} = -60x^{3}$`, R`$108x^{3} - 60x^{3} = 48x^{3}$, so the coefficient is $48$`],
        e: [{ value: 108, fb: 'There is a second x³ term: −5 × 12x³.' }, { value: -60, fb: 'There is a second x³ term: 2x × 54x².' }, { value: 168, fb: 'Check the sign: −5 × 12x³ = −60x³.' }], h: 'There are two ways to make x³: 2x times an x² term, and −5 times the x³ term.', v: 'expand((2*x-5)*(x+3)**4).coeff(x,3)' }
    ] },
    { parts: [
      { c: 'Show that', p: R`the expansions of $(1 - 3x)^{4}$ and $(-3x + 1)^{4}$ are the same.`, m: 2, a: 'open',
        ms: [['M1', R`expands one of them, e.g. $1 - 12x + 54x^{2} - 108x^{3} + 81x^{4}$`], ['R1', R`$1 - 3x$ and $-3x + 1$ are the same number for every $x$ (addition is commutative), so their fourth powers are identical`], ['AG', '']],
        w: [R`$(1 - 3x)^{4} = 1 - 12x + 54x^{2} - 108x^{3} + 81x^{4}$`, R`$(-3x + 1)^{4} = 81x^{4} - 108x^{3} + 54x^{2} - 12x + 1$ — the same terms in the opposite order.`], h: 'Is 1 − 3x the same number as −3x + 1?', v: 'expand((1-3*x)**4) == expand((-3*x+1)**4)' },
      { c: 'Explain', p: R`whether $(1 - 3x)^{4}$ and $(3x - 1)^{4}$ have the same expansion.`, m: 2, a: 'open',
        ms: [['R1', R`$3x - 1 = -(1 - 3x)$`], ['R1', R`$(-1)^{4} = 1$, so yes, they are the same (for an even power)`]],
        w: [R`$(3x - 1)^{4} = \left(-(1 - 3x)\right)^{4} = (-1)^{4}(1 - 3x)^{4} = (1 - 3x)^{4}$`, R`So the expansions are the same. (With an odd power they would differ in sign.)`], h: 'Write 3x − 1 as −(1 − 3x). What is (−1)⁴?', v: 'expand((3*x-1)**4) == expand((1-3*x)**4)' }
    ] },
    { parts: [
      { c: 'Find', p: R`the binomial, in the form $(a + b)^{n}$, whose expansion is $8x^{3} + 36x^{2}y + 54xy^{2} + 27y^{3}$.`, m: 3, a: { mc: [R`$(2x + 3y)^{3}$`, R`$(8x + 27y)^{3}$`, R`$(2x + 9y)^{3}$`, R`$(4x + 3y)^{3}$`] },
        ms: [['(M1)', R`$n = 3$ (four terms)`], ['(M1)', R`$a^{3} = 8x^{3}$ and $b^{3} = 27y^{3}$`], ['A1', R`$(2x + 3y)^{3}$`]],
        w: [R`Four terms, so $n = 3$.`, R`First term $8x^{3} = (2x)^{3}$, last term $27y^{3} = (3y)^{3}$.`, R`Check: $3(2x)^{2}(3y) = 36x^{2}y$ ✓, so $(2x + 3y)^{3}$`], h: 'Count the terms to find n. The first and last terms are a³ and b³.', v: mcv('expand((2*x+3*y)**3) == 8*x**3+36*x**2*y+54*x*y**2+27*y**3') }
    ] },
    { parts: [
      { c: 'Show that', p: R`$\binom{n}{0} + \binom{n}{1} + \binom{n}{2} + \dots + \binom{n}{n} = 2^{n}$ by considering the expansion of $(1 + x)^{n}$.`, m: 2, a: 'open',
        ms: [['M1', R`$(1 + x)^{n} = \binom{n}{0} + \binom{n}{1}x + \dots + \binom{n}{n}x^{n}$`], ['M1', R`substituting $x = 1$: $2^{n} = \binom{n}{0} + \binom{n}{1} + \dots + \binom{n}{n}$`], ['AG', '']],
        w: [R`$(1 + x)^{n} = \binom{n}{0} + \binom{n}{1}x + \binom{n}{2}x^{2} + \dots + \binom{n}{n}x^{n}$`, R`Let $x = 1$: $(1 + 1)^{n} = 2^{n} = \binom{n}{0} + \binom{n}{1} + \dots + \binom{n}{n}$`], h: 'What happens to (1 + x)ⁿ and to each term of its expansion when x = 1?', v: 'all(sum(binomial(m,i) for i in range(m+1)) == 2**m for m in range(1,12))' },
      { c: 'Hence find', p: R`the value of $\binom{8}{1} + \binom{8}{2} + \dots + \binom{8}{7}$.`, m: 2, a: 254,
        ms: [['M1', R`$2^{8} - \binom{8}{0} - \binom{8}{8}$`], ['A1', R`$254$`]],
        w: [R`The full sum is $2^{8} = 256$; leave out $\binom{8}{0} = 1$ and $\binom{8}{8} = 1$.`, R`$256 - 2 = 254$`], e: [{ value: 256, fb: 'The sum starts at 8C1 and stops at 8C7 — remove the two 1s.' }], h: 'Use part (a) with n = 8, then remove the terms you do not need.', v: 'sum(binomial(8,i) for i in range(1,8))' }
    ] }
  ]);

  /* ===== 1.6 Proofs ===== */
  const proof = (lhs, rhs, steps, v) => ({ c: 'Prove', p: 'that $' + lhs + ' = ' + rhs + '$.', m: 3, a: 'open', h: 'Start with the LHS only. Expand or use a common denominator, simplify, and finish with LHS = RHS.',
    ms: [['M1', 'works on one side only (the LHS), e.g. expanding the brackets or using a common denominator'], ['A1', steps[steps.length - 2]], ['A1', 'reaches the RHS and writes a concluding statement (LHS = RHS)']], w: steps.concat(['LHS = RHS ∎']), v });
  B('SL', '1P', { page: 56, sec: '1.6', title: 'Proofs', skill: 'SL-1.6', paper: 1 }, [
    { parts: [proof(R`3(2b + 5) - 4(b - 1) + 2(b - 6)`, R`4b + 7`, [R`$\text{LHS} = 6b + 15 - 4b + 4 + 2b - 12$`, R`$= (6b - 4b + 2b) + (15 + 4 - 12)$`, R`$= 4b + 7 = \text{RHS}$`], 'expand(3*(2*k+5)-4*(k-1)+2*(k-6)) == 4*k+7')] },
    { parts: [proof(R`(x + 4)^{2} - 7`, R`x^{2} + 8x + 9`, [R`$\text{LHS} = x^{2} + 8x + 16 - 7$`, R`$= x^{2} + 8x + 9$`, R`$= \text{RHS}$`], 'expand((x+4)**2-7) == x**2+8*x+9')] },
    { parts: [proof(R`\frac{1}{n} - \frac{1}{n + 2}`, R`\frac{2}{n(n + 2)}`, [R`$\text{LHS} = \frac{n + 2}{n(n + 2)} - \frac{n}{n(n + 2)}$`, R`$= \frac{n + 2 - n}{n(n + 2)}$`, R`$= \frac{2}{n(n + 2)} = \text{RHS}$`], 'simplify(1/n - 1/(n+2) - 2/(n*(n+2))) == 0')] },
    { stem: R`Consider the statement $\frac{x^{2} - x - 6}{x^{2} - 9} \equiv \frac{x + 2}{x + 3}$.`, parts: [
      { c: 'Prove', p: 'that the statement is true for all values of $x$ for which both sides are defined.', m: 3, a: 'open',
        ms: [['M1', R`factorizes: $\frac{(x - 3)(x + 2)}{(x - 3)(x + 3)}$`], ['A1', R`cancels the common factor $(x - 3)$`], ['A1', R`$= \frac{x + 2}{x + 3} = \text{RHS}$ with a concluding statement`]],
        w: [R`$\text{LHS} = \frac{(x - 3)(x + 2)}{(x - 3)(x + 3)}$`, R`$= \frac{x + 2}{x + 3}$ (for $x \neq 3$)`, R`$= \text{RHS}$ ∎`], h: 'Factorize the numerator and the denominator of the LHS.', v: 'simplify((x**2-x-6)/(x**2-9) - (x+2)/(x+3)) == 0' },
      { c: 'Write down', p: 'the values of $x$ for which the statement does not hold.', m: 2, a: { list: [3, -3], d: R`x = 3,\ x = -3` },
        ms: [['A1', R`$x = 3$`], ['A1', R`$x = -3$`]], w: [R`The LHS is undefined when $x^{2} - 9 = 0$, i.e. $x = \pm 3$.`, R`So the statement does not hold for $x = 3$ or $x = -3$.`], h: 'When is a fraction undefined?', v: 'solve(x**2-9, x)' }
    ] },
    { parts: [proof(R`(2n + 1)^{2} - (2n - 1)^{2}`, R`8n`, [R`$\text{LHS} = (4n^{2} + 4n + 1) - (4n^{2} - 4n + 1)$`, R`$= 4n^{2} + 4n + 1 - 4n^{2} + 4n - 1$`, R`$= 8n = \text{RHS}$`], 'expand((2*n+1)**2-(2*n-1)**2) == 8*n')] }
  ]);
})(window.Hub = window.Hub || {});
