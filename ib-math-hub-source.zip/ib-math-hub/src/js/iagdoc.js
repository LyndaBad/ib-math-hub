/* IA Studio · Google Docs. The student signs in with Google (Google Identity Services, scope drive.file — the Hub can only
   reach documents it creates for that student). The document is created in the student's own Drive, so they own it.
   There is no live sync: the Hub reads the document only when the student presses “Check my doc” and says when that was.
   Needs Miss Badmus to add a Google OAuth client ID in IA settings (setup steps are there). Until then students can paste
   a link to their own Google Doc so it is one click away, and keep writing in the Hub.
   Data: ia[sid].gdoc = { id, url, name, via: 'hub' | 'link', created, check: { at, modified, words, headings, cites }, shared, bibAt }. */
(function (Hub) {
  'use strict';
  const { esc, $, toast, fmtDateTime } = Hub.core;
  const U = Hub.ui, S = () => Hub.store.state;
  const SCOPE = 'https://www.googleapis.com/auth/drive.file';
  const cfg = () => (S().settings || {}).iaconfig || {};
  const clientId = () => String(cfg().googleClientId || ((window.HUB_CONFIG || {}).google || {}).clientId || '').trim();
  const teacherEmail = () => cfg().teacherGoogle || 'lyndab.badmus@cms.k12.nc.us';
  let token = null, tokenExp = 0, gisP = null;
  function loadGIS() {
    if (window.google && google.accounts && google.accounts.oauth2) return Promise.resolve();
    if (gisP) return gisP;
    gisP = new Promise((res, rej) => { const sc = document.createElement('script'); sc.src = 'https://accounts.google.com/gsi/client'; sc.async = true; sc.onload = () => res(); sc.onerror = () => { gisP = null; rej(Error('Google sign-in could not load — check the connection (some school networks block it).')); }; document.head.appendChild(sc); });
    return gisP;
  }
  function getToken() {
    if (token && Date.now() < tokenExp - 60000) return Promise.resolve(token);
    if (!clientId()) return Promise.reject(Error('Google Docs is not set up yet.'));
    return loadGIS().then(() => new Promise((res, rej) => {
      const tc = google.accounts.oauth2.initTokenClient({ client_id: clientId(), scope: SCOPE,
        callback: r => { if (r.error) return rej(Error(r.error === 'access_denied' ? 'Google access was not allowed.' : 'Google sign-in failed (' + r.error + ').')); token = r.access_token; tokenExp = Date.now() + (Number(r.expires_in) || 3600) * 1000; res(token); },
        error_callback: e => rej(Error(e && e.type === 'popup_closed' ? 'The Google window was closed before you finished.' : e && e.type === 'popup_failed_to_open' ? 'Your browser blocked the Google window — allow pop-ups for this site.' : 'Google sign-in did not finish.')) });
      tc.requestAccessToken();
    }));
  }
  async function api(url, opts = {}) {
    const t = await getToken(), r = await fetch(url, Object.assign({}, opts, { headers: Object.assign({ Authorization: 'Bearer ' + t }, opts.headers || {}) }));
    if (r.status === 401) { token = null; throw Error('Your Google sign-in has expired — press the button again.'); }
    if (!r.ok) { let m = ''; try { m = ((await r.json()).error || {}).message || ''; } catch (e) { /* not JSON */ } throw Error(r.status === 403 ? `Google refused (${m || 'no permission'}). Your school’s Google administrator may need to allow this app.` : r.status === 404 ? 'Google cannot find that document for the Hub — it may be deleted, or it was not created by the Hub.' : `Google error ${r.status}${m ? ': ' + m : ''}`); }
    return r;
  }
  const docUrl = id => `https://docs.google.com/document/d/${id}/edit`;
  /** A blank exploration with headings and short prompts (the student replaces the prompts with their own writing). */
  function templateHTML(s, n) {
    const P = n.planB || {}, ol = (P.outline || []).filter(o => o.h);
    const secs = ol.length ? ol.map(o => [o.h, o.m || '']) : Hub.ia.WRITE.map(w => [w.title, (w.parts || []).map(p => p[1]).join(' · ')]);
    return `<h1>${esc((n.fields || {}).title || 'Title of my exploration')}</h1><p><i>IB Mathematics: analysis and approaches · ${s.course === 'HL' ? 'Higher' : 'Standard'} Level · Mathematical exploration</i></p>` +
      secs.map(([h, p]) => `<h2>${esc(h)}</h2><p style="color:#888888"><i>${esc(p ? 'Prompt — replace with your own writing: ' + p : 'Write this section in your own words.')}</i></p>`).join('');
  }
  async function createDoc(s, n, fromHub) {
    const name = 'IA · ' + String((n.fields || {}).title || 'Mathematical exploration').slice(0, 90), html = fromHub ? Hub.ia.printDoc(s, n, true) : templateHTML(s, n), b = 'hubia' + Date.now();
    const body = `--${b}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify({ name, mimeType: 'application/vnd.google-apps.document', description: 'My IB Mathematics exploration (created from the IB Math Hub).' })}\r\n--${b}\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n<html><head><meta charset="utf-8"></head><body>${html}</body></html>\r\n--${b}--`;
    const f = await (await api('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink', { method: 'POST', headers: { 'Content-Type': 'multipart/related; boundary=' + b }, body })).json();
    n.gdoc = { id: f.id, url: f.webViewLink || docUrl(f.id), name: f.name || name, via: 'hub', created: new Date().toISOString() };
  }
  const CITE_RE = /\([^()]{2,90}?\b(?:(?:19|20)\d\d|n\.d\.|no date|\d{1,4})[^()]{0,30}\)|[A-Z][\p{L}'’\-]+(?:(?:,? and |,? & |, )[A-Z][\p{L}'’\-]+)*(?: et al\.)? \((?:19|20)\d\d[a-z]?\)/gu;
  async function check(s, n) {
    const id = n.gdoc.id, meta = await (await api(`https://www.googleapis.com/drive/v3/files/${id}?fields=name,modifiedTime,trashed,webViewLink`)).json();
    const text = await (await api(`https://www.googleapis.com/drive/v3/files/${id}/export?mimeType=text/plain`)).text();
    const html = await (await api(`https://www.googleapis.com/drive/v3/files/${id}/export?mimeType=text/html`)).text();
    const headings = [...html.matchAll(/<h[1-3][^>]*>([\s\S]*?)<\/h[1-3]>/g)].map(m => m[1].replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').trim()).filter(Boolean).slice(0, 40);
    const cites = [...new Set(text.match(CITE_RE) || [])].filter(c => /[A-Z]/.test(c)).slice(0, 150);
    n.gdoc.check = { at: new Date().toISOString(), modified: meta.modifiedTime, words: text.split(/\s+/).filter(Boolean).length, headings, cites, trashed: !!meta.trashed };
    if (meta.name) n.gdoc.name = meta.name; if (meta.webViewLink) n.gdoc.url = meta.webViewLink;
  }
  async function share(s, n) {
    const email = teacherEmail();
    await api(`https://www.googleapis.com/drive/v3/files/${n.gdoc.id}/permissions?sendNotificationEmail=false&fields=id`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ role: 'commenter', type: 'user', emailAddress: email }) });
    n.gdoc.shared = { at: new Date().toISOString(), email, role: 'commenter' };
  }
  const canInsert = n => !!(n.gdoc && n.gdoc.id && n.gdoc.via === 'hub' && clientId());
  /** Adds a “References” heading and the list (italics and hanging indents kept) at the end of the student's Google Doc. */
  async function insertBibliography(s, n, list) {
    if (!canInsert(n)) throw Error('Create your IA document from the Hub first (Writing stage).');
    const id = n.gdoc.id, doc = await (await api(`https://docs.googleapis.com/v1/documents/${id}?fields=body(content(endIndex))`)).json();
    const at = doc.body.content[doc.body.content.length - 1].endIndex - 1;
    const head = '\nReferences\n', reqs = [], ital = []; let text = head, pos = at + head.length;
    const entryStart = pos;
    list.forEach(segs => { segs.forEach(([t, i]) => { if (i && t) ital.push([pos, pos + t.length]); pos += t.length; text += t; }); text += '\n'; pos += 1; });
    reqs.push({ insertText: { location: { index: at }, text } });
    reqs.push({ updateParagraphStyle: { range: { startIndex: at + 1, endIndex: at + head.length }, paragraphStyle: { namedStyleType: 'HEADING_2' }, fields: 'namedStyleType' } });
    reqs.push({ updateParagraphStyle: { range: { startIndex: entryStart, endIndex: pos }, paragraphStyle: { namedStyleType: 'NORMAL_TEXT', indentStart: { magnitude: 36, unit: 'PT' }, indentFirstLine: { magnitude: 0, unit: 'PT' } }, fields: 'namedStyleType,indentStart,indentFirstLine' } });
    reqs.push({ updateTextStyle: { range: { startIndex: entryStart, endIndex: pos }, textStyle: { italic: false, bold: false }, fields: 'italic,bold' } });
    ital.forEach(([a, b]) => reqs.push({ updateTextStyle: { range: { startIndex: a, endIndex: b }, textStyle: { italic: true }, fields: 'italic' } }));
    await api(`https://docs.googleapis.com/v1/documents/${id}:batchUpdate`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ requests: reqs }) });
    n.gdoc.bibAt = new Date().toISOString(); Hub.ia.stamp(n); Hub.store.save(true);
  }
  function sideBySide(url) { const w = Math.round((screen.availWidth || 1200) / 2), h = screen.availHeight || 800; const win = window.open(url, 'iadoc', `popup=yes,width=${w},height=${h},left=${w},top=0`); if (!win) toast('Your browser blocked the window — allow pop-ups, or use “Open in a new tab”.', 'error'); }

  /* ---------- the panel in the Writing stage ---------- */
  function panel(s, n, r, teacher) {
    const g = n.gdoc || {}, ready = !!clientId(), c = g.check;
    const head = `<section class="card gdoc"><div class="row-between"><h2 class="bar-head blue">My Google Doc</h2>${g.url ? `<span class="pill ${g.via === 'hub' ? 'green' : 'grey'}">${g.via === 'hub' ? 'created by the Hub' : 'linked'}</span>` : ''}</div>`;
    if (teacher) return head + (g.url ? `<p class="small">${g.shared ? `Shared with ${esc(g.shared.email)} on ${fmtDateTime(g.shared.at)}. <a class="btn small" href="${esc(g.url)}" target="_blank" rel="noopener">Open the student’s Google Doc ↗</a>` : `Linked, but not shared with you yet. <a href="${esc(g.url)}" target="_blank" rel="noopener">Try the link ↗</a> (it opens only if the student has shared it).`}</p>${c ? `<p class="tiny muted">The student last checked it from the Hub ${fmtDateTime(c.at)}: ${c.words} words, ${c.headings.length} headings.</p>` : ''}` : '<p class="small muted">No Google Doc linked yet.</p>') + (ready ? '' : '<p class="tiny muted">Google Docs connection: not set up — see <a href="#/ia?view=settings">IA settings</a>.</p>') + '</section>';
    if (g.url) return head + `<p class="small"><b>${esc(g.name || 'My IA document')}</b></p>
      <div class="actions"><a class="btn small primary" href="${esc(g.url)}" target="_blank" rel="noopener">Open in a new tab ↗</a><button class="btn small" type="button" data-gd="side">Open side by side</button>${g.via === 'hub' && !r ? '<button class="btn small" type="button" data-gd="check">Check my doc</button>' : ''}${g.via === 'hub' && !r && !g.shared ? '<button class="btn small" type="button" data-gd="share">Share with Miss Badmus</button>' : ''}${r ? '' : '<button class="btn small ghost" type="button" data-gd="unlink">Unlink</button>'}</div>
      <p class="tiny muted" id="gd-msg">${c ? `Last checked ${fmtDateTime(c.at)} — ${c.words} words, ${c.headings.length} heading${c.headings.length === 1 ? '' : 's'}${c.modified ? `; Google says it was last edited ${fmtDateTime(c.modified)}` : ''}.` : g.via === 'hub' ? 'Not checked yet.' : ''} ${g.via === 'hub' ? 'The Hub does not sync live: it reads your document only when you press “Check my doc”.' : 'The Hub can only open linked documents, not read them. Create your document from the Hub if you want word counts, citation checks and the reference list added for you.'}${g.shared ? ` Shared with Miss Badmus (can comment) on ${fmtDateTime(g.shared.at)}.` : ''}</p>
      ${c && c.headings.length ? `<details><summary class="tiny">Headings found in your document</summary><ol class="tiny">${c.headings.map(h => `<li>${esc(h)}</li>`).join('')}</ol></details>` : ''}
      <p class="tiny muted">Your document lives in your own Google Drive — you own it.</p></section>`;
    if (r) return head + '<p class="small muted">No Google Doc linked.</p></section>';
    return head + (ready ? `<p class="small">Write your exploration in Google Docs and keep the Hub beside it for the checklists, checks and references. The Hub creates the document in <b>your own Google Drive</b> — you own it. It can only see documents it creates for you, and only when you press “Check my doc”.</p>
      <label class="inline-check"><input type="checkbox" id="gd-from"> Start it from what I have already written in the Hub (otherwise: headings and prompts only)</label>
      <div class="actions"><button class="btn small primary" type="button" data-gd="create">Connect Google and create my IA document</button></div><p class="tiny muted" id="gd-msg"></p>`
      : `<p class="small">The Google Docs connection is not switched on yet, so the Hub cannot create or read documents. You can write here in the Hub, or keep your own Google Doc one click away:</p>`) +
      `<details ${ready ? '' : 'open'}><summary class="small">Link a Google Doc I already have</summary><div class="lookup"><label>Paste the link<input id="gd-link" placeholder="https://docs.google.com/document/d/…"></label><button class="btn small" type="button" data-gd="link">Link it</button></div><p class="tiny muted">The Hub only stores the link so you can open it from here.</p></details></section>`;
  }
  function bind(el, s, n, r, teacher) {
    if (teacher || r) { const sb = el.querySelector('[data-gd="side"]'); if (sb) sb.onclick = () => sideBySide(n.gdoc.url); return; }
    const msg = t => { const m = $('#gd-msg', el); if (m) m.textContent = t; };
    const act = async (b, fn, busy) => { b.disabled = true; msg(busy); try { await fn(); Hub.ia.stamp(n); Hub.store.save(true); await Hub.store.flush(); Hub.app.render(); } catch (e) { msg(e.message); toast(e.message, 'error'); b.disabled = false; } };
    el.querySelectorAll('[data-gd]').forEach(b => (b.onclick = async () => {
      const k = b.dataset.gd;
      if (k === 'create') return act(b, async () => { await createDoc(s, n, !!($('#gd-from', el) || {}).checked); toast('Your IA document is ready in your Google Drive.'); }, 'Opening Google…');
      if (k === 'check') return act(b, async () => { await check(s, n); toast('Checked.'); }, 'Reading your document…');
      if (k === 'share') { if (!(await U.confirmBox(`Share your document with Miss Badmus (${esc(teacherEmail())}) so she can read it and comment? You stay the owner.`, 'Share'))) return; return act(b, async () => { await share(s, n); toast('Shared with Miss Badmus.'); }, 'Sharing…'); }
      if (k === 'side') return sideBySide(n.gdoc.url);
      if (k === 'unlink') { if (!(await U.confirmBox('Unlink this document from the Hub? The document itself stays in your Google Drive.', 'Unlink'))) return; delete n.gdoc; Hub.ia.stamp(n); Hub.store.save(true); Hub.app.render(); return; }
      if (k === 'link') { const v = ($('#gd-link', el).value || '').trim(), m = v.match(/^https:\/\/docs\.google\.com\/document\/(?:u\/\d+\/)?d\/([\w-]{20,})/); if (!m) return toast('Paste the link of a Google Doc (https://docs.google.com/document/d/…).', 'error'); n.gdoc = { id: m[1], url: docUrl(m[1]), via: 'link', name: 'My IA document', created: new Date().toISOString() }; Hub.ia.stamp(n); Hub.store.save(true); Hub.app.render(); }
    }));
  }
  /** Teacher settings: what is set up, and the steps to set it up. */
  function setupHTML() {
    const id = clientId();
    return `<p class="small">Status: ${id ? `<span class="pill green">client ID saved</span> — test it with a test-student account before telling the class.` : '<span class="pill amber">not set up</span> — students can still write in the Hub and link their own Google Doc.'}</p>
      <ol class="small setup"><li>Signed in to Google with an account you control (your personal account works; Claude cannot do this part), open <b>console.cloud.google.com</b> and create a project, e.g. “IB Math Hub IA”.</li>
      <li><b>APIs &amp; Services → Library</b>: enable the <b>Google Drive API</b> and the <b>Google Docs API</b>.</li>
      <li><b>OAuth consent screen</b>: user type <i>External</i>, app name “Miss Badmus’ IB Math Hub”, your email as support and developer contact, scope <code>…/auth/drive.file</code> only (a non-sensitive scope), then <b>Publish app</b> so it is not limited to test users.</li>
      <li><b>Credentials → Create credentials → OAuth client ID</b>: type <i>Web application</i>; Authorised JavaScript origin <code>https://missbadmusibmath.com</code>. No redirect URI is needed. Copy the <b>Client ID</b> (it ends in <code>.apps.googleusercontent.com</code>; it is not a secret) and paste it below.</li>
      <li><b>CMS students are under 18.</b> Google Workspace for Education blocks unconfigured third-party apps for under-18 accounts, so CMS’s Google administrator must allow this client ID (Admin console → Security → API controls → App access control → Configure new app → the client ID → <i>Specific Google data</i> or <i>Limited</i>). The district is also responsible for any parental-consent requirements. Until they do, students will see “access blocked”.</li></ol>
      <div class="form-grid"><label class="span2">Google OAuth client ID<input id="gd-cid" value="${esc(id)}" placeholder="1234…-abc.apps.googleusercontent.com"></label><label class="span2">Email students share their document with (as commenter)<input id="gd-temail" value="${esc(teacherEmail())}"></label></div>`;
  }
  function readSetup(root) { const v = ($('#gd-cid', root) || {}).value || '', e = ($('#gd-temail', root) || {}).value || ''; if (v && !/^[\w-]+\.apps\.googleusercontent\.com$/.test(v.trim())) throw Error('That does not look like an OAuth client ID (it ends in .apps.googleusercontent.com).'); if (e && !/^\S+@\S+\.\S+$/.test(e.trim())) throw Error('Check the sharing email address.'); return { googleClientId: v.trim(), teacherGoogle: e.trim() }; }

  Hub.iagdoc = { panel, bind, setupHTML, readSetup, canInsert, insertBibliography, check, createDoc, share, clientId, _reset: () => { token = null; tokenExp = 0; } };
})(window.Hub = window.Hub || {});
