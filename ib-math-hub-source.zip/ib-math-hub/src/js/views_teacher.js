/* Teacher views: dashboard, Assessment Studio (build → review → approve → publish), marking queue,
   item analysis, personalised Do Now, mastery, student profile. */
(function (Hub) {
  'use strict';
  const { esc, $, $$, fmtDate, fmtDateTime, toast, download, debounce, todayISO } = Hub.core;
  const U = Hub.ui, C = () => Hub.curriculum, S = () => Hub.store.state, M = t => Hub.math.render(t);
  const go = h => Hub.app.nav(h);
  const pref = (k, v) => { try { if (v === undefined) return localStorage.getItem('hub-pref-' + k); localStorage.setItem('hub-pref-' + k, v); } catch (e) { return null; } };
  const groupPick = (id, sel, course) => `<label class="inline"><span class="sr">Group</span><select id="${id}">${U.groupOptions(sel, course)}</select></label>`;
  const curGroup = () => pref('group') || 'HL-A';

  /* ================= Dashboard ================= */
  function dashboard(main) {
    const asOf = Hub.mastery.asOf(), q = Hub.assess.queue(), drafts = S().assessments.filter(a => a.status === 'draft');
    const cards = Object.values(C().GROUPS).map(g => {
      const nl = C().nextLesson(g.id, asOf), dn = S().donow[g.id], dnCur = dn && nl && dn.lessonDate === nl.date;
      const ia = C().iaSchedule(g.id).find(s => s.date && s.date >= asOf);
      return `<section class="card group-card ${g.course.toLowerCase()}"><div class="gc-head"><h3><a href="#/class/${g.id}">${g.label}</a></h3><span class="tiny muted">${g.block} · ${Hub.roster.inGroup(g.id).length} students</span></div>
        ${nl ? `<p class="gc-date">${fmtDate(nl.date, true)}</p><p class="gc-lesson">${esc(nl.activity)}</p><div class="chips">${nl.skills.map(s => U.skillChip(s)).join('')}</div>` : '<p>No more lessons in the calendar.</p>'}
        <div class="gc-actions">${nl && Hub.lessons.idFor(g.id, nl.date) ? `<a class="btn small ghost" href="#/lesson/${encodeURIComponent(Hub.lessons.idFor(g.id, nl.date))}">▣ Notebook</a>` : ''}<a class="btn small" href="#/studio?group=${g.id}">✎ Exit Ticket</a><a class="btn small ${dnCur && dn.status === 'published' ? 'ghost' : 'pink'}" href="#/donow?group=${g.id}">${dnCur ? (dn.status === 'published' ? '✓ Do Now published' : 'Approve Do Now') : '☀ Plan Do Now'}</a></div>
        ${Hub.ia ? Hub.ia.cardLine(g.id) : ia ? `<p class="tiny gc-ia">IA · ${esc(ia.short)} due ${fmtDate(ia.date)}</p>` : ''}
        ${Hub.classdash ? Hub.classdash.cardSnippet(g.id) : ''}<a class="btn small primary gc-open" href="#/class/${g.id}">Class dashboard →</a></section>`;
    }).join('');
    const mis = ['SL-A', 'SL-B', 'HL-A', 'HL-B'].flatMap(g => Hub.mastery.misconceptions(g, 28).slice(0, 2).map(m => Object.assign({ g }, m))).sort((a, b) => b.students - a.students).slice(0, 6);
    main.innerHTML = U.heading(`${fmtDate(asOf, true).toUpperCase()} · TEACHER DASHBOARD`, 'Every learner. A next step.', 'Inquirers. Thinkers. Reflective Learners.', `<img class="hero-wolf" src="${Hub.LOGO}" alt="Miss Badmus’ IB wolf logo">`) +
      `<div class="attention">
        <a class="att ${q.length ? 'hot' : ''}" href="#/marking"><b>${q.length}</b><span>submission${q.length === 1 ? '' : 's'} to mark</span></a>
        <a class="att ${drafts.length ? 'warm' : ''}" href="#/studio?status=draft"><b>${drafts.length}</b><span>draft${drafts.length === 1 ? '' : 's'} to review</span></a>
        <a class="att" href="#/studio?status=approved"><b>${S().assessments.filter(a => a.status === 'approved').length}</b><span>approved, not published</span></a>
        <a class="att" href="#/ia"><b>${Object.values(S().ia).filter(n => Object.values(n.status || {}).includes('submitted')).length}</b><span>IA checkpoints waiting</span></a>
      </div>
      <h2 class="sec">Next lessons</h2><div class="grid g4">${cards}</div>
      <div class="grid g2"><section class="card"><h2 class="bar-head amber">Misconception watchlist · last 4 weeks</h2>${mis.length ? `<ul class="mis">${mis.map(m => `<li><span class="mis-n">${m.students}</span><div><b>${esc(Hub.mastery.tagText(m.tag))}</b><br><span class="tiny muted">${C().GROUPS[m.g].label} · ${esc(U.skillName(m.skill))}</span></div></li>`).join('')}</ul>` : '<p>No misconceptions recorded yet.</p>'}<p class="tiny muted">Detected automatically when a wrong answer matches a known error (no AI involved).</p></section>
      <section class="card"><h2 class="bar-head blue">Class snapshot</h2>${['SL-A', 'SL-B', 'HL-A', 'HL-B'].map(g => { const sk = C().skillsFor(g.slice(0, 2)).filter(k => C().isTaught(k.id, g, asOf)); const avgs = sk.map(k => Hub.mastery.groupSkill(g, k.id).avg).filter(v => v !== null); const av = avgs.length ? Math.round(avgs.reduce((a, b) => a + b, 0) / avgs.length) : null; const low = sk.map(k => [k, Hub.mastery.groupSkill(g, k.id).avg]).filter(x => x[1] !== null).sort((a, b) => a[1] - b[1])[0];
        return `<div class="snap"><a href="#/mastery?group=${g}"><b>${C().GROUPS[g].label}</b></a><span>${av ?? '—'}%</span>${U.bar(av)}<span class="tiny muted">${low ? 'Lowest: ' + esc(low[0].name) + ' (' + low[1] + '%)' : ''}</span></div>`; }).join('')}<p class="tiny muted">Average of recency-weighted mastery across taught skills. Classroom indicator, not an IB grade.</p></section></div>`;
  }

  /* ================= Assessment Studio: library + builder ================= */
  function studio(main, params) {
    const status = params.status || pref('studio-status') || 'all', group = params.group || curGroup(), course = C().GROUPS[group].course;
    const asOf = Hub.mastery.asOf(), nl = C().nextLesson(group, asOf);
    const lessonOpts = C().lessons(group).filter(l => l.skills.length).map(l => `<option value="${l.date}" ${nl && l.date === nl.date ? 'selected' : ''}>${fmtDate(l.date)} · ${esc(l.activity.slice(0, 70))}</option>`).join('');
    const list = S().assessments.filter(a => status === 'all' ? a.status !== 'archived' : a.status === status);
    main.innerHTML = U.heading('TEACHER WORKSPACE', 'Assessment Studio', 'Original IB-style questions with markschemes. Every question must be reviewed before you can approve, and you choose when and to whom it is published.') +
      `${Hub.bookex ? Hub.bookex.studioCard(group) : ''}<section class="card builder"><h2 class="bar-head green">Build a new draft</h2><form id="build" class="form-grid">
        <label>Group<select id="b-group">${U.groupOptions(group)}</select></label>
        <label>Lesson (from the ${C().GROUPS[group].label} calendar)<select id="b-lesson"><option value="">— choose skills instead —</option>${lessonOpts}</select></label>
        <label>Type<select id="b-type">${Object.keys(Hub.assess.TYPES).map(t => `<option ${t === 'Exit Ticket' ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
        <label>Paper<select id="b-paper"><option value="P1">Paper 1 · no calculator</option><option value="Mixed" selected>Mixed (Paper 1 + Paper 2)</option></select></label>
        <label>Rigour<select id="b-rigour"><option value="standard">${course} course level</option><option value="challenge">Challenge (top band)</option></select></label>
        <label>Question style<select id="b-style"><option value="mixed">Mixed: exam-style + skill practice</option><option value="exam">IB exam-style only (multi-part)</option><option value="practice">Skill practice only</option></select></label>
        <label>Generated questions <span class="tiny muted">(from the skills; 0 = book exercises only)</span><input id="b-count" type="number" min="0" max="12" value="2"></label>
        <fieldset class="skills-pick span2"><legend>Skills <span class="tiny muted">(${course} · ticked from the lesson; change freely)</span></legend><div id="b-skills" class="skill-grid">${C().skillsFor(course).map(s => `<label class="sk ${U.unitColour(s.unit)}"><input type="checkbox" value="${s.id}" ${nl && nl.skills.includes(s.id) ? 'checked' : ''}> ${U.skillLabel(s.id)}${C().isTaught(s.id, group, asOf) ? '' : ' <span class="tiny muted">(not yet taught)</span>'}</label>`).join('')}</div></fieldset>
        <fieldset class="span2 bb-book"><legend>Book-exercise questions <span class="tiny muted">(optional · new questions labelled with the ${esc(Hub.bookex ? Hub.bookex.BOOK[course] : '')} exercise — add as many exercises as you like)</span></legend>${Hub.bookex ? `<div class="form-grid">${Hub.bookex.pickerHTML(course, 'bb', [], 'Add a book exercise to this draft')}</div><p class="tiny" id="bb-sum"></p>` : ''}</fieldset>
        <div class="span2 actions"><button class="btn primary" type="submit">Generate review draft →</button><span class="tiny muted">Homework answers are typed by students and marked automatically; “show that” parts become self-check with the model answer.</span></div></form></section>
      <section class="card"><div class="row-between"><h2 class="bar-head blue">Library</h2><div class="tabs" role="tablist">${['all', 'draft', 'approved', 'published', 'closed', 'archived'].map(s => `<button role="tab" class="tab ${s === status ? 'on' : ''}" data-status="${s}" aria-selected="${s === status}">${s[0].toUpperCase() + s.slice(1)}</button>`).join('')}</div></div>
      ${list.length ? `<div class="lib">${list.map(libRow).join('')}</div>` : U.empty('Nothing here yet.')}</section>`;
    $('#b-group').onchange = e => { pref('group', e.target.value); go('#/studio?group=' + e.target.value); };
    $('#b-lesson').onchange = e => { const l = C().lessons(group).find(x => x.date === e.target.value); $$('#b-skills input').forEach(c => (c.checked = !!(l && l.skills.includes(c.value)))); };
    $('#b-type').onchange = e => { $('#b-count').value = Hub.assess.TYPES[e.target.value].count; };
    $$('.tab[data-status]').forEach(b => (b.onclick = () => { pref('studio-status', b.dataset.status); go('#/studio?status=' + b.dataset.status + '&group=' + group); }));
    const bb = Hub.bookex ? Hub.bookex.bindPicker($('#build'), course, 'bb', api => { const n = api.chosen().length, q = api.only().length; $('#bb-sum').textContent = n ? `${n} exercise${n > 1 ? 's' : ''} · ${q} question${q === 1 ? '' : 's'} · ${api.marks()} marks added to this draft` : ''; }) : null;
    $('#build').onsubmit = e => {
      e.preventDefault(); const skills = $$('#b-skills input:checked').map(c => c.value), book = bb && bb.chosen().length ? { exs: bb.chosen(), only: bb.only() } : null;
      if (!skills.length && !book) return toast('Tick at least one skill, or add a book exercise.', 'error');
      const count = book && !skills.length ? 0 : $('#b-count').value;
      const r = Hub.assess.createDraft({ course, type: $('#b-type').value, skills: book && Number(count) === 0 ? [] : skills, paper: $('#b-paper').value, style: $('#b-style').value, rigour: $('#b-rigour').value, count, lessonDate: $('#b-lesson').value || null, groups: [group], book });
      if (!r.ok) return toast(r.error, 'error'); toast('Draft ready — review each question.'); go('#/edit/' + r.assessment.id);
    };
    if (Hub.bookex) Hub.bookex.bindStudio(main, group);
    bindLibActions(main);
  }
  const STATUS_TXT = { draft: ['Draft', 'grey'], approved: ['Approved', 'green'], published: ['Published', 'blue'], closed: ['Closed', 'amber'], archived: ['Archived', 'grey'] };
  function libRow(a) {
    const subs = S().attempts.filter(t => t.aid === a.id), waiting = subs.filter(t => t.status === 'submitted').length, rev = a.questions.filter(q => a.reviewed[q.id]).length;
    return `<div class="lib-row"><div class="lib-main"><a href="#/edit/${a.id}" class="lib-title">${esc(a.title)}</a><div class="tiny muted">${a.course} · ${a.type} · ${a.questions.length} question${a.questions.length > 1 ? 's' : ''} · ${a.questions.reduce((s, q) => s + q.marks, 0)} marks · ${a.paper}${a.groups.length && a.status !== 'draft' ? ' · ' + a.groups.map(g => C().GROUPS[g].label.replace('AA ', '')).join(', ') : ''}${a.status === 'draft' ? ` · reviewed ${rev}/${a.questions.length}` : ''}${['published', 'closed'].includes(a.status) && dueText(a) ? ' · ' + dueText(a) : ''}${a.autoClosed && a.status === 'closed' ? ' · closed automatically' : ''}${subs.length ? ` · ${subs.length} submitted${waiting ? `, <b>${waiting} to mark</b>` : ''}` : ''}</div></div>
      <span class="pill ${STATUS_TXT[a.status][1]}">${STATUS_TXT[a.status][0]}</span>
      <div class="lib-act"><a class="btn small" href="#/edit/${a.id}">${a.status === 'draft' ? 'Review' : 'Open'}</a><a class="btn small ghost" href="#/print/${a.id}" title="Printable worksheet and answer key">🖨 Print</a>${subs.length ? `<a class="btn small ghost" href="#/analysis/${a.id}">Analysis</a>` : ''}<button class="btn small ghost" data-dup="${a.id}">Duplicate</button>${['published', 'closed'].includes(a.status) && a.type !== 'Retest' ? `<button class="btn small ghost" data-retest="${a.id}">Retest</button>` : ''}${!['draft', 'archived'].includes(a.status) ? `<button class="btn small ghost" data-arch="${a.id}">Archive</button>` : ''}<button class="btn small ghost danger" data-destroy="${a.id}">Delete</button></div></div>`;
  }
  /** Delete at any stage: unpublishes it and removes its submissions, marks and evidence (after a clear warning). */
  async function confirmDestroy(aid, after) {
    const a = Hub.assess.byId(aid); if (!a) return;
    const subs = S().attempts.filter(t => t.aid === aid).length;
    const msg = `Delete <b>${esc(a.title)}</b>?` + (['published', 'closed'].includes(a.status) ? ' It will be unpublished and disappear for students.' : '') +
      (subs ? ` <b>${subs} student submission${subs > 1 ? 's' : ''}</b>, with their marks and mastery evidence from it, will also be deleted. Download the gradebook CSV first if you need the marks.` : '') + ' This cannot be undone.';
    if (!(await U.confirmBox(msg, subs ? `Delete it and ${subs} submission${subs > 1 ? 's' : ''}` : 'Delete', { danger: true }))) return;
    const r = Hub.assess.destroy(aid); if (!r.ok) return toast(r.error || 'Could not delete.', 'error');
    toast('Deleted.'); if (after) go(after); else Hub.app.render();
  }
  function bindLibActions(root) {
    $$('[data-dup]', root).forEach(b => (b.onclick = () => { const a = Hub.assess.duplicate(b.dataset.dup); toast('Copy created as a draft.'); go('#/edit/' + a.id); }));
    $$('[data-retest]', root).forEach(b => (b.onclick = () => { const a = Hub.assess.duplicate(b.dataset.retest, true); toast('Retest drafted with new numbers (capped at 80%).'); go('#/edit/' + a.id); }));
    $$('[data-destroy]', root).forEach(b => (b.onclick = () => confirmDestroy(b.dataset.destroy)));
    $$('[data-arch]', root).forEach(b => (b.onclick = async () => { if (await U.confirmBox('Archive this assessment? Students will no longer see it; results are kept.', 'Archive')) { Hub.assess.archive(b.dataset.arch); Hub.app.render(); } }));
  }

  /* ================= Draft editor / review / approve / publish ================= */
  function edit(main, params) {
    const a = Hub.assess.byId(params.id); if (!a) { main.innerHTML = U.empty('That assessment no longer exists.', '<a class="btn" href="#/studio">Back to the studio</a>'); return; }
    const locked = !['draft', 'approved'].includes(a.status), probs = Hub.assess.problems(a), rev = a.questions.filter(q => a.reviewed[q.id]).length;
    const subs = S().attempts.filter(t => t.aid === a.id);
    main.innerHTML = `<a class="back" href="#/studio">← Assessment Studio</a>` + U.heading(`${a.course} · ${a.type.toUpperCase()} · VERSION ${a.version}`, esc(a.title), '', `<span class="pill big ${STATUS_TXT[a.status][1]}">${STATUS_TXT[a.status][0]}</span><div class="actions print-acts"><a class="btn small" href="#/print/${a.id}">🖨 Print worksheet</a><a class="btn small ghost" href="#/print/${a.id}?key=1">Answer key</a></div>`) +
      `<div class="flow" aria-label="Workflow"><span class="${a.status === 'draft' ? 'now' : 'done'}">1 Review every question</span><span class="${a.status === 'approved' ? 'now' : ['published', 'closed', 'archived'].includes(a.status) ? 'done' : ''}">2 Approve</span><span class="${a.status === 'published' ? 'now' : ['closed', 'archived'].includes(a.status) ? 'done' : ''}">3 Publish to groups</span></div>
      ${locked ? `<div class="notice">This assessment is ${a.status}. It is locked so every student sees the same version${subs.length ? ` (${subs.length} submission${subs.length > 1 ? 's' : ''})` : ''}. Duplicate it to make changes.</div>` : ''}
      <section class="card meta-card"><div class="form-grid">
        <label class="span2">Title<input id="e-title" value="${esc(a.title)}" ${locked ? 'disabled' : ''}></label>
        <div class="tiny muted span2">${a.skills.map(s => U.skillChip(s)).join(' ')} · ${a.paper} · ${a.rigour === 'challenge' ? 'Challenge rigour' : a.course + ' rigour'}${a.lessonDate ? ` · for ${fmtDate(a.lessonDate)}` : ''}${a.cap ? ` · retest capped at ${a.cap}%` : ''}</div></div></section>
      ${!locked ? `<div id="review-all-bar">${reviewAllBar(a)}</div>` : ''}
      <div id="qs">${a.questions.map((q, i) => editorCard(a, q, i, locked)).join('')}</div>
      ${!locked ? `<div class="add-q card"><label>Add a question on<select id="add-skill">${C().skillsFor(a.course).map(s => `<option value="${s.id}">${s.ox ? s.ox + ' ' : ''}${esc(s.name)}</option>`).join('')}</select></label><button class="btn ghost" id="add-q">+ Add question</button></div>` : ''}
      <section class="card approve-card" id="approve-card">${approvePanel(a, probs, rev)}</section>
      <div class="actions end"><button class="btn small ghost danger" id="destroy">🗑 Delete this ${esc(a.type.toLowerCase())}</button></div>
      <details class="card history"><summary>History (${(a.history || []).length})</summary><ul>${(a.history || []).slice().reverse().map(h => `<li><span class="tiny muted">${fmtDateTime(h.at)} · ${esc(h.who)}</span> ${esc(h.what)}</li>`).join('')}</ul></details>`;
    bindEditor(main, a, locked);
  }
  /** One tick for the whole assessment instead of one per question. */
  function reviewAllBar(a) {
    const n = a.questions.length, done = a.questions.filter(q => a.reviewed[q.id]).length, all = done === n;
    return `<label class="review-all ${all ? 'on' : ''}"><input type="checkbox" id="review-all" ${all ? 'checked' : ''}> <span><b>${all ? `All ${n} questions reviewed ✓` : `I have checked all ${n} question${n > 1 ? 's' : ''}, answers and markschemes`}</b><span class="tiny muted"> ${all ? '— untick to clear every tick' : `· ${done}/${n} ticked so far · or tick them one by one below`}</span></span></label>`;
  }
  function editorCard(a, q, i, locked) {
    const reviewed = !!a.reviewed[q.id];
    const editForm = locked ? '' : `<details class="edit-box"><summary>✎ Edit wording, answer key or markscheme</summary>
      <label>Context / stem (use $…$ for maths, e.g. $\\frac{3}{4}$)<textarea data-stem="${q.id}" rows="2">${esc(q.stem)}</textarea></label>
      ${q.parts.map(p => `<fieldset class="part-edit"><legend>Part (${p.label}) · ${esc(p.command)}</legend>
        <label>Question text<textarea data-f="prompt" data-q="${q.id}" data-p="${p.id}" rows="2">${esc(p.prompt)}</textarea></label>
        <div class="form-grid"><label>Marks<input type="number" min="1" max="20" data-f="marks" data-q="${q.id}" data-p="${p.id}" value="${p.marks}"></label>${answerEditor(q, p)}</div>
        <label>Markscheme (one line each: <code>M1 | text</code>)<textarea data-f="ms" data-q="${q.id}" data-p="${p.id}" rows="${Math.max(2, p.ms.length)}">${esc(p.ms.map(m => m[0] + ' | ' + m[1]).join('\n'))}</textarea></label>
        <label>Worked solution (one line each)<textarea data-f="working" data-q="${q.id}" data-p="${p.id}" rows="${Math.max(2, p.working.length)}">${esc(p.working.join('\n'))}</textarea></label></fieldset>`).join('')}</details>`;
    const footer = `<div class="q-foot">${locked ? '' : `${/^bx\./.test(q.gen || '') ? '' : `<button class="btn small ghost" data-regen="${q.id}" title="Same skill, new numbers">↻ New numbers</button>`}${a.questions.length > 1 ? `<button class="btn small ghost danger" data-rm="${q.id}">Remove</button>` : ''}`}
      <label class="review-tick ${reviewed ? 'on' : ''}"><input type="checkbox" data-review="${q.id}" ${reviewed ? 'checked' : ''} ${locked ? 'disabled' : ''}> ${reviewed ? 'Reviewed ✓' : 'I have checked this question, answer and markscheme'}</label></div>` + editForm;
    return U.question(q, i, { mode: 'teacher', footer, cls: reviewed ? 'reviewed' : 'unreviewed' });
  }
  function answerEditor(q, p) {
    const a = p.answer, at = `data-q="${q.id}" data-p="${p.id}"`;
    if (a.kind === 'num') return `<label>Answer (number or expression, e.g. 3/4, 2sqrt(3))<input data-f="ans-num" ${at} value="${esc(Hub.assess.valueTex(a.value).replace(/\\frac\{(-?\d+)\}\{(\d+)\}/, '$1/$2').replace(/\\sqrt\{(\d+)\}/, 'sqrt($1)'))}"></label><label>Accuracy<select data-f="ans-acc" ${at}><option value="exact" ${a.exact && !a.int ? 'selected' : ''}>Exact value</option><option value="sf" ${!a.exact && a.dp === undefined && !a.int ? 'selected' : ''}>3 s.f.</option><option value="dp2" ${a.dp === 2 ? 'selected' : ''}>2 d.p.</option><option value="int" ${a.int ? 'selected' : ''}>Whole number</option></select></label>`;
    if (a.kind === 'tuple' || a.kind === 'list') return `<label>${a.kind === 'list' ? 'Solutions (any order)' : 'Values in order: ' + a.labels.join(', ')} — separate with ;<input data-f="ans-list" ${at} value="${esc(a.value.map(v => Hub.assess.valueTex(v).replace(/\\frac\{(-?\d+)\}\{(\d+)\}/, '$1/$2').replace(/^(-?)\\sqrt\{(\d+)\}$/, '$1sqrt($2)')).join(' ; '))}"></label>`;
    if (a.kind === 'mc') return `<fieldset class="span2"><legend>Correct option</legend>${a.choices.map((c, i) => `<label class="inline-radio"><input type="radio" name="mc-${q.id}-${p.id}" data-f="ans-mc" ${at} value="${i}" ${i === a.correct ? 'checked' : ''}> ${'ABCDEF'[i]}: ${M(c)}</label>`).join('')}</fieldset>`;
    return '<p class="tiny muted">Teacher-marked from uploaded working.</p>';
  }
  /** Default due dates per day from the paired A/B calendar row of the assignment's lesson. */
  function defaultDue(a) { const r = a.lessonDate && Hub.lessons ? Hub.lessons.calendar(a.course).find(x => x.dates.A === a.lessonDate || x.dates.B === a.lessonDate) : null; return r ? { A: r.dates.A, B: r.dates.B } : { A: a.lessonDate, B: a.lessonDate }; }
  const dueText = a => a.groups.map(g => Hub.assess.dueFor(a, g) ? `${C().GROUPS[g].day} day due ${fmtDate(Hub.assess.dueFor(a, g))}` : '').filter(Boolean).join(' · ');
  function approvePanel(a, probs, rev) {
    if (a.status === 'draft') return `<h2 class="bar-head green">Approve</h2><p>${rev}/${a.questions.length} questions reviewed.</p>${probs.length ? `<ul class="problems">${probs.map(p => `<li>${esc(p)}</li>`).join('')}</ul>` : '<p class="ok-text">Everything is reviewed and valid.</p>'}<div class="actions">${rev < a.questions.length ? `<button class="btn" id="review-all-btn">✓ I’ve checked all ${a.questions.length} — tick them all</button>` : ''}<button class="btn primary" id="approve" ${probs.length ? 'disabled aria-disabled="true"' : ''}>Approve this assessment</button><button class="btn ghost" id="preview-st">👁 Preview as a student</button></div><p class="tiny muted">Students never see drafts or approved-but-unpublished work. Previews are never recorded.</p>`;
    if (a.status === 'approved') {
      const t = Hub.assess.TYPES[a.type] || {};
      return `<h2 class="bar-head blue">Publish</h2><p class="ok-text">Approved ${fmtDateTime(a.approvedAt)}. Choose who gets it and how results are released.</p><form id="pub" class="form-grid">
        <fieldset class="span2 due-set"><legend>Groups and due dates <span class="tiny muted">· one assignment for both days, each with its own due date</span></legend>${Object.values(C().GROUPS).filter(g => g.course === a.course).map(g => { const dd = defaultDue(a); return `<div class="due-row"><label class="inline-check"><input type="checkbox" name="g" value="${g.id}" checked> ${g.label}</label><label class="inline">Due <input type="date" data-due="${g.id}" value="${(a.dueBy && a.dueBy[g.id]) || dd[g.day] || ''}"></label></div>`; }).join('')}<span class="tiny muted">Each day closes automatically ${Hub.assess.CLOSE_AFTER_DAYS} days after its own due date. You can close it sooner.</span></fieldset>
        <label>Suggested minutes<input type="number" id="p-min" min="1" max="120" value="${a.minutes || t.minutes || 10}"></label>
        <label class="inline-check span2"><input type="checkbox" id="p-up" ${a.uploadRequired ? 'checked' : ''}> Students must upload a photo of their working (0 marks, no upload = cannot submit)</label>
        <label class="span2">Results<select id="p-rel"><option value="hold" ${a.release === 'hold' ? 'selected' : ''}>Hold for my review in the marking queue, then release</option><option value="auto" ${a.release === 'auto' ? 'selected' : ''}>Release auto-marked results immediately</option></select></label>
        <div class="actions span2"><button class="btn primary" type="submit">Publish to students</button><button class="btn ghost" type="button" id="preview-st">👁 Preview as a student</button></div></form>`;
    }
    const subs = S().attempts.filter(t => t.aid === a.id);
    return `<h2 class="bar-head blue">${a.status === 'published' ? 'Published' : a.status[0].toUpperCase() + a.status.slice(1)}</h2><ul class="due-list">${a.groups.map(g => { const d = Hub.assess.dueFor(a, g); return `<li><b>${C().GROUPS[g].label}</b> · ${d ? 'due ' + fmtDate(d, true) : 'no due date'}${a.status === 'published' ? (d ? (Hub.assess.isOpen(a, g) ? ` · closes automatically ${fmtDate(Hub.assess.closesOn(a, g), true)}` : ' · <b>closed</b> (10 days after due)') : ' · stays open until you close it') : ''}</li>`; }).join('')}</ul><p>${a.status === 'closed' ? (a.autoClosed ? 'Closed automatically 10 days after the due dates · ' : 'Closed · ') : ''}${a.uploadRequired ? 'upload required' : 'no upload'} · results ${a.release === 'auto' ? 'released automatically' : 'held for review'} · ${subs.length} submission${subs.length === 1 ? '' : 's'}</p>
      <div class="actions">${subs.length ? `<a class="btn" href="#/analysis/${a.id}">Item analysis</a><button class="btn ghost" id="csv">Gradebook CSV</button>` : ''}${a.status === 'published' ? `<button class="btn ghost" id="close">Close now</button>${subs.length ? '' : '<button class="btn ghost" id="unpub">Unpublish</button>'}` : ''}<button class="btn ghost" id="preview-st">👁 Preview as a student</button></div>
      ${['published', 'closed'].includes(a.status) ? `<details class="due-edit"><summary>Change due dates</summary><div class="due-set">${a.groups.map(g => `<div class="due-row"><span>${C().GROUPS[g].label}</span><label class="inline">Due <input type="date" data-due="${g}" value="${Hub.assess.dueFor(a, g) || ''}"></label></div>`).join('')}<button class="btn small" id="due-save" type="button">Save due dates</button></div></details>` : ''}`;
  }
  function bindEditor(main, a, locked) {
    const rerenderApprove = () => { $('#approve-card').innerHTML = approvePanel(a, Hub.assess.problems(a), a.questions.filter(q => a.reviewed[q.id]).length); bindApprove(main, a); const bar = $('#review-all-bar'); if (bar) { bar.innerHTML = reviewAllBar(a); bindAll(); } };
    const bindAll = () => { const ra = $('#review-all'); if (ra) ra.onchange = () => { Hub.assess.setAllReviewed(a.id, ra.checked); Hub.app.render(); if (ra.checked) toast('Every question is marked as reviewed.'); }; };
    bindAll();
    if (!locked) {
      $('#e-title').oninput = debounce(e => { a.title = e.target.value; if (a.status === 'approved') { a.status = 'draft'; } Hub.store.save(); rerenderApprove(); }, 400);
      const card = qid => $(`#q-${qid}`);
      const refreshCard = qid => { const i = a.questions.findIndex(q => q.id === qid); const el = card(qid); const open = el && el.querySelector('.edit-box') && el.querySelector('.edit-box').open; el.outerHTML = editorCard(a, a.questions[i], i, false); if (open) card(qid).querySelector('.edit-box').open = true; bindCard(qid); rerenderApprove(); };
      const onEdit = debounce(el => {
        const qid = el.dataset.q || el.dataset.stem, pid = el.dataset.p, f = el.dataset.f;
        if (el.dataset.stem) Hub.assess.updateStem(a.id, el.dataset.stem, el.value);
        else if (f === 'prompt') Hub.assess.updatePart(a.id, qid, pid, { prompt: el.value });
        else if (f === 'marks') Hub.assess.updatePart(a.id, qid, pid, { marks: el.value });
        else if (f === 'ms') Hub.assess.updatePart(a.id, qid, pid, { ms: el.value.split('\n').filter(l => l.trim()).map(l => { const k = l.indexOf('|'); return k > 0 ? [l.slice(0, k).trim(), l.slice(k + 1).trim()] : ['', l.trim()]; }) });
        else if (f === 'working') Hub.assess.updatePart(a.id, qid, pid, { working: el.value.split('\n').filter(l => l.trim()) });
        else if (f === 'ans-num') { const r = Hub.math.parse(el.value); if (r.error) { el.setCustomValidity(r.error === 'blank' ? 'Enter the answer' : r.error); el.reportValidity(); return; } el.setCustomValidity(''); const p = partOf(qid, pid); Hub.assess.updatePart(a.id, qid, pid, { answer: { value: r.value, display: r.tex } }); }
        else if (f === 'ans-acc') { const v = el.value; Hub.assess.updatePart(a.id, qid, pid, { answer: { exact: v === 'exact' || v === 'int', int: v === 'int', dp: v === 'dp2' ? 2 : undefined, sf: v === 'sf' ? 3 : undefined } }); }
        else if (f === 'ans-list') { const vals = el.value.split(';').map(x => Hub.math.parse(x)); if (vals.some(v => v.error)) { el.setCustomValidity('Each value must be a number, e.g. 3/4 or sqrt(2)'); el.reportValidity(); return; } el.setCustomValidity(''); Hub.assess.updatePart(a.id, qid, pid, { answer: { value: vals.map(v => v.value), display: vals.map(v => v.tex).join(',\\ ') } }); }
        else if (f === 'ans-mc') Hub.assess.updatePart(a.id, qid, pid, { answer: { correct: Number(el.value) } });
        refreshCard(qid); toast('Saved. This question needs reviewing again.');
      }, 700);
      const partOf = (qid, pid) => a.questions.find(q => q.id === qid).parts.find(p => p.id === pid);
      const bindCard = qid => {
        const el = card(qid); if (!el) return;
        $$('textarea, input:not([data-review]), select', el.querySelector('.edit-box') || document.createElement('div')).forEach(x => { x.addEventListener(x.type === 'radio' || x.tagName === 'SELECT' ? 'change' : 'input', () => onEdit(x)); });
        const rv = el.querySelector('[data-review]'); if (rv) rv.onchange = () => { Hub.assess.setReviewed(a.id, qid, rv.checked); refreshCard(qid); };
        const rg = el.querySelector('[data-regen]'); if (rg) rg.onclick = () => { Hub.assess.regenerate(a.id, qid); const nq = a.questions.find(q => q.gen && !document.getElementById('q-' + q.id)); const i = a.questions.indexOf(nq); el.outerHTML = editorCard(a, nq, i, false); bindCard(nq.id); rerenderApprove(); toast('New numbers generated — review it again.'); };
        const rm = el.querySelector('[data-rm]'); if (rm) rm.onclick = async () => { if (await U.confirmBox('Remove this question from the draft?', 'Remove')) { Hub.assess.removeQ(a.id, qid); Hub.app.render(); } };
      };
      a.questions.forEach(q => bindCard(q.id));
      const add = $('#add-q'); if (add) add.onclick = () => { if (Hub.assess.addQ(a.id, $('#add-skill').value)) { Hub.app.render(); toast('Question added — review it before approving.'); } else toast('No questions for that skill in this paper type.', 'error'); };
    }
    bindApprove(main, a);
    $('#destroy').onclick = () => confirmDestroy(a.id, '#/studio');
  }
  function bindApprove(main, a) {
    const rab = $('#review-all-btn'); if (rab) rab.onclick = () => { Hub.assess.setAllReviewed(a.id, true); toast('Every question is marked as reviewed.'); Hub.app.render(); };
    const ap = $('#approve'); if (ap) ap.onclick = () => { const r = Hub.assess.approve(a.id); if (!r.ok) return toast(r.error, 'error'); toast('Approved. Now choose groups and publish.'); Hub.app.render(); };
    const pub = $('#pub'); if (pub) pub.onsubmit = e => { e.preventDefault(); const groups = $$('input[name="g"]:checked', pub).map(x => x.value); const dueBy = Object.fromEntries(groups.map(g => [g, ($(`[data-due="${g}"]`, pub) || {}).value || null])); const r = Hub.assess.publish(a.id, { groups, dueBy, uploadRequired: $('#p-up').checked, release: $('#p-rel').value, minutes: $('#p-min').value }); if (!r.ok) return toast(r.error, 'error'); toast('Published. Students in those groups can see it now.'); Hub.app.render(); };
    const pv = $('#preview-st'); if (pv) pv.onclick = () => go('#/preview/' + a.id);
    const ds = $('#due-save'); if (ds) ds.onclick = () => { const box = ds.closest('.due-set'); const r = Hub.assess.setDue(a.id, Object.fromEntries($$('[data-due]', box).map(i => [i.dataset.due, i.value || null]))); if (!r.ok) return toast(r.error, 'error'); toast('Due dates saved.'); Hub.app.render(); };
    const csv = $('#csv'); if (csv) csv.onclick = () => download(a.title.replace(/[^\w]+/g, '_') + '_gradebook.csv', Hub.assess.gradebookCSV(a.id), 'text/csv');
    const cl = $('#close'); if (cl) cl.onclick = async () => { if (await U.confirmBox('Close to new submissions? Existing results are kept.', 'Close')) { Hub.assess.close(a.id); Hub.app.render(); } };
    const un = $('#unpub'); if (un) un.onclick = () => { const r = Hub.assess.unpublish(a.id); if (!r.ok) return toast(r.error || 'Could not unpublish.', 'error'); Hub.app.render(); };
  }

  /** Student preview has its own address (#/preview/<id>) so “← Back to the editor” is a real page change. */
  function preview(main, params) {
    const a = Hub.assess.byId(params.id); if (!a) { main.innerHTML = U.empty('That assessment no longer exists.', '<a class="btn" href="#/studio">Back to the studio</a>'); return; }
    Hub.student.previewAssessment(a, main);
  }

  /* ================= Item analysis ================= */
  function analysis(main, params) {
    const a = Hub.assess.byId(params.id); if (!a) { main.innerHTML = U.empty('Not found.'); return; }
    const rows = Hub.assess.itemAnalysis(a.id), ts = S().attempts.filter(t => t.aid === a.id), sc = ts.map(t => Hub.assess.score(t).pct).filter(v => v !== null);
    const hardest = rows.filter(r => r.n).slice().sort((x, y) => x.mean - y.mean).slice(0, 3);
    main.innerHTML = `<a class="back" href="#/edit/${a.id}">← ${esc(a.title)}</a>` + U.heading('ITEM ANALYSIS', esc(a.title), `${ts.length} submissions · class average ${sc.length ? Math.round(sc.reduce((s, v) => s + v, 0) / sc.length) : '—'}% (auto + teacher marks)`, `<button class="btn" id="csv">Gradebook CSV</button>`) +
      `<section class="card"><h2 class="bar-head pink">Walk-through priorities</h2><ol class="hardest">${hardest.map(r => `<li><b>${r.label}</b> · ${esc(U.skillName(r.skill))} — mean ${r.mean}%${r.tags.length ? ` · most common error: <i>${esc(Hub.mastery.tagText(r.tags[0][0]))}</i> (${r.tags[0][1]})` : ''}</li>`).join('')}</ol></section>
      <section class="card scroll"><table class="tbl"><thead><tr><th>Part</th><th>Skill</th><th>Marks</th><th>Mean</th><th>Full marks</th><th>Common wrong answers</th><th>Misconceptions</th></tr></thead><tbody>${rows.map(r => `<tr><td><b>${r.label}</b></td><td>${esc(U.skillName(r.skill))}</td><td>${r.marks}</td><td>${r.mean ?? '—'}%${U.bar(r.mean, r.mean < 60 ? 'low' : '')}</td><td>${r.full ?? '—'}%</td><td>${r.wrong.map(([w, n]) => `<code>${esc(w)}</code> ×${n}`).join('<br>') || '—'}</td><td>${r.tags.map(([t, n]) => `${esc(Hub.mastery.tagText(t))} ×${n}`).join('<br>') || '—'}</td></tr>`).join('')}</tbody></table></section>`;
    $('#csv').onclick = () => download(a.title.replace(/[^\w]+/g, '_') + '_gradebook.csv', Hub.assess.gradebookCSV(a.id), 'text/csv');
  }

  /* ================= Marking queue ================= */
  function marking(main) {
    const q = Hub.assess.queue(), by = {};
    q.forEach(t => (by[t.aid] = by[t.aid] || []).push(t));
    main.innerHTML = U.heading('FEEDBACK THAT MOVES LEARNING', 'Marking queue', 'Typed answers are auto-marked and checked against known misconceptions. You confirm method marks from the uploaded working, then release.') +
      `<div class="notice ai-off"><b>AI reading of handwritten photos is switched off.</b> The analysis shown here is free and runs in the browser: answer checking (exact / 3 s.f.), misconception matching and item analysis. Reading photos with AI needs a paid service you have not approved yet.</div>` +
      (Object.keys(by).length ? Object.entries(by).map(([aid, ts]) => { const a = Hub.assess.byId(aid); const ready = ts.filter(t => !Object.values(t.auto.parts).some(r => r.verdict === 'teacher') && (!a.uploadRequired || t.uploads.length)).length;
        return `<section class="card"><div class="row-between"><h2 class="bar-head blue">${esc(a.title)}</h2><div class="actions"><a class="btn small ghost" href="#/analysis/${aid}">Item analysis</a>${ready ? `<button class="btn small" data-relall="${aid}">Release all ${ready} auto-marked</button>` : ''}</div></div>
        <table class="tbl"><thead><tr><th>Student</th><th>Group</th><th>Submitted</th><th>Working</th><th>Auto score</th><th>Flags</th><th></th></tr></thead><tbody>${ts.map(t => { const s = Hub.roster.byId(t.sid), sc = Hub.assess.score(t), tags = [...new Set(Object.values(t.auto.parts).map(r => r.tag).filter(Boolean))];
          return `<tr><td><b>${esc(s ? s.name : t.sid)}</b></td><td>${s ? C().GROUPS[s.group].label.replace('AA ', '') : ''}</td><td>${fmtDateTime(t.at)}</td><td>${t.uploads.length ? `📷 ${t.uploads.length}` : a.uploadRequired ? '<span class="pill red">missing</span>' : '—'}</td><td>${sc.earned}/${sc.max} (${sc.pct}%)</td><td>${tags.length ? tags.map(x => `<span class="pill pink tiny">${esc(Hub.mastery.tagText(x))}</span>`).join(' ') : ''}${Object.values(t.auto.parts).some(r => r.verdict === 'teacher') ? '<span class="pill amber tiny">needs your marks</span>' : ''}</td><td><a class="btn small" href="#/mark/${t.id}">Mark →</a></td></tr>`; }).join('')}</tbody></table></section>`; }).join('') : U.empty('Nothing waiting. Lovely.'));
    $$('[data-relall]').forEach(b => (b.onclick = async () => { if (await U.confirmBox('Release the auto-marked results for every student whose work needs no method marks? You can still review each one afterwards in the gradebook.', 'Release')) { const n = Hub.assess.releaseAuto(b.dataset.relall); toast(`${n} result${n === 1 ? '' : 's'} released.`); Hub.app.render(); } }));
  }
  async function mark(main, params) {
    const t = S().attempts.find(x => x.id === params.id); if (!t) { main.innerHTML = U.empty('Not found.'); return; }
    const a = Hub.assess.byId(t.aid), s = Hub.roster.byId(t.sid), qs = Hub.assess.questionsOf(t), queue = Hub.assess.queue(), idx = queue.findIndex(x => x.id === t.id);
    const marks = {}; qs.forEach(q => q.parts.forEach(p => { const k = q.id + '|' + p.id; marks[k] = t.final ? t.final.parts[k] : t.auto.parts[k].earned; }));
    main.innerHTML = `<a class="back" href="#/marking">← Marking queue</a>` + U.heading(`${esc(a ? a.title : t.type)}`, esc(s ? s.name : t.sid), `${s ? C().GROUPS[s.group].label : ''} · submitted ${fmtDateTime(t.at)} · ${t.status === 'released' ? 'released ' + fmtDateTime(t.releasedAt) : 'waiting for you'}`, `<div class="actions">${idx > 0 ? `<a class="btn small ghost" href="#/mark/${queue[idx - 1].id}">← Previous</a>` : ''}${idx >= 0 && idx < queue.length - 1 ? `<a class="btn small ghost" href="#/mark/${queue[idx + 1].id}">Next →</a>` : ''}</div>`) +
      `<div class="mark-grid"><section class="card work-pane"><h2 class="bar-head amber">Uploaded working</h2><div id="uploads">${t.uploads.length ? '<p class="tiny muted">Loading…</p>' : '<p>No working uploaded.</p>'}</div>${t.reflection ? `<div class="sticky"><b>Student reflection:</b> ${esc(t.reflection)}</div>` : ''}${t.proof ? '<p class="tiny">✓ Confirmed proof of studying</p>' : ''}</section>
      <section class="card mark-pane"><h2 class="bar-head green">Marks</h2>${qs.map((q, i) => `<div class="mq"><div class="mq-head"><b>Q${i + 1}</b> ${U.skillChip(q.skill)}</div>${q.stem ? `<div class="q-stem small">${M(q.stem)}</div>` : ''}${q.parts.map(p => { const k = q.id + '|' + p.id, r = t.auto.parts[k];
        return `<div class="mp"><div class="mp-q"><b>(${p.label})</b> ${U.cmd(p.command)} ${M(p.prompt)}</div><div class="fb-row"><span class="key-lab">Answer given</span><span>${U.respText(p, (t.responses[q.id] || {})[p.id])}</span></div><div class="fb-row"><span class="key-lab">Key</span><span>${U.answerDisplay(p)}</span></div>
          <div class="auto">Auto: <span class="verdict ${r.verdict === 'correct' ? 'ok' : r.verdict === 'teacher' ? 'wait' : r.verdict === 'partial' || r.verdict === 'inexact' ? 'part' : 'no'}">${r.verdict}</span> ${r.earned}/${p.marks}${r.tag ? ` · <span class="pill pink tiny">${esc(Hub.mastery.tagText(r.tag))}</span>` : ''}</div>
          <div class="ms-ticks">${p.ms.map(([m, txt], j) => `<label class="ms-tick"><input type="checkbox" data-k="${k}" data-v="${U.msValue(m)}" data-j="${j}"><b>${esc(m)}</b> ${M(txt)}</label>`).join('')}</div>
          <div class="stepper"><button class="btn small ghost" data-dec="${k}" aria-label="One mark fewer">−</button><output data-out="${k}">${marks[k]}</output><span>/ ${p.marks}</span><button class="btn small ghost" data-inc="${k}" data-max="${p.marks}" aria-label="One mark more">+</button></div></div>`; }).join('')}</div>`).join('')}
        <label>Comment for the student<textarea id="m-comment" rows="3" placeholder="What went well · one next step">${esc(t.comment || '')}</textarea></label>
        <div class="total">Total <b id="m-total"></b> / ${t.max}</div>
        <div class="actions"><button class="btn primary" id="m-release">${t.status === 'released' ? 'Update released marks' : 'Release to student'}</button></div></section></div>`;
    const total = () => { $('#m-total').textContent = Object.values(marks).reduce((s, v) => s + v, 0); };
    const setK = (k, v) => { const p = qs.flatMap(q => q.parts.map(pp => [q.id + '|' + pp.id, pp])).find(x => x[0] === k)[1]; marks[k] = Math.max(0, Math.min(p.marks, v)); $(`[data-out="${k}"]`).textContent = marks[k]; total(); };
    $$('[data-inc]').forEach(b => (b.onclick = () => setK(b.dataset.inc, marks[b.dataset.inc] + 1)));
    $$('[data-dec]').forEach(b => (b.onclick = () => setK(b.dataset.dec, marks[b.dataset.dec] - 1)));
    $$('.ms-tick input').forEach(c => (c.onchange = () => { const k = c.dataset.k; const sum = $$(`.ms-tick input[data-k="${k}"]:checked`).reduce((s, x) => s + Number(x.dataset.v), 0); setK(k, sum); }));
    total();
    $('#m-release').onclick = () => { const r = Hub.assess.release(t.id, marks, $('#m-comment').value); if (!r.ok) return toast('Could not release.', 'error'); toast('Released — the student can see their marks and feedback.'); const nxt = Hub.assess.queue()[0]; go(nxt ? '#/mark/' + nxt.id : '#/marking'); };
    // Load private signed attachment URLs
    const box = $('#uploads'); if (t.uploads.length) {
      const html = [];
      for (const u of t.uploads) {
        const url = await Hub.uploads.url(u.id);
        html.push(url ? (u.type === 'application/pdf' ? `<p><a class="btn small" href="${url}" target="_blank" rel="noopener">Open PDF: ${esc(u.name)}</a></p>` : `<figure class="work-img"><img src="${url}" alt="Uploaded working by ${esc(s ? s.name : '')}"><figcaption class="tiny muted">${esc(u.name)}</figcaption></figure>`) : `<p class="tiny muted">${esc(u.name)} could not be loaded. Check your connection and refresh.</p>`);
      }
      box.innerHTML = `<div class="zoom-ctl"><label>Zoom <input type="range" id="zoom" min="60" max="220" value="100"></label><button class="btn small ghost" id="rot">↻ Rotate</button></div><div class="work-scroll">${html.join('')}</div>`;
      let rot = 0; const apply = () => $$('.work-img img').forEach(img => (img.style.transform = `rotate(${rot}deg)`, img.style.width = $('#zoom').value + '%'));
      $('#zoom').oninput = apply; $('#rot').onclick = () => { rot = (rot + 90) % 360; apply(); };
    }
  }
  function demoLines(t, qs) { const out = []; qs.forEach((q, i) => q.parts.forEach(p => { const r = (t.responses[q.id] || {})[p.id]; const w = (p.working[0] || '').replace(/\$|\\[a-z]+|[{}]/g, ' ').replace(/\s+/g, ' ').slice(0, 52); out.push(`Q${i + 1}${p.label})  ${w}`); out.push(`      answer: ${Array.isArray(r) ? r.join(', ') : p.answer.kind === 'mc' ? 'option ' + 'ABCD'[r] : r}`); })); return out.slice(0, 14); }

  /* ================= Personalised Do Now ================= */
  function donow(main, params) {
    const group = params.group || curGroup(); pref('group', group);
    Hub.donow.relabel();
    const asOf = Hub.mastery.asOf(), nl = C().nextLesson(group, asOf), rec = S().donow[group], kind = Hub.donow.kindOf(rec);
    const current = rec && (kind !== 'Do Now' || (nl && rec.lessonDate === nl.date)), slots = Hub.donow.KINDS[kind].slots;
    const students = Hub.roster.inGroup(group, true);
    const makers = `<div class="pq-make"><div><b>☀ Do Now</b><p class="tiny">Four questions plus an extension for ${nl ? fmtDate(nl.date, true) : 'the next lesson'}: repair, retrieve, prerequisite, bridge.</p><button class="btn ${current ? 'ghost' : 'primary'}" data-mk="Do Now" type="button">Generate Do Now</button></div>
      <div><b>✎ Exit Ticket</b><p class="tiny">Three questions: two on the lesson just taught (a challenge version if already secure) and one repair on their weakest skill or misconception.</p><button class="btn ${current ? 'ghost' : 'primary'}" data-mk="Exit Ticket" type="button">Generate Exit Ticket</button></div>
      <div><b>◆ Quiz</b><p class="tiny">Six questions: four on each student’s weakest skills (misconceptions first), one spaced retrieval, one extension.</p><button class="btn ${current ? 'ghost' : 'primary'}" data-mk="Quiz" type="button">Generate quiz</button></div></div>`;
    let body;
    if (!current) body = `<section class="card"><h2 class="bar-head amber">Make a personalised task</h2><p class="tiny muted">Every student gets their own questions, chosen from their own evidence. You review the plan before anyone sees it. One personalised task is live per class at a time.</p>${makers}</section>`;
    else {
      const counts = {}; Object.values(rec.plans).forEach(items => items.forEach(it => { const k = it.slot + '|' + it.skill; counts[k] = (counts[k] || 0) + 1; }));
      const done = S().attempts.filter(t => t.type === 'Do Now' && t.donowKey === group + '|' + rec.lessonDate);
      body = `<section class="card dn-status ${rec.status}"><div class="row-between"><div><b><span class="pill">${esc(kind)}</span> ${rec.status === 'published' ? '✓ Published to students' : 'Draft · students cannot see it yet'}</b><p class="tiny muted">${kind === 'Do Now' ? 'For ' + fmtDate(rec.lessonDate, true) + ' · ' : ''}${esc(rec.lessonTitle)}${rec.status === 'published' ? ` · ${done.length}/${students.length} completed` : ''}</p></div>
        <div class="actions">${rec.status === 'published' ? '<button class="btn ghost" id="dn-withdraw">Withdraw</button>' : '<button class="btn primary" id="dn-approve">Approve & publish</button>'}<button class="btn ghost" id="dn-regen">↻ Re-plan from latest evidence</button><a class="btn ghost" href="#/donow-print?group=${group}" target="_self">🖨 Print slips</a></div></div>
        <details class="pq-new"><summary class="small">Start a different personalised task instead…</summary><p class="tiny muted">This replaces the one above for students. Work already submitted is kept.</p>${makers}</details></section>
        <section class="card"><h2 class="bar-head amber">What the class is getting</h2><div class="slot-sum">${[...new Map(slots.map(x => [x[0], x])).values()].map(([k, lab]) => `<div><b>${lab}</b>${Object.entries(counts).filter(([x]) => x.startsWith(k + '|')).sort((a, b) => b[1] - a[1]).map(([x, n]) => `<div class="tiny">${U.skillChip(x.split('|')[1])} ×${n}</div>`).join('')}</div>`).join('')}</div></section>
        <section class="card scroll"><table class="tbl dn-table"><thead><tr><th>Student</th>${slots.map(([k, l], i) => `<th>${k === 'extension' ? '★' : i + 1} ${l}</th>`).join('')}<th>Done</th></tr></thead><tbody>${students.map(st => { const items = rec.plans[st.id] || []; const t = done.find(x => x.sid === st.id);
          return `<tr><td><a href="#/student/${st.id}">${esc(st.name)}</a></td>${items.map((it, i) => { const ms = Hub.mastery.stat(st.id, it.skill); return `<td><button class="dn-cell" data-sid="${st.id}" data-i="${i}" title="${esc(it.reason)}">${U.skillChip(it.skill)}<span class="tiny">${it.preview ? 'preview' : ms.pct !== null ? ms.pct + '%' : ''}</span></button></td>`; }).join('')}<td>${t ? Hub.assess.score(t).earned + '/' + t.max : '—'}</td></tr>`; }).join('')}</tbody></table><p class="tiny muted">Click any cell to see the question and why it was chosen, or swap the skill. Swapping withdraws approval until you approve again.</p></section>`;
    }
    main.innerHTML = U.heading('PERSONALISED LEARNING', 'Personalised quizzes', 'A Do Now, Exit Ticket or quiz with questions chosen for each student from their own evidence and misconceptions.', groupPick('dn-group', group)) +
      `<div class="card next-lesson"><span class="kicker">NEXT LESSON · ${C().GROUPS[group].label}</span><h3>${nl ? fmtDate(nl.date, true) + ' — ' + esc(nl.activity) : 'No lesson found'}</h3>${nl ? `<div class="chips">${nl.skills.map(s => U.skillChip(s)).join('')}</div>` : ''}</div>` + body +
      `<details class="card"><summary>How the questions are chosen</summary><ol class="small"><li><b>Repair</b> — lowest recency-weighted mastery among skills already taught to this group, with enough evidence.</li><li><b>Retrieve</b> — a skill with too little evidence, otherwise the longest-unseen skill (spaced retrieval).</li><li><b>Prerequisite</b> — the weakest prerequisite of the next lesson’s skills.</li><li><b>Bridge</b> — a first look at the next lesson. If it has not been taught yet it is a preview and never counts against mastery.</li><li><b>★ Extension</b> — a challenge-level version of a secure skill.</li></ol><p class="tiny muted">Mastery weights: unit tests and quizzes 1, Exit Tickets 0.8, Do Nows 0.7, homework 0.6, practice 0.5 (0.3 with hints), halving every ${S().settings.halfLifeDays} days; a retake halves the weight of the earlier attempt.</p></details>`;
    $('#dn-group').onchange = e => go('#/donow?group=' + e.target.value);
    $$('[data-mk]').forEach(b => (b.onclick = async () => { const k = b.dataset.mk; if (current && rec.status === 'published' && !(await U.confirmBox(`Replace the published ${esc(kind)} with a new ${esc(k)}? Students who have not done it yet will no longer see it.`, 'Replace'))) return; Hub.donow.draft(group, k); toast(`${k} drafted — check it, then approve.`); Hub.app.render(); }));
    const re = $('#dn-regen'); if (re) re.onclick = async () => { if (await U.confirmBox('Re-plan every student from the latest evidence? Any swaps you made will be replaced and approval withdrawn.', 'Re-plan')) { Hub.donow.draft(group, kind); Hub.app.render(); } };
    const ap = $('#dn-approve'); if (ap) ap.onclick = () => { Hub.donow.approve(group); toast(`Published — students see their own ${kind} on My day.`); Hub.app.render(); };
    const wd = $('#dn-withdraw'); if (wd) wd.onclick = () => { Hub.donow.withdraw(group); Hub.app.render(); };
    $$('.dn-cell').forEach(b => (b.onclick = () => {
      const it = rec.plans[b.dataset.sid][Number(b.dataset.i)], st = Hub.roster.byId(b.dataset.sid);
      const m = U.modal(`<h2 class="modal-title">${esc(st.name)} · ${esc(Hub.donow.slotLabel(it.slot))}</h2><p class="sticky">${esc(it.reason)}</p>${it.question ? U.question(it.question, 0, { mode: 'teacher' }) : '<p>No question available.</p>'}
        <label>Swap to another skill<select id="swap">${C().skillsFor(st.course).map(s => `<option value="${s.id}" ${s.id === it.skill ? 'selected' : ''}>${s.ox ? s.ox + ' ' : ''}${esc(s.name)}${C().isTaught(s.id, group, asOf) ? '' : ' (preview)'}</option>`).join('')}</select></label><div class="actions"><button class="btn" id="swap-ok">Swap</button></div>`, { wide: true });
      m.el.querySelector('#swap-ok').onclick = () => { Hub.donow.swap(group, st.id, Number(b.dataset.i), m.el.querySelector('#swap').value); m.close(); toast('Swapped. Approve again to publish.'); Hub.app.render(); };
    }));
  }
  function donowPrint(main, params) {
    const group = params.group || curGroup(), rec = S().donow[group];
    if (!rec) { main.innerHTML = U.empty('Generate the Do Now first.', `<a class="btn" href="#/donow?group=${group}">Back</a>`); return; }
    main.innerHTML = `<div class="no-print"><a class="back" href="#/donow?group=${group}">← Do Now</a><p>Two slips per page with big working boxes. ${rec.status !== 'published' ? '<b>Not yet approved.</b>' : ''}</p>${Hub.HOST === 'artifact' ? '<p class="tiny muted">Printing is not available inside this preview; it works in the hosted Hub (Ctrl+P / ⌘P).</p>' : '<button class="btn primary" id="print-now">🖨 Print</button>'}</div><div class="slips">${Hub.roster.inGroup(group).map(st => `<section class="slip"><header class="slip-h">${U.ibLogo()}<div><b>${Hub.donow.kindOf(rec) === 'Do Now' ? 'Do Now · ' + fmtDate(rec.lessonDate, true) : 'Personalised ' + Hub.donow.kindOf(rec) + ' · ' + fmtDate(rec.lessonDate, true)}</b><div class="slip-line">Name: <u>${esc(st.name)}</u> · ${C().GROUPS[group].block} · ☐ A day ☐ B day · Date: ________</div></div></header>${(rec.plans[st.id] || []).map((it, i) => it.question ? `<div class="slip-q"><b>${i < 4 ? i + 1 : '★'}.</b> <span class="tiny">${esc(Hub.donow.SLOTS.find(s => s[0] === it.slot)[1])}</span> ${it.question.stem ? M(it.question.stem) + ' ' : ''}${U.cmd(it.question.parts[0].command)} ${M(it.question.parts[0].prompt)} <span class="tiny">[${it.question.marks}]</span><div class="box"></div></div>` : '').join('')}</section>`).join('')}</div>`;
    const pn = $('#print-now'); if (pn) pn.onclick = () => window.print();
  }

  /* ================= Mastery ================= */
  function mastery(main, params) {
    const group = params.group || curGroup(); pref('group', group); const course = C().GROUPS[group].course, asOf = Hub.mastery.asOf();
    const taught = C().skillsFor(course).filter(s => C().isTaught(s.id, group, asOf)), next = C().skillsFor(course).filter(s => !C().isTaught(s.id, group, asOf)).slice(0, 3);
    const cols = taught.concat(next), students = Hub.roster.inGroup(group);
    const sort = params.sort || 'name';
    const rows = students.map(s => ({ s, stats: cols.map(k => Hub.mastery.stat(s.id, k.id)), overall: Hub.mastery.overall(s.id) }));
    if (sort === 'overall') rows.sort((a, b) => (a.overall ?? 999) - (b.overall ?? 999));
    main.innerHTML = U.heading('UNDERSTANDING OVER TIME', 'Mastery', 'Skill by skill, recency-weighted, with how much evidence sits behind each number.', groupPick('m-group', group)) +
      `<div class="legend">${['revisit', 'developing', 'secure', 'low-evidence', 'no-evidence', 'not-taught'].map(k => `<span class="st ${Hub.mastery.STATUS[k].cls}">${Hub.mastery.STATUS[k].short}</span> ${Hub.mastery.STATUS[k].label}`).join(' ')}<span class="tiny muted">Revisit &lt; 60% · Developing 60–79% · Secure ≥ 80%. Classroom indicators, not IB grade boundaries.</span></div>
      <section class="card scroll heat-wrap"><table class="tbl heat"><thead><tr><th class="sticky-col"><a href="#/mastery?group=${group}&sort=${sort === 'name' ? 'overall' : 'name'}">Student ${sort === 'name' ? '↕ (sort by overall)' : '↕ (sort by name)'}</a></th><th>Overall</th>${cols.map(k => { const gs = Hub.mastery.groupSkill(group, k.id); return `<th class="${gs.taught ? '' : 'nt'}" title="${esc(k.name)}"><div class="vh">${k.ox ? k.ox + ' ' : ''}${esc(k.name)}</div><span class="tiny">${gs.avg !== null ? gs.avg + '%' : gs.taught ? '—' : 'next'}</span></th>`; }).join('')}</tr></thead>
      <tbody>${rows.map(r => `<tr><td class="sticky-col"><a href="#/student/${r.s.id}">${esc(r.s.name)}</a></td><td><b>${r.overall ?? '—'}${r.overall !== null ? '%' : ''}</b></td>${r.stats.map(st => `<td>${U.statusChip(st)}</td>`).join('')}</tr>`).join('')}</tbody></table></section>
      <div class="actions"><button class="btn ghost" id="m-csv">Download mastery CSV</button></div>`;
    $('#m-group').onchange = e => go('#/mastery?group=' + e.target.value);
    $('#m-csv').onclick = () => download(`mastery_${group}.csv`, Hub.core.toCSV([['Student', 'Email', 'Overall %'].concat(cols.map(k => k.name + ' %'), cols.map(k => k.name + ' evidence marks'))].concat(rows.map(r => [r.s.name, r.s.email, r.overall].concat(r.stats.map(x => x.status === 'not-taught' ? 'not taught' : x.pct ?? ''), r.stats.map(x => x.marks))))), 'text/csv');
  }
  function student(main, params) {
    const s = Hub.roster.byId(params.id); if (!s) { main.innerHTML = U.empty('Student not found.'); return; }
    const stats = Hub.mastery.studentSkills(s.id), atts = S().attempts.filter(t => t.sid === s.id).slice().reverse();
    const mis = {}; S().evidence.filter(e => e.sid === s.id).forEach(e => (e.tags || []).forEach(t => (mis[t] = (mis[t] || 0) + 1)));
    main.innerHTML = `<a class="back" href="#/mastery?group=${s.group}">← Mastery</a>` + U.heading(C().GROUPS[s.group].label.toUpperCase(), esc(s.name), `${esc(s.username || s.email || 'not joined yet')} · overall ${Hub.mastery.overall(s.id) ?? '—'}%`, `<button class="btn ghost" id="view-as">👁 View as ${esc(s.name.split(' ')[0])}</button>`) +
      `<div class="grid g2"><section class="card"><h2 class="bar-head green">Skills</h2>${C().UNITS[s.course].filter(([u]) => stats.some(x => C().SKILL[x.skill].unit === u)).map(([u, name]) => `<h3 class="unit-h ${U.unitColour(u)}">Unit ${u} · ${esc(name)}</h3>${stats.filter(x => C().SKILL[x.skill].unit === u).map(x => `<div class="skill-row"><span>${U.skillLabel(x.skill)}</span>${U.statusChip(x)}<span class="tiny muted">${x.status === 'not-taught' ? 'taught ' + (C().taughtDate(x.skill, s.group) ? fmtDate(C().taughtDate(x.skill, s.group)) : 'later') : x.marks + ' marks' + (x.recent !== null ? ` · recent ${x.recent}%` : '')}</span></div>`).join('')}`).join('')}</section>
      <section><div class="card"><h2 class="bar-head pink">Recurring misconceptions</h2>${Object.keys(mis).length ? `<ul class="mis">${Object.entries(mis).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([t, n]) => `<li><span class="mis-n">${n}</span><b>${esc(Hub.mastery.tagText(t))}</b></li>`).join('')}</ul>` : '<p>None recorded.</p>'}</div>
      <div class="card"><h2 class="bar-head blue">Recent work</h2>${atts.length ? atts.slice(0, 8).map(t => `<div class="row-between small"><span>${esc(t.inline ? t.inline.title : (Hub.assess.byId(t.aid) || {}).title || t.type)}</span><span>${Hub.assess.score(t).earned}/${t.max} · ${t.status === 'released' ? 'released' : '<a href="#/mark/' + t.id + '">to mark</a>'}</span></div>`).join('') : '<p>No submissions yet.</p>'}</div>
      ${Hub.join ? Hub.join.loginCardHTML(s) : ''}
      <div class="card"><h2 class="bar-head green">Lesson notebooks</h2>${notebookList(s)}</div>
      <div class="card"><h2 class="bar-head amber">IA</h2>${iaSummary(s)}<a class="btn small" href="#/ia/${s.id}">Open notebook</a></div></section></div>`;
    $('#view-as').onclick = () => { Hub.auth.viewAs(s.id); go('#/home'); };
    if (Hub.join) Hub.join.bindManage(main, () => go('#/mastery?group=' + s.group));
  }
  /** Every notebook this student's course has, newest first, with how far they got and a link to read their whole notebook. */
  function notebookList(s) {
    if (!Hub.lessons) return '';
    const day = s.group.slice(-1), all = Hub.lessons.all().filter(L => L.course === s.course).sort((a, b) => String(b.dates[day] || '').localeCompare(String(a.dates[day] || '')));
    if (!all.length) return '<p class="tiny muted">No notebooks yet.</p>';
    return all.map(L => { const p = S().progress[s.id + '|nb:' + L.id], x = p && Hub.lessons.summary(L, p.responses);
      return `<div class="row-between small nb-row"><span>${L.dates[day] ? fmtDate(L.dates[day]) + ' · ' : ''}${esc(L.title.slice(0, 60))}</span><span>${x ? `<span class="tiny muted">notes ${x.notes} · your turn ${x.yt} · own ${x.own || 0}</span> <a class="btn small" href="#/lesson/${encodeURIComponent(L.id)}?view=responses&sid=${encodeURIComponent(s.id)}">Open notebook</a>` : '<span class="tiny muted">not opened</span>'}</span></div>`; }).join('');
  }
  function iaSummary(s) { const n = S().ia[s.id]; const sch = C().iaSchedule(s.group); return `<div class="ia-dots">${sch.map(st => `<span class="ia-dot ${(n && n.status && n.status[st.id]) || 'not-started'}" title="${esc(st.title)} · ${st.date ? fmtDate(st.date) : ''} · ${((n && n.status && n.status[st.id]) || 'not started').replace('-', ' ')}">${st.id.replace('cp', '')}</span>`).join('')}</div>`; }

  Hub.teacher = { dashboard, studio, edit, preview, analysis, marking, mark, donow, donowPrint, mastery, student, iaSummary, groupPick, pref };
})(window.Hub = window.Hub || {});
