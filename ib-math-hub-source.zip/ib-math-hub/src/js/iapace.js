/* IA Studio · teacher pacing: release, schedule, lock and close each stage per class, set deadlines, and make exceptions
   for one student or a group. Saved in settings.iapace = { groups: { 'SL-A': { topic: { mode, releaseAt, due, lockAfterDue,
   gate, show } } }, students: { sid: { topic: { mode, releaseAt, due, reopen, skipGate } } } }. The server applies these rules
   to every student request, so a scheduled stage opens on time without Miss Badmus signing in. */
(function (Hub) {
  'use strict';
  const { esc, $, $$, toast, fmtDate, fmtDateTime } = Hub.core;
  const U = Hub.ui, S = () => Hub.store.state, K = () => Hub.iacore, C = () => Hub.curriculum;
  const GROUPS = ['SL-A', 'SL-B', 'HL-A', 'HL-B'];
  const pace = () => { const st = S(); st.settings.iapace = st.settings.iapace || {}; const P = st.settings.iapace; P.groups = P.groups || {}; P.students = P.students || {}; return P; };
  const peek = () => (S().settings || {}).iapace || {};
  const pad = x => String(x).padStart(2, '0');
  const toLocal = iso => { if (!iso) return ''; const d = new Date(iso); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`; };
  const fromLocal = v => v ? new Date(v).toISOString() : null;
  const MODES = [['locked', 'Keep locked'], ['open', 'Release now'], ['scheduled', 'Schedule release'], ['view', 'Close (view only)']];
  function classState(c) { const m = c.mode || 'locked'; if (m === 'open') return ['open', 'Open']; if (m === 'view') return ['view', 'View only']; if (m === 'scheduled') return c.releaseAt && Date.now() >= Date.parse(c.releaseAt) ? ['open', 'Open (released ' + fmtDateTime(c.releaseAt) + ')'] : ['locked', c.releaseAt ? 'Opens ' + fmtDateTime(c.releaseAt) : 'Scheduled — no date set']; return ['locked', 'Locked']; }
  function counts(group, id) {
    const out = { done: 0, waiting: 0, overdue: 0, none: 0, custom: 0, total: 0 }, now = Date.now();
    Hub.roster.inGroup(group).forEach(s => { const n = (S().ia || {})[s.id] || {}, a = K().access(S(), s.id)[id], x = Hub.iastages.statusOf(s, n, id); out.total++;
      if (x === 'approved' || x === 'submitted') out.done++; if (x === 'submitted') out.waiting++; if (!['approved', 'submitted'].includes(x) && a.due && now > Date.parse(a.due)) out.overdue++; if (x === 'not-started') out.none++; if (a.own) out.custom++; });
    return out;
  }
  /** Suggested plan from the pacing-calendar checkpoints (filled into the form; nothing is saved until Save). */
  function suggestion(group) {
    const sch = C().iaSchedule(group), d = id => (sch.find(x => x.id === id) || {}).date, at = (date, h, m, add = 0) => { if (!date) return null; const x = new Date(date + 'T00:00:00'); x.setDate(x.getDate() + add); x.setHours(h, m, 0, 0); return x.toISOString(); };
    return { topic: { mode: 'scheduled', releaseAt: at(d('cp1'), 7, 30), due: at(d('cp2'), 23, 59, -7) }, title: { mode: 'scheduled', releaseAt: at(d('cp1'), 7, 30, 7), due: at(d('cp2'), 23, 59) }, rq: { mode: 'scheduled', releaseAt: at(d('cp2'), 7, 30), due: at(d('cp3'), 23, 59) },
      plan: { mode: 'scheduled', releaseAt: at(d('cp3'), 7, 30), due: at(d('y1'), 23, 59) }, write: { mode: 'scheduled', releaseAt: at(d('cp4'), 7, 30, -14), due: null }, review: { mode: 'locked' }, final: { mode: 'locked' } };
  }
  function timeline(group) {
    const G = (peek().groups || {})[group] || {}, rows = K().STAGES.map(st => ({ st, c: G[st.id] || {} })), ts = rows.flatMap(r => [r.c.releaseAt, r.c.due]).filter(Boolean).map(Date.parse);
    if (!ts.length) return '<p class="tiny muted">Set release dates and deadlines to see the timeline.</p>';
    const t0 = Math.min(Date.now(), ...ts) - 5 * 864e5, t1 = Math.max(Date.now(), ...ts) + 10 * 864e5, W = 760, x = t => 120 + (W - 130) * (t - t0) / (t1 - t0);
    const months = []; for (let d = new Date(t0); d <= t1; d.setMonth(d.getMonth() + 1, 1)) months.push(new Date(d.getFullYear(), d.getMonth(), 1).getTime());
    return `<svg class="pace-tl" viewBox="0 0 ${W} ${rows.length * 26 + 30}" role="img" aria-label="Release timeline for ${esc(group)}">${months.filter(m => m >= t0).map(m => `<line x1="${x(m)}" x2="${x(m)}" y1="14" y2="${rows.length * 26 + 20}" class="grid"/><text x="${x(m) + 3}" y="11" class="lab">${new Date(m).toLocaleString('en-GB', { month: 'short' })}</text>`).join('')}
      ${rows.map((r, i) => { const y = 20 + i * 26, a = r.c.releaseAt ? Date.parse(r.c.releaseAt) : r.c.mode === 'open' ? t0 : null, b = r.c.due ? Date.parse(r.c.due) : null; return `<text x="4" y="${y + 13}" class="lab">${r.st.n} · ${esc(r.st.short)}</text>${a !== null ? `<rect x="${x(a)}" y="${y + 2}" width="${Math.max(4, x(b || t1) - x(a))}" height="14" rx="7" class="bar ${b ? '' : 'open-end'}"/>` : ''}${b ? `<circle cx="${x(b)}" cy="${y + 9}" r="5" class="due"/>` : ''}`; }).join('')}
      <line x1="${x(Date.now())}" x2="${x(Date.now())}" y1="14" y2="${rows.length * 26 + 20}" class="today"/><text x="${x(Date.now()) + 3}" y="${rows.length * 26 + 28}" class="lab today-l">today</text></svg>`;
  }
  function overrideText(o) { if (!o || !Object.keys(o).length) return 'class settings'; return [o.mode ? { open: 'released', locked: 'locked', scheduled: 'opens ' + fmtDateTime(o.releaseAt), view: 'view only' }[o.mode] : '', o.due ? 'deadline ' + fmtDateTime(o.due) : '', o.reopen ? 'reopened after the deadline' : '', o.skipGate ? 'no approval needed' : ''].filter(Boolean).join(', '); }
  function applyOverride(sid, id, act, when) {
    const P = pace(), o = Object.assign({}, (P.students[sid] || {})[id]);
    if (act === 'clear') { if (P.students[sid]) { delete P.students[sid][id]; if (!Object.keys(P.students[sid]).length) delete P.students[sid]; } return; }
    if (act === 'open') { o.mode = 'open'; delete o.releaseAt; } else if (act === 'locked') { o.mode = 'locked'; delete o.releaseAt; } else if (act === 'view') { o.mode = 'view'; delete o.releaseAt; }
    else if (act === 'scheduled') { if (!when) throw Error('Choose the date and time it opens.'); o.mode = 'scheduled'; o.releaseAt = when; }
    else if (act === 'due') { if (!when) throw Error('Choose the new deadline.'); o.due = when; }
    else if (act === 'reopen') o.reopen = true; else if (act === 'skipGate') o.skipGate = true;
    P.students[sid] = Object.assign(P.students[sid] || {}, { [id]: o });
  }
  const ACTS = [['open', 'Release now'], ['locked', 'Keep locked'], ['scheduled', 'Schedule release at…'], ['due', 'Extend the deadline to…'], ['reopen', 'Reopen after the deadline'], ['view', 'Close (view only)'], ['skipGate', 'Let them skip the approval step'], ['clear', 'Back to class settings']];
  const actSelect = () => `<select data-ov-act>${ACTS.map(([k, l]) => `<option value="${k}">${l}</option>`).join('')}</select><input type="datetime-local" data-ov-when aria-label="Date and time">`;

  /* ---------- the Pacing page ---------- */
  function page(main, group) {
    const P = peek(), G = (P.groups || {})[group] || {}, studs = Hub.roster.inGroup(group), other = group.slice(0, 3) + (group.endsWith('A') ? 'B' : 'A');
    main.insertAdjacentHTML('beforeend', `<section class="card"><div class="row-between"><h2 class="bar-head amber">Stage releases · ${esc(C().GROUPS[group].label)}</h2><div class="actions"><button class="btn small ghost" type="button" id="pc-suggest">Suggest dates from the pacing calendar</button><button class="btn small ghost" type="button" id="pc-copy">Copy this plan to ${esc(C().GROUPS[other].label)}</button></div></div>
      <p class="small">Students only see and use stages that are open to them. A scheduled stage opens by itself at its time — you do not need to sign in. Deadlines do not lock anything unless you tick “close after deadline”. Locking a stage never deletes work.</p>
      <div class="scroll"><table class="tbl pace"><thead><tr><th>Stage</th><th>Now</th><th>Release</th><th>Opens at</th><th>Deadline</th><th title="Students can still read their work but cannot change or submit it">Close after deadline</th><th title="The next stage stays locked for a student until you approve this one">Approval before next stage</th><th title="Show the stage’s name and date to students while it is locked">Show when locked</th><th>Progress</th></tr></thead>
      <tbody>${K().STAGES.map(st => { const c = G[st.id] || {}, [cls, lab] = classState(c), k = counts(group, st.id); return `<tr data-st="${st.id}"><td><b>${st.n} · ${esc(st.title)}</b></td><td><span class="pill ${cls === 'open' ? 'green' : cls === 'view' ? 'blue' : 'grey'}">${esc(lab)}</span></td>
        <td><select data-k="mode">${MODES.map(([m, l]) => `<option value="${m}" ${(c.mode || 'locked') === m ? 'selected' : ''}>${l}</option>`).join('')}</select></td>
        <td><input type="datetime-local" data-k="releaseAt" value="${toLocal(c.releaseAt)}"></td><td><input type="datetime-local" data-k="due" value="${toLocal(c.due)}"></td>
        <td class="c"><input type="checkbox" data-k="lockAfterDue" ${c.lockAfterDue ? 'checked' : ''}></td><td class="c">${st.n < 7 ? `<input type="checkbox" data-k="gate" ${c.gate ? 'checked' : ''}>` : ''}</td><td class="c"><input type="checkbox" data-k="show" ${c.show !== false ? 'checked' : ''}></td>
        <td class="small"><a href="#/ia?group=${group}&stage=${st.id}">${k.done}/${k.total} done</a>${k.waiting ? ` · <span class="pill blue">${k.waiting} to approve</span>` : ''}${k.overdue ? ` · <span class="pill red">${k.overdue} overdue</span>` : ''}${k.custom ? ` · <span class="pill amber">${k.custom} custom</span>` : ''}</td></tr>`; }).join('')}</tbody></table></div>
      <div class="actions"><button class="btn primary" type="button" id="pc-save">Save release plan</button><span class="tiny muted" id="pc-msg"></span></div>
      <h3>Timeline</h3>${timeline(group)}</section>
      <section class="card"><h2 class="bar-head blue">Exceptions for one student or a group</h2><p class="small">Release a stage early, keep it locked, extend a deadline, or reopen it after the deadline — for the students you tick. Everyone else keeps the class settings.</p>
        <div class="form-grid"><label>Stage<select id="ov-stage">${K().STAGES.map(st => `<option value="${st.id}">${st.n} · ${esc(st.title)}</option>`).join('')}</select></label><label>What to do${actSelect()}</label></div>
        <div class="tiny"><button class="btn small ghost" type="button" data-pick="all">Tick all</button><button class="btn small ghost" type="button" data-pick="none">Untick all</button><button class="btn small ghost" type="button" data-pick="behind">Tick those not done</button></div>
        <div class="ov-students">${studs.map(s => `<label class="inline-check"><input type="checkbox" data-ov-sid="${esc(s.id)}"> ${esc(s.name)}</label>`).join('') || '<p class="muted">No students in this class.</p>'}</div>
        <div class="actions"><button class="btn small primary" type="button" id="ov-apply">Apply to ticked students</button></div>
        ${(() => { const rows = studs.flatMap(s => Object.entries(((P.students || {})[s.id]) || {}).map(([id, o]) => [s, id, o])); return rows.length ? `<h3>Current exceptions</h3><table class="tbl small"><thead><tr><th>Student</th><th>Stage</th><th>Exception</th><th></th></tr></thead><tbody>${rows.map(([s, id, o]) => `<tr><td>${esc(s.name)}</td><td>${K().BY[id] ? K().BY[id].n + ' · ' + esc(K().BY[id].title) : id}</td><td>${esc(overrideText(o))}</td><td><button class="btn small ghost" type="button" data-ov-clear="${esc(s.id)}|${id}">Remove</button></td></tr>`).join('')}</tbody></table>` : ''; })()}</section>`);
    bindPage(main, group, other);
  }
  function readRows(main) {
    const out = {};
    $$('tr[data-st]', main).forEach(tr => { const g = k => $(`[data-k="${k}"]`, tr), o = { mode: g('mode').value };
      if (g('releaseAt').value) o.releaseAt = fromLocal(g('releaseAt').value); if (g('due').value) o.due = fromLocal(g('due').value);
      if (g('lockAfterDue').checked) o.lockAfterDue = true; if (g('gate') && g('gate').checked) o.gate = true; if (!g('show').checked) o.show = false;
      if (o.mode === 'scheduled' && !o.releaseAt) throw Error(`Stage ${K().BY[tr.dataset.st].n}: choose when it opens, or pick another release option.`);
      if (o.mode === 'open' && !o.releaseAt) o.releaseAt = new Date().toISOString();
      out[tr.dataset.st] = o; });
    return out;
  }
  function bindPage(main, group, other) {
    const msg = t => { $('#pc-msg', main).textContent = t; };
    $('#pc-save', main).onclick = () => { try { const rows = readRows(main); pace().groups[group] = rows; Hub.store.log(`IA release plan saved for ${group}`); Hub.store.save(true); toast('Release plan saved — students see it straight away.'); Hub.app.render(); } catch (e) { msg(e.message); toast(e.message, 'error'); } };
    $('#pc-suggest', main).onclick = () => { const sg = suggestion(group); $$('tr[data-st]', main).forEach(tr => { const c = sg[tr.dataset.st] || {}, g = k => $(`[data-k="${k}"]`, tr); g('mode').value = c.mode || 'locked'; g('releaseAt').value = toLocal(c.releaseAt); g('due').value = toLocal(c.due); }); msg('Dates filled in from the pacing calendar — check them, then press Save.'); };
    $('#pc-copy', main).onclick = async () => { try { const rows = readRows(main); if (!(await U.confirmBox(`Replace the ${esc(C().GROUPS[other].label)} release plan with this one (same dates and settings)? Save this page too if you changed it.`, 'Copy plan'))) return; pace().groups[other] = JSON.parse(JSON.stringify(rows)); Hub.store.save(true); toast('Copied. Adjust the dates for the other day if needed.'); } catch (e) { toast(e.message, 'error'); } };
    const boxes = () => $$('[data-ov-sid]', main);
    $$('[data-pick]', main).forEach(b => (b.onclick = () => { const id = $('#ov-stage', main).value; boxes().forEach(c => { const s = Hub.roster.byId(c.dataset.ovSid), x = Hub.iastages.statusOf(s, (S().ia || {})[s.id] || {}, id); c.checked = b.dataset.pick === 'all' ? true : b.dataset.pick === 'none' ? false : !['approved', 'submitted'].includes(x); }); }));
    $('#ov-apply', main).onclick = () => { const id = $('#ov-stage', main).value, act = $('[data-ov-act]', main).value, when = fromLocal($('[data-ov-when]', main).value), sids = boxes().filter(c => c.checked).map(c => c.dataset.ovSid);
      if (!sids.length) return toast('Tick at least one student.', 'error');
      try { sids.forEach(sid => applyOverride(sid, id, act, when)); Hub.store.log(`IA Stage ${K().BY[id].n}: ${act} for ${sids.length} student(s)`); Hub.store.save(true); toast(`Done for ${sids.length} student${sids.length > 1 ? 's' : ''}.`); Hub.app.render(); } catch (e) { toast(e.message, 'error'); } };
    $$('[data-ov-clear]', main).forEach(b => (b.onclick = () => { const [sid, id] = b.dataset.ovClear.split('|'); applyOverride(sid, id, 'clear'); Hub.store.save(true); Hub.app.render(); }));
  }
  /* ---------- the same exceptions from one student's stage page ---------- */
  function overrideForm(s, id) { const o = ((peek().students || {})[s.id] || {})[id]; return `<div class="ov-one"><p class="tiny">Now: ${esc(overrideText(o))}.</p><div class="lookup">${actSelect()}<button class="btn small" type="button" data-ov-one="${id}">Apply</button></div></div>`; }
  function bindOverride(el, s, id) { const b = $(`[data-ov-one="${id}"]`, el); if (!b) return; b.onclick = () => { const box = b.closest('.ov-one'); try { applyOverride(s.id, id, $('[data-ov-act]', box).value, fromLocal($('[data-ov-when]', box).value)); Hub.store.log(`IA Stage ${K().BY[id].n} exception for ${s.name}`); Hub.store.save(true); toast('Saved for ' + s.name + '.'); Hub.app.render(); } catch (e) { toast(e.message, 'error'); } }; }

  /* ---------- IA settings ---------- */
  function settings(main) {
    const cfg = (S().settings || {}).iaconfig || {};
    main.insertAdjacentHTML('beforeend', `<section class="card"><h2 class="bar-head blue">Referencing style</h2><p class="small">Every student’s reference list and in-text citations use this style.</p><select id="is-style">${Object.entries(Hub.iacite.STYLES).map(([k, l]) => `<option value="${k}" ${(cfg.citeStyle || 'APA') === k ? 'selected' : ''}>${l}</option>`).join('')}</select></section>
      <section class="card"><h2 class="bar-head green">Google Docs connection</h2>${Hub.iagdoc.setupHTML()}</section>
      <section class="card"><h2 class="bar-head pink">The Hub mentor</h2><p class="small">Topic suggestions, title and research-question checks, planning prompts and the criteria checks are <b>built into the Hub</b>: rule-based, free, and run in the browser. They ask questions and point out strengths and limitations; they never write IA text, and they are labelled as formative, not as marks.</p><p class="small">Connecting an AI model for richer, open-ended feedback would need an AI API account (a paid service) and a decision about your school’s AI policy — it is not switched on.</p></section>
      <div class="actions"><button class="btn primary" type="button" id="is-save">Save IA settings</button></div>`);
    $('#is-save', main).onclick = () => { try { const g = Hub.iagdoc.readSetup(main), st = S(); st.settings.iaconfig = Object.assign({}, st.settings.iaconfig, { citeStyle: $('#is-style', main).value }, g); Hub.store.log('IA settings saved'); Hub.store.save(true); toast('IA settings saved.'); Hub.app.render(); } catch (e) { toast(e.message, 'error'); } };
  }

  Hub.iapace = { page, settings, overrideForm, bindOverride, applyOverride, suggestion, counts, classState, GROUPS };
})(window.Hub = window.Hub || {});
