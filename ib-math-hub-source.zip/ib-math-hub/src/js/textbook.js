/* Textbook worked-example references for each calendar lesson: example number and printed page in the Oxford
   Mathematics: Analysis and Approaches SL / HL books (2019). References only — no textbook content is stored here.
   Keyed by lesson id (course + the A-day date, as in Lessons & notebooks). Each entry: [example number, page]. */
(function (Hub) {
  'use strict';
  const BOOK = { SL: 'Oxford SL', HL: 'Oxford HL' };
  const R = {
    // AA SL
    'SL-2026-10-29': [[31, 53], [32, 53]],
    'SL-2026-11-04': [[33, 53], [34, 54]],
    'SL-2026-11-06': [[35, 56]],
    'SL-2026-11-10': [[1, 67], [2, 68]],
    'SL-2026-11-13': [[3, 70], [4, 71], [5, 72], [6, 72], [7, 75], [8, 76]],
    'SL-2026-11-17': [[9, 78], [10, 80], [11, 81], [12, 83]],
    'SL-2026-11-19': [[13, 86], [14, 88], [15, 89], [16, 90], [17, 91]],
    'SL-2026-11-30': [[18, 93], [19, 94], [20, 95], [21, 97], [22, 98]],
    'SL-2026-12-04': [[1, 111], [2, 112], [3, 113], [4, 114], [5, 117], [6, 118], [7, 119], [8, 120]],
    'SL-2026-12-08': [[9, 122], [10, 123], [11, 124], [12, 125], [13, 126], [14, 127], [15, 128]],
    'SL-2026-12-10': [[16, 133], [17, 135], [18, 138], [19, 140]],
    'SL-2026-12-14': [[20, 142], [21, 144], [22, 146], [23, 147], [24, 149], [25, 150], [26, 152]],
    'SL-2026-12-16': [[27, 155], [28, 156], [29, 157], [30, 158], [31, 162], [32, 163]],
    'SL-2026-12-18': [[33, 165], [34, 168], [35, 169], [36, 170], [37, 171], [38, 172]],
    // AA HL
    'HL-2026-10-29': [[1, 76], [2, 78], [3, 79]],
    'HL-2026-11-04': [[4, 83], [5, 83], [6, 84], [7, 87], [8, 88], [9, 89], [10, 90], [11, 91], [12, 92]],
    'HL-2026-11-06': [[13, 94], [14, 95], [15, 96], [16, 96], [17, 97], [18, 98], [19, 99], [20, 99], [21, 100]],
    'HL-2026-11-10': [[22, 103], [23, 105], [24, 107]],
    'HL-2026-11-13': [[25, 110], [26, 110]],
    'HL-2026-11-17': [[27, 113], [28, 113], [29, 115]],
    'HL-2026-11-19': [[30, 117], [31, 119], [32, 121], [33, 122], [34, 123], [35, 124], [36, 125]],
    'HL-2026-11-30': [[37, 129], [38, 131], [39, 134], [40, 135], [41, 137]],
    'HL-2026-12-14': [[1, 149], [2, 151], [3, 152], [4, 154], [5, 155], [6, 157], [7, 157], [8, 158], [9, 159], [10, 160]],
    'HL-2026-12-16': [[11, 162], [12, 164], [13, 165], [14, 167], [15, 167]],
    'HL-2026-12-18': [[16, 169], [17, 169], [18, 170], [19, 173], [20, 174]]
  };
  /** Worked-example cards (reference only) for a lesson id. */
  function cards(lessonId) {
    const course = String(lessonId).slice(0, 2), list = R[lessonId] || [];
    return list.map(([n, p]) => ({ ref: `${BOOK[course]} · Example ${n} · p. ${p}`, page: p, book: BOOK[course], q: '', steps: '' }));
  }
  function summary(lessonId) {
    const list = R[lessonId] || []; if (!list.length) return '';
    const course = String(lessonId).slice(0, 2), ns = list.map(x => x[0]), ps = list.map(x => x[1]);
    return `${BOOK[course]} · Example${ns.length > 1 ? 's' : ''} ${ns.length > 1 ? ns[0] + '–' + ns[ns.length - 1] : ns[0]} · ${ps[0] === ps[ps.length - 1] ? 'p. ' + ps[0] : 'pp. ' + ps[0] + '–' + ps[ps.length - 1]}`;
  }
  Hub.textbook = { cards, summary, has: id => !!(R[id] && R[id].length) };
})(window.Hub = window.Hub || {});
