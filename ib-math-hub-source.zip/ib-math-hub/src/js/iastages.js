/* IA Studio · the seven-stage journey (Topic → Title → Research question → Plan → Writing → Criteria review → Final check).
   Each stage opens only when Miss Badmus releases it (rules in iacore.js, enforced on the server). The Hub's built-in mentor
   asks questions, checks drafts against the IA criteria and suggests starting points — it never writes IA text.
   Student data: ia[sid].topic / titleB / rqB / planB / review / final / stages / seen (plus the existing fields and write).
   Teacher data: settings['iastage:'+sid][stage] = { state: 'approved' | 'returned', approved, at, text, crit }. */
(function (Hub) {
  'use strict';
  const { esc, $, $$, fmtDate, fmtDateTime, toast, debounce, download, todayISO } = Hub.core;
  const U = Hub.ui, S = () => Hub.store.state, M = t => Hub.math.render(t), K = () => Hub.iacore, TP = () => Hub.iatopics, IA = () => Hub.ia;
  const clone = x => JSON.parse(JSON.stringify(x));
  const now = () => new Date().toISOString();
  const rid = p => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const save = (n, now2) => { IA().stamp(n); Hub.store.save(now2); };

  /* ---------- access and status ---------- */
  const accessOf = s => Hub.auth.isTeacher() ? K().access(S(), s.id) : (S().iaAccess || K().access(S(), s.id));
  const tOf = s => ((S().settings || {})['iastage:' + s.id]) || {};
  function tFor(s) { const st = S(), k = 'iastage:' + s.id; st.settings[k] = st.settings[k] || {}; return st.settings[k]; }
  const mine = (n, id) => ((n.stages || {})[id]) || {};
  function hasWork(n, id) {
    const st = K().BY[id]; if (st.obj.some(k => n[k] && Object.keys(n[k]).length)) return true;
    if (st.fields.some(k => (n.fields || {})[k])) return true; if (st.write && Object.keys(n.write || {}).some(k => n.write[k] && k !== 'bodyCount')) return true;
    if (st.self && Object.keys(n.self || {}).length) return true; return false;
  }
  function statusOf(s, n, id) { let x = K().status(S(), s.id, id); if (x === 'not-started' && hasWork(n, id)) x = 'in-progress'; return x; }
  const LABEL = { 'not-started': 'Not started', 'in-progress': 'In progress', submitted: 'Submitted', returned: 'Returned for revision', approved: 'Approved' };
  const PILL = { 'not-started': 'grey', 'in-progress': 'amber', submitted: 'blue', returned: 'red', approved: 'green' };
  const isDone = x => x === 'approved' || x === 'submitted';
  const when = iso => iso ? fmtDateTime(iso) : '';
  function lockText(a, long) {
    if (a.why === 'scheduled' && a.releaseAt) return long ? `Opens on ${fmtDate(a.releaseAt.slice(0, 10), true)} at ${fmtDateTime(a.releaseAt).split(', ')[1]}.` : 'opens ' + fmtDate(a.releaseAt.slice(0, 10));
    if (a.why === 'approval') return long ? 'Opens when Miss Badmus approves the stage before it.' : 'after approval';
    return long ? 'Miss Badmus will open this stage when the class is ready.' : 'locked';
  }
  const INFO = {
    topic: { col: 'amber', crit: ['C'], blurb: 'Discover topics that connect what you care about with mathematics. Answer a few questions, explore suggestions, save and compare ideas, then choose one.', next: 'Answer the questions, save a few ideas, shortlist two or three and choose one with a reason.' },
    title: { col: 'green', crit: ['A', 'C'], blurb: 'Draft titles, check each one against what makes a strong IA title, and compare versions until you have one that is focused and yours.', next: 'Draft at least two versions, check them, and choose one.' },
    rq: { col: 'blue', crit: ['A', 'E', 'D'], blurb: 'Shape a research question or an exploration aim. The checks look for focus, enough mathematics at the right level, a manageable scope, room for your own work and room for reflection.', next: 'Write a question or aim, check it, improve it, and use your best version.' },
    plan: { col: 'pink', crit: ['E', 'B', 'D'], blurb: 'Plan the mathematics: the concepts, what you need to revise, your methods, your data, technology, limitations and the structure of the exploration.', next: 'Choose your concepts, describe your data and methods, and outline your sections.' },
    write: { col: 'green', crit: ['A', 'B', 'C', 'D', 'E'], blurb: 'Write your exploration — in your Google Doc or here, section by section. The sections are a guide, not a template: rename, add or merge them to suit your exploration.', next: 'Write a section at a time and use the checklist beside each one.' },
    review: { col: 'pink', crit: ['A', 'B', 'C', 'D', 'E'], blurb: 'Review your draft against the five criteria: read what each level needs, find your evidence, and use the Hub’s formative checks to decide what to improve.', next: 'Self-assess each criterion with evidence, then act on the checks.' },
    final: { col: 'amber', crit: ['A', 'B', 'C', 'D', 'E'], blurb: 'Check that everything is ready, then export a formatted copy and hand in your final version.', next: 'Work through the checklist and export your final copy.' }
  };

  /* ---------- the stage stepper under the tabs ---------- */
  function stepper(s, tab, teacher) {
    const a = accessOf(s), n = IA().note(s.id), base = teacher ? `#/ia/${encodeURIComponent(s.id)}` : '#/ia';
    const items = K().STAGES.map(st => {
      const x = a[st.id]; if (!teacher && x.state === 'locked' && x.show === false) return '';
      const stt = statusOf(s, n, st.id), fresh = !teacher && x.state === 'open' && !(n.seen || {})[st.id];
      const sub = x.state === 'locked' ? '🔒 ' + lockText(x) : x.state === 'view' ? 'view only' : LABEL[stt];
      return `<a class="ia-step ${x.state} st-${stt} ${tab === 's-' + st.id ? 'on' : ''}" href="${base}?tab=s-${st.id}" ${x.state === 'locked' && !teacher ? 'aria-disabled="true"' : ''}><b>${st.n}</b><span>${esc(st.short)}</span><em>${esc(sub)}${fresh ? ' <i class="new">NEW</i>' : ''}</em></a>`;
    }).join('');
    return `<nav class="ia-steps" aria-label="IA stages">${items}</nav>`;
  }

  /* ---------- one stage ---------- */
  function stage(el, s, n, id, ro, teacher, main) {
    const st = K().BY[id], a = accessOf(s)[id];
    if (!teacher && a.state === 'locked') {
      el.innerHTML = `<section class="card ia-locked"><h2 class="bar-head grey">🔒 Stage ${st.n} · ${esc(a.show === false ? 'Coming later' : st.title)}</h2><p>${esc(lockText(a, true))}</p><p class="small muted">Your work in earlier stages is saved. You will see a <b>NEW</b> label here when this stage opens.</p><a class="btn small" href="#/ia">← My IA journey</a></section>`;
      return;
    }
    const view = !teacher && a.state === 'view', r = ro || view;
    if (!teacher && !Hub.auth.isPreview() && !(n.seen || {})[id]) { n.seen = n.seen || {}; n.seen[id] = now(); Hub.store.save(); }
    el.innerHTML = headCard(s, n, st, a, r, teacher, view) + `<div class="stage-body">${BODY[id].html(s, n, r, teacher)}</div>` + footCard(s, n, st, a, r, teacher);
    BODY[id].bind(el, s, n, r, teacher, main);
    bindHeadFoot(el, s, n, st, r, teacher);
    if (main) IA().bindPlan(el, s, n, r, teacher);
  }
  function headCard(s, n, st, a, r, teacher, view) {
    const i = INFO[st.id], stt = statusOf(s, n, st.id), T = tOf(s)[st.id], my = mine(n, st.id);
    const dates = [a.releaseAt && a.mode === 'scheduled' ? `Opened ${when(a.releaseAt)}` : '', a.due ? `<b>Deadline ${when(a.due)}</b>${a.lockAfter ? ' — closes for changes after this' : ''}` : 'No deadline set yet'].filter(Boolean).join(' · ');
    return `<section class="card stage-head"><div class="row-between"><h2 class="bar-head ${i.col}">Stage ${st.n} · ${esc(st.title)}</h2><span class="pill ${PILL[stt]}">${LABEL[stt]}</span></div>
      <p class="small">${esc(i.blurb)}</p><p class="tiny muted">${dates} · Criteria: ${i.crit.map(k => `<span class="pill pink">${k}</span>`).join(' ')}${teacher ? ` · ${a.state === 'open' ? 'open to this student' : a.state === 'view' ? 'view only for this student' : '🔒 locked for this student'}` : ''}</p>
      ${view ? `<div class="notice">This stage is closed for changes — you can read your work but not change or submit it. ${a.why === 'deadline' ? 'The deadline has passed.' : ''} Ask Miss Badmus if you need it reopened.</div>` : ''}
      ${T && T.state && (!my.at || T.at >= my.at) ? `<div class="sticky ${T.state}"><b>${T.state === 'approved' ? '✓ Approved by Miss Badmus' : '↩ Returned for revision'}</b>${T.text ? ': ' + esc(T.text) : ''} <span class="tiny muted">${when(T.at)}</span></div>` : ''}
      ${!r ? `<label class="tiny target">My own target date <input type="date" data-target value="${esc(my.target || '')}"></label>` : my.target ? `<p class="tiny">Target date: ${fmtDate(my.target)}</p>` : ''}</section>`;
  }
  function footCard(s, n, st, a, r, teacher) {
    const my = mine(n, st.id), stt = statusOf(s, n, st.id), T = tOf(s)[st.id] || {};
    if (teacher) {
      const o = (((S().settings.iapace || {}).students || {})[s.id] || {})[st.id] || {};
      return `<section class="card stage-teacher"><h2 class="bar-head blue">Miss Badmus · Stage ${st.n}</h2>
        ${my.status === 'submitted' ? `<p class="small"><b>Submitted ${when(my.at)}.</b>${my.reflection ? ` Student’s reflection: <i>${esc(my.reflection)}</i>` : ''}</p>` : `<p class="small muted">${my.at ? 'Last submitted ' + when(my.at) : 'Not submitted yet.'}</p>`}
        <form class="ap-form"><label>Feedback for the student<textarea name="t" rows="2">${esc(T.text || '')}</textarea></label>
        <div class="actions"><button class="btn small primary" name="act" value="approved">✓ Approve</button><button class="btn small" name="act" value="returned">↩ Return for revision</button></div></form>
        <details class="ov"><summary>Release settings for ${esc(s.name.split(/[ ,]/)[0])} only${Object.keys(o).length ? ' <span class="pill amber">custom</span>' : ''}</summary>${Hub.iapace ? Hub.iapace.overrideForm(s, st.id) : ''}</details></section>`;
    }
    if (r) return my.reflection ? `<section class="card"><p class="small"><b>My reflection:</b> ${esc(my.reflection)}</p></section>` : '';
    return `<section class="card stage-submit"><h2 class="bar-head ${INFO[st.id].col}">Finish Stage ${st.n}</h2>
      <label>Reflection: what did you decide in this stage, and why?<textarea data-reflect rows="3" placeholder="In this stage I decided… because… Next I need to…">${esc(my.reflection || '')}</textarea></label>
      <div class="actions"><button class="btn primary" data-submit-stage type="button">${stt === 'submitted' ? 'Submit again (updated)' : stt === 'returned' ? 'Resubmit to Miss Badmus' : 'Submit Stage ' + st.n + ' to Miss Badmus'}</button><span class="tiny muted">${stt === 'submitted' ? 'Submitted ' + when(my.at) + '. You can keep improving it.' : 'A copy of your work is saved as a version when you submit.'}</span></div></section>`;
  }
  function bindHeadFoot(el, s, n, st, r, teacher) {
    const t = $('[data-target]', el); if (t) t.onchange = () => { n.stages = n.stages || {}; n.stages[st.id] = Object.assign({}, mine(n, st.id), { target: t.value, status: mine(n, st.id).status || 'in-progress' }); save(n, true); toast('Target date saved.'); };
    const rf = $('[data-reflect]', el); if (rf) rf.addEventListener('input', debounce(() => { n.stages = n.stages || {}; n.stages[st.id] = Object.assign({}, mine(n, st.id), { reflection: rf.value.slice(0, 4000), status: mine(n, st.id).status || 'in-progress' }); save(n); }, 700));
    const sb = $('[data-submit-stage]', el); if (sb) sb.onclick = async () => {
      if (!(rf && rf.value.trim())) return toast('Write a short reflection first — what you decided and why.', 'error');
      if (!(await U.confirmBox(`Submit Stage ${st.n} · ${esc(st.title)} to Miss Badmus? You can keep improving it afterwards.`, 'Submit'))) return;
      n.stages = n.stages || {}; n.stages[st.id] = Object.assign({}, mine(n, st.id), { status: 'submitted', at: now(), reflection: rf.value.slice(0, 4000) });
      IA().snapshot(n, `Stage ${st.n} submitted`); save(n, true); try { await Hub.store.flush(); toast(`Stage ${st.n} submitted.`); } catch (e) { return; } Hub.app.render();
    };
    if (teacher) {
      const f = $('.ap-form', el); if (f) f.onsubmit = e => { e.preventDefault(); const act = e.submitter ? e.submitter.value : 'approved', T = tFor(s), prev = T[st.id] || {};
        T[st.id] = Object.assign({}, prev, { state: act, approved: act === 'approved' || !!prev.approved, at: now(), text: f.t.value.trim() });
        Hub.store.log(`IA Stage ${st.n} ${act === 'approved' ? 'approved' : 'returned'} for ${s.name}`); Hub.store.save(true); toast(act === 'approved' ? 'Stage approved.' : 'Returned for revision — the student can edit and resubmit.'); Hub.app.render(); };
      if (Hub.iapace) Hub.iapace.bindOverride(el, s, st.id);
    }
  }

  /* ---------- shared bits for the builders ---------- */
  function checksHTML(checks) {
    const good = checks.filter(c => c.ok === 'yes'), think = checks.filter(c => c.ok !== 'yes');
    return `<div class="ia-ana"><div><span class="key-lab">Strengths</span>${good.length ? `<ul class="ia-checks">${good.map(c => `<li class="yes"><span class="mk">✓</span><b>${esc(c.label)}</b> — ${esc(c.why)}</li>`).join('')}</ul>` : '<p class="tiny muted">None yet.</p>'}</div>
      <div><span class="key-lab">To think about</span>${think.length ? `<ul class="ia-checks">${think.map(c => `<li class="${c.ok}"><span class="mk">${c.ok === 'no' ? '✗' : '◐'}</span><b>${esc(c.label)}</b> — ${esc(c.why)}<br><i>Ask yourself: ${esc(c.ask)}</i></li>`).join('')}</ul>` : '<p class="tiny muted">Nothing flagged — now ask Miss Badmus.</p>'}</div></div>
      <p class="tiny muted">Hub mentor · built-in checks that prompt your thinking. They are not a mark, and they do not decide whether your work is approved.</p>`;
  }
  const mark = c => c.ok === 'yes' ? '✓' : c.ok === 'maybe' ? '◐' : '✗';
  function versionsHTML(kind, list, chosenId, r, checkFn) {
    if (!list.length) return '<p class="tiny muted">No saved versions yet. Save each draft so you can compare them.</p>';
    const rows = list.slice().reverse();
    return `<div class="ver-list">${rows.map(v => { const ch = checkFn(v.text); return `<div class="ver ${v.id === chosenId ? 'chosen' : ''}"><div class="row-between"><span class="tiny muted">${when(v.at)}${v.id === chosenId ? ' · <b>in use</b>' : ''}</span><span class="tiny">${ch.map(mark).join(' ')}</span></div><p>${esc(v.text)}</p>
      <div class="actions">${r ? '' : `<button class="btn small" type="button" data-use-${kind}="${v.id}">Use this version</button><button class="btn small ghost" type="button" data-rm-${kind}="${v.id}">Delete</button>`}<label class="inline-check tiny"><input type="checkbox" data-cmp-${kind}="${v.id}"> compare</label></div></div>`; }).join('')}</div>
      <div id="cmp-${kind}"></div>`;
  }
  function compareTable(list, checkFn) {
    if (list.length < 2) return '<p class="tiny muted">Tick two or three versions to compare them side by side.</p>';
    const cs = list.map(v => checkFn(v.text));
    return `<div class="scroll"><table class="tbl small cmp"><thead><tr><th></th>${list.map((v, i) => `<th>Version ${i + 1}<div class="tiny muted">${when(v.at)}</div></th>`).join('')}</tr></thead><tbody><tr><td><b>Text</b></td>${list.map(v => `<td>${esc(v.text)}</td>`).join('')}</tr>
      ${cs[0].map((c, j) => `<tr><td><b>${esc(c.label)}</b></td>${cs.map(x => `<td class="ck-${x[j].ok}">${mark(x[j])} <span class="tiny">${esc(x[j].why)}</span></td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
  }
  function bindVersions(el, kind, getList, setChosen, checkFn, r) {
    const cmp = () => { const ids = $$(`[data-cmp-${kind}]:checked`, el).map(x => x.getAttribute(`data-cmp-${kind}`)); const list = getList().filter(v => ids.includes(v.id)); $(`#cmp-${kind}`, el).innerHTML = compareTable(list, checkFn); };
    $$(`[data-cmp-${kind}]`, el).forEach(c => (c.onchange = cmp));
    if (r) return;
    $$(`[data-use-${kind}]`, el).forEach(b => (b.onclick = () => { setChosen(getList().find(v => v.id === b.getAttribute(`data-use-${kind}`))); }));
    $$(`[data-rm-${kind}]`, el).forEach(b => (b.onclick = async () => { if (!(await U.confirmBox('Delete this saved version?', 'Delete', { danger: true }))) return; const L = getList(), i = L.findIndex(v => v.id === b.getAttribute(`data-rm-${kind}`)); if (i >= 0) L.splice(i, 1); Hub.store.save(true); Hub.app.render(); }));
  }
  const cps = (s, n, r, teacher, ids) => { const sch = Hub.curriculum.iaSchedule(s.group); return ids.map(id => sch.find(x => x.id === id)).filter(Boolean).map(cp => IA().planSection(cp, n, s, r, teacher)).join(''); };
  const cpWrap = (s, n, r, teacher, ids) => ids.length ? `<details class="card cp-wrap" open><summary><h2 class="bar-head grey">Class checkpoint${ids.length > 1 ? 's' : ''} from the pacing calendar</h2></summary>${cps(s, n, r, teacher, ids)}</details>` : '';

  /* ================= Stage 1 · Topic Finder ================= */
  let browseArea = '', cmpSet = null, lastSid = null;
  function topicHTML(s, n, r) {
    const T = n.topic || {}, A = T.answers || {}, P = TP(), saved = {};
    if (lastSid !== s.id) { cmpSet = null; lastSid = s.id; }
    // Ideas saved with the old Topic finder still count (shown, not rewritten).
    Object.keys(n.checks || {}).filter(k => /^idea:/.test(k) && n.checks[k]).forEach(k => { const id = P.OLD[k.slice(5)]; if (id) saved[id] = { at: '', old: true }; });
    Object.assign(saved, T.saved || {});
    const chip = (name, list, val, label) => `<label class="ia-chip"><input type="checkbox" data-ans-list="${name}" value="${esc(val)}" ${(list || []).includes(val) ? 'checked' : ''} ${r ? 'disabled' : ''}><span>${esc(label || val)}</span></label>`;
    const sug = T.ran ? P.suggest(A, s.course, 8) : [];
    const savedIds = Object.keys(saved), own = T.own || [];
    const ideaOf = id => P.TOPIC[id] || own.find(o => o.id === id);
    return `<section class="card"><h2 class="bar-head amber">1 · Tell the mentor about you</h2><p class="small">The more you say, the closer the suggestions. Write in your own words — hobbies, things you are curious about, places, objects, problems.</p>
      <div class="form-grid"><label class="span2">What do you enjoy doing or think about outside class?<textarea data-ans="hobbies" rows="2" placeholder="e.g. volleyball, baking, my grandmother’s garden, Formula 1, playing guitar" ${r ? 'readonly' : ''}>${esc(A.hobbies || '')}</textarea></label>
      <label>Real-world problems or questions you care about<textarea data-ans="problems" rows="2" placeholder="e.g. why does traffic jam near school? is recycling worth it?" ${r ? 'readonly' : ''}>${esc(A.problems || '')}</textarea></label>
      <label>Anything else — things you have wondered about<textarea data-ans="other" rows="2" ${r ? 'readonly' : ''}>${esc(A.other || '')}</textarea></label></div>
      <span class="key-lab">Subjects you enjoy</span><div class="chips-row">${P.SUBJECTS.map(x => chip('subjects', A.subjects, x)).join('')}</div>
      <span class="key-lab">Future study or careers you are considering</span><div class="chips-row">${P.CAREERS.map(x => chip('careers', A.careers, x)).join('')}</div>
      <span class="key-lab">Mathematics you like most</span><div class="chips-row">${Object.entries(P.MATHS).filter(([k]) => s.course === 'HL' || !/HL/.test(P.MATHS[k])).map(([k, l]) => chip('maths', A.maths, k, l)).join('')}</div>
      <span class="key-lab">How would you like to work?</span><div class="chips-row">${Object.entries(P.DATA).map(([k, l]) => `<label class="ia-chip"><input type="radio" name="ans-data" data-ans-radio="data" value="${k}" ${(A.data || 'any') === k ? 'checked' : ''} ${r ? 'disabled' : ''}><span>${esc(l)}</span></label>`).join('')}</div>
      <label class="inline-check"><input type="checkbox" data-ans-bool="fresh" ${A.fresh ? 'checked' : ''} ${r ? 'disabled' : ''}> I would like a less common topic</label>
      ${r ? '' : `<div class="actions"><button class="btn primary" id="tf-run" type="button">${T.ran ? 'Update my suggestions' : 'Find topics for me'}</button></div>`}</section>
      ${T.ran ? `<section class="card"><h2 class="bar-head green">2 · Suggestions for you</h2><p class="small">Matched to your answers from the Hub’s topic bank (${P.TOPICS.length} starting points). Each one shows the mathematics, how well it suits ${s.course}, its potential, likely challenges, where data comes from and how original it is. <b>They are starting points to make your own — not topics chosen for you.</b></p>
        <div class="idea-grid">${sug.map(x => ideaCard(x.t, x.why, s.course, !!saved[x.t.id], r)).join('')}</div>${sug.every(x => !x.why.length) ? '<p class="small muted">These are general starting points — say more about your interests above for closer matches.</p>' : ''}</section>` : ''}
      <details class="card"><summary><h2 class="bar-head blue">Browse every topic</h2></summary><div class="tabs">${['', ...new Set(P.TOPICS.map(t => t.area))].map(a => `<button class="tab ${a === browseArea ? 'on' : ''}" data-browse="${esc(a)}" type="button">${a || 'All'}</button>`).join('')}</div>
        <div class="idea-grid">${P.TOPICS.filter(t => (!browseArea || t.area === browseArea) && (t.lvl !== 'HL' || s.course === 'HL')).map(t => ideaCard(t, [], s.course, !!saved[t.id], r)).join('')}</div></details>
      <section class="card"><h2 class="bar-head pink">3 · My ideas</h2>${savedIds.length ? savedIds.map(id => { const t = ideaOf(id), v = saved[id]; if (!t) return ''; return `<div class="my-idea ${v.star ? 'star' : ''}"><div class="row-between"><b>${v.star ? '★ ' : ''}${esc(t.t)}</b><span class="actions">${r ? '' : `<button class="btn small ${v.star ? '' : 'ghost'}" data-star="${esc(id)}" type="button">${v.star ? '★ Shortlisted' : '☆ Shortlist'}</button><button class="btn small ghost" data-unsave="${esc(id)}" type="button">Remove</button>`}<label class="inline-check tiny"><input type="checkbox" data-cmpi="${esc(id)}" ${(cmpSet ? cmpSet.has(id) : v.star) ? 'checked' : ''}> compare</label></span></div>
        <label class="tiny">Why does it appeal to me? What could I add of my own?<textarea data-inote="${esc(id)}" rows="2" ${r ? 'readonly' : ''}>${esc(v.note || '')}</textarea></label></div>`; }).join('') : '<p class="muted">Save ideas from the suggestions, or add your own below.</p>'}
        ${r ? '' : `<details class="own-idea"><summary>+ Add my own idea</summary><div class="form-grid"><label>Idea<input id="oi-t" placeholder="e.g. Timing the school buses"></label><label>Mathematics I might use<input id="oi-m"></label><label class="span2">Where the data or model would come from<input id="oi-d"></label><div><button class="btn small" id="oi-add" type="button">Add to my ideas</button></div></div></details>`}</section>
      <section class="card"><h2 class="bar-head blue">4 · Compare</h2><div id="tf-cmp"></div></section>
      <section class="card"><h2 class="bar-head green">5 · My choice</h2>${savedIds.length ? `<div class="chips-row">${savedIds.filter(id => ideaOf(id)).map(id => `<label class="ia-chip"><input type="radio" name="tf-choice" data-choice value="${esc(id)}" ${T.choice === id ? 'checked' : ''} ${r ? 'disabled' : ''}><span>${esc(ideaOf(id).t)}</span></label>`).join('')}</div>
        <label>Why this one? What will make it yours?<textarea data-tchoice-why rows="3" ${r ? 'readonly' : ''}>${esc(T.why || '')}</textarea></label>` : '<p class="muted">Save and shortlist some ideas first.</p>'}</section>`;
  }
  function ideaCard(t, why, course, saved, r) {
    const P = TP(), dots = '●'.repeat(t.d[1]) + '○'.repeat(3 - t.d[1]);
    return `<article class="idea2 ${saved ? 'saved' : ''}"><div class="row-between"><span class="tiny muted">${esc(t.area)}${t.lvl === 'HL' ? ' · HL' : ''}</span>${saved ? '<span class="pill green">in my ideas</span>' : ''}</div><h4>${esc(t.t)}</h4>
      ${why.length ? `<ul class="why">${why.map(w => `<li>${esc(w)}</li>`).join('')}</ul>` : ''}
      <dl class="idea-dl"><dt>Mathematics</dt><dd>${esc(t.m)}${course === 'HL' ? `<br><b>HL depth:</b> ${esc(t.hl)}` : ''}</dd><dt>Suits</dt><dd>${t.lvl === 'HL' ? 'HL (the mathematics goes beyond SL)' : course === 'HL' ? 'SL and HL — at HL, go for the HL depth above' : 'SL and HL'}</dd>
      <dt>Potential</dt><dd>${esc(t.pot)}</dd><dt>Challenges</dt><dd>${esc(t.ch)}</dd><dt>Data</dt><dd><span title="${esc(P.dataWord(t.d))}">${dots}</span> ${esc(P.dataWord(t.d))} — ${esc(t.d[2])}</dd><dt>Originality</dt><dd>${esc(P.commonWord(t.common))}. ${esc(t.orig)}</dd></dl>
      <details><summary class="tiny">Angles to adapt — not titles to copy</summary><ul class="small">${t.angles.map(a => `<li>${esc(a)}</li>`).join('')}</ul></details>
      ${r ? '' : `<button class="btn small ${saved ? 'ghost' : ''}" data-save="${t.id}" type="button">${saved ? 'Remove from my ideas' : '☆ Save to my ideas'}</button>`}</article>`;
  }
  function topicBind(el, s, n, r) {
    const P = TP(), T = () => (n.topic = n.topic || {}), A = () => (T().answers = T().answers || {}), SV = () => (T().saved = T().saved || {});
    const renderCmp = () => { const saved = (n.topic || {}).saved || {}, ids = $$('[data-cmpi]:checked', el).map(x => x.dataset.cmpi); cmpSet = new Set(ids); const own = (n.topic || {}).own || [];
      const list = ids.map(id => P.TOPIC[id] ? Object.assign({ own: false }, P.TOPIC[id]) : Object.assign({ own: true }, own.find(o => o.id === id) || {})).filter(x => x.t);
      $('#tf-cmp', el).innerHTML = list.length < 2 ? '<p class="tiny muted">Tick “compare” on two or three of your ideas (shortlisted ones are ticked for you).</p>' : `<div class="scroll"><table class="tbl small cmp"><thead><tr><th></th>${list.map(t => `<th>${esc(t.t)}</th>`).join('')}</tr></thead><tbody>
        ${[['Mathematics', t => t.own ? t.m : t.m + (s.course === 'HL' ? ' · HL: ' + t.hl : '')], ['Suits', t => t.own ? '—' : t.lvl === 'HL' ? 'HL' : 'SL and HL'], ['Potential', t => t.own ? '—' : t.pot], ['Challenges', t => t.own ? '—' : t.ch], ['Data', t => t.own ? t.d || '—' : P.dataWord(t.d) + ' — ' + t.d[2]], ['Originality', t => t.own ? 'Your own idea' : P.commonWord(t.common)], ['My note', t => (saved[t.id] || {}).note || '—']].map(([l, f]) => `<tr><td><b>${l}</b></td>${list.map(t => `<td>${esc(f(t))}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`; };
    renderCmp(); $$('[data-cmpi]', el).forEach(c => (c.onchange = renderCmp));
    $$('[data-browse]', el).forEach(b => (b.onclick = () => { browseArea = b.dataset.browse; const d = b.closest('details'); Hub.app.render(); const d2 = $$('details.card', document).find(x => /Browse every topic/.test(x.textContent)); if (d && d2) d2.open = true; }));
    if (r) return;
    const sv = debounce(() => save(n), 600);
    $$('[data-ans]', el).forEach(t => t.addEventListener('input', () => { A()[t.dataset.ans] = t.value.slice(0, 2000); sv(); }));
    $$('[data-ans-list]', el).forEach(c => (c.onchange = () => { const k = c.dataset.ansList; A()[k] = $$(`[data-ans-list="${k}"]:checked`, el).map(x => x.value); sv(); }));
    $$('[data-ans-radio]', el).forEach(c => (c.onchange = () => { A().data = c.value; sv(); }));
    $$('[data-ans-bool]', el).forEach(c => (c.onchange = () => { A()[c.dataset.ansBool] = c.checked; sv(); }));
    const run = $('#tf-run', el); if (run) run.onclick = () => { const a = A(); if (!(a.hobbies || a.problems || a.other || (a.subjects || []).length || (a.maths || []).length)) return toast('Tell the mentor a little about yourself first.', 'error'); T().ran = now(); save(n, true); Hub.app.render(); setTimeout(() => { const g = $('.idea-grid'); if (g) g.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 50); };
    $$('[data-save]', el).forEach(b => (b.onclick = () => { const id = b.dataset.save, m = SV(); if (m[id]) { delete m[id]; if (n.checks) delete n.checks['idea:' + id]; } else m[id] = { at: now() }; save(n, true); Hub.app.render(); }));
    $$('[data-unsave]', el).forEach(b => (b.onclick = () => { const id = b.dataset.unsave; delete SV()[id]; Object.keys(n.checks || {}).forEach(k => { if (k === 'idea:' + id || P.OLD[k.slice(5)] === id) delete n.checks[k]; }); if (T().choice === id) delete T().choice; save(n, true); Hub.app.render(); }));
    $$('[data-star]', el).forEach(b => (b.onclick = () => { const m = SV(), v = m[b.dataset.star] = m[b.dataset.star] || { at: now() }; if (!v.star && Object.values(m).filter(x => x.star).length >= 3) return toast('Shortlist up to three — remove one first.', 'error'); v.star = !v.star; cmpSet = null; save(n, true); Hub.app.render(); }));
    $$('[data-inote]', el).forEach(t => t.addEventListener('input', () => { const m = SV(); m[t.dataset.inote] = Object.assign(m[t.dataset.inote] || { at: now() }, { note: t.value.slice(0, 2000) }); sv(); }));
    const oa = $('#oi-add', el); if (oa) oa.onclick = () => { const t = $('#oi-t', el).value.trim(); if (!t) return toast('Name your idea first.', 'error'); const id = rid('own-'); T().own = (T().own || []).concat([{ id, t: t.slice(0, 200), m: $('#oi-m', el).value.trim().slice(0, 300), d: $('#oi-d', el).value.trim().slice(0, 300) }]); SV()[id] = { at: now() }; save(n, true); Hub.app.render(); };
    $$('[data-choice]', el).forEach(c => (c.onchange = () => { T().choice = c.value; save(n, true); toast('Choice saved — write why below.'); }));
    const cw = $('[data-tchoice-why]', el); if (cw) cw.addEventListener('input', () => { T().why = cw.value.slice(0, 3000); sv(); });
  }

  /* ================= Stage 2 · Title Builder ================= */
  const topicName = n => { const T = n.topic || {}, P = TP(); if (!T.choice) return ''; const t = P.TOPIC[T.choice] || (T.own || []).find(o => o.id === T.choice); return t ? t.t : ''; };
  const ctxOf = n => ({ mine: TP().words([((n.topic || {}).answers || {}).hobbies, ((n.topic || {}).answers || {}).problems].join(' ')) });
  function titleHTML(s, n, r) {
    const B = n.titleB || {}, list = B.versions || [], ck = t => TP().titleCheck(t, s.course, ctxOf(n));
    return `<section class="card"><h2 class="bar-head green">Draft a title</h2>${topicName(n) ? `<p class="small">Your topic from Stage 1: <b>${esc(topicName(n))}</b></p>` : ''}
      <p class="small">A strong title tells a reader what the exploration is about and hints at the mathematics. It can be a question or a statement. Try a few shapes — fill the blanks with your own situation:</p>
      <ul class="shapes small"><li>How does [<i>something you change</i>] affect [<i>something you measure</i>] in [<i>your situation</i>]?</li><li>Modelling [<i>your situation</i>] with [<i>the mathematics</i>]</li><li>To what extent can [<i>the mathematics</i>] predict [<i>an outcome</i>] in [<i>your situation</i>]?</li><li>Finding the [<i>best / fastest / largest</i>] [<i>quantity</i>] for [<i>your situation</i>]</li></ul>
      <label>My draft title<textarea id="tb-draft" rows="2" ${r ? 'readonly' : ''} placeholder="Write it yourself — the mentor checks it, it never writes it.">${esc(B.draft || '')}</textarea></label>
      <div id="tb-checks">${(B.draft || '').trim() ? checksHTML(ck(B.draft)) : '<p class="tiny muted">The checks appear as you type.</p>'}</div>
      ${r ? '' : '<div class="actions"><button class="btn small" id="tb-save" type="button">Save this version</button></div>'}</section>
      <section class="card"><h2 class="bar-head blue">My versions</h2><p class="small">Current title: <b>${esc((n.fields || {}).title || '— none chosen yet')}</b></p>${versionsHTML('tv', list, B.chosen, r, ck)}</section>`;
  }
  function titleBind(el, s, n, r) {
    const B = () => (n.titleB = n.titleB || {}), ck = t => TP().titleCheck(t, s.course, ctxOf(n));
    bindVersions(el, 'tv', () => B().versions || [], v => { n.fields = n.fields || {}; n.fields.title = v.text; B().chosen = v.id; n.status = n.status || {}; if (!n.status.cp2 || n.status.cp2 === 'not-started') n.status.cp2 = 'in-progress'; save(n, true); toast('Title saved to Checkpoint 2.'); Hub.app.render(); }, ck, r);
    if (r) return;
    const d = $('#tb-draft', el), sv = debounce(() => save(n), 700);
    d.addEventListener('input', debounce(() => { B().draft = d.value.slice(0, 600); $('#tb-checks', el).innerHTML = d.value.trim() ? checksHTML(ck(d.value)) : ''; sv(); }, 350));
    $('#tb-save', el).onclick = () => { const t = d.value.trim(); if (!t) return toast('Write a title first.', 'error'); const L = B().versions = B().versions || []; if (L.some(v => v.text === t)) return toast('That version is already saved.'); L.push({ id: rid('tv-'), at: now(), text: t.slice(0, 600) }); if (L.length > 20) L.shift(); save(n, true); toast('Version saved.'); Hub.app.render(); };
  }

  /* ================= Stage 3 · Research Question Builder ================= */
  function rqShapes(c, kind) {
    const v = k => esc((c['rq' + k] || '').trim() || '…');
    return kind === 'question' ? [`How does ${v('Var')} affect ${v('Out')} in ${v('Sit')}?`, `To what extent can ${v('Maths')} model ${v('Out')} in ${v('Sit')}?`, `Which ${v('Var')} gives the greatest or least ${v('Out')} in ${v('Sit')}?`, `How accurately can ${v('Maths')} predict ${v('Out')} in ${v('Sit')}?`]
      : [`The aim of this exploration is to use ${v('Maths')} to find how ${v('Var')} affects ${v('Out')} in ${v('Sit')}.`, `This exploration aims to build and evaluate a model of ${v('Out')} in ${v('Sit')} using ${v('Maths')}.`];
  }
  function rqHTML(s, n, r) {
    const B = n.rqB || {}, kind = B.kind || 'question', c = n.checks || {}, list = B.versions || [];
    const topic = TP().TOPIC[(n.topic || {}).choice], ck = t => TP().rqCheck(t, s.course, { data: topic ? topic.d[1] : null });
    const shapes = rqShapes(c, kind);
    return `<section class="card"><h2 class="bar-head blue">Question or aim?</h2><p class="small">An IA can be driven by a research question or by a clearly stated aim. Either way it must be focused, need course-level mathematics and leave room for your own decisions and reflection.</p>
      <div class="chips-row">${[['question', 'A research question'], ['aim', 'An exploration aim']].map(([k, l]) => `<label class="ia-chip"><input type="radio" name="rqkind" data-rqkind value="${k}" ${kind === k ? 'checked' : ''} ${r ? 'disabled' : ''}><span>${l}</span></label>`).join('')}</div></section>
      <section class="card"><h2 class="bar-head amber">Build it from its parts</h2><div class="form-grid">
        ${[['Sit', 'The real situation', 'e.g. my volleyball serve'], ['Var', 'What you change or compare', 'e.g. the launch angle'], ['Out', 'What you find, measure or predict', 'e.g. whether it clears the net'], ['Maths', 'The mathematics', 'e.g. a quadratic model and calculus']].map(([k, l, ph]) => `<label>${l}<input data-rqp="rq${k}" value="${esc(c['rq' + k] || '')}" placeholder="${ph}" ${r ? 'readonly' : ''}></label>`).join('')}</div>
        <span class="key-lab">Sentence shapes to try (rewrite them in your own words)</span><ul class="shapes small" id="rq-shapes">${shapes.map(x => `<li>${x}</li>`).join('')}</ul></section>
      <section class="card"><h2 class="bar-head green">My ${kind === 'aim' ? 'aim' : 'research question'}</h2>
        <label>Draft<textarea id="rb-draft" rows="3" ${r ? 'readonly' : ''}>${esc(B.draft || '')}</textarea></label><div id="rb-checks">${(B.draft || '').trim() ? checksHTML(ck(B.draft)) : '<p class="tiny muted">The six checks appear as you type: focus, mathematics, level, scope, your own work, reflection.</p>'}</div>
        ${r ? '' : '<div class="actions"><button class="btn small" id="rb-save" type="button">Save this version</button></div>'}</section>
      <section class="card"><h2 class="bar-head pink">My versions</h2><p class="small">In use: <b>${esc((n.fields || {}).rq || '— none yet')}</b></p>${versionsHTML('rv', list, B.chosen, r, ck)}</section>`;
  }
  function rqBind(el, s, n, r) {
    const B = () => (n.rqB = n.rqB || {}), topic = TP().TOPIC[(n.topic || {}).choice], ck = t => TP().rqCheck(t, s.course, { data: topic ? topic.d[1] : null });
    bindVersions(el, 'rv', () => B().versions || [], v => { n.fields = n.fields || {}; n.fields.rq = v.text; B().chosen = v.id; n.status = n.status || {}; if (!n.status.cp3 || n.status.cp3 === 'not-started') n.status.cp3 = 'in-progress'; save(n, true); toast('Saved to Checkpoint 3 — copy it into your writing when that stage opens.'); Hub.app.render(); }, ck, r);
    if (r) return;
    const sv = debounce(() => save(n), 700);
    $$('[data-rqkind]', el).forEach(x => (x.onchange = () => { B().kind = x.value; save(n, true); Hub.app.render(); }));
    $$('[data-rqp]', el).forEach(i => i.addEventListener('input', () => { n.checks = n.checks || {}; n.checks[i.dataset.rqp] = i.value.slice(0, 300); $('#rq-shapes', el).innerHTML = rqShapes(n.checks, B().kind || 'question').map(x => `<li>${x}</li>`).join(''); sv(); }));
    const d = $('#rb-draft', el); d.addEventListener('input', debounce(() => { B().draft = d.value.slice(0, 1000); $('#rb-checks', el).innerHTML = d.value.trim() ? checksHTML(ck(d.value)) : ''; sv(); }, 350));
    $('#rb-save', el).onclick = () => { const t = d.value.trim(); if (!t) return toast('Write it first.', 'error'); const L = B().versions = B().versions || []; if (L.some(v => v.text === t)) return toast('That version is already saved.'); L.push({ id: rid('rv-'), at: now(), text: t.slice(0, 1000) }); if (L.length > 20) L.shift(); save(n, true); toast('Version saved.'); Hub.app.render(); };
  }

  /* ================= Stage 4 · Exploration Planner ================= */
  const OUTLINE0 = [['Introduction', 'Why this topic; the aim or research question; the plan', 'A, C'], ['Background and key terms', 'Variables and notation defined', 'B'], ['Part 1', '', 'E, D'], ['Part 2', '', 'E, D'], ['Conclusion and evaluation', 'Answer, interpretation, strengths, limitations, extensions', 'D, A'], ['References', 'Every source, data set and piece of software', 'A']];
  function planHTML(s, n, r) {
    const P = TP(), B = n.planB || {}, ch = new Set(B.concepts || []), D = B.data || {}, out = B.outline || OUTLINE0.map(([h, m, c]) => ({ h, m, c }));
    const groups = [...new Set(P.CONCEPTS.map(c => c.grp))];
    const chip = c => `<label class="ia-chip ${c.lvl === 'HL' ? 'hl' : ''}"><input type="checkbox" data-concept="${c.k}" ${ch.has(c.k) ? 'checked' : ''} ${r ? 'disabled' : ''}><span>${esc(c.t)}${c.lvl === 'HL' ? ' <i>HL</i>' : ''}</span></label>`;
    const chosen = P.CONCEPTS.filter(c => ch.has(c.k)), pre = [...new Set(chosen.flatMap(c => c.pre.split('; ')))];
    const lvlNote = !chosen.length ? '<p class="tiny muted">Choose the concepts you expect to use.</p>' : s.course === 'HL'
      ? (chosen.some(c => c.lvl === 'HL') ? '<p class="small ok-line">✓ HL-level mathematics is in your plan.</p>' : '<p class="small warn-line">◐ No HL-only concepts yet. At HL, criterion E rewards rigour and sophistication — plan where they will appear.</p>')
      : (chosen.some(c => c.k !== 'stat') ? '<p class="small ok-line">✓ Course-level mathematics is in your plan.</p>' : '<p class="small warn-line">✗ Statistics beyond averages alone is close to prior learning — add course-level mathematics.</p>') + (chosen.some(c => c.lvl === 'HL') ? '<p class="small warn-line">◐ You chose HL-only mathematics: you must learn it and explain it fully in your own words.</p>' : '');
    const E = IA().levelsOf('E', s.course);
    return `<section class="card"><h2 class="bar-head pink">1 · The mathematics</h2><p class="small">Tick the course concepts you expect to use. ${s.course === 'SL' ? 'HL-only topics are hidden under “Beyond SL” — only use them if you can learn and explain them.' : 'HL-only concepts are marked HL.'}</p>
      ${groups.map(g => { const L = P.CONCEPTS.filter(c => c.grp === g && (s.course === 'HL' || c.lvl === 'SL')); return L.length ? `<span class="key-lab">${esc(g)}</span><div class="chips-row">${L.map(chip).join('')}</div>` : ''; }).join('')}
      ${s.course === 'SL' ? `<details><summary class="small">Beyond SL (only if you can explain it)</summary><div class="chips-row">${P.CONCEPTS.filter(c => c.lvl === 'HL').map(chip).join('')}</div></details>` : ''}
      ${lvlNote}${pre.length ? `<div class="sticky blue"><b>Revise before you start:</b> ${pre.map(esc).join(' · ')}</div>` : ''}
      <label>${s.course === 'HL' ? 'Where will HL depth or rigour appear (a proof, a derivation, HL-only content)?' : 'Which parts go beyond what you learned before the IB?'}<textarea data-pb="depth" rows="2" ${r ? 'readonly' : ''}>${esc(B.depth || '')}</textarea></label></section>
      <section class="card"><h2 class="bar-head blue">2 · Methods, data and technology</h2>
      <label>Methods and techniques — what will you do, in what order, and why does each method fit?<textarea data-pb="methods" rows="4" ${r ? 'readonly' : ''}>${esc(B.methods || '')}</textarea></label>
      <div class="form-grid"><label>Where will your data or model come from?<select data-pbd="kind" ${r ? 'disabled' : ''}>${[['', 'Choose…'], ['collect', 'I will collect it (measure, film, survey, experiment)'], ['online', 'A published data set'], ['model', 'No data — a model or pure mathematics'], ['mixed', 'A mix']].map(([k, l]) => `<option value="${k}" ${D.kind === k ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
      <label>What data, exactly, and how much?<input data-pbd="what" value="${esc(D.what || '')}" ${r ? 'readonly' : ''} placeholder="e.g. 30 filmed serves at 3 angles"></label>
      <label class="span2">How will you collect or find it, and how will you make it reliable?<textarea data-pbd="how" rows="2" ${r ? 'readonly' : ''}>${esc(D.how || '')}</textarea></label></div>
      <span class="key-lab">Technology</span><div class="chips-row">${P.TECH.map(t => `<label class="ia-chip"><input type="checkbox" data-tech value="${esc(t)}" ${(B.tech || []).includes(t) ? 'checked' : ''} ${r ? 'disabled' : ''}><span>${esc(t)}</span></label>`).join('')}</div>
      <p class="tiny muted">When technology gives a result, your write-up still has to show or explain the mathematics behind it.</p>
      <label>Limitations and assumptions you can already see<textarea data-pb="limits" rows="2" ${r ? 'readonly' : ''}>${esc(B.limits || '')}</textarea></label></section>
      <section class="card"><h2 class="bar-head green">3 · Structure</h2><p class="small">Sketch your sections and the mathematics in each. This is your plan — change it as the exploration develops.</p>
      <div class="outline">${out.map((o, i) => `<div class="ol-row"><span class="ol-n">${i + 1}</span><input data-ol="${i}" data-k="h" value="${esc(o.h || '')}" ${r ? 'readonly' : ''} aria-label="Section heading"><input data-ol="${i}" data-k="m" value="${esc(o.m || '')}" placeholder="Mathematics or content in this section" ${r ? 'readonly' : ''}><span class="tiny">${esc(o.c || '')}</span>${r ? '' : `<span class="ol-b"><button class="btn small ghost" type="button" data-olup="${i}" aria-label="Move up">↑</button><button class="btn small ghost" type="button" data-olrm="${i}" aria-label="Remove">×</button></span>`}</div>`).join('')}</div>
      ${r ? '' : '<button class="btn small" type="button" id="ol-add">+ Add a section</button>'}</section>
      <details class="card"><summary><h2 class="bar-head pink">Criterion E at ${s.course}</h2></summary><ol class="lv-list" start="0">${E.map(d => `<li>${esc(d)}</li>`).join('')}</ol><p class="tiny muted">${s.course === 'HL' ? 'At HL the top levels need correct mathematics that shows sophistication or rigour.' : 'At SL the top level needs correct, course-level mathematics with thorough understanding.'}</p></details>`;
  }
  function planBind(el, s, n, r) {
    if (r) return;
    const B = () => (n.planB = n.planB || {}), sv = debounce(() => save(n), 600);
    $$('[data-concept]', el).forEach(c => (c.onchange = () => { B().concepts = $$('[data-concept]:checked', el).map(x => x.dataset.concept); save(n, true); Hub.app.render(); }));
    $$('[data-pb]', el).forEach(t => t.addEventListener('input', () => { B()[t.dataset.pb] = t.value.slice(0, 5000); sv(); }));
    $$('[data-pbd]', el).forEach(t => t.addEventListener(t.tagName === 'SELECT' ? 'change' : 'input', () => { B().data = Object.assign({}, B().data, { [t.dataset.pbd]: t.value.slice(0, 3000) }); sv(); }));
    $$('[data-tech]', el).forEach(c => (c.onchange = () => { B().tech = $$('[data-tech]:checked', el).map(x => x.value); sv(); }));
    const OL = () => (B().outline = B().outline || OUTLINE0.map(([h, m, c]) => ({ h, m, c })));
    $$('[data-ol]', el).forEach(i => i.addEventListener('input', () => { OL()[Number(i.dataset.ol)][i.dataset.k] = i.value.slice(0, 300); sv(); }));
    $$('[data-olup]', el).forEach(b => (b.onclick = () => { const i = Number(b.dataset.olup), L = OL(); if (i > 0) { [L[i - 1], L[i]] = [L[i], L[i - 1]]; save(n, true); Hub.app.render(); } }));
    $$('[data-olrm]', el).forEach(b => (b.onclick = () => { OL().splice(Number(b.dataset.olrm), 1); save(n, true); Hub.app.render(); }));
    const add = $('#ol-add', el); if (add) add.onclick = () => { OL().push({ h: '', m: '', c: '' }); save(n, true); Hub.app.render(); };
  }

  /* ================= Stage 5 · Writing ================= */
  function writeStageHTML(s, n, r, teacher) {
    return (Hub.iagdoc ? Hub.iagdoc.panel(s, n, r, teacher) : '') + IA().writeHTML(s, n, r, teacher);
  }
  function writeStageBind(el, s, n, r, teacher) { if (Hub.iagdoc) Hub.iagdoc.bind(el, s, n, r, teacher); IA().bindWrite(el, s, n, r); }

  /* ================= Stage 6 · Criteria review ================= */
  const REF = /this (means|shows|suggests|implies|tells)|however|limitation|reliab|accura|assum|compar|surpris|expected|makes sense|therefore|which suggests|realistic|valid/i;
  function hubChecks(n, course) {
    const w = n.write || {}, nb = IA().bodyCount(n), body = Array.from({ length: nb }, (_, i) => ({ t: w['b' + (i + 1) + 't'] || '', x: w['b' + (i + 1)] || '' }));
    const strip = t => String(t || '').replace(/\$[^$]*\$/g, ' ');
    const intro = [w.why, w.aim, w.rq, w.approach].join(' '), concl = [w.answer, w.meaning, w.limits, w.next].join(' '), bodyText = body.map(b => b.x).join(' '), all = [intro, w.context, w.terms, bodyText, concl].join(' ');
    const A = [], B = [], Cc = [], D = [], E = [], add = (L, ok, t) => L.push({ ok, t });
    add(A, w.aim || w.rq ? 'yes' : 'no', w.aim || w.rq ? 'Your introduction states an aim or research question.' : 'State your aim or research question in the introduction.');
    add(A, body.filter(b => b.x.trim()).length ? (body.every(b => !b.x.trim() || b.t.trim()) ? 'yes' : 'maybe') : 'no', body.some(b => b.x.trim()) ? (body.every(b => !b.x.trim() || b.t.trim()) ? 'Every part of the mathematics has a heading.' : 'Give every part of the mathematics a heading so a reader can find their way.') : 'The mathematics section is still empty.');
    const shared = [...TP().words(concl)].filter(x => x.length > 4 && TP().words((w.aim || '') + ' ' + (w.rq || '')).has(x)).length;
    add(A, !w.answer ? 'no' : shared >= 2 ? 'yes' : 'maybe', !w.answer ? 'Your conclusion does not answer the question yet.' : shared >= 2 ? 'Your conclusion returns to the words of your aim.' : 'Check that your conclusion answers the exact question you asked.');
    add(A, 'maybe', `${IA().writeWords(n)} words written here so far. The IB limit is 12–20 pages (double-spaced, including graphs) — check the page count of your final document.`);
    const raw = strip(all), calc = /\d\s*\*\s*\d|[a-z0-9)]\^|\^\(|sqrt\(|\bpi\b/i.test(raw);
    add(B, calc ? 'no' : 'yes', calc ? 'Calculator-style notation found (*, ^, sqrt(…)). Use real notation: x², √, stacked fractions — the maths keys or an equation editor.' : 'No calculator-style notation found.');
    add(B, /\b(let|where|denote|represents?|stands? for|is defined as|defined as)\b/i.test(all) ? 'yes' : 'maybe', /\b(let|where|denote|represents?|stands? for|defined as)\b/i.test(all) ? 'You define variables (“let…”, “where…”).' : 'Define every variable and its units the first time you use it.');
    add(B, /\[(graph|table|figure|diagram)|\b(figure|graph|table|diagram) \d/i.test(all) ? 'yes' : 'maybe', /\[(graph|table|figure|diagram)|\b(figure|graph|table|diagram) \d/i.test(all) ? 'You refer to labelled graphs or tables.' : 'Most explorations need labelled graphs or tables placed where you discuss them — mark where each goes, e.g. [Graph 1: …].');
    const voice = t => /\b(I|my|me|I'm|I've)\b/.test(t || ''), bodyVoice = body.some(b => voice(b.x));
    add(Cc, voice(intro) && bodyVoice ? 'yes' : voice(intro) ? 'maybe' : 'no', voice(intro) && bodyVoice ? 'Your own voice appears in the introduction and in the mathematics.' : voice(intro) ? 'Your personal connection appears in the introduction but not in the mathematics — show your own decisions and thinking there too.' : 'Nothing yet shows why this exploration is yours.');
    add(Cc, /\bI (predicted|expected|decided|chose|wondered|noticed|tested|measured|collected|designed|realised|realized)\b/i.test(all) ? 'yes' : 'maybe', /\bI (predicted|expected|decided|chose|wondered|noticed|tested|measured|collected|designed|realised|realized)\b/i.test(all) ? 'You describe your own predictions, decisions or data.' : 'Show your own predictions, choices and tests — “I predicted…, so I tested…”.');
    body.forEach((b, i) => { if (b.x.trim()) add(D, REF.test(b.x) ? 'yes' : 'maybe', REF.test(b.x) ? `Part ${i + 1}${b.t ? ' (' + b.t + ')' : ''}: you comment on what the result means.` : `Part ${i + 1}${b.t ? ' (' + b.t + ')' : ''}: add what the result means, whether it makes sense and how reliable it is.`); });
    add(D, w.limits ? 'yes' : 'no', w.limits ? 'Your conclusion discusses strengths and limitations.' : 'Discuss strengths, limitations and assumptions — and how they affect your answer.');
    const maths = TP().mathsFound(bodyText);
    add(E, maths.length ? 'yes' : 'no', maths.length ? `The mathematics section uses ${maths.join(', ')}.` : 'No mathematics is visible in the mathematics section yet.');
    if (course === 'HL') add(E, /differential equation|complex|vector|proof|prove|induction|bayes|maclaurin|integration by parts|implicit|l.h[oô]pital|euler|derive|derivation/i.test(bodyText) ? 'yes' : 'maybe', 'HL: show rigour — derive or justify key results, and use HL mathematics where it fits.');
    add(E, /\b(because|since|therefore|so that|this gives|we (get|obtain)|substitut|differentiat|integrat|rearrang)\b/i.test(bodyText) ? 'yes' : 'maybe', 'Explain each step — why it works, not just what you did.');
    if (/desmos|geogebra|numworks|calculator|excel|spreadsheet|python|sheets/i.test(all)) add(E, 'maybe', 'You use technology: make sure the mathematics behind each result is shown or explained.');
    return { A, B, C: Cc, D, E };
  }
  function reviewHTML(s, n, r, teacher) {
    const R = n.review || {}, ev = R.ev || {}, CR = IA().CRIT, hub = hubChecks(n, s.course), T = (tOf(s).review || {}).crit || {};
    return `<div class="notice">Formative feedback from the Hub’s built-in checks — <b>not an official IB mark and not a prediction</b>. They read the writing in this Hub (not your Google Doc). Miss Badmus marks your IA with the full IB descriptors.</div>
      ${IA().CRIT_KEYS.map(k => { const c = CR[k], lv = IA().levelsOf(k, s.course), cur = (n.self || {})[k]; return `<section class="card rv-crit"><div class="row-between"><h2 class="bar-head ${{ A: 'green', B: 'blue', C: 'amber', D: 'pink', E: 'green' }[k]}">${k} · ${esc(c.name)} <small>/${c.max}</small></h2>${cur !== undefined ? `<span class="pill">My level: ${cur}</span>` : ''}</div>
        <p class="small">${esc(c.means)}</p>
        <div class="rv-grid"><div><span class="key-lab">Levels${k === 'E' ? ' (' + s.course + ')' : ''} — which fits best?</span>${lv.map((d, i) => `<label class="mk-lv ${String(cur) === String(i) ? 'on' : ''}"><input type="radio" name="self-${k}" data-selfl="${k}" value="${i}" ${String(cur) === String(i) ? 'checked' : ''} ${r ? 'disabled' : ''}><b>${i}</b><span>${esc(d)}</span></label>`).join('')}
          <label class="tiny">My evidence — where in my IA does this show? (section, page)<textarea data-ev="${k}" rows="2" ${r ? 'readonly' : ''}>${esc(ev[k] || '')}</textarea></label></div>
          <div><span class="key-lab">Hub formative checks</span><ul class="ia-checks">${hub[k].map(x => `<li class="${x.ok}"><span class="mk">${x.ok === 'yes' ? '✓' : x.ok === 'maybe' ? '◐' : '✗'}</span>${esc(x.t)}</li>`).join('')}</ul>
          ${T[k] ? `<div class="sticky"><b>Miss Badmus:</b> ${esc(T[k])}</div>` : ''}
          ${teacher ? `<label class="tiny">Your formative comment on ${k}<textarea data-tcrit="${k}" rows="2">${esc(T[k] || '')}</textarea></label>` : ''}</div></div></section>`; }).join('')}
      ${teacher ? '<div class="actions"><button class="btn small primary" id="tcrit-save" type="button">Save criterion comments</button></div>' : ''}`;
  }
  function reviewBind(el, s, n, r, teacher) {
    if (teacher) { const b = $('#tcrit-save', el); if (b) b.onclick = () => { const T = tFor(s), rv = T.review = T.review || {}; rv.crit = Object.fromEntries($$('[data-tcrit]', el).map(t => [t.dataset.tcrit, t.value.trim()]).filter(([, v]) => v)); Hub.store.save(true); toast('Criterion comments saved — the student can see them.'); Hub.app.render(); }; }
    if (r) return;
    const R = () => (n.review = n.review || {}), sv = debounce(() => save(n), 600);
    $$('[data-selfl]', el).forEach(x => (x.onchange = () => { n.self = n.self || {}; n.self[x.dataset.selfl] = Number(x.value); $$(`[name="self-${x.dataset.selfl}"]`, el).forEach(y => y.closest('.mk-lv').classList.toggle('on', y.checked)); sv(); }));
    $$('[data-ev]', el).forEach(t => t.addEventListener('input', () => { R().ev = Object.assign({}, R().ev, { [t.dataset.ev]: t.value.slice(0, 2000) }); sv(); }));
  }

  /* ================= Stage 7 · Final check & export ================= */
  const MANUAL = [['pages', 'It is 12–20 pages, double-spaced, including graphs and diagrams (the bibliography is not counted).'], ['contents', 'It has a title page, a contents page and page numbers.'], ['graphs', 'Every graph and table is labelled and sits where I discuss it.'], ['notation', 'Equations are typed with an equation editor — no calculator notation.'], ['names', 'I have followed Miss Badmus’ instructions about names on the work.'], ['ai', 'Any AI tool I was allowed to use is acknowledged, with the prompt and the date.'], ['read', 'I have read the whole exploration once, slowly, as a reader would.']];
  function finalItems(s, n) {
    const a = accessOf(s), cites = Hub.iacite ? Hub.iacite.summary(n) : null, m = IA().markOf(s.id) || {}, w = n.write || {};
    const stagesDone = K().STAGES.filter(st => st.id !== 'final').every(st => isDone(statusOf(s, n, st.id)));
    return [
      ['Stages 1–6 are submitted or approved', stagesDone],
      ['A title and a research question or aim are chosen', !!((n.fields || {}).title && (n.fields || {}).rq)],
      ['Every section of the Write stage has text', !!(w.why && w.aim && w.b1 && w.answer && w.limits)],
      ['References: at least one, all complete and checked', !!(cites && cites.count && !cites.incomplete && !cites.unconfirmed)],
      ['Every reference is cited in the writing', !!(cites && cites.count && !cites.uncited)],
      ['The academic honesty tutorial is done', !!(cites && cites.tutorial)],
      ['Feedback on a full draft received', !!m.fullDraft],
      ['The final version is handed in (Drafts tab)', (n.drafts || []).some(d => d.kind === 'final')]
    ];
  }
  function finalHTML(s, n, r, teacher) {
    const F = n.final || {}, C = F.checks || {}, auto = finalItems(s, n), base = teacher ? `?sid=${encodeURIComponent(s.id)}&` : '?';
    return `<section class="card"><h2 class="bar-head amber">Ready to submit?</h2><span class="key-lab">Checked by the Hub</span><ul class="ia-checks">${auto.map(([t, ok]) => `<li class="${ok ? 'yes' : 'no'}"><span class="mk">${ok ? '✓' : '○'}</span>${esc(t)}</li>`).join('')}</ul>
      <span class="key-lab">Check these yourself</span>${MANUAL.map(([k, t]) => `<label class="inline-check"><input type="checkbox" data-fck="${k}" ${C[k] ? 'checked' : ''} ${r ? 'disabled' : ''}> ${esc(t)}</label>`).join('')}
      <label class="inline-check declare"><input type="checkbox" data-fck="declare" ${C.declare ? 'checked' : ''} ${r ? 'disabled' : ''}> <b>This exploration is my own work. Every source, and any permitted AI use, is acknowledged.</b></label></section>
      <section class="card"><h2 class="bar-head blue">Export a formatted copy</h2><p class="small">Builds a clean copy from what you wrote in the Hub: title page, contents, your sections and your reference list (in ${esc(Hub.iacite ? Hub.iacite.styleName() : 'the class style')}). If you write in Google Docs, your Google Doc is your final document — use this as a check.</p>
      <div class="form-grid"><label>Session on the title page<input data-fin="session" value="${esc(F.session || '')}" placeholder="e.g. May 2028" ${r ? 'readonly' : ''}></label><label class="inline-check"><input type="checkbox" data-finb="nameOff" ${F.nameOff !== false ? 'checked' : ''} ${r ? 'disabled' : ''}> Leave my name off the title page</label></div>
      <div class="actions"><a class="btn small" href="#/iaprint${base}full=1" target="_blank" rel="noopener">🖨 Formatted print / save as PDF</a><button class="btn small" id="fin-doc" type="button">⬇ Download Word copy (.doc)</button></div></section>`;
  }
  function finalBind(el, s, n, r) {
    const dl = $('#fin-doc', el); if (dl) dl.onclick = () => { const html = IA().printDoc(s, n, true); download(((n.fields || {}).title || 'My IA').replace(/[^\w\- ]+/g, '').slice(0, 60) + '.doc', '<html><head><meta charset="utf-8"></head><body>' + html + '</body></html>', 'application/msword'); };
    if (r) return;
    const F = () => (n.final = n.final || {}), sv = debounce(() => save(n), 600);
    $$('[data-fck]', el).forEach(c => (c.onchange = () => { F().checks = Object.assign({}, F().checks, { [c.dataset.fck]: c.checked }); save(n, true); }));
    $$('[data-fin]', el).forEach(t => t.addEventListener('input', () => { F()[t.dataset.fin] = t.value.slice(0, 100); sv(); }));
    $$('[data-finb]', el).forEach(c => (c.onchange = () => { F()[c.dataset.finb] = c.checked; save(n, true); }));
  }

  const BODY = {
    topic: { html: (s, n, r, t) => topicHTML(s, n, r) + cpWrap(s, n, r, t, ['cp1']), bind: (el, s, n, r) => topicBind(el, s, n, r) },
    title: { html: (s, n, r, t) => titleHTML(s, n, r) + cpWrap(s, n, r, t, ['cp2']), bind: (el, s, n, r) => titleBind(el, s, n, r) },
    rq: { html: (s, n, r, t) => rqHTML(s, n, r) + cpWrap(s, n, r, t, ['cp3']), bind: (el, s, n, r) => rqBind(el, s, n, r) },
    plan: { html: (s, n, r, t) => planHTML(s, n, r) + cpWrap(s, n, r, t, ['ws', 'y1']), bind: (el, s, n, r) => planBind(el, s, n, r) },
    write: { html: (s, n, r, t) => writeStageHTML(s, n, r, t) + cpWrap(s, n, r, t, ['cp4', 'cp5', 'cp6']), bind: writeStageBind },
    review: { html: reviewHTML, bind: reviewBind },
    final: { html: finalHTML, bind: finalBind }
  };

  /* ================= My IA journey (the student's dashboard) ================= */
  function journey(el, s, n, ro, teacher) {
    const a = accessOf(s), base = teacher ? `#/ia/${encodeURIComponent(s.id)}` : '#/ia', T = tOf(s);
    const rows = K().STAGES.map(st => ({ st, x: a[st.id], stt: statusOf(s, n, st.id), my: mine(n, st.id), t: T[st.id] }));
    const done = rows.filter(r => isDone(r.stt)).length, visible = rows.filter(r => teacher || !(r.x.state === 'locked' && r.x.show === false));
    const fresh = rows.filter(r => !teacher && r.x.state === 'open' && !(n.seen || {})[r.st.id]);
    const next = rows.find(r => r.x.state === 'open' && !isDone(r.stt)) || rows.find(r => r.x.state === 'open' && r.stt === 'returned');
    const upcoming = rows.filter(r => r.x.state === 'locked' && r.x.why === 'scheduled' && r.x.releaseAt && r.x.show !== false).sort((p, q) => p.x.releaseAt < q.x.releaseAt ? -1 : 1)[0];
    const sch = Hub.curriculum.iaSchedule(s.group), asOf = Hub.mastery.asOf(), cites = Hub.iacite ? Hub.iacite.summary(n) : null, g = n.gdoc || {};
    const fb = rows.filter(r => r.t && r.t.text).map(r => ({ at: r.t.at, who: `Stage ${r.st.n}`, text: r.t.text, st: r.t.state })).concat(Object.entries(n.feedback || {}).map(([k, f]) => ({ at: f.at, who: (sch.find(x => x.id === k) || {}).short || k, text: f.text }))).sort((p, q) => (q.at || '') < (p.at || '') ? -1 : 1).slice(0, 4);
    el.innerHTML = `${fresh.length ? `<div class="notice new-stage">🔓 <b>New:</b> ${fresh.map(r => `<a href="${base}?tab=s-${r.st.id}">Stage ${r.st.n} · ${esc(r.st.title)}</a>`).join(', ')} ${fresh.length > 1 ? 'are' : 'is'} now open.</div>` : ''}
      <div class="grid g2"><section class="card"><h2 class="bar-head amber">Progress</h2><div class="ia-prog"><div class="bar"><span style="width:${Math.round(100 * done / 7)}%"></span></div><b>${done} of 7 stages</b> submitted or approved</div>
        <p class="small">${next ? `<b>Next step:</b> <a href="${base}?tab=s-${next.st.id}">Stage ${next.st.n} · ${esc(next.st.title)}</a> — ${esc(INFO[next.st.id].next)}${next.x.due ? ` <span class="pill amber">due ${when(next.x.due)}</span>` : ''}` : upcoming ? `Nothing to do right now. <b>Stage ${upcoming.st.n}</b> opens ${when(upcoming.x.releaseAt)}.` : 'Nothing is open right now — Miss Badmus will open the next stage.'}</p></section>
      <section class="card"><h2 class="bar-head blue">Latest feedback</h2>${fb.length ? fb.map(f => `<div class="log-i"><span class="tiny muted">${esc(f.who)} · ${when(f.at)}</span><p class="small">${f.st === 'approved' ? '✓ ' : f.st === 'returned' ? '↩ ' : ''}${esc(f.text)}</p></div>`).join('') : '<p class="muted small">Feedback from Miss Badmus appears here.</p>'}</section></div>
      <section class="card"><h2 class="bar-head green">My timeline</h2><ol class="ia-tl">${visible.map(r => `<li class="${r.x.state} st-${r.stt}"><span class="tl-dot">${r.x.state === 'locked' ? '🔒' : isDone(r.stt) ? '✓' : r.st.n}</span><div><a href="${base}?tab=s-${r.st.id}"><b>Stage ${r.st.n} · ${esc(r.x.show === false && r.x.state === 'locked' && !teacher ? 'Coming later' : r.st.title)}</b></a> <span class="pill ${PILL[r.stt]}">${LABEL[r.stt]}</span>${r.x.state === 'view' ? ' <span class="pill grey">view only</span>' : ''}
        <div class="tiny muted">${r.x.state === 'locked' ? esc(lockText(r.x, true)) : ''}${r.x.due ? ` Deadline ${when(r.x.due)}.` : ''}${r.my.target ? ` My target ${fmtDate(r.my.target)}.` : ''}${r.my.at ? ` Submitted ${when(r.my.at)}.` : ''}</div>${r.t && r.t.text ? `<div class="tiny">💬 ${esc(r.t.text)}</div>` : ''}</div></li>`).join('')}</ol></section>
      <div class="grid g2"><section class="card"><h2 class="bar-head pink">References & document</h2>${cites ? `<p class="small"><a href="${base}?tab=refs">${cites.count} reference${cites.count === 1 ? '' : 's'}</a>${cites.flags ? ` · <span class="pill amber">${cites.flags} to fix</span>` : cites.count ? ' · ✓ no problems found' : ''}${cites.tutorial ? ' · academic honesty tutorial done' : ''}</p>` : ''}
        <p class="small">${g.url ? `Google Doc: <a href="${esc(g.url)}" target="_blank" rel="noopener">open ↗</a>${g.check ? ` · last checked ${when(g.check.at)} (${g.check.words} words)` : ''}` : 'No Google Doc linked yet — that happens in the Writing stage.'}</p></section>
        <section class="card"><h2 class="bar-head amber">Class checkpoints</h2><ul class="tiny cp-list">${sch.map(x => `<li class="${x.date && x.date < asOf ? 'past' : ''}">${esc(x.short)} — ${x.date ? fmtDate(x.date) : 'date tbc'} <span class="pill ${{ 'signed-off': 'green', submitted: 'blue', 'in-progress': 'amber' }[(n.status || {})[x.id]] || 'grey'}">${((n.status || {})[x.id] || 'not started').replace('-', ' ')}</span></li>`).join('')}</ul></section></div>
      <div class="grid g2"><section class="card"><h2 class="bar-head green">Reflection log</h2>${(n.log || []).slice().reverse().slice(0, 8).map(l => `<div class="log-i"><span class="tiny muted">${fmtDateTime(l.at)}</span><p>${esc(l.text)}</p></div>`).join('') || '<p class="muted small">Reflections feed criterion D — note what you tried, what changed and why.</p>'}${ro ? '' : '<form id="log-form"><label>New entry<textarea id="log-t" rows="2" placeholder="Today I…, which changed my plan because…"></textarea></label><button class="btn small">Add reflection</button></form>'}</section>
        <section class="card"><h2 class="bar-head blue">Saved versions</h2>${(n.versions || []).length ? n.versions.slice().reverse().slice(0, 10).map((v, i) => `<div class="row-between small"><span>${fmtDateTime(v.at)}${v.label ? ' · ' + esc(v.label) : ''}</span>${ro ? '' : `<button class="btn small ghost" data-restore="${n.versions.length - 1 - i}" type="button">Restore</button>`}</div>`).join('') : '<p class="tiny muted">A version is kept every time you submit, and every 10 minutes while you write.</p>'}<p class="tiny muted" id="ia-saved">${n.updatedAt ? 'Saved ' + fmtDateTime(n.updatedAt) : ''}</p></section></div>`;
    if (ro) return;
    const lf = $('#log-form', el); if (lf) lf.onsubmit = e => { e.preventDefault(); const t = $('#log-t', el).value.trim(); if (!t) return; n.log = n.log || []; n.log.push({ at: now(), text: t.slice(0, 3000) }); save(n, true); Hub.app.render(); };
    $$('[data-restore]', el).forEach(b => (b.onclick = async () => {
      const v = n.versions[Number(b.dataset.restore)]; if (!(await U.confirmBox(`Restore your writing from ${fmtDateTime(v.at)}? Only stages that are open now are restored, and your current text is kept as a version first.`, 'Restore'))) return;
      const acc = accessOf(s), open = id => acc[id] && acc[id].state === 'open'; IA().snapshot(n, 'Before restore');
      const vf = v.fields || {}; for (const k of new Set([...Object.keys(n.fields || {}), ...Object.keys(vf)])) { const id = K().stageOf('fields', k); if (id && !open(id)) continue; if (k in vf) n.fields[k] = vf[k]; else delete n.fields[k]; }
      if (v.write && open('write')) n.write = clone(v.write); save(n, true); toast('Restored.'); Hub.app.render();
    }));
  }

  /** Auto-refresh when a scheduled stage is due to open while the page is open. */
  let refreshTimer = null;
  function watch() { clearTimeout(refreshTimer); const t = S() && S().iaNext ? Date.parse(S().iaNext) - Date.now() : null; if (t !== null && t > 0 && t < 12 * 3600e3) refreshTimer = setTimeout(() => Hub.store.refresh().then(() => { Hub.app.render(); toast('A new IA stage has opened.'); }).catch(() => {}), t + 5000); }
  /** For the student home page: newly opened stages. */
  function newStages(s) { const n = (S().ia || {})[s.id] || {}, a = accessOf(s); return K().STAGES.filter(st => a[st.id] && a[st.id].state === 'open' && !(n.seen || {})[st.id]); }

  Hub.iastages = { stepper, stage, journey, statusOf, accessOf, hasWork, LABEL, PILL, INFO, hubChecks, watch, newStages, isDone };
})(window.Hub = window.Hub || {});
