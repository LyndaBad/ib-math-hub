/* Student views: My day, Do Now, tasks (with upload), results, practice, progress.
   When Miss Badmus previews as a student, every submission is a preview and is never stored. */
(function (Hub) {
  'use strict';
  const { esc, $, $$, fmtDate, fmtDateTime, toast, uid, debounce, daysBetween } = Hub.core;
  const U = Hub.ui, C = () => Hub.curriculum, S = () => Hub.store.state, M = t => Hub.math.render(t);
  const me = () => Hub.roster.byId(Hub.auth.sid());
  const go = h => Hub.app.nav(h);

  function home(main) {
    Hub.donow.relabel();
    const s = me(); if (!s) { main.innerHTML = U.empty('Your account is not on a class roster.'); return; }
    const asOf = Hub.mastery.asOf(), nl = C().nextLesson(s.group, asOf), dn = Hub.donow.forStudent(s.id);
    const tasks = Hub.assess.forStudent(s.id).map(a => ({ a, t: Hub.assess.attemptsFor(a.id, s.id).pop() }));
    const todo = tasks.filter(x => !x.t), returned = S().attempts.filter(t => t.sid === s.id && t.status === 'released').slice().reverse().slice(0, 4);
    const stats = Hub.mastery.studentSkills(s.id).filter(x => x.taught && x.pct !== null).sort((a, b) => a.pct - b.pct);
    const ia = C().iaSchedule(s.group).find(x => x.date && x.date >= asOf), hour = new Date().getHours();
    main.innerHTML = `<section class="hero"><div><p class="kicker">${C().GROUPS[s.group].label.toUpperCase()} · ${fmtDate(asOf, true).toUpperCase()}</p><h1>${hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'}, ${esc(s.name.split(' ')[0])}.</h1><p class="lead">Inquirers. Thinkers. Reflective Learners.</p>${nl ? `<p class="next-pill">Next lesson · <b>${fmtDate(nl.date, true)}</b> · ${esc(nl.activity)}</p>` : ''}</div><img class="hero-wolf" src="${Hub.LOGO}" alt="Miss Badmus’ IB wolf logo"></section>
      <div class="grid g2">
        <section class="card donow-card"><h2 class="bar-head amber">☀ ${dn && dn.kind !== 'Do Now' ? 'Your personalised ' + esc(dn.kind) : 'Today’s Do Now'}</h2>${dn ? (dn.done ? `<p>Done — <b>${Hub.assess.score(dn.done).earned}/${dn.done.max}</b>.</p><a class="btn small" href="#/result/${dn.done.id}">See feedback</a>` : `<p>${dn.items.filter(it => it.question).length} questions picked just for you${dn.kind === 'Do Now' ? ' for ' + fmtDate(dn.rec.lessonDate, true) : ''}.</p><a class="btn primary" href="#/donow">Start my ${esc(dn.kind === 'Do Now' ? 'Do Now' : dn.kind)} →</a>`) : '<p>Your personalised Do Now, Exit Ticket or quiz appears here once Miss Badmus publishes it.</p>'}</section>
        ${(L => L ? `<section class="card"><h2 class="bar-head blue">▣ Lesson notebook</h2><p><b>${esc(L.title)}</b></p><a class="btn primary" href="#/notebook/${encodeURIComponent(L.id)}">Open today’s notebook →</a></section>` : '')(Hub.lessons && Hub.lessons.latestFor(s))}
        <section class="card"><h2 class="bar-head green">To do</h2>${todo.length ? todo.map(({ a }) => `<div class="todo"><div><b>${esc(a.title)}</b><div class="tiny muted">${a.type} · ${a.questions.length} question${a.questions.length > 1 ? 's' : ''} · about ${a.minutes} min${Hub.assess.dueFor(a, s.group) ? ` · due ${fmtDate(Hub.assess.dueFor(a, s.group))}` : ''}${a.uploadRequired ? ' · 📷 upload your working' : ''}</div></div><a class="btn small" href="#/task/${a.id}">Start →</a></div>`).join('') : '<p>Nothing to do right now. 🎉</p>'}</section>
        <section class="card"><h2 class="bar-head blue">Feedback</h2>${returned.length ? returned.map(t => `<div class="todo"><div><b>${esc(t.inline ? t.inline.title : (Hub.assess.byId(t.aid) || {}).title || t.type)}</b><div class="tiny muted">${fmtDate(t.date)} · ${Hub.assess.score(t).earned}/${t.max}${t.comment ? ' · 💬 comment from Miss Badmus' : ''}</div></div><a class="btn small ghost" href="#/result/${t.id}">Open</a></div>`).join('') : '<p>Marked work will appear here.</p>'}${tasks.filter(x => x.t && x.t.status === 'submitted').map(({ a, t }) => `<div class="todo"><div><b>${esc(a.title)}</b><div class="tiny muted">Submitted ${fmtDateTime(t.at)} · waiting for Miss Badmus</div></div><a class="btn small ghost" href="#/result/${t.id}">View</a></div>`).join('')}</section>
        <section class="card wtw"><h2 class="bar-head pink">What to work on</h2>${(() => {
          const weak = stats.filter(x => x.status !== 'low-evidence' && x.pct < 80).slice(0, 4), show = weak.length ? weak : stats.slice(0, 2);
          const since = Hub.core.addDays(asOf, -56), mis = {};
          S().attempts.filter(t => t.sid === s.id && t.status === 'released' && String(t.date || t.at || '').slice(0, 10) >= since && t.auto && t.auto.parts).forEach(t => {
            const qs = (t.inline || Hub.assess.byId(t.aid) || {}).questions || [];
            Object.entries(t.auto.parts).forEach(([k, r]) => { if (!r || !r.tag || r.verdict === 'correct') return; const q = qs.find(x => x.id === k.split('|')[0]); const key = r.tag + '|' + (q ? q.skill : '');
              mis[key] = mis[key] || { tag: r.tag, skill: q ? q.skill : null, fb: r.feedback || '', n: 0 }; mis[key].n++; if (!mis[key].fb && r.feedback) mis[key].fb = r.feedback; }); });
          const watch = Object.values(mis).sort((a, b) => b.n - a.n).slice(0, 3);
          if (!show.length && !watch.length) return '<p>Complete some work to see your next steps.</p>';
          return (show.length ? `<p class="small"><b>Skills to strengthen</b></p>${show.map(x => `<div class="skill-row"><span>${U.skillLabel(x.skill)}</span>${U.statusChip(x)}<a class="btn small ghost" href="#/practice?skill=${x.skill}">Practise</a></div>`).join('')}` : '') +
            (watch.length ? `<p class="small wtw-h"><b>Mistakes to watch out for</b></p>${watch.map(m => `<div class="wtw-mis"><b>${esc(Hub.mastery.tagText(m.tag))}</b>${m.n > 1 ? ` <span class="tiny muted">× ${m.n}</span>` : ''}${m.fb ? `<p class="small">${esc(m.fb)}</p>` : ''}${m.skill ? `<a class="btn small ghost" href="#/practice?skill=${m.skill}">Practise ${esc(U.skillName(m.skill))}</a>` : ''}</div>`).join('')}` : '');
        })()}${ia ? `<p class="tiny gc-ia">IA · <b>${esc(ia.short)}</b> due ${fmtDate(ia.date)} (${daysBetween(asOf, ia.date)} days) — <a href="#/ia">open my IA studio</a></p>` : ''}${(ns => ns.length ? `<p class="small ia-new">🔓 <b>New in your IA Studio:</b> ${ns.map(st => `<a href="#/ia?tab=s-${st.id}">Stage ${st.n} · ${esc(st.title)}</a>`).join(', ')}</p>` : '')(Hub.iastages ? Hub.iastages.newStages(s) : [])}</section>
      </div>`;
  }

  /* ---------- taking work ---------- */
  function renderTake(main, a, opts) {
    const s = me(), key = a.id, prog = opts.preview ? null : Hub.assess.getProgress(s ? s.id : 'x', key) || {};
    const responses = (prog && prog.responses) || {}, uploads = (prog && prog.uploads) || [];
    const token = uid('tok');
    main.innerHTML = (opts.back || `<a class="back" href="#/home">← My day</a>`) + U.heading(`${a.type.toUpperCase()}${a.course ? ' · AA ' + a.course : ''}`, esc(a.title), `${a.questions.length} question${a.questions.length > 1 ? 's' : ''} · ${a.questions.reduce((x, q) => x + q.marks, 0)} marks${a.minutes ? ` · about ${a.minutes} minutes` : ''}${Hub.assess.dueFor(a, s ? s.group : null) ? ` · due ${fmtDate(Hub.assess.dueFor(a, s ? s.group : null))}` : ''}`) +
      (opts.preview ? '<div class="notice preview">Preview — nothing you enter here is saved or marked into anyone’s record.</div>' : '') +
      `<form id="take" novalidate>${a.questions.map((q, i) => U.question(q, i, { mode: 'answer', responses, hints: opts.hints, slot: opts.slots ? opts.slots[i] : '' })).join('')}
      ${a.uploadRequired || opts.allowUpload ? `<section class="card upload-card"><h2 class="bar-head amber">📷 Upload your working ${a.uploadRequired ? '<span class="pill red">required · 0 marks</span>' : '<span class="pill">optional</span>'}</h2><p class="small">Take a clear photo of every page (all questions). On a Chromebook use the camera or choose a file. No upload means you cannot submit.</p><label class="file-btn btn"><input type="file" id="up" accept="image/*,application/pdf" multiple capture="environment"> Add photo or PDF</label><ul id="up-list" class="up-list"></ul></section>` : ''}
      ${a.type === 'Retest' ? `<label class="inline-check proof"><input type="checkbox" id="proof"> I have done my retest preparation (proof of studying) and understand a retest is capped at ${a.cap || 80}%.</label>` : ''}
      ${opts.reflect !== false ? `<label>Reflection — what will you check next time? <span class="tiny muted">(optional)</span><textarea id="reflection" rows="2">${esc((prog && prog.reflection) || '')}</textarea></label>` : ''}
      <div class="actions sticky-actions"><button class="btn primary" id="submit" type="submit">Submit</button><span id="autosave" class="tiny muted">${prog && prog.updatedAt ? 'Answers saved ' + fmtDateTime(prog.updatedAt) : 'Your answers save as you type.'}</span></div></form>`;
    // Paper 1 work (no calculator): hide the NumWorks panel. Practice keeps it.
    if (Hub.calc && a.type !== 'Practice' && a.questions.length && a.questions.every(q => q.paper === 1)) Hub.calc.setAllowed(false);
    const form = $('#take'); let ups = uploads.slice(); const hints = {};
    const listUps = () => { const ul = $('#up-list'); if (ul) ul.innerHTML = ups.map((u, i) => `<li>📄 ${esc(u.name)} <span class="tiny muted">${Math.round(u.size / 1024)} KB</span> <button type="button" class="btn small ghost" data-rmup="${i}">Remove</button></li>`).join(''); $$('[data-rmup]').forEach(b => (b.onclick = () => { ups.splice(Number(b.dataset.rmup), 1); listUps(); persist(); })); };
    const persist = () => { if (opts.preview || !s || opts.noProgress) return; Hub.assess.saveProgress(s.id, key, { responses: U.readResponses(form, a.questions), uploads: ups, reflection: $('#reflection') ? $('#reflection').value : '' }); const el = $('#autosave'); if (el) el.textContent = 'Saving answers to cloud…'; };
    U.bindPreviews(form, persist); listUps();
    $$('details.hint', form).forEach(d => d.addEventListener('toggle', () => { if (d.open) hints[d.dataset.hint] = true; }));
    const up = $('#up'); if (up) up.onchange = async () => { for (const f of up.files) { try { const meta = await Hub.uploads.add(f); ups.push(meta); toast('Added ' + f.name); } catch (e) { toast(e.message, 'error'); } } up.value = ''; listUps(); persist(); };
    let busy = false;
    form.onsubmit = async e => {
      e.preventDefault(); if (busy) return;
      const responses = U.readResponses(form, a.questions);
      const blanks = a.questions.reduce((n, q) => n + q.parts.filter(p => p.answer.kind !== 'open' && [].concat(responses[q.id][p.id]).every(v => v === '' || v === undefined)).length, 0);
      const bad = []; a.questions.forEach((q, i) => q.parts.forEach(p => { if (['num', 'tuple', 'list'].includes(p.answer.kind)) [].concat(responses[q.id][p.id]).forEach(v => { if (v && String(v).trim() && Hub.math.parse(v).error) bad.push(`Q${i + 1}(${p.label})`); }); }));
      if (bad.length) return toast(`I can’t read your answer in ${bad.join(', ')}. Use numbers, fractions like 3/4, sqrt( ) or pi.`, 'error');
      if (a.uploadRequired && !ups.length && !opts.preview) return toast('Upload a photo of your working before submitting.', 'error');
      if (a.type === 'Retest' && !opts.preview && !($('#proof') && $('#proof').checked)) return toast('Tick the proof-of-studying box first.', 'error');
      if (!(await U.confirmBox(`${blanks ? `<b>${blanks} answer${blanks > 1 ? 's are' : ' is'} blank.</b> ` : ''}Submit now? You can’t change your answers afterwards.`, 'Submit'))) return;
      busy = true; $('#submit').disabled = true; $('#submit').textContent = 'Submitting…';
      let r; try { r = await opts.submit({ responses, uploads: ups, reflection: $('#reflection') ? $('#reflection').value : '', proof: $('#proof') ? $('#proof').checked : false, token, hints }); } catch(e) { r={ok:false,error:e.message}; }
      if (!r.ok) { busy = false; $('#submit').disabled = false; $('#submit').textContent = 'Submit'; return toast(r.error, 'error'); }
      if (r.preview) { showResult(main, r.attempt, a, { preview: true, back: opts.back }); return; }
      toast(r.attempt.status === 'released' ? 'Submitted and marked.' : 'Submitted — Miss Badmus will release your marks.'); go('#/result/' + r.attempt.id);
    };
  }
  function task(main, params) {
    const s = me(), a = Hub.assess.byId(params.id);
    if (!a || !s || !Hub.assess.forStudent(s.id).some(x => x.id === a.id)) { main.innerHTML = U.empty('This task is not available to you.', '<a class="btn" href="#/home">Back to My day</a>'); return; }
    const prev = Hub.assess.attemptsFor(a.id, s.id).pop(); if (prev) { go('#/result/' + prev.id); return; }
    renderTake(main, a, { submit: d => Hub.assess.submit(a.id, s.id, d), preview: Hub.auth.isPreview() });
  }
  function donow(main) {
    const s = me(), d = s && Hub.donow.forStudent(s.id);
    if (!d) { main.innerHTML = U.heading('JUST FOR YOU', 'Personalised task') + U.empty('Nothing is open yet. Your personalised Do Now, Exit Ticket or quiz appears here once Miss Badmus publishes it.'); return; }
    if (d.done) { go('#/result/' + d.done.id); return; }
    const slotNames = d.items.filter(it => it.question).map(it => Hub.donow.slotLabel(it.slot));
    renderTake(main, Object.assign({}, d.assessment, { type: d.kind || 'Do Now', minutes: d.kind === 'Quiz' ? 15 : d.kind === 'Exit Ticket' ? 6 : 8 }), { submit: x => Hub.donow.submit(s.id, x.responses, x.token), preview: Hub.auth.isPreview(), slots: slotNames, reflect: false, noProgress: false });
    const why = document.createElement('details'); why.className = 'card why'; why.innerHTML = `<summary>Why these questions?</summary><ol class="small">${d.items.map(it => `<li><b>${esc(Hub.donow.slotLabel(it.slot))}</b> — ${esc(it.reason)}</li>`).join('')}</ol>`;
    main.querySelector('.page-head').after(why);
  }
  function result(main, params) {
    Hub.donow.relabel();
    const t = S().attempts.find(x => x.id === params.id), s = me();
    if (!t || !s || t.sid !== s.id) { main.innerHTML = U.empty('Not found.'); return; }
    const a = t.inline ? { title: t.inline.title, type: t.inline.type, questions: t.inline.questions } : Hub.assess.byId(t.aid);
    showResult(main, t, a, {});
  }
  function showResult(main, t, a, opts) {
    const released = t.status === 'released', sc = Hub.assess.score(t), aa = Hub.assess.byId(t.aid);
    main.innerHTML = (opts.back || `<a class="back" href="#/home">← My day</a>`) + U.heading('REFLECT & GROW', esc(a.title), released ? `You scored <b>${sc.earned}/${sc.max}</b> (${sc.pct}%)${aa && aa.cap ? ` · recorded as ${sc.capped}% (retest cap ${aa.cap}%)` : ''}` : 'Submitted. Typed answers are checked; Miss Badmus is reviewing your working and will release your marks.') +
      (opts.preview ? '<div class="notice preview">Preview result — not saved.</div>' : '') + (t.comment ? `<div class="sticky big"><b>Miss Badmus:</b> ${esc(t.comment)}</div>` : '') +
      a.questions.map((q, i) => U.question(q, i, { mode: 'feedback', responses: t.responses, results: t.auto.parts, final: t.final ? t.final.parts : null, released: released || !!opts.preview })).join('') +
      (released || opts.preview ? `<div class="card"><h2 class="bar-head green">Keep going</h2><p>Practise the skills from this task:</p><div class="chips">${[...new Set(a.questions.map(q => q.skill))].map(k => `<a class="chip-link" href="#/practice?skill=${k}">${U.skillChip(k)}</a>`).join('')}</div></div>` : '');
  }
  function previewAssessment(a, main) { main = main || $('#main'); renderTake(main, a, { submit: d => Hub.assess.submit(a.id, 'preview', d, { preview: true }), preview: true, back: `<div class="row-between no-print"><a class="back" href="#/edit/${a.id}">← Back to the editor</a><a class="btn small ghost" href="#/print/${a.id}">🖨 Print worksheet</a></div>`, allowUpload: false }); window.scrollTo(0, 0); }

  /* ---------- practice ---------- */
  function practice(main, params) {
    const s = me(); if (!s) return; const asOf = Hub.mastery.asOf();
    if (params.skill) return practiseOne(main, s, params.skill);
    const stats = Hub.mastery.studentSkills(s.id), taught = stats.filter(x => x.taught), rec = taught.filter(x => x.pct !== null).sort((a, b) => a.pct - b.pct).slice(0, 3);
    main.innerHTML = U.heading('INDEPENDENT LEARNING', 'Practice', 'Original IB-style questions with hints, NumWorks screens and worked solutions. Practice counts a little towards mastery (less if you use hints).') +
      (rec.length ? `<section class="card"><h2 class="bar-head pink">Recommended for you</h2><div class="grid g3">${rec.map(x => `<a class="rec" href="#/practice?skill=${x.skill}">${U.skillChip(x.skill)}<span>${U.statusChip(x)}</span></a>`).join('')}</div></section>` : '') +
      C().UNITS[s.course].filter(([u]) => stats.some(x => C().SKILL[x.skill].unit === u)).map(([u, name]) => `<section class="card"><h3 class="unit-h ${U.unitColour(u)}">Unit ${u} · ${esc(name)}</h3>${stats.filter(x => C().SKILL[x.skill].unit === u).map(x => `<div class="skill-row"><span>${U.skillLabel(x.skill)}</span>${U.statusChip(x)}<a class="btn small ${x.taught ? '' : 'ghost'}" href="#/practice?skill=${x.skill}">${x.taught ? 'Practise' : 'Preview'}</a></div>`).join('')}</section>`).join('');
  }
  async function practiseOne(main, s, skill) {
    if (!Hub.auth.isPreview()) {
      main.innerHTML=U.empty('Preparing your practice…');
      try {const r=await Hub.cloud.call('practice',{skill});
        renderTake(main,r.assessment,{submit:d=>Hub.live.submit(r.assessment.id,d,'practice'),preview:false,hints:true,reflect:false,noProgress:true,back:'<a class="back" href="#/practice">← Practice</a>'});
      } catch(e){main.innerHTML=U.empty(esc(e.message));} return;
    }
    const sk = C().SKILL[skill]; if (!sk || sk.course !== s.course) { main.innerHTML = U.empty('Skill not found.'); return; }
    const gen = sk.gens[Math.floor(Math.random() * sk.gens.length)], q = Hub.qcore.build(gen, Math.floor(Math.random() * 1e6) + 1, {});
    q.parts = q.parts.filter(p => p.answer.kind !== 'open'); q.marks = q.parts.reduce((x, p) => x + p.marks, 0);
    q.preview = !C().isTaught(skill, s.group, Hub.mastery.asOf());
    const a = { id: 'practice-' + skill, title: (sk.ox ? sk.ox + ' ' : '') + sk.name + ' · Practice', type: 'Practice', course: s.course, release: 'auto', questions: [q] };
    renderTake(main, a, { submit: d => Hub.assess.submit(a.id, s.id, d, { assessment: a }), preview: Hub.auth.isPreview(), hints: true, reflect: false, noProgress: true, back: `<a class="back" href="#/practice">← Practice</a>` });
  }

  /* ---------- progress ---------- */
  function progress(main) {
    Hub.donow.relabel();
    const s = me(); if (!s) return; const stats = Hub.mastery.studentSkills(s.id), atts = S().attempts.filter(t => t.sid === s.id).slice().reverse();
    main.innerHTML = U.heading('UNDERSTANDING OVER TIME', 'My progress', `Overall ${Hub.mastery.overall(s.id) ?? '—'}% across the skills you have been taught. Recent work counts more than old work.`) +
      `<div class="legend">${['revisit', 'developing', 'secure', 'low-evidence', 'not-taught'].map(k => `<span class="st ${Hub.mastery.STATUS[k].cls}">${Hub.mastery.STATUS[k].short}</span> ${Hub.mastery.STATUS[k].label}`).join(' ')}</div>
      <div class="grid g2"><section class="card">${C().UNITS[s.course].filter(([u]) => stats.some(x => C().SKILL[x.skill].unit === u && x.status !== 'not-taught')).map(([u, name]) => `<h3 class="unit-h ${U.unitColour(u)}">Unit ${u} · ${esc(name)}</h3>${stats.filter(x => C().SKILL[x.skill].unit === u).map(x => `<div class="skill-row"><span>${U.skillLabel(x.skill)}</span>${U.statusChip(x)}${x.pct !== null ? U.bar(x.pct, x.pct < 60 ? 'low' : '') : '<span class="tiny muted">' + (x.status === 'not-taught' ? 'coming up' : 'no evidence yet') + '</span>'}</div>`).join('')}`).join('')}</section>
      <section class="card"><h2 class="bar-head blue">My work</h2>${atts.length ? atts.map(t => `<div class="todo"><div><b>${esc(t.inline ? t.inline.title : (Hub.assess.byId(t.aid) || {}).title || t.type)}</b><div class="tiny muted">${fmtDate(t.date)} · ${t.status === 'released' ? Hub.assess.score(t).earned + '/' + t.max : 'waiting for marking'}</div></div><a class="btn small ghost" href="#/result/${t.id}">Open</a></div>`).join('') : '<p>Nothing yet.</p>'}</section></div>`;
  }
  Hub.student = { home, task, donow, result, practice, progress, previewAssessment, renderTake };
})(window.Hub = window.Hub || {});
