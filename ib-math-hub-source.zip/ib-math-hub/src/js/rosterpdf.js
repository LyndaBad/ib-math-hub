/* Roster import from a PDF (e.g. a class roster printed from the student information system).
   The PDF is read in the browser only (nothing is uploaded). Names and school emails are picked out of each line,
   "Last, First M" becomes "First Last", and the group (SL/HL, A/B day) is detected from the page text when it is printed
   there. The result goes into the normal review box, where Miss Badmus checks it before anything is saved. */
(function (Hub) {
  'use strict';
  const PDFJS = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
  const WORKER = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  let loading = null;
  function load() {
    if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
    return loading || (loading = new Promise((res, rej) => {
      const s = document.createElement('script'); s.src = PDFJS; s.async = true;
      s.onload = () => { window.pdfjsLib.GlobalWorkerOptions.workerSrc = WORKER; res(window.pdfjsLib); };
      s.onerror = () => { loading = null; rej(new Error('Could not open the PDF reader. Check your internet connection, or save the roster as CSV.')); };
      document.head.appendChild(s);
    }));
  }
  /** Text of the PDF as lines (cells separated by tabs when there is a wide gap). */
  async function lines(file) {
    const lib = await load();
    const doc = await lib.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise, out = [];
    for (let i = 1; i <= doc.numPages; i++) {
      const tc = await (await doc.getPage(i)).getTextContent(), rows = {};
      tc.items.forEach(it => { if (!it.str || !it.str.trim()) return; const y = Math.round(it.transform[5] / 3); (rows[y] = rows[y] || []).push({ x: it.transform[4], s: it.str, w: it.width || 0 }); });
      Object.keys(rows).map(Number).sort((a, b) => b - a).forEach(y => {
        let line = '', end = null;
        rows[y].sort((a, b) => a.x - b.x).forEach(c => { if (end !== null) line += c.x - end > 12 ? '\t' : c.x - end > 1 ? ' ' : ''; line += c.s; end = c.x + c.w; });
        out.push(line);
      });
    }
    return out;
  }
  const EMAIL = /[A-Za-z0-9._%+'-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/;
  const HEADER = /^(student|students|name|names|teacher|course|period|block|room|grade|page|total|school|section|term|semester|report|roster|date|id|gender|email|class|day|printed|enrolled|counselor)\b/i;
  const PART = "(?:[A-Z][A-Za-z'’\\-]+|de|la|le|del|della|der|den|van|von|da|di|du|dos|das|bin|al|el|st\\.?)";
  const LASTFIRST = new RegExp(`^([A-Z][A-Za-z'’\\-]+(?:[ -]${PART})*),\\s*([A-Z][A-Za-z'’.\\-]*(?:\\s+[A-Z][A-Za-z'’.\\-]*)*)$`);
  const FIRSTLAST = /^[A-Z][A-Za-z'’\-]+(?:\s+[A-Z][A-Za-z'’.\-]*){1,3}$/;
  /** "Ainumpudi, Taneesh" → "Taneesh Ainumpudi"; middle initials are dropped. */
  function niceName(cell) {
    const m = cell.match(LASTFIRST);
    if (m) { const given = m[2].split(/\s+/).filter(w => w.replace(/\./g, '').length > 1); return (given.length ? given.join(' ') + ' ' : '') + m[1]; }
    return cell.split(/\s+/).filter((w, i, a) => i === 0 || i === a.length - 1 || w.replace(/\./g, '').length > 1).join(' ');
  }
  function detectGroup(text) {
    const t = ' ' + text + ' ';
    const course = /\bHL\b|Higher Level|Block\s*4\b/i.test(t) ? 'HL' : /\bSL\b|Standard Level|Block\s*1\b/i.test(t) ? 'SL' : '';
    const day = /\bA[\s-]?Day\b|\bDay\s*A\b/i.test(t) ? 'A' : /\bB[\s-]?Day\b|\bDay\s*B\b/i.test(t) ? 'B' : '';
    return course && day ? course + '-' + day : '';
  }
  /** Turn PDF lines into roster rows. group: a chosen group, or '' to use the one printed in the PDF. */
  function parse(textLines, group) {
    const detected = detectGroup(textLines.join(' ')), g = group || detected, rows = [], seen = new Set();
    for (const raw of textLines) {
      const email = (raw.match(EMAIL) || [''])[0].toLowerCase();
      const cells = raw.replace(EMAIL, '\t').split(/\t+/).map(c => c.replace(/\s+/g, ' ').trim()).filter(Boolean);
      const cell = cells.find(c => !/\d/.test(c) && !HEADER.test(c) && (LASTFIRST.test(c) || (FIRSTLAST.test(c) && c.split(' ').length <= 4)));
      if (!cell) continue;
      const name = niceName(cell), key = email || name.toLowerCase();
      if (seen.has(key)) continue; seen.add(key);
      rows.push({ name, email, group: g });
    }
    const csv = ['name,email,group'].concat(rows.map(r => `"${r.name.replace(/"/g, '""')}",${r.email},${r.group}`)).join('\n');
    return { rows, csv, detected, group: g, withEmail: rows.filter(r => r.email).length };
  }
  async function read(file, group) { return parse(await lines(file), group); }
  Hub.rosterPdf = { read, parse, lines, niceName, detectGroup };
})(window.Hub = window.Hub || {});
