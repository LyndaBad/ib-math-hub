/* Book exercises: for every exercise in the Oxford AA SL / HL books (2019) the Hub carries NEW questions written
   for the same skills, in the same style and at the same level, with full IB markschemes. Only the exercise names
   and page numbers come from the books — no textbook questions are stored or shown.
   Questions live in q_bx_*.js (registered through Hub.qcore.bx); this file holds the exercise list and the
   teacher tools: Studio card, notebook shortcut and homework drafts. */
(function (Hub) {
  'use strict';
  const { esc, uid } = Hub.core;
  const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const S = () => Hub.store.state, C = () => Hub.curriculum, toast = (m, k) => Hub.core.toast(m, k);
  const BOOK = { SL: 'Oxford AA SL', HL: 'Oxford AA HL' };
  /* Exercise → printed page, from the books' own exercise headings. */
  const PAGES = {
    SL: '1A:8 1B:10 1C:12 1D:15 1E:16 1F:19 1G:20 1H:21 1I:28 1J:33 1K:34 1L:39 1M:43 1N:52 1O:54 1P:56 2A:68 2B:73 2C:76 2D:82 2E:84 2F:89 2G:90 2H:92 2I:96 2J:99 3A:113 3B:115 3C:119 3D:122 3E:123 3F:125 3G:125 3H:126 3I:129 3J:136 3K:140 3L:143 3M:149 3N:151 3O:153 3P:156 3Q:157 3R:159 3S:163 3T:164 3U:166 3V:169 3W:172 3X:176 4A:187 4B:191 4C:195 4D:199 4E:206 5A:219 5B:221 5C:227 5D:229 5E:231 5F:233 5G:236 5H:238 5I:239 5J:240 5K:243 5L:246 5M:249 5N:255 5O:257 5P:259 5Q:264 5R:267 6A:282 6B:286 6C:289 6D:292 6E:294 6F:297 6G:300 6H:303 6I:307 6J:309 7A:324 7B:327 7C:332 7D:335 7E:339 7F:342 8A:357 8B:361 8C:368 8D:370 8E:371 8F:373 8G:376 8H:379 8I:385 9A:398 9B:400 9C:401 9D:404 9E:406 9F:409 9G:411 9H:414 9I:415 9J:416 9K:417 9L:420 9M:424 10A:435 10B:437 10C:439 10D:441 10E:443 10F:445 10G:449 10H:452 10I:454 10J:458 10K:459 11A:470 11B:473 11C:479 11D:481 11E:483 11F:485 11G:489 11H:491 11I:493 12A:511 12B:512 12C:517 12D:519 12E:520 12F:522 12G:525 12H:527 12I:529 12J:532 13A:548 13B:548 13C:551 13D:555 13E:558 13F:560 13G:563 13H:566 13I:571 13J:574 13K:576 14A:587 14B:590 14C:596 14D:598 14E:599 14F:600 14G:602 14H:609 14I:612 14J:612 14K:615 14L:616 14M:619',
    HL: '1A:9 1B:15 1C:26 1D:31 1E:40 1F:44 1G:50 1H:57 1I:61 1J:65 2A:80 2B:85 2C:89 2D:90 2E:91 2F:93 2G:95 2H:98 2I:100 2J:101 2K:105 2L:108 2M:111 2N:116 2O:118 2P:120 2Q:126 2R:134 2S:139 3A:149 3B:152 3C:156 3D:159 3E:160 3F:166 3G:171 3H:174 3I:179 3J:181 3K:184 3L:190 3M:194 3N:196 3O:200 3P:203 3Q:205 3R:210 4A:223 4B:227 4C:232 4D:235 4E:241 4F:243 4G:248 4H:252 4I:254 4J:256 4K:258 4L:261 4M:264 4N:268 4O:273 4P:274 4Q:277 4R:281 4S:283 4T:287 4U:290 4V:294 5A:311 5B:313 5C:323 5D:331 5E:333 5F:339 5G:342 5H:346 5I:355 6A:374 6B:377 6C:380 6D:383 6E:390 6F:391 6G:393 6H:396 6I:398 6J:400 6K:403 6L:404 6M:408 6N:414 6O:417 6P:420 6Q:421 6R:423 6S:425 6T:426 6U:428 6V:431 6W:432 7A:450 7B:459 7C:464 7D:472 7E:481 7F:487 7G:495 7H:499 7I:503 7J:507 7K:508 7L:509 8A:522 8B:523 8C:527 8D:532 8E:535 8F:539 8G:543 8H:545 8I:549 8J:553 8K:556 8L:562 9A:581 9B:585 9C:592 9D:596 9E:604 9F:610 9G:613 9H:620 9I:628 9J:630 9K:633 9L:638 10A:655 10B:659 10C:663 10D:667 10E:671 10F:674 11A:687 11B:692 11C:695 11D:699 11E:701 11F:705 11G:708 11H:711 11I:717 11J:722 11K:724'
  };
  const idx = Hub.qcore.bxIndex;
  /** Section (e.g. '1.5') an exercise belongs to: the last section of its chapter that starts on or before its page. */
  function secOf(course, ex, page) {
    const ch = ex.slice(0, -1), secs = Object.entries(C().OXFORD[course] || {}).filter(([s]) => s.split('.')[0] === ch && C().OXFORD[course][s][1] <= page).sort((a, b) => a[1][1] - b[1][1]);
    return secs.length ? secs[secs.length - 1][0] : null;
  }
  let cache = null;
  /** Every exercise in both books, with section, title and how many new questions the Hub has for it. */
  function all() {
    if (cache) return cache;
    cache = {};
    for (const course of ['SL', 'HL']) cache[course] = PAGES[course].split(' ').map(t => { const [ex, p] = t.split(':'), page = Number(p), have = idx[course + '-' + ex];
      const sec = (have && have.sec) || secOf(course, ex, page), title = (have && have.title) || (sec && C().OXFORD[course][sec] ? C().OXFORD[course][sec][0] : `Chapter ${ex.slice(0, -1)}`);
      return { course, ex, page, sec, title, key: course + '-' + ex, qs: have ? have.qs : [], ready: !!(have && have.qs.length) }; });
    return cache;
  }
  const get = (course, ex) => (all()[course] || []).find(e => e.ex === ex) || null;
  /** Exercises for the sections a lesson's calendar text mentions (e.g. "2.2 … and 2.3 …"). */
  function forLesson(course, text) {
    const secs = [...String(text || '').matchAll(/\b(\d{1,2}\.\d{1,2})\b/g)].map(m => m[1]);
    return (all()[course] || []).filter(e => e.sec && secs.includes(e.sec));
  }
  const marksOf = e => e.qs.reduce((s, id) => { try { const q = Hub.qcore.build(id, 1); return s + q.marks; } catch (_) { return s; } }, 0);

  /* ---------- homework draft ---------- */
  /** Typed answers stay typed and are marked automatically; show that / sketch parts become self-check. */
  function buildQ(id, mc) {
    const q = Hub.assess.buildQ(id, false, true, mc);
    q.bookRef = `Exercise ${q.gen.split('.')[2]} · Q${q.gen.split('.')[3]}`; return q;
  }
  /** Built questions (labelled with their exercise) for the ticked ids of the given exercises, in order.
      hw: homework rules (typed answers, open parts self-check); otherwise open parts stay for the teacher to mark. */
  function questions(course, exs, only, opts = {}) {
    const list = [...new Set(exs || [])].map(ex => get(course, ex)).filter(e => e && e.ready);
    const ids = list.flatMap(e => only && only.length ? e.qs.filter(id => only.includes(id)) : e.qs);
    return ids.map(id => { const q = Hub.assess.buildQ(id, false, opts.hw !== false, opts.mc === true); q.bookRef = `Exercise ${q.gen.split('.')[2]} · Q${q.gen.split('.')[3]}`; return q; });
  }
  /** Homework assessment (a review draft) from one or more exercises, in the order given. groups: the days it goes to.
      opts.only: the question ids to keep (from any of the exercises). */
  function draft(course, exs, opts = {}) {
    const list = [...new Set((Array.isArray(exs) ? exs : [exs]).filter(Boolean))].map(ex => get(course, ex));
    if (!list.length || list.some(e => !e || !e.ready)) return { ok: false, error: 'There are no questions for that exercise yet.' };
    const ids = list.flatMap(e => opts.only && opts.only.length ? e.qs.filter(id => opts.only.includes(id)) : e.qs); if (!ids.length) return { ok: false, error: 'Tick at least one question.' };
    const used = list.filter(e => ids.some(id => e.qs.includes(id))), names = used.map(e => e.ex), titles = [...new Set(used.map(e => e.title))];
    const qs = ids.map(id => buildQ(id, opts.mc === true)), skills = [...new Set(qs.map(q => q.skill))];
    const title = used.length === 1 ? `Exercise ${names[0]} · ${used[0].title}` : `Exercises ${names.slice(0, -1).join(', ')} and ${names[names.length - 1]} · ${titles.length === 1 ? titles[0] : titles.join('; ')}`;
    const a = { id: uid('a'), course, title: title.slice(0, 160), type: 'Homework', lessonDate: opts.lessonDate || null, skills, paper: 'Mixed', rigour: 'standard', book: { course, ex: names[0], exs: names, page: used[0].page, pages: used.map(e => e.page) },
      questions: qs, reviewed: {}, status: 'draft', version: 1, groups: opts.groups || [course + '-A', course + '-B'], uploadRequired: opts.upload === true, release: 'auto', minutes: Math.min(120, 45 + 30 * (used.length - 1)), due: null, retestOf: null, cap: null, createdAt: new Date().toISOString(),
      history: [{ at: new Date().toISOString(), who: Hub.auth.who(), what: `Draft made from ${BOOK[course]} Exercise${names.length > 1 ? 's' : ''} ${names.join(', ')} (new questions)` }] };
    S().assessments.unshift(a); Hub.store.log(`Made homework draft “${a.title}”`); Hub.store.save(); return { ok: true, assessment: a };
  }

  /* ---------- Studio card: pick one or more exercises for one assignment ---------- */
  function options(course, pick) {
    const list = all()[course] || [], bySec = [];
    list.forEach(e => { const k = e.sec ? `${e.sec} ${e.title}` : e.title; let g = bySec.find(x => x[0] === k); if (!g) bySec.push(g = [k, []]); g[1].push(e); });
    return `<option value="">Choose an exercise to add…</option>` + bySec.map(([k, es]) => `<optgroup label="${esc(k)}">${es.map(e => `<option value="${e.ex}" ${e.ready ? '' : 'disabled'}>Exercise ${e.ex} · p. ${e.page}${e.ready ? ` · ${e.qs.length} question${e.qs.length > 1 ? 's' : ''}` : ' · coming soon'}</option>`).join('')}</optgroup>`).join('');
  }
  function qList(e) {
    if (!e || !e.ready) return '<p class="tiny muted">New questions for this exercise are coming soon.</p>';
    return `<div class="bx-qs">${e.qs.map((id, i) => { let q; try { q = Hub.qcore.build(id, 7); } catch (_) { return ''; } const first = q.parts[0];
      return `<label class="bx-q"><input type="checkbox" value="${id}" data-marks="${q.marks}" checked><span class="q-num">${i + 1}</span><span class="bx-q-t">${Hub.math.render((t => { let x = t.slice(0, 170); if ((x.match(/\$/g) || []).length % 2) x = x.slice(0, x.lastIndexOf('$')); return x + (t.length > x.length ? '…' : ''); })((q.stem ? q.stem + ' ' : '') + (first.command ? first.command + ' ' : '') + first.prompt))}${q.parts.length > 1 ? ` <span class="tiny muted">(${q.parts.length} parts)</span>` : ''}</span><span class="tiny muted">${q.marks} marks</span></label>`; }).join('')}</div>`;
  }
  const block = e => `<div class="bx-block" data-ex="${e.ex}"><div class="row-between"><b>Exercise ${e.ex} · ${esc(e.title)} <span class="tiny muted">p. ${e.page}</span></b><span class="actions"><button class="btn small ghost" type="button" data-bxall="${e.ex}">All / none</button><button class="btn small ghost danger" type="button" data-bxrm="${e.ex}">Remove</button></span></div>${qList(e)}</div>`;
  function studioCard(group) {
    const g = C().GROUPS[group], course = g.course, nl = C().nextLesson(group, Hub.mastery.asOf()), sugs = nl ? forLesson(course, nl.activity).filter(e => e.ready) : [];
    const first = sugs[0] || (all()[course] || []).find(e => e.ready), ready = (all()[course] || []).filter(e => e.ready).length;
    return `<section class="card bx-card"><h2 class="bar-head amber">Homework from book exercises</h2>
      <p class="small">New questions for each exercise in the ${BOOK[course]} book — the same skills, style and level, with new numbers and wording, full M/A/R markschemes and model answers. Students see the exercise name on each question (e.g. “Exercise ${first ? first.ex : '1O'} · Q3”). ${ready} exercise${ready === 1 ? '' : 's'} ready so far; more are being added.</p>
      <div class="form-grid"><label>Add an exercise to this homework<select id="bx-ex">${options(course)}</select></label>
      <label>Goes to<select id="bx-days"><option value="both">${course} A day and B day (one assignment)</option><option value="${course}-A">${course} A day only</option><option value="${course}-B">${course} B day only</option></select></label></div>
      <p class="tiny muted">Pick as many exercises as you like — each one is added below, in order, as one homework. Untick any questions you don’t want.</p>
      ${sugs.length ? `<p class="tiny">Suggested for the next lesson (${Hub.core.fmtDate(nl.date)}): <b>${sugs.map(e => 'Exercise ' + e.ex).join(', ')}</b>${sugs.length > 1 ? ' <button class="btn small ghost" type="button" id="bx-sug">Add all of these</button>' : ''}</p>` : ''}
      <div id="bx-list">${first ? block(first) : ''}</div>
      <div class="actions"><button class="btn primary" id="bx-make" type="button" ${first ? '' : 'disabled'}>Make homework draft →</button><span class="tiny" id="bx-sum"></span></div>
      <p class="tiny muted">Students type their answers and the Hub marks them; “show that” and sketch parts are self-check with the model answer. No photo upload.</p></section>`;
  }
  /** The exercise picker (select to add, one block per exercise with a question checklist). p = id prefix. */
  function pickerHTML(course, p, initial, label) {
    return `<label>${label || 'Add an exercise'}<select id="${p}-ex">${options(course)}</select></label><div id="${p}-list" class="bx-list span2">${(initial || []).map(e => block(e)).join('')}</div>`;
  }
  function bindPicker(root, course, p, onChange) {
    const sel = $('#' + p + '-ex', root), list = $('#' + p + '-list', root), fire = () => onChange && onChange(api);
    const api = { chosen: () => $$('.bx-block', list).map(b => b.dataset.ex), only: () => $$('input[type="checkbox"]:checked', list).map(c => c.value), marks: () => $$('input[type="checkbox"]:checked', list).reduce((t, c) => t + Number(c.dataset.marks || 0), 0),
      add: ex => { const e = get(course, ex); if (!e || !e.ready) return; if (api.chosen().includes(ex)) return toast(`Exercise ${ex} is already in this homework.`); list.insertAdjacentHTML('beforeend', block(e)); fire(); } };
    sel.onchange = () => { if (sel.value) api.add(sel.value); sel.value = ''; };
    list.addEventListener('click', e => { const rm = e.target.closest('[data-bxrm]'), al = e.target.closest('[data-bxall]');
      if (rm) { rm.closest('.bx-block').remove(); fire(); }
      if (al) { const bs = $$('input[type="checkbox"]', al.closest('.bx-block')), on = bs.some(c => !c.checked); bs.forEach(c => (c.checked = on)); fire(); } });
    list.addEventListener('change', fire); fire(); return api;
  }
  function bindStudio(main, group) {
    const card = $('.bx-card', main); if (!card) return;
    const course = C().GROUPS[group].course, sel = $('#bx-ex', card), list = $('#bx-list', card), make = $('#bx-make', card);
    const chosen = () => $$('.bx-block', list).map(b => b.dataset.ex);
    const sum = () => { const n = chosen().length, ticks = $$('input[type="checkbox"]:checked', list), m = ticks.reduce((t, c) => t + Number(c.dataset.marks || 0), 0);
      $('#bx-sum', card).textContent = n ? `${n} exercise${n > 1 ? 's' : ''} · ${ticks.length} question${ticks.length === 1 ? '' : 's'} · ${m} marks` : 'Add at least one exercise.'; make.disabled = !n || !ticks.length; };
    const add = ex => { const e = get(course, ex); if (!e || !e.ready) return; if (chosen().includes(ex)) return toast(`Exercise ${ex} is already in this homework.`); list.insertAdjacentHTML('beforeend', block(e)); sum(); };
    sel.onchange = () => { if (sel.value) add(sel.value); sel.value = ''; };
    const sg = $('#bx-sug', card); if (sg) sg.onclick = () => { const nl = C().nextLesson(group, Hub.mastery.asOf()); forLesson(course, nl.activity).filter(e => e.ready).forEach(e => { if (!chosen().includes(e.ex)) add(e.ex); }); };
    list.addEventListener('click', e => { const rm = e.target.closest('[data-bxrm]'), al = e.target.closest('[data-bxall]');
      if (rm) { rm.closest('.bx-block').remove(); sum(); }
      if (al) { const bs = $$('input[type="checkbox"]', al.closest('.bx-block')), on = bs.some(c => !c.checked); bs.forEach(c => (c.checked = on)); sum(); } });
    list.addEventListener('change', sum); sum();
    make.onclick = () => {
      const days = $('#bx-days', card).value, only = $$('input:checked', list).map(c => c.value);
      const r = draft(course, chosen(), { groups: days === 'both' ? [course + '-A', course + '-B'] : [days], only });
      if (!r.ok) return toast(r.error, 'error'); toast('Homework draft ready — review each question, then approve and publish.'); location.hash = '#/edit/' + r.assessment.id;
    };
  }

  /* ---------- notebook shortcut (Lessons & notebooks → Homework) ---------- */
  function notebookButtons(L) {
    const es = forLesson(L.course, L.title).filter(e => e.ready); if (!es.length) return '';
    return `<p class="small bx-nb">Book exercise homework (new questions): ${es.length > 1 ? `<button class="btn small" data-bxnb="${es.map(e => e.ex).join(',')}" type="button">Make one homework from Exercises ${es.map(e => e.ex).join(', ')}</button> ` : ''}${es.map(e => `<button class="btn small ghost" data-bxnb="${e.ex}" type="button">Make homework from Exercise ${e.ex}</button>`).join(' ')}</p>`;
  }
  function bindNotebook(main, L, after) {
    $$('[data-bxnb]', main).forEach(b => (b.onclick = () => {
      const exs = b.dataset.bxnb.split(','), r = draft(L.course, exs, { lessonDate: (L.dates || {}).A || null }); if (!r.ok) return toast(r.error, 'error');
      L.homeworkId = r.assessment.id; if (!(L.homework || '').trim()) L.homework = `Exercise${exs.length > 1 ? 's' : ''} ${exs.join(', ')} — on the Hub`; if (after) after(L);
      toast(`Homework draft “${r.assessment.title}” made and linked. Review and publish it in the Assessment Studio.`); Hub.app.render();
    }));
  }

  Hub.bookex = { all, get, forLesson, draft, questions, pickerHTML, bindPicker, studioCard, bindStudio, notebookButtons, bindNotebook, marksOf, BOOK };
})(window.Hub = window.Hub || {});
