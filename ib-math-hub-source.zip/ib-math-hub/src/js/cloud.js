/* Supabase transport. Public configuration contains no privileged key. */
(function(Hub){
 'use strict';
 const cfg=window.HUB_CONFIG, clone=x=>JSON.parse(JSON.stringify(x));
 const activation=/type=(invite|recovery)/.test(location.hash);
 const client=window.supabase.createClient(cfg.supabaseUrl,cfg.supabaseKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
 async function call(action,data={}){
  const {data:{session}}=await client.auth.getSession();if(!session)throw Error('Please sign in again.');
  const r=await fetch(cfg.supabaseUrl+'/functions/v1/hub',{method:'POST',headers:{'Content-Type':'application/json',apikey:cfg.supabaseKey,Authorization:'Bearer '+session.access_token},body:JSON.stringify({action,...data})});
  const body=await r.json();if(!r.ok)throw Error(body.error||'Could not reach the Hub.');return body;
 }
 /** Without a signed-in user: only the 'join' action (class code + name + new password) accepts this. */
 async function callPublic(action,data={}){
  const r=await fetch(cfg.supabaseUrl+'/functions/v1/hub',{method:'POST',headers:{'Content-Type':'application/json',apikey:cfg.supabaseKey,Authorization:'Bearer '+cfg.supabaseKey},body:JSON.stringify({action,...data})});
  let body={};try{body=await r.json();}catch(e){}if(!r.ok)throw Error(body.error||body.message||'Could not reach the Hub. Ask Miss Badmus.');return body;
 }
 /** Students sign in with a username (amara.okafor); the server keeps it as a plus-address of the teacher's Gmail. Nothing is emailed to it. */
 const loginEmail=u=>String(u).includes('@')?String(u).trim().toLowerCase():'badmuslyn+'+String(u).trim().toLowerCase().replace(/[^a-z0-9.]/g,'')+'@gmail.com';
 Hub.cloud={client,call,callPublic,loginEmail,clone,activation};
})(window.Hub=window.Hub||{});
