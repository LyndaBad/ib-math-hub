/* Joining a class with a code — no emails, no Google.
   Student: opens …/#/join, types the class code, their first and last name and a new password. The server matches the name to the
   roster for that class (automatically — the teacher does nothing), makes their sign-in, and gives them a username (amara.okafor).
   Teacher (Data & settings): a code per class, open/close joining, new code, who has joined, and Reset login for a forgotten password. */
(function (Hub) {
  'use strict';
  const { $, $$, esc, toast } = Hub.core;
  const ALPH = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  const GROUPS = () => Hub.curriculum.GROUPS;
  const clean = c => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12);
  const joinURL = () => location.origin + location.pathname + '#/join';
  const app = () => $('#app');
  const card = inner => `<main class="signin join" id="main"><section class="signin-card"><img class="signin-wolf" src="${Hub.LOGO}" alt="Miss Badmus’ wolf logo"><p class="kicker">MISS BADMUS’ IB MATH HUB</p>${inner}</section></main>`;
  const classLabel = g => (GROUPS()[g] || {}).label || g;

  /* ---------- student: the join page ---------- */
  function page(msg) {
    const signinBtn = (id, label) => `<a class="btn big-signin" href="#/" id="${id}">${label}</a>`;
    app().innerHTML = card(`<div class="join-already"><p><b>Already joined?</b> You don’t need to join again.</p>${signinBtn('join-back-top', 'Sign in with my username →')}</div>
      <h1>New here? Join your class</h1><p>Type the class code from Miss Badmus and your name as it is on the class register. Then choose a password. You only do this once.</p>
      <form id="join-form" novalidate>
        <label>Class code<input id="join-code" class="code-in" autocomplete="off" autocapitalize="characters" spellcheck="false" maxlength="12" placeholder="e.g. K7Q2MX" required></label>
        <div class="join-names"><label>First name<input id="join-first" autocomplete="given-name" required></label><label>Last name<input id="join-last" autocomplete="family-name" required></label></div>
        <label>Choose a password <span class="tiny muted">(8 characters or more)</span><input id="join-pw" type="password" autocomplete="new-password" minlength="8" required></label>
        <label>Type the password again<input id="join-pw2" type="password" autocomplete="new-password" minlength="8" required></label>
        <button class="btn primary" id="join-go">Join my class</button></form>
      <p id="join-msg" role="alert" class="small">${msg ? esc(msg) : ''}</p>
      <div class="join-already bottom">${signinBtn('join-back', 'I have already joined — sign in')}</div>`);
    const codeIn = $('#join-code');
    codeIn.oninput = () => { const v = clean(codeIn.value); if (v !== codeIn.value) codeIn.value = v; };
    $$('#join-back, #join-back-top').forEach(a => (a.onclick = e => { e.preventDefault(); location.hash = '#/'; location.reload(); }));
    $('#join-form').onsubmit = async e => {
      e.preventDefault(); const say = t => { $('#join-msg').textContent = t; };
      const code = clean(codeIn.value), first = $('#join-first').value.trim(), last = $('#join-last').value.trim(), pw = $('#join-pw').value;
      if (code.length < 4) { say('Type the class code from Miss Badmus.'); return codeIn.focus(); }
      if (!first || !last) { say('Type your first name and your last name.'); return (first ? $('#join-last') : $('#join-first')).focus(); }
      if (pw.length < 8) { say('Choose a password with at least 8 characters.'); return $('#join-pw').focus(); }
      if (pw !== $('#join-pw2').value) { say('The two passwords are not the same.'); return $('#join-pw2').focus(); }
      const b = $('#join-go'); b.disabled = true; say('Joining…');
      try {
        const r = await Hub.cloud.callPublic('join', { code, first, last, password: pw });
        // signed in straight away; the username is how they sign in next time
        await Hub.cloud.client.auth.signInWithPassword({ email: r.login, password: pw }).catch(() => {});
        app().innerHTML = card(`<h1>You’re in! 🎉</h1><p>Welcome to <b>${esc(classLabel(r.group))}</b>, ${esc(first)}.</p>
          <div class="join-user"><span class="key-lab">Your username</span><b id="join-username">${esc(r.username)}</b></div>
          <p class="small"><b>Write it down.</b> Next time, sign in with this username and the password you just chose.</p>
          <button class="btn primary" id="join-in" type="button">Go to my Hub →</button>`);
        $('#join-in').onclick = () => { location.hash = '#/home'; location.reload(); };
      } catch (err) { say(err.message); b.disabled = false; if (/already joined/.test(err.message)) $('#join-back').focus(); }
    };
    codeIn.focus();
  }

  /** Called while the app starts: the join link shows the join page — unless this browser is already signed in, then straight to the Hub. */
  async function resume(session) { if (/^#\/join\b/.test(location.hash) && !session) { page(); return true; } if (/^#\/join\b/.test(location.hash)) history.replaceState(null, '', '#/home'); return false; }

  /* ---------- teacher: Data & settings card ---------- */
  const S = () => Hub.store.state;
  const cfg = () => { const st = S(); st.settings.join = st.settings.join || { codes: {} }; st.settings.join.codes = st.settings.join.codes || {}; return st.settings.join; };
  function newCode() { const used = new Set(Object.values(cfg().codes).map(c => c && c.code)); let c; do { const r = crypto.getRandomValues(new Uint32Array(6)); c = Array.from(r, x => ALPH[x % ALPH.length]).join(''); } while (used.has(c)); return c; }
  const isIn = s => !!(s && (s.joinedAt || s.email));
  let openG = null; // the class whose list stays open after adding a student
  function cardHTML() {
    const J = (S().settings || {}).join || { codes: {} };
    const row = g => { const c = (J.codes || {})[g.id], studs = Hub.roster.inGroup(g.id), n = studs.filter(isIn).length;
      return `<tr><td><b>${esc(g.label)}</b></td><td>${c && c.code ? `<span class="join-code">${esc(c.code)}</span>` : '<span class="tiny muted">no code yet</span>'}</td><td>${c && c.code ? (c.open === false ? '<span class="pill grey">Closed</span>' : '<span class="pill green">Open</span>') : ''}</td><td>${n}/${studs.length}</td>
        <td><div class="join-act">${c && c.code ? `<button class="btn small ghost" data-jcopy="${g.id}" type="button">Copy for students</button><button class="btn small ghost" data-jtoggle="${g.id}" type="button">${c.open === false ? 'Open joining' : 'Close joining'}</button><button class="btn small ghost" data-jnew="${g.id}" type="button">New code</button>` : `<button class="btn small" data-jnew="${g.id}" type="button">Make a code</button>`}</div></td></tr>`; };
    const who = Object.values(GROUPS()).map(g => { const studs = Hub.roster.inGroup(g.id); const yes = studs.filter(isIn);
      return `<details class="join-who"${openG === g.id ? ' open' : ''}><summary><b>${esc(g.label)}</b> · ${studs.length ? `${yes.length}/${studs.length} joined` : 'no students yet'}</summary>${studs.length ? `<table class="tbl join-stu"><tbody>${studs.map(s => `<tr><td>${esc(s.name)}</td><td>${isIn(s) ? `<code>${esc(s.username || s.email || '')}</code>` : '<span class="tiny muted">not joined yet</span>'}</td><td><div class="join-act">${manageButtons(s)}</div></td></tr>`).join('')}</tbody></table>` : ''}
        <form class="join-add" data-jadd="${g.id}" novalidate><p class="key-lab">Add a student to ${esc(g.label)}</p><div class="join-add-row"><label>First name<input name="first" autocomplete="off" spellcheck="false" required></label><label>Last name<input name="last" autocomplete="off" spellcheck="false" required></label><button class="btn small primary">Add student</button></div><p class="tiny muted">Type the name exactly as the student will type it when they join.</p></form></details>`; }).join('');
    return `<section class="card join-card"><h2 class="bar-head green">Class join codes</h2>
      <p>Give students the join link and their class code. They type the code and their first and last name, and choose a password. They are matched to your roster <b>automatically</b> and get a username (e.g. <code>amara.okafor</code>) to sign in with. No emails.</p>
      <div class="join-link"><span class="key-lab">Join link</span><code id="join-url">${esc(joinURL().replace(/^https?:\/\//, ''))}</code><button class="btn small ghost" id="join-copy-link" type="button">Copy link</button></div>
      <div class="scroll"><table class="tbl join-tbl"><thead><tr><th>Class</th><th>Code</th><th>Joining</th><th>Joined</th><th></th></tr></thead><tbody>${Object.values(GROUPS()).map(row).join('')}</tbody></table></div>
      <p class="tiny muted">If a student’s name is not found, check how it is spelled on your roster. A new code stops the old one working; close joining once everyone is in.</p>
      <h3 class="sub-h">Your students</h3><p class="tiny muted"><b>Reset password</b> gives a student a new password to sign in with straight away. <b>Join again</b> lets them redo the class-code join (e.g. someone else used their name). <b>Delete</b> removes the student and all their work. To add one student, open their class and use <b>Add a student</b>.</p>
      ${who || '<p class="tiny muted">Upload a roster first.</p>'}</section>`;
  }
  function manageButtons(s) {
    return `${s.uid ? `<button class="btn small" data-pw="${esc(s.id)}" type="button">Reset password</button>` : ''}${s.joinedAt ? `<button class="btn small ghost" data-reset="${esc(s.id)}" type="button">Join again</button>` : ''}<button class="btn small ghost danger" data-del="${esc(s.id)}" type="button">Delete</button>`;
  }
  const pwWords = ['maths', 'wolf', 'prime', 'delta', 'sigma', 'vector', 'matrix', 'theta', 'graph', 'radius'];
  const newPassword = () => { const r = crypto.getRandomValues(new Uint32Array(2)); return pwWords[r[0] % pwWords.length] + '-' + (1000 + r[1] % 9000); };
  /** Teacher sets a new password for a student; shows it so she can tell them. */
  function resetPassword(s) {
    const first = String(s.name).includes(',') ? s.name.split(',')[1].trim().split(' ')[0] : s.name.split(' ')[0];
    const m = Hub.ui.modal(`<h2 class="modal-title">Reset ${esc(s.name)}’s password</h2><p>Username: <code>${esc(s.username || '')}</code></p>
      <label>New password <span class="tiny muted">(8 characters or more — change it if you like)</span><input id="rp-pw" value="${newPassword()}" autocomplete="off" spellcheck="false"></label>
      <div class="actions"><button class="btn primary" id="rp-save" type="button">Save new password</button><button class="btn ghost" id="rp-cancel" type="button">Cancel</button></div><p id="rp-msg" role="status"></p>`);
    $('#rp-cancel', m.el).onclick = m.close;
    $('#rp-save', m.el).onclick = async () => {
      const pw = $('#rp-pw', m.el).value.trim(), b = $('#rp-save', m.el); if (pw.length < 8) { $('#rp-msg', m.el).textContent = 'Use at least 8 characters.'; return; }
      b.disabled = true; $('#rp-msg', m.el).textContent = 'Saving…';
      try { await Hub.store.flush(); const r = await Hub.cloud.call('set-password', { sid: s.id, password: pw }); if (r.state) Hub.store.accept(r.state);
        m.el.innerHTML = `<h2 class="modal-title">Done ✓</h2><p>Tell ${esc(first)}:</p><div class="join-user"><span class="key-lab">Username</span><b>${esc(r.username || s.username)}</b><span class="key-lab">Password</span><b>${esc(pw)}</b></div><div class="actions"><button class="btn primary" id="rp-ok" type="button">OK</button></div>`;
        $('#rp-ok', m.el).onclick = () => { m.close(); Hub.app.render(); };
      } catch (e) { $('#rp-msg', m.el).textContent = e.message; b.disabled = false; }
    };
  }
  async function deleteStudent(s, after) {
    if (!(await Hub.ui.confirmBox(`Delete <b>${esc(s.name)}</b> (${esc(classLabel(s.group))})? This removes them from your roster with all their work, notebook answers and photos, and their login. It cannot be undone.`, 'Delete student', { danger: true }))) return;
    try { await Hub.store.flush(); const r = await Hub.cloud.call('delete-student', { sid: s.id }); if (r.state) Hub.store.accept(r.state); toast(`${s.name} deleted.`); if (after) after(); else Hub.app.render(); }
    catch (e) { toast(e.message, 'error'); }
  }
  async function joinAgain(s) {
    if (!(await Hub.ui.confirmBox(`Let ${esc(s.name)} join again with the class code? Their current password stops mattering once they rejoin and choose a new one. Their username (${esc(s.username || '')}) and all their work stay.`, 'Join again'))) return;
    delete s.joinedAt; Hub.store.log(`Let ${s.name} join again with the class code`); await saveNow(`Done. ${s.name} can join again with the class code.`);
  }
  /** Buttons on a student's profile page. */
  const loginCardHTML = s => `<div class="card"><h2 class="bar-head blue">Login</h2><p>${isIn(s) ? `Username: <code>${esc(s.username || s.email || '')}</code>${s.joinedAt ? ` · joined ${Hub.core.fmtDate(String(s.joinedAt).slice(0, 10))}` : ''}` : 'Not joined yet — they join with the class code (Data & settings).'}</p><div class="join-act">${manageButtons(s)}</div></div>`;
  function bindManage(root, after) {
    $$('[data-pw]', root).forEach(b => (b.onclick = () => { const s = Hub.roster.byId(b.dataset.pw); if (s) resetPassword(s); }));
    $$('[data-del]', root).forEach(b => (b.onclick = () => { const s = Hub.roster.byId(b.dataset.del); if (s) deleteStudent(s, after); }));
    $$('[data-reset]', root).forEach(b => (b.onclick = () => { const s = Hub.roster.byId(b.dataset.reset); if (s) joinAgain(s); }));
  }
  /* ---------- test students: one per class, so Miss Badmus can sign in and see the student side ---------- */
  const testUser = g => 'test.' + g.toLowerCase().replace('-', '');
  const testOf = g => S().roster.students.find(s => s.test && s.group === g && s.active !== false);
  function testCardHTML() {
    const gs = Object.values(GROUPS()), any = gs.some(g => testOf(g.id)), ready = gs.filter(g => (testOf(g.id) || {}).uid).length;
    const rows = gs.map(g => { const s = testOf(g.id); return `<tr><td><b>${esc(g.label)}</b></td><td>${s && s.uid ? `<code>${esc(s.username || testUser(g.id))}</code>` : '<span class="tiny muted">not set up yet</span>'}</td>
      <td><div class="join-act">${s && s.uid ? `<button class="btn small" data-pw="${esc(s.id)}" type="button">Reset password</button><a class="btn small ghost" href="#/student/${encodeURIComponent(s.id)}">Their record</a><button class="btn small ghost" data-tclear="${esc(s.id)}" type="button">Clear their work</button>` : ''}</div></td></tr>`; }).join('');
    return `<section class="card test-card"><h2 class="bar-head amber">Test students</h2>
      <p>One test student in each class, so you can sign in and see exactly what your students see — notebooks, homework, Do Now, results and the IA studio. Work a test student submits saves like a real student’s, so you can check marking and feedback too.</p>
      <div class="scroll"><table class="tbl test-tbl"><thead><tr><th>Class</th><th>Username</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
      <div class="actions"><button class="btn ${ready === gs.length ? 'ghost' : 'primary'}" id="test-setup" type="button">${ready === gs.length ? 'New password for all test students' : ready ? 'Set up the missing test students' : 'Set up test students'}</button>${any ? '<button class="btn small ghost danger" id="test-remove" type="button">Remove test students</button>' : ''}</div>
      <p class="tiny muted">Sign in as a test student in a <b>private (incognito) window</b> or another browser, so you stay signed in as yourself here. Test students are left out of class dashboards, missing-work lists, mastery, the IA overview and gradebooks; they still appear in Do Now plans and the marking queue.</p></section>`;
  }
  function setupTests() {
    const m = Hub.ui.modal(`<h2 class="modal-title">Test students</h2><p>Every test student gets this password:</p>
      <label>Password <span class="tiny muted">(8 characters or more — change it if you like)</span><input id="ts-pw" value="${newPassword()}" autocomplete="off" spellcheck="false"></label>
      <div class="actions"><button class="btn primary" id="ts-go" type="button">Set up</button><button class="btn ghost" id="ts-cancel" type="button">Cancel</button></div><p id="ts-msg" role="status"></p>`);
    $('#ts-cancel', m.el).onclick = m.close;
    $('#ts-go', m.el).onclick = async () => {
      const pw = $('#ts-pw', m.el).value.trim(), b = $('#ts-go', m.el), msg = $('#ts-msg', m.el);
      if (pw.length < 8) { msg.textContent = 'Use at least 8 characters.'; return; }
      b.disabled = true; msg.textContent = 'Setting up… (a few seconds)';
      const groups = Object.keys(GROUPS()), reopened = [], done = [];
      try {
        for (const g of groups) {
          if (!testOf(g)) S().roster.students.push({ id: crypto.randomUUID(), name: 'Test Student', first: 'Test', last: 'Student', group: g, course: g.slice(0, 2), test: true, active: true, username: testUser(g) });
          const c = cfg().codes[g];
          if (!(testOf(g).uid)) { if (!c || !c.code) cfg().codes[g] = { code: newCode(), open: true, at: new Date().toISOString() }; else if (c.open === false) { c.open = true; reopened.push(g); } }
        }
        Hub.store.log('Set up test students'); Hub.store.save(true); await Hub.store.flush();
        for (const g of groups) {
          const s = testOf(g);
          if (s.uid) { const r = await Hub.cloud.call('set-password', { sid: s.id, password: pw }); done.push([g, r.username || s.username]); }
          else { const r = await Hub.cloud.callPublic('join', { code: cfg().codes[g].code, first: 'Test', last: 'Student', password: pw }); done.push([g, r.username]); }
        }
        await Hub.store.refresh();
        if (reopened.length) { reopened.forEach(g => { cfg().codes[g].open = false; }); Hub.store.save(true); await Hub.store.flush(); }
        m.el.innerHTML = `<h2 class="modal-title">Test students ready ✓</h2><p>Open <b>${esc(location.host)}</b> in a private window and sign in with:</p>
          <table class="tbl"><thead><tr><th>Class</th><th>Username</th><th>Password</th></tr></thead><tbody>${done.map(([g, u]) => `<tr><td>${esc(classLabel(g))}</td><td><b>${esc(u)}</b></td><td><b>${esc(pw)}</b></td></tr>`).join('')}</tbody></table>
          <div class="actions"><button class="btn small ghost" id="ts-copy" type="button">Copy these</button><button class="btn primary" id="ts-ok" type="button">OK</button></div>`;
        $('#ts-copy', m.el).onclick = async () => { try { await navigator.clipboard.writeText(done.map(([g, u]) => `${classLabel(g)}: ${u} / ${pw}`).join('\n')); toast('Copied.'); } catch (e) { toast('Could not copy here — select the text and copy it.', 'error'); } };
        $('#ts-ok', m.el).onclick = () => { m.close(); Hub.app.render(); };
      } catch (e) { msg.textContent = e.message; b.disabled = false; }
    };
  }
  async function clearTest(s) {
    if (!(await Hub.ui.confirmBox(`Clear everything the ${esc(classLabel(s.group))} test student has done — answers, results, notebook work and IA? Their login stays.`, 'Clear their work', { danger: true }))) return;
    const st = S(), id = s.id;
    st.attempts = st.attempts.filter(t => t.sid !== id); st.evidence = st.evidence.filter(e => e.sid !== id);
    Object.keys(st.progress || {}).forEach(k => { if (k.startsWith(id + '|')) delete st.progress[k]; });
    if (st.ia) delete st.ia[id]; delete st.settings['iamark:' + id];
    Hub.store.log(`Cleared the ${classLabel(s.group)} test student’s work`); await saveNow('Test student’s work cleared.');
  }
  async function removeTests() {
    const list = Object.keys(GROUPS()).map(testOf).filter(Boolean);
    if (!(await Hub.ui.confirmBox(`Remove all ${list.length} test students, their work and their logins? You can set them up again any time.`, 'Remove test students', { danger: true }))) return;
    try { await Hub.store.flush(); for (const s of list) { const r = await Hub.cloud.call('delete-student', { sid: s.id }); if (r.state) Hub.store.accept(r.state); } toast('Test students removed.'); }
    catch (e) { toast(e.message, 'error'); }
    Hub.app.render();
  }
  function bindTests(main) {
    const c = $('.test-card', main); if (!c) return;
    $('#test-setup', c).onclick = setupTests;
    const rm = $('#test-remove', c); if (rm) rm.onclick = removeTests;
    $$('[data-tclear]', c).forEach(b => (b.onclick = () => { const s = Hub.roster.byId(b.dataset.tclear); if (s) clearTest(s); }));
    bindManage(c);
  }
  async function saveNow(msg) { Hub.store.save(true); try { await Hub.store.flush(); if (msg) toast(msg); } catch (e) { toast(e.message, 'error'); } Hub.app.render(); }
  function bind(main) {
    const J = () => cfg();
    const copy = async (txt, ok) => { try { await navigator.clipboard.writeText(txt); toast(ok); } catch (e) { toast('Could not copy here — select the text and copy it.', 'error'); } };
    const cl = $('#join-copy-link', main); if (cl) cl.onclick = () => copy(joinURL(), 'Join link copied.');
    $$('[data-jnew]', main).forEach(b => (b.onclick = async () => { const g = b.dataset.jnew, had = J().codes[g] && J().codes[g].code; if (had && !(await Hub.ui.confirmBox(`Make a new code for ${esc(classLabel(g))}? The old code stops working. Students who have already joined are not affected.`, 'New code'))) return; J().codes[g] = { code: newCode(), open: true, at: new Date().toISOString() }; Hub.store.log(`New class join code for ${classLabel(g)}`); await saveNow('New code ready.'); }));
    $$('[data-jtoggle]', main).forEach(b => (b.onclick = async () => { const c = J().codes[b.dataset.jtoggle]; c.open = c.open === false; await saveNow(c.open ? 'Joining is open.' : 'Joining is closed for that class.'); }));
    $$('[data-jcopy]', main).forEach(b => (b.onclick = () => { const g = b.dataset.jcopy, c = J().codes[g]; copy(`Join Miss Badmus’ ${classLabel(g)} on the IB Math Hub: open ${joinURL()} , type the class code ${c.code}, your first and last name, and choose a password.`, 'Copied — paste it to your students.'); }));
    $$('[data-jadd]', main).forEach(f => (f.onsubmit = async e => {
      e.preventDefault(); const g = f.dataset.jadd, first = f.first.value.replace(/\s+/g, ' ').trim(), last = f.last.value.replace(/\s+/g, ' ').trim();
      if (!first || !last) { toast('Type a first name and a last name.', 'error'); return (first ? f.last : f.first).focus(); }
      const row = { name: first + ' ' + last, first, last, email: '', group: g, course: g.slice(0, 2) }, ex = Hub.roster.findExisting(row);
      if (ex && ex.active !== false) { toast(`${ex.name} is already on the ${classLabel(g)} roster.`, 'error'); return f.first.focus(); }
      const btn = f.querySelector('button'); btn.disabled = true;
      try { Hub.roster.applyImport([row]); await Hub.store.flush(); toast(`${row.name} added to ${classLabel(g)}. They can now join with the class code.`); }
      catch (err) { toast(err.message, 'error'); btn.disabled = false; return; }
      openG = g; Hub.app.render();
      setTimeout(() => { const i = document.querySelector(`[data-jadd="${g}"] input[name="first"]`); if (i) i.focus(); }, 0);
    }));
    bindManage($('.join-card', main) || main);
    bindTests(main);
  }
  Hub.join = { page, resume, cardHTML, testCardHTML, bind, newCode, loginCardHTML, bindManage, testUser };
})(window.Hub = window.Hub || {});
