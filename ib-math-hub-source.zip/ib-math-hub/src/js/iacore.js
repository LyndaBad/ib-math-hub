/* IA stages — the shared rules for what a student can open and change in the IA Studio.
   The block between the IACORE markers is copied word for word into supabase/functions/hub/policy.js by
   tools/build-engine.cjs, so the browser and the server always use the same rules. The server is what enforces them:
   a locked stage's work is not sent to the student, and a save that changes a locked or closed stage is refused.
   Teacher-only data: settings.iapace (release plan) and settings['iastage:'+sid] (approvals and returns). */
(function (Hub) {
  'use strict';
  /* IACORE-START */
  const IA_STAGES = [
    { id: 'topic', n: 1, title: 'Topic Finder', short: 'Topic', cps: ['cp1'], obj: ['topic'], fields: ['interests', 'connections', 'working'], checks: [/^idea:/, /^area$/] },
    { id: 'title', n: 2, title: 'Title Builder', short: 'Title', cps: ['cp2'], obj: ['titleB'], fields: ['title', 'why', 'aim', 'planIntro', 'terms'], checks: [], titleCheck: true },
    { id: 'rq', n: 3, title: 'Research Question Builder', short: 'Research question', cps: ['cp3'], obj: ['rqB'], fields: ['rq', 'outline'], checks: [/^rq(Sit|Var|Out|Maths)$/] },
    { id: 'plan', n: 4, title: 'Exploration Planner', short: 'Plan', cps: ['ws', 'y1'], obj: ['planB'], fields: ['mathsPlan', 'beyond', 'explorationPlan', 'hlEnough'], checks: [] },
    { id: 'write', n: 5, title: 'Writing', short: 'Writing', cps: ['cp4', 'cp5', 'cp6'], obj: ['gdoc'], fields: ['intro', 'peerGiven', 'peerReceived', 'finalIntro'], checks: [/^w:/], write: true },
    { id: 'review', n: 6, title: 'Criteria Review', short: 'Criteria review', cps: [], obj: ['review'], fields: [], checks: [], self: true },
    { id: 'final', n: 7, title: 'Final Check & Export', short: 'Final check', cps: [], obj: ['final'], fields: [], checks: [] }
  ];
  const IA_STAGE_BY = Object.fromEntries(IA_STAGES.map(s => [s.id, s]));
  const iaEq = (a, b) => JSON.stringify(a === undefined ? null : a) === JSON.stringify(b === undefined ? null : b);
  const iaTime = t => { if (t === null || t === undefined || t === '') return null; const x = typeof t === 'number' ? t : Date.parse(t); return isNaN(x) ? null : x; };
  /** Which stage owns a piece of a student's IA record. null = not tied to a stage (references, drafts, reflection log). */
  function iaStageOf(group, key) {
    if (group === 'fields') { const s = IA_STAGES.find(s => s.fields.includes(key)); return s ? s.id : null; }
    if (group === 'checks') { const s = IA_STAGES.find(s => s.checks.some(r => r.test(key))); return s ? s.id : null; }
    if (group === 'status' || group === 'feedback') { const s = IA_STAGES.find(s => s.cps.includes(key)); return s ? s.id : null; }
    if (group === 'titleCheck') return 'title';
    if (group === 'self') return 'review';
    if (group === 'write') return 'write';
    if (group === 'stages') return IA_STAGE_BY[key] ? key : null;
    if (group === 'obj') { const s = IA_STAGES.find(s => s.obj.includes(key)); return s ? s.id : null; }
    return null;
  }
  const IA_MAPS = ['fields', 'checks', 'status', 'feedback', 'titleCheck', 'self', 'write', 'stages'];
  const IA_OBJS = IA_STAGES.flatMap(s => s.obj);
  /** For one student: each stage's state now — 'open' (work and submit), 'view' (read only) or 'locked' (no access). */
  function iaAccess(state, sid, now) {
    now = now === undefined || now === null ? Date.now() : iaTime(now);
    const st = (((state || {}).roster || {}).students || []).find(s => s.id === sid), group = st ? st.group : null;
    const S = (state && state.settings) || {}, P = S.iapace || {}, G = ((P.groups || {})[group]) || {}, O = ((P.students || {})[sid]) || {}, T = S['iastage:' + sid] || {};
    const out = {};
    IA_STAGES.forEach((stg, i) => {
      const c = G[stg.id] || {}, o = O[stg.id] || {};
      const mode = o.mode || c.mode || 'locked', releaseAt = o.mode ? (o.releaseAt || null) : (c.releaseAt || null), due = o.due || c.due || null;
      let st8 = 'locked', why = mode === 'scheduled' ? 'scheduled' : mode === 'locked' ? 'locked' : '';
      if (mode === 'open') st8 = 'open';
      else if (mode === 'view') st8 = 'view';
      else if (mode === 'scheduled') { const r = iaTime(releaseAt); if (r !== null && now >= r) { st8 = 'open'; why = ''; } }
      const prev = IA_STAGES[i - 1], gate = !!(prev && (G[prev.id] || {}).gate) && !o.skipGate;
      if (gate && st8 !== 'locked' && !(T[prev.id] && T[prev.id].approved)) { st8 = 'locked'; why = 'approval'; }
      const mine = ((((state || {}).ia || {})[sid] || {}).stages || {})[stg.id] || {}, tr = T[stg.id] || {};
      const returned = tr.state === 'returned' && (iaTime(tr.at) || 0) >= (iaTime(mine.at) || 0);
      const lockAfter = o.lockAfterDue !== undefined ? !!o.lockAfterDue : !!c.lockAfterDue, d = iaTime(due);
      if (st8 === 'open' && lockAfter && d !== null && now > d && !o.reopen && !returned) { st8 = 'view'; why = 'deadline'; }
      if (st8 === 'view' && (o.reopen || returned)) { st8 = 'open'; why = ''; }
      out[stg.id] = { state: st8, why, mode, releaseAt, due, lockAfter, gate, show: c.show !== false, n: stg.n, title: stg.title, own: !!(o.mode || o.due || o.reopen || o.skipGate || o.lockAfterDue !== undefined) };
    });
    return out;
  }
  /** The student's own IA record without anything that belongs to a locked stage (kept safely on the server). */
  function iaStrip(rec, acc) {
    const r = JSON.parse(JSON.stringify(rec || {})), locked = id => id && acc[id] && acc[id].state === 'locked';
    for (const g of IA_MAPS) if (r[g] && typeof r[g] === 'object') for (const k of Object.keys(r[g])) if (locked(iaStageOf(g, k))) delete r[g][k];
    for (const k of IA_OBJS) if (locked(iaStageOf('obj', k))) delete r[k];
    if (Array.isArray(r.versions)) r.versions.forEach(v => { if (v && v.fields) for (const k of Object.keys(v.fields)) if (locked(iaStageOf('fields', k))) delete v.fields[k]; if (v && locked('write')) delete v.write; });
    return r;
  }
  /** Stages whose work differs between two copies of a student's IA record. */
  function iaChanged(b, n) {
    b = b || {}; n = n || {}; const hit = new Set();
    for (const g of IA_MAPS) { const B = b[g] || {}, N = n[g] || {}; for (const k of new Set([...Object.keys(B), ...Object.keys(N)])) if (!iaEq(B[k], N[k])) { const s = iaStageOf(g, k); if (s) hit.add(s); } }
    for (const k of IA_OBJS) if (!iaEq(b[k], n[k])) hit.add(iaStageOf('obj', k));
    return [...hit];
  }
  /** A stage's status for the student: approved / returned (teacher), submitted / in-progress / not-started (student). */
  function iaStatus(state, sid, stageId) {
    const own = ((((state || {}).ia || {})[sid] || {}).stages || {})[stageId] || {}, T = ((((state || {}).settings || {})['iastage:' + sid]) || {})[stageId] || {};
    const sAt = iaTime(own.at) || 0, tAt = iaTime(T.at) || 0;
    if (T.state && tAt >= sAt) return T.state;
    return own.status || 'not-started';
  }
  /** The next moment a scheduled stage opens for this student (so the page can refresh itself then). */
  function iaNextRelease(acc, now) { now = now === undefined ? Date.now() : iaTime(now); const t = Object.values(acc).filter(a => a.state === 'locked' && a.why === 'scheduled').map(a => iaTime(a.releaseAt)).filter(x => x !== null && x > now); return t.length ? new Date(Math.min(...t)).toISOString() : null; }
  /* IACORE-END */
  Hub.iacore = { STAGES: IA_STAGES, BY: IA_STAGE_BY, stageOf: iaStageOf, access: iaAccess, strip: iaStrip, changed: iaChanged, status: iaStatus, nextRelease: iaNextRelease, time: iaTime };
})(window.Hub = window.Hub || {});
