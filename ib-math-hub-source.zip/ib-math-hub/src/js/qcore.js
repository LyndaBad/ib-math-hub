/* Question-bank core: seeded randomness, exact fractions, TeX formatting, registry.
   Every generator is ORIGINAL (parameterised by Miss Badmus' Hub), mapped to a lesson-level skill.
   Each part carries: command term, marks, answer spec, IB-style markscheme (M/A/R/AG), worked
   working, hint, known-error values (misconception detection) and a SymPy `verify` expression
   that tests/verify_answers.py re-derives independently. */
(function (Hub) {
  'use strict';
  function rng(seed) {
    let a = (seed >>> 0) || 1;
    const next = () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    const R = {
      next,
      int: (lo, hi) => lo + Math.floor(next() * (hi - lo + 1)),
      pick: arr => arr[Math.floor(next() * arr.length)],
      nz: (lo, hi) => { let v; do v = lo + Math.floor(next() * (hi - lo + 1)); while (v === 0); return v; },
      bool: () => next() < 0.5,
      shuffle: arr => { const b = arr.slice(); for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(next() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; } return b; },
      distinct: (n, lo, hi, avoid = []) => { const out = []; let guard = 0; while (out.length < n && guard++ < 999) { const v = lo + Math.floor(next() * (hi - lo + 1)); if (!out.includes(v) && !avoid.includes(v)) out.push(v); } return out; }
    };
    return R;
  }
  const gcd = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a || 1; };
  class F {
    constructor(n, d = 1) { if (d === 0) throw Error('zero denominator'); if (d < 0) { n = -n; d = -d; } const g = gcd(n, d); this.n = n / g; this.d = d / g; }
    static of(x) { return x instanceof F ? x : new F(x, 1); }
    add(o) { o = F.of(o); return new F(this.n * o.d + o.n * this.d, this.d * o.d); }
    sub(o) { o = F.of(o); return new F(this.n * o.d - o.n * this.d, this.d * o.d); }
    mul(o) { o = F.of(o); return new F(this.n * o.n, this.d * o.d); }
    div(o) { o = F.of(o); return new F(this.n * o.d, this.d * o.n); }
    neg() { return new F(-this.n, this.d); }
    pow(k) { let r = new F(1); const b = k < 0 ? new F(this.d, this.n) : this; for (let i = 0; i < Math.abs(k); i++) r = r.mul(b); return r; }
    val() { return this.n / this.d; }
    isInt() { return this.d === 1; }
    tex() { return this.d === 1 ? String(this.n) : (this.n < 0 ? `-\\frac{${-this.n}}{${this.d}}` : `\\frac{${this.n}}{${this.d}}`); }
    py() { return this.d === 1 ? String(this.n) : `Rational(${this.n},${this.d})`; }
    eq(o) { o = F.of(o); return this.n === o.n && this.d === o.d; }
  }
  const fr = (n, d = 1) => new F(n, d);
  const T = x => x instanceof F ? x.tex() : num(x);
  function num(x) { if (Number.isInteger(x)) return String(x); const r = Number(x.toPrecision(12)); return String(r); }
  function round(x, dp) { const m = Math.pow(10, dp); return Math.round((x + Number.EPSILON * Math.sign(x)) * m) / m; }
  function sf(x, s = 3) { if (x === 0) return 0; return Number(x.toPrecision(s)); }
  /** "+ 3" / "- 3" for joining terms; coefficient formatting for polynomials. */
  function poly(terms, first = true) { // terms: [[coef, '<tex var>'], ...]
    let out = '';
    for (const [c0, v] of terms) {
      const c = F.of(c0); if (c.n === 0) continue;
      const neg = c.n < 0, a = neg ? c.neg() : c;
      let body = v ? ((a.n === 1 && a.d === 1) ? v : (a.d === 1 ? `${a.n}${v}` : `${a.tex()}${v}`)) : a.tex();
      if (!out) out = (neg ? '-' : '') + body; else out += (neg ? ' - ' : ' + ') + body;
    }
    return out || '0';
  }
  const lin = (a, b, v = 'x') => poly([[a, v], [b, '']]);
  const sgn = c => (F.of(c).n < 0 ? ` - ${F.of(c).neg().tex()}` : ` + ${F.of(c).tex()}`);
  const paren = x => (F.of(x).n < 0 ? `(${T(x)})` : T(x));
  function comb(n, r) { if (r < 0 || r > n) return 0; let c = 1; for (let i = 1; i <= r; i++) c = c * (n - r + i) / i; return Math.round(c); }
  function factorial(n) { let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; }
  /** Build a multiple-choice answer: options [{tex, key}], correct key; shuffled with seeded rng. */
  function mc(R, options, correctKey) { const sh = R.shuffle(options); return { kind: 'mc', choices: sh.map(o => o.tex), keys: sh.map(o => o.key), correct: sh.findIndex(o => o.key === correctKey) }; }
  const pyF = x => x instanceof F ? x.py() : String(x);

  const registry = {};
  /** meta: {skill, title, paper:1|2, challenge?:bool} ; gen(R, opts) → {stem, parts, calc?, numworks?} */
  function reg(id, meta, gen) { registry[id] = Object.assign({ id, gen }, meta); }

  let counter = 0;
  function build(genId, seed, opts = {}) {
    const g = registry[genId]; if (!g) throw Error('Unknown generator ' + genId);
    const R = rng(seed * 7919 + genId.length * 104729 + (opts.challenge ? 31 : 0));
    const q = g.gen(R, opts);
    const course = g.skill.slice(0, 2);
    q.parts.forEach((p, i) => {
      p.label = p.label || String.fromCharCode(97 + i); p.id = p.label; p.ms = p.ms || []; p.working = p.working || [];
      // keep only misconception values that are finite and differ from the correct answer
      const same = (u, v) => Math.abs(u - v) <= 1e-9 * Math.max(1, Math.abs(v));
      p.errors = (p.errors || []).filter(e => {
        if (e.choice !== undefined) return true;
        const ev = Array.isArray(e.value) ? e.value : [e.value];
        if (!ev.every(Number.isFinite)) return false;
        if (p.answer.kind === 'num') return !same(ev[0], p.answer.value);
        if (p.answer.kind === 'tuple') return !(ev.length === p.answer.value.length && ev.every((v, j) => same(v, p.answer.value[j])));
        if (p.answer.kind === 'list') { const a = ev.slice().sort((u, v) => u - v), b = p.answer.value.slice().sort((u, v) => u - v); return !(a.length === b.length && a.every((v, j) => same(v, b[j]))); }
        return true;
      });
    });
    return Object.assign({
      id: 'q' + Date.now().toString(36) + (counter++).toString(36) + Math.floor(Math.random() * 1e4).toString(36),
      gen: genId, seed, skill: g.skill, course, title: g.title, paper: q.paper || g.paper, calc: (q.paper || g.paper) === 2,
      challenge: !!opts.challenge, marks: q.parts.reduce((s, p) => s + p.marks, 0)
    }, q);
  }

  /* ---------- Book-exercise questions (new questions written for each Oxford exercise; no book text) ----------
     bx('SL', '1O', {page, sec, skill, paper}, [ {stem, fig, paper, skill, parts: [{c, p, m, a, ms, w, v, h, e, fig, kfig}]} ])
     a: number | {n, sf|dp|exact, d (display TeX)} | {f: [num, den]} | {mc: ['$right$', '$wrong$', …]} | {t: [...], l: [labels]} | {list: [...]} | 'open' */
  const bxIndex = {};
  function bxAnswer(a, R) {
    if (a === 'open') return { kind: 'open' };
    if (typeof a === 'number') return { kind: 'num', value: a, exact: true, display: num(a) };
    if (a.mc) { const m = mc(R, a.mc.map((tex, i) => ({ tex, key: 'k' + i })), 'k0'); return Object.assign(m, { display: a.mc[0].replace(/^\$|\$$/g, '') }); }
    if (a.f) { const q = fr(a.f[0], a.f[1]); return { kind: 'num', value: q.val(), exact: true, display: a.d || q.tex() }; }
    if (a.t) return { kind: 'tuple', labels: a.l || a.t.map((_, i) => String.fromCharCode(97 + i)), value: a.t.map(v => Array.isArray(v) ? v[0] / v[1] : v), markEach: !!a.each, exact: a.sf ? false : true, sf: a.sf, display: a.d || a.t.map(v => Array.isArray(v) ? fr(v[0], v[1]).tex() : num(v)).join(',\\ ') };
    if (a.list) return { kind: 'list', value: a.list.map(v => Array.isArray(v) ? v[0] / v[1] : v), exact: a.sf ? false : true, sf: a.sf, display: a.d || a.list.map(v => Array.isArray(v) ? fr(v[0], v[1]).tex() : num(v)).join(',\\ ') };
    const out = { kind: 'num', value: a.n, display: a.d || num(a.sf ? sf(a.n, a.sf) : a.dp !== undefined ? round(a.n, a.dp) : a.n) };
    if (a.sf) out.sf = a.sf; else if (a.dp !== undefined) out.dp = a.dp; else out.exact = true; if (a.int) out.int = true;
    return out;
  }
  function bx(course, ex, meta, list) {
    const key = course + '-' + ex, ids = [];
    list.forEach((q, i) => {
      const id = `bx.${course}.${ex}.${i + 1}`; ids.push(id);
      reg(id, { skill: q.skill || meta.skill, title: `Exercise ${ex} · Question ${i + 1}`, paper: q.paper || meta.paper || 1, book: { course, ex, n: i + 1, page: meta.page, sec: meta.sec } }, R => ({
        stem: q.stem || '', fig: q.fig || '', paper: q.paper || meta.paper || 1,
        parts: q.parts.map((p, j) => ({ label: p.l || (q.parts.length > 1 ? String.fromCharCode(97 + j) : 'a'), command: p.c, prompt: p.p, marks: p.m || 1, answer: bxAnswer(p.a, R),
          ms: p.ms || [], working: p.w || [], hint: p.h || '', errors: (p.e || []).map(e => Object.assign({ tag: String(e.fb || 'slip').replace(/[.:;,]+$/, '').slice(0, 70) }, e)), verify: p.v || '', fig: p.fig || '', kfig: p.kfig || '' }))
      }));
    });
    bxIndex[key] = Object.assign({ course, ex, qs: ids, title: meta.title || '' }, meta);
  }

  /* ---------- Small SVG graphs for questions and model answers ----------
     plot({x:[-6,6], y:[-6,6], f:[{f: x => ..., from, to, dash}], pts:[[x, y, 'label']], vl:[x…], hl:[y…], w, h, labels}) */
  function plot(o) {
    const W = o.w || 280, H = o.h || 240, P = 22, [x0, x1] = o.x || [-6, 6], [y0, y1] = o.y || [-6, 6];
    const X = x => P + (x - x0) / (x1 - x0) * (W - 2 * P), Y = y => H - P - (y - y0) / (y1 - y0) * (H - 2 * P), r1 = v => Math.round(v * 10) / 10;
    let g = '';
    const [sx, sy] = o.step || [1, 1];
    if (o.grid !== false) { for (let i = Math.ceil(x0 / sx) * sx; i <= x1; i += sx) g += `<line x1="${r1(X(i))}" y1="${P}" x2="${r1(X(i))}" y2="${H - P}" class="pg"/>`; for (let j = Math.ceil(y0 / sy) * sy; j <= y1; j += sy) g += `<line x1="${P}" y1="${r1(Y(j))}" x2="${W - P}" y2="${r1(Y(j))}" class="pg"/>`; }
    if (y0 <= 0 && y1 >= 0) g += `<line x1="${P - 4}" y1="${r1(Y(0))}" x2="${W - P + 6}" y2="${r1(Y(0))}" class="pa"/><text x="${W - P + 8}" y="${r1(Y(0)) + 4}" class="pt">x</text>`;
    if (x0 <= 0 && x1 >= 0) g += `<line x1="${r1(X(0))}" y1="${H - P + 4}" x2="${r1(X(0))}" y2="${P - 6}" class="pa"/><text x="${r1(X(0)) - 4}" y="${P - 9}" class="pt">y</text>`;
    (o.vl || []).forEach(v => { g += `<line x1="${r1(X(v))}" y1="${P}" x2="${r1(X(v))}" y2="${H - P}" class="pd"/>`; });
    (o.hl || []).forEach(v => { g += `<line x1="${P}" y1="${r1(Y(v))}" x2="${W - P}" y2="${r1(Y(v))}" class="pd"/>`; });
    g += `<g clip-path="url(#c${W}${H})">`;
    (o.f || []).forEach(c => {
      const a = c.from ?? x0, b = c.to ?? x1, n = 240; let d = '', pen = false;
      for (let i = 0; i <= n; i++) { const x = a + (b - a) * i / n, y = c.f(x); if (!Number.isFinite(y) || y < y0 - (y1 - y0) || y > y1 + (y1 - y0)) { pen = false; continue; } d += (pen ? 'L' : 'M') + r1(X(x)) + ' ' + r1(Y(y)); pen = true; }
      g += `<path d="${d}" class="pf${c.dash ? ' dash' : ''}"/>`;
    });
    g += '</g>';
    (o.pts || []).forEach(([x, y, lab, pos]) => { g += `<circle cx="${r1(X(x))}" cy="${r1(Y(y))}" r="3.2" class="pp"/>`; if (lab) g += `<text x="${r1(X(x)) + (pos === 'l' ? -6 : 6)}" y="${r1(Y(y)) + (pos === 'b' ? 14 : -6)}" class="pt"${pos === 'l' ? ' text-anchor="end"' : ''}>${lab}</text>`; });
    (o.labels || []).forEach(([x, y, lab]) => { g += `<text x="${r1(X(x))}" y="${r1(Y(y))}" class="pt">${lab}</text>`; });
    return `<svg class="qplot" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="${o.alt || 'Graph'}"><defs><clipPath id="c${W}${H}"><rect x="${P}" y="${P}" width="${W - 2 * P}" height="${H - 2 * P}"/></clipPath></defs>${g}</svg>`;
  }

  Hub.qcore = { rng, F, fr, T, num, round, sf, poly, lin, sgn, paren, comb, factorial, mc, pyF, gcd, reg, registry, build, bx, bxIndex, plot };
})(window.Hub = window.Hub || {});
