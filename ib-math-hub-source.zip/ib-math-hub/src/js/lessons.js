/* Lesson notebooks — one interactive notebook per calendar lesson, released by Miss Badmus to each day (A then B).
   Stored in the cloud as settings['lesson:<id>'] (teacher-only writes, merged per lesson so two lessons never clash).
   A student's own notebook answers are saved in progress['<sid>|nb:<lessonId>'] (the server only lets students write their own).
   Sections: Do Now link · slide deck · key ideas (guided notes with blanks) · extra worked examples (optional, line-by-line reveal)
   · Your turn (optional practice, never graded) · Exit Ticket and homework (assigned) · my own notes (optional) · reflection. */
(function (Hub) {
  'use strict';
  const { esc, $, $$, fmtDate, fmtDateTime, toast, debounce } = Hub.core;
  const U = Hub.ui, C = () => Hub.curriculum, S = () => Hub.store.state, M = t => Hub.math.render(t);
  const go = h => Hub.app.nav(h);
  const KEY = 'lesson:', NB = 'nb:';
  const groupsOf = course => [course + '-A', course + '-B'];
  const nowISO = () => new Date().toISOString();
  const newSeed = () => Math.floor(Math.random() * 1e6) + 1;

  /* ================= storage ================= */
  function all() { const s = S().settings || {}; return Object.keys(s).filter(k => k.startsWith(KEY)).map(k => s[k]).filter(v => v && v.id); }
  const get = id => (S().settings || {})[KEY + id] || null;
  function put(L) { L.updatedAt = nowISO(); S().settings[KEY + L.id] = L; Hub.store.save(); }
  function remove(id) { delete S().settings[KEY + id]; Hub.store.save(); }
  const firstDate = L => [L.dates.A, L.dates.B].filter(Boolean).sort()[0] || '';

  /* ================= calendar: pair the A-day and B-day rows of the same lesson ================= */
  function calendar(course) {
    const rows = g => C().lessons(g).filter(l => l.kind !== 'none');
    const A = rows(course + '-A'), B = rows(course + '-B'), out = []; let j = 0;
    const row = (a, b) => { const r = a || b; return { id: course + '-' + r.date, course, title: r.activity, dates: { A: a ? a.date : null, B: b ? b.date : null }, skills: r.skills.slice(), kind: r.kind }; };
    for (const a of A) {
      let k = -1; for (let t = j; t < Math.min(B.length, j + 4); t++) if (B[t].activity === a.activity) { k = t; break; }
      if (k < 0) { out.push(row(a, null)); continue; }
      for (let t = j; t < k; t++) out.push(row(null, B[t]));
      out.push(row(a, B[k])); j = k + 1;
    }
    for (; j < B.length; j++) out.push(row(null, B[j]));
    return out.sort((x, y) => firstDate(x).localeCompare(firstDate(y)));
  }
  /** Lesson id for a group's calendar date (used by the dashboard's "Notebook" buttons). */
  function idFor(groupId, date) { const g = C().GROUPS[groupId]; const r = calendar(g.course).find(x => x.dates[g.day] === date); return r ? r.id : null; }

  /* ================= release ================= */
  const visibleTo = (L, g) => !!(L.release && L.release[g] && L.release[g] <= nowISO());
  function relLabel(L, g) {
    const r = L.release && L.release[g];
    if (!r) return ['Hidden', 'grey'];
    return r <= nowISO() ? ['Released ' + fmtDate(r), 'green'] : ['Opens ' + fmtDate(r) + ', 7:00', 'amber'];
  }
  function setRelease(L, g, act) {
    L.release = L.release || {};
    if (act === 'now') L.release[g] = nowISO();
    else if (act === 'hide') delete L.release[g];
    else if (act === 'sched') { const d = L.dates[g.slice(-1)]; if (!d) return false; L.release[g] = new Date(d + 'T07:00:00').toISOString(); }
    put(L); Hub.store.log(`Notebook “${L.title}” · ${C().GROUPS[g].label}: ${act === 'hide' ? 'hidden' : act === 'now' ? 'released' : 'scheduled'}`); return true;
  }

  /* ================= questions (rebuilt from generator + seed, so everyone sees the same numbers) ================= */
  const gensFor = skills => [...new Set(skills.flatMap(id => (C().SKILL[id] || { gens: [] }).gens))].filter(g => Hub.qcore.registry[g]);
  function buildQ(spec, id) { try { const q = Hub.qcore.build(spec.gen, spec.seed, { challenge: !!spec.challenge }); q.id = id; return q; } catch (e) { return null; } }
  const hashSeed = str => { let h = 2166136261; for (const c of String(str)) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return (Math.abs(h) % 1e6) + 1; };
  /** Two extra worked examples with new numbers for the lesson's skills (the same for every student). */
  const defaultExamples = (skills, id) => { const gens = gensFor(skills || []); return gens.length ? [0, 1].map(i => ({ gen: gens[i % gens.length], seed: hashSeed(id + ':ex' + i) })) : []; };
  const exampleSpecs = L => (L.examples && L.examples.length) || L.extraSet ? (L.examples || []) : defaultExamples(L.skills, L.id);
  const examplesOf = L => exampleSpecs(L).map((s, i) => buildQ(s, 'ex' + i)).filter(Boolean);
  /** Teacher-typed example cards with something to show (textbook page references alone are not shown). */
  const ownExamples = L => (L.myExamples || []).filter(e => (e.q || '').trim() || (e.steps || '').trim());
  const tasksOf = L => (L.tasks || []).map((s, i) => buildQ(s, 'yt' + i)).filter(Boolean);

  function create(row) {
    const gens = gensFor(row.skills);
    const L = { id: row.id, course: row.course, title: row.title, dates: row.dates, eq: '', skills: row.skills.slice(), deck: null, doNow: true,
      examples: defaultExamples(row.skills, row.id), extraSet: true, myExamples: [], keyIdeas: Hub.guidedNotes ? Hub.guidedNotes.text(row.id) : '', notesFilled: true, homeworkId: null,
      tasks: gens.length ? [0, 1, 2].map(i => ({ gen: gens[i % gens.length], seed: newSeed() })) : [],
      exitTicketId: null, homework: '', homeworkUrl: '', reflect: true, release: {}, createdAt: nowISO() };
    put(L); Hub.store.log(`Created lesson notebook “${L.title}”`); return L;
  }

  /* ================= slide decks: turn a pasted link (or embed code) into something that can be shown in the page ================= */
  function deckFrom(raw) {
    let s = String(raw || '').trim(); if (!s) return null;
    const m = s.match(/<iframe[^>]*\ssrc=["']([^"']+)["']/i); if (m) s = m[1];
    s = s.replace(/&amp;/g, '&');
    if (!/^https:\/\//i.test(s)) return { url: raw.trim(), error: 'Paste a link that starts with https:// (or the embed code from Share → Embed).' };
    let u; try { u = new URL(s); } catch (e) { return { url: raw.trim(), error: 'That link is not valid.' }; }
    const h = u.hostname; let g;
    if ((g = s.match(/docs\.google\.com\/presentation\/d\/e\/([\w-]+)/))) return { url: raw.trim(), kind: 'Google Slides (published)', embed: `https://docs.google.com/presentation/d/e/${g[1]}/embed?start=false&loop=false&delayms=3000`, open: `https://docs.google.com/presentation/d/e/${g[1]}/pub` };
    if ((g = s.match(/docs\.google\.com\/presentation\/d\/([\w-]+)/))) return { url: raw.trim(), kind: 'Google Slides', embed: `https://docs.google.com/presentation/d/${g[1]}/embed?start=false&loop=false&delayms=3000`, open: `https://docs.google.com/presentation/d/${g[1]}/view` };
    if ((g = s.match(/drive\.google\.com\/file\/d\/([\w-]+)/)) || (h === 'drive.google.com' && u.searchParams.get('id') && (g = [0, u.searchParams.get('id')]))) return { url: raw.trim(), kind: 'Google Drive file (PowerPoint or PDF)', embed: `https://drive.google.com/file/d/${g[1]}/preview`, open: `https://drive.google.com/file/d/${g[1]}/view` };
    if (/(^|\.)canva\.com$/.test(h) && /\/design\//.test(u.pathname)) { const base = s.split('?')[0].replace(/\/(edit|view|watch)\/?$/, '') + '/view'; return { url: raw.trim(), kind: 'Canva', embed: base + '?embed', open: base }; }
    if (/(onedrive\.live\.com|1drv\.ms|sharepoint\.com|officeapps\.live\.com|office\.com)$/.test(h)) return { url: raw.trim(), kind: 'PowerPoint online', embed: s, open: s, note: /embed/.test(s) ? '' : 'For PowerPoint online, use File → Share → Embed and paste the embed code here, so it shows inside the page.' };
    return { url: raw.trim(), kind: 'Web page', embed: s, open: s };
  }
  const deckHTML = d => d && d.embed ? `<div class="deck"><iframe src="${esc(d.embed)}" title="Lesson slides" loading="lazy" allowfullscreen allow="fullscreen" referrerpolicy="strict-origin-when-cross-origin"></iframe></div><p class="tiny"><a href="${esc(d.open)}" target="_blank" rel="noopener">Open the slides in a new tab ↗</a></p>` : '';

  /* ================= guided notes with [[blanks]] ================= */
  const BLANK = /\[\[([^\]]+)\]\]/g;
  const blanksOf = text => { const out = []; String(text || '').replace(BLANK, (m, a) => { out.push(a.split('|').map(x => x.trim()).filter(Boolean)); return m; }); return out; };
  const norm = s => String(s ?? '').toLowerCase().replace(/−/g, '-').replace(/²/g, '^2').replace(/³/g, '^3').replace(/π/g, 'pi').replace(/√/g, 'sqrt').replace(/×/g, '*').replace(/÷/g, '/').replace(/\s+/g, ' ').replace(/[.\s]+$/, '').trim();
  function blankOK(ans, val) {
    const v = norm(val); if (!v) return false;
    return ans.some(a => { if (norm(a) === v || norm(a).replace(/\s/g, '') === v.replace(/\s/g, '')) return true; const x = Hub.math.parse(a), y = Hub.math.parse(val); return !x.error && !y.error && Math.abs(x.value - y.value) <= 1e-9 * Math.max(1, Math.abs(x.value)); });
  }
  /** Numbers typed as 1/2 show stacked (her fraction rule); words show as written. */
  const showAns = a => { const r = Hub.math.parse(a); return r.error ? M(a) : Hub.math.texToMathML(r.tex, false); };
  function notesHTML(text, vals, o) {
    let i = 0, html = '', inList = false;
    const inline = line => line.split(/(\[\[[^\]]+\]\])/).map(ch => {
      const m = ch.match(/^\[\[([^\]]+)\]\]$/); if (!m) return M(ch);
      const k = i++, ans = m[1].split('|')[0].trim();
      if (o.key) return `<mark class="blank-key">${showAns(ans)}</mark>`;
      return `<span class="blank-wrap"><input class="blank" data-mathpad="symbols" data-b="${k}" size="${Math.max(5, Math.min(26, ans.length + 3))}" value="${esc(vals[k] || '')}" aria-label="Blank ${k + 1}" autocomplete="off" spellcheck="false" ${o.dis}><span class="blank-fb" data-bfb="${k}"></span></span>`;
    }).join('');
    for (const raw of String(text || '').split('\n')) {
      const line = raw.replace(/\s+$/, '');
      if (/^\s*[-•]\s+/.test(line)) { if (!inList) { html += '<ul class="nb-list">'; inList = true; } html += `<li>${inline(line.replace(/^\s*[-•]\s+/, ''))}</li>`; continue; }
      if (inList) { html += '</ul>'; inList = false; }
      if (!line.trim()) continue;
      html += /^##\s+/.test(line) ? `<h3 class="nb-h">${inline(line.replace(/^##\s+/, ''))}</h3>` : `<p>${inline(line)}</p>`;
    }
    return html + (inList ? '</ul>' : '');
  }

  /* ================= worked examples: question on one half, solution revealed one line at a time on the other ================= */
  function exampleHTML(q, n, showAll) {
    const steps = [];
    q.parts.forEach(p => {
      steps.push(`<div class="step part-tag">(${esc(p.label)})</div>`);
      p.working.forEach(w => steps.push(`<div class="step">${M(w)}</div>`));
      steps.push(`<div class="step ans-step"><span class="key-lab">Answer</span> ${U.answerDisplay(p)}</div>`);
      if (p.numworks) steps.push(`<div class="step">${U.numworks(p.numworks)}</div>`);
    });
    return `<article class="ex" data-ex="${q.id}"><div class="ex-q"><div class="q-head"><span class="q-num">${n}</span><div class="q-meta">${U.skillChip(q.skill)} ${U.paperBadge(q.paper)}</div></div>${q.stem ? `<div class="q-stem">${M(q.stem)}</div>` : ''}${q.parts.map(p => `<div class="ex-pq"><b>(${esc(p.label)})</b> ${U.cmd(p.command)} ${M(p.prompt)} <span class="tiny muted">[${p.marks}]</span></div>`).join('')}</div>
      <div class="ex-sol"><div class="hand ex-steps">${steps.map(s => showAll ? s : s.replace('class="step', 'hidden class="step')).join('')}</div>
      ${showAll ? '' : `<div class="actions"><button type="button" class="btn small primary" data-next="${q.id}">Show next step</button><button type="button" class="btn small ghost" data-allsteps="${q.id}">Show all</button></div>`}</div></article>`;
  }

  /** A worked example typed by Miss Badmus (e.g. the textbook example used on her slides): question left, steps revealed one line at a time. */
  function myExampleHTML(e, i, showAll) {
    const steps = String(e.steps || '').split('\n').map(x => x.trim()).filter(Boolean).map(w => `<div class="step">${M(w)}</div>`);
    return `<article class="ex${steps.length ? '' : ' ref-only'}" data-ex="my${i}"><div class="ex-q"><div class="q-head"><span class="q-num">${i + 1}</span>${e.ref ? `<div class="q-meta"><span class="pill blue">${esc(e.ref)}</span></div>` : ''}</div>${(e.q || '').trim() ? `<div class="q-stem">${M(e.q)}</div>` : ''}</div>
      ${steps.length ? '' : '<!--'}<div class="ex-sol"><div class="hand ex-steps">${steps.map(x => showAll ? x : x.replace('class="step', 'hidden class="step')).join('')}</div>${showAll || !steps.length ? '' : `<div class="actions"><button type="button" class="btn small primary" data-next="my${i}">Show next step</button><button type="button" class="btn small ghost" data-allsteps="my${i}">Show all</button></div>`}</div>${steps.length ? '' : '-->'}</article>`;
  }
  /** Exit Ticket / homework from the Assessment Studio, as a link that works for students (their own day's due date) and in the teacher's preview. */
  function linkedTask(a, label, ctx, sid) {
    if (!a) return ctx.teacher ? `<p class="muted">The ${label} linked here no longer exists.</p>` : '';
    const meta = `<b>${esc(a.title)}</b> · ${a.questions.length} question${a.questions.length > 1 ? 's' : ''}`;
    if (ctx.preview || ctx.teacher || !sid) return `<p>${meta}${a.status === 'published' ? '' : ' · <span class="pill amber">not published yet</span>'}</p><a class="btn primary" href="#/preview/${a.id}">Open the ${label} →</a><p class="tiny muted">${a.status === 'published' ? 'Students start it from this button.' : 'Students can start it here once you publish it.'}</p>`;
    const st = Hub.roster.byId(sid), t = Hub.assess.attemptsFor(a.id, sid).pop(), open = Hub.assess.forStudent(sid).some(x => x.id === a.id), due = Hub.assess.dueFor(a, st && st.group);
    if (t) return `<p>${meta} · done ✓</p><a class="btn ghost" href="#/result/${t.id}">See my feedback →</a>`;
    if (open) return `<p>${meta}${due ? ' · due ' + fmtDate(due, true) : ''}</p><a class="btn primary" href="#/task/${a.id}">Start the ${label} →</a>`;
    return `<p class="muted">The ${label} opens here when Miss Badmus publishes it.</p>`;
  }
  /* ================= the notebook page (student view; also teacher preview and read-only response view) ================= */
  const opt = t => `<span class="sec-tag opt">${t}</span>`, req = t => `<span class="sec-tag req">${t}</span>`;
  /** Each section folds away: tap its heading to open it. */
  function sectionCard(n, title, cls, body, open) { return `<section class="card nb-sec ${cls}" id="nb-${cls}"><details class="nb-det" data-sec="${cls}" ${open ? 'open' : ''}><summary><h2 class="nb-sec-h"><span class="nb-n">${n}</span>${title}<span class="nb-chev" aria-hidden="true"></span></h2></summary><div class="nb-body">${body}</div></details></section>`; }
  /** Which sections a student left open in this notebook (this browser only). Slides and the Do Now start open. */
  const OPEN_KEY = id => 'hub-nb-open:' + id;
  function openSecs(id) { try { const v = JSON.parse(localStorage.getItem(OPEN_KEY(id))); if (Array.isArray(v)) return v; } catch (e) { /* no storage */ } return ['donow', 'slides']; }
  function rememberOpen(id, root) { try { localStorage.setItem(OPEN_KEY(id), JSON.stringify($$('details.nb-det[open]', root).map(d => d.dataset.sec))); } catch (e) { /* no storage */ } }
  function notebookHTML(L, ctx) {
    const r = ctx.resp || {}, dis = ctx.readOnly ? 'disabled' : '', sid = ctx.sid;
    const secs = []; let n = 0, opened = ctx.readOnly || ctx.key ? null : openSecs(L.id);
    const add = (title, cls, body) => { if (body) secs.push(sectionCard(++n, title, cls, body, !opened || opened.includes(cls))); };
    // Do Now
    if (L.doNow) {
      let body;
      if (ctx.preview || !sid) body = '<p>Students see a link to their own personalised Do Now here once you publish it.</p>';
      else { const d = Hub.donow.forStudent(sid); body = d ? (d.done ? `<p>Done — <b>${Hub.assess.score(d.done).earned}/${d.done.max}</b>. <a href="#/result/${d.done.id}">See feedback</a></p>` : `<p>Your personalised Do Now is ready.</p><a class="btn primary" href="#/donow">Start my Do Now →</a>`) : '<p class="muted">Your Do Now appears here when Miss Badmus publishes it.</p>'; }
      add('☀ Do Now', 'donow', body);
    }
    if (L.deck && L.deck.embed) add('Slides', 'slides', deckHTML(L.deck));
    if (blanksOf(L.keyIdeas).length || (L.keyIdeas || '').trim()) {
      const nb = blanksOf(L.keyIdeas).length;
      add('Key ideas', 'notes', `<div class="nb-notes" id="nb-notes">${notesHTML(L.keyIdeas, (r.blanks || {}), { dis, key: ctx.key })}</div>${nb && !ctx.key ? `<div class="actions"><button type="button" class="btn small" id="check-notes" ${dis}>Check my notes</button><button type="button" class="btn small ghost" id="show-notes" ${r.notesChecked || ctx.readOnly ? '' : 'hidden'}>Show the answers</button><span class="tiny muted" id="notes-score"></span></div>` : ''}`);
    }
    const ex = examplesOf(L), mine = ownExamples(L);
    if (ex.length || mine.length) add(`Extra worked examples ${opt('Optional · extra support')}`, 'examples', `<p class="tiny muted">Optional — extra support if you want more examples. Try each one first, then reveal the solution one line at a time.</p>${mine.map((e, i) => myExampleHTML(e, i, ctx.key)).join('')}${ex.map((q, i) => exampleHTML(q, mine.length + i + 1, ctx.key)).join('')}`);
    const ts = tasksOf(L);
    if (ts.length) add(`Your turn ${opt('Optional practice · not graded')}`, 'yourturn', `<p class="tiny muted">Optional practice — not graded. Check each answer straight away. Use the maths keys at the bottom of the screen for fractions, √ and π.</p><form id="yt-form" novalidate>${ts.map((q, i) => U.question(q, i, { mode: ctx.key ? 'teacher' : 'answer', responses: r.tasks || {}, hints: !ctx.readOnly, disabled: ctx.readOnly, footer: ctx.key ? '' : `<div class="yt-foot"><button type="button" class="btn small" data-check="${q.id}" ${dis}>Check my answer</button><button type="button" class="btn small ghost" data-sol="${q.id}" ${(r.checked || {})[q.id] || ctx.readOnly ? '' : 'hidden'}>Show the solution</button></div><div class="yt-fb" id="fb-${q.id}"></div><div class="yt-sol" id="sol-${q.id}" hidden></div>` })).join('')}</form>`);
    if (L.exitTicketId) add(`Exit Ticket ${req('Assigned')}`, 'exit', linkedTask(Hub.assess.byId(L.exitTicketId), 'Exit Ticket', ctx, sid));
    const hwA = L.homeworkId ? Hub.assess.byId(L.homeworkId) : null;
    if (hwA || L.homeworkId || (L.homework || '').trim() || L.homeworkUrl) add(`Homework ${req('Assigned')}`, 'homework', `${L.homeworkId ? linkedTask(hwA, 'homework', ctx, sid) : ''}${L.homework ? `<p class="hw">${M(L.homework)}</p>` : ''}${/^https:\/\//.test(L.homeworkUrl || '') ? `<p><a class="btn small" href="${esc(L.homeworkUrl)}" target="_blank" rel="noopener">Open the homework ↗</a> <code class="link-text">${esc(L.homeworkUrl.replace(/^https?:\/\//, ''))}</code></p>` : ''}`);
    if (!ctx.key) add(`My own notes ${opt('Optional')}`, 'mine', `<p class="tiny muted">Optional — make this page your own. Add a photo of your handwritten notes, or type your own notes. For maths, tap the maths keys: fractions, √, powers, π.</p><div id="mine-list">${mineHTML(r.mine || [], ctx)}</div>${ctx.readOnly ? '' : `<div class="actions mine-add"><label class="btn small primary file-btn"><input type="file" accept="image/*" data-mine-photo capture="environment" aria-label="Add a photo of my notes"> 📷 Add a photo of my notes</label><button type="button" class="btn small" data-mine-add="note">+ Type a note</button><button type="button" class="btn small" data-mine-add="example">+ My worked example</button><button type="button" class="btn small" data-mine-add="term">+ Key word</button></div>`}`);
    if (L.reflect !== false) add('Reflection', 'reflect', `<fieldset class="rag"><legend>How confident do you feel about today’s lesson?</legend>${[['red', 'I’m stuck'], ['amber', 'Getting there'], ['green', 'I’ve got it']].map(([v, t]) => `<label class="rag-opt ${v}"><input type="radio" name="rag" value="${v}" ${r.rag === v ? 'checked' : ''} ${dis}> ${t}</label>`).join('')}</fieldset>
      <label>One thing I learned today<textarea id="nb-learned" rows="2" ${dis}>${esc(r.learned || '')}</textarea></label><label>A question I still have <span class="tiny muted">(Miss Badmus reads these)</span><textarea id="nb-question" rows="2" ${dis}>${esc(r.question || '')}</textarea></label>`);
    const eq = L.eq ? `<div class="eq-strip"><span class="eq-tag">Essential question</span> ${M(L.eq)}</div>` : '';
    const tools = secs.length > 2 ? `<div class="nb-tools no-print"><span class="tiny muted">Tap a heading to open or close it.</span><button type="button" class="btn small ghost" data-nb-all="open">Open all</button><button type="button" class="btn small ghost" data-nb-all="close">Close all</button></div>` : '';
    return `${eq}<div class="chips nb-skills">${L.skills.map(s => U.skillChip(s)).join('')}</div>${tools}${secs.join('') || U.empty('This notebook is still empty.')}`;
  }
  /** Student-built blocks: note, example, key word, photo. Editable for the student; read-only for the teacher. */
  const MINE = { note: 'Note', example: 'My worked example', term: 'Key word', photo: 'Photo of my notes' };
  const lines = t => String(t || '').split('\n').filter(x => x.trim()).map(x => `<div>${M(x)}</div>`).join('');
  function mineView(b) {
    if (b.type === 'term') return `<p><b>${esc(b.title || '')}</b>${b.text ? ' — ' + M(b.text) : ''}</p>`;
    if (b.type === 'example') return `${b.title ? `<p><b>${esc(b.title)}</b></p>` : ''}<div class="q-stem">${lines(b.q)}</div><div class="hand">${lines(b.steps)}</div>`;
    if (b.type === 'photo') return `${b.title ? `<p><b>${esc(b.title)}</b></p>` : ''}${b.upload ? `<figure class="mine-photo"><img data-up="${esc(b.upload.id)}" alt="${esc(b.title || 'Photo of notes')}"></figure>` : ''}`;
    return `${b.title ? `<p><b>${esc(b.title)}</b></p>` : ''}<div class="mine-text">${lines(b.text)}</div>`;
  }
  function mineHTML(list, ctx) {
    if (!list.length) return ctx.readOnly ? '<p class="tiny muted">Nothing added yet.</p>' : '';
    return list.map((b, i) => {
      if (ctx.readOnly) return `<article class="mine-blk"><span class="pill">${MINE[b.type] || 'Note'}</span>${mineView(b)}</article>`;
      const fld = (k, label, rows, ph) => rows ? `<div class="mfld"><span class="mfld-lab">${label}</span><textarea data-mi="${i}" data-mk="${k}" data-rich-ok rows="${rows}" placeholder="${esc(ph || 'Type here…')}">${esc(b[k] || '')}</textarea></div>` : `<label>${label}<input data-mi="${i}" data-mk="${k}" value="${esc(b[k] || '')}" placeholder="${esc(ph || '')}"></label>`;
      const body = b.type === 'term' ? fld('title', 'Key word') + fld('text', 'What it means', 2) : b.type === 'example' ? fld('title', 'Title (optional)', 0, 'e.g. My own version of Example 1') + fld('q', 'Question', 2) + fld('steps', 'My steps (press Enter for a new line)', 4) : b.type === 'photo' ? fld('title', 'Caption (optional)') : fld('title', 'Heading (optional)') + fld('text', 'My note', 3);
      return `<article class="mine-blk edit" data-mb="${i}"><div class="row-between"><span class="pill">${MINE[b.type] || 'Note'}</span><button type="button" class="btn small ghost danger" data-mine-del="${i}">Remove</button></div>${body}${b.type === 'photo' ? `<div class="mine-pv" data-mpv="${i}">${mineView(b)}</div>` : ''}</article>`;
    }).join('');
  }
  function loadPhotos(root) { $$('img[data-up]', root).forEach(img => { if (img.src) return; Hub.uploads.url(img.dataset.up).then(u => { if (u) img.src = u; }).catch(() => { img.replaceWith(Object.assign(document.createElement('p'), { className: 'tiny muted', textContent: 'Photo could not be loaded right now.' })); }); }); }
  /** Interactions for a rendered notebook. save(collected) is called on every change (debounced) unless read-only. */
  function bindNotebook(root, L, ctx) {
    const blanks = blanksOf(L.keyIdeas), ts = tasksOf(L), r = ctx.resp || {};
    const state = { notesChecked: !!r.notesChecked, checked: Object.assign({}, r.checked || {}), mine: JSON.parse(JSON.stringify(r.mine || [])) };
    const collect = () => {
      const out = { blanks: {}, tasks: {}, checked: state.checked, notesChecked: state.notesChecked, mine: state.mine, rag: '', learned: '', question: '' };
      $$('.blank', root).forEach(b => { if (b.value.trim()) out.blanks[b.dataset.b] = b.value; });
      const f = $('#yt-form', root); if (f && ts.length) out.tasks = U.readResponses(f, ts);
      const rag = $('input[name="rag"]:checked', root); out.rag = rag ? rag.value : '';
      out.learned = ($('#nb-learned', root) || {}).value || ''; out.question = ($('#nb-question', root) || {}).value || '';
      return out;
    };
    const saveNow = ctx.readOnly || !ctx.save ? () => {} : debounce(() => ctx.save(collect()), 600);
    // open / close sections (remembered in this browser for students)
    const remember = () => { if (!ctx.readOnly && !ctx.key) rememberOpen(L.id, root); };
    $$('details.nb-det', root).forEach(d => d.addEventListener('toggle', remember));
    $$('[data-nb-all]', root).forEach(b => (b.onclick = () => { const open = b.dataset.nbAll === 'open'; $$('details.nb-det', root).forEach(d => { d.open = open; }); remember(); }));
    root.addEventListener('input', saveNow); root.addEventListener('change', saveNow);
    // notes
    const markNotes = reveal => { let ok = 0; $$('.blank', root).forEach(b => { const k = Number(b.dataset.b), good = blankOK(blanks[k] || [], b.value), fb = $(`[data-bfb="${k}"]`, root); b.classList.toggle('good', good); b.classList.toggle('bad', !good); if (good) ok++; if (fb) fb.innerHTML = good ? '✓' : reveal ? `<span class="reveal">${showAns((blanks[k] || [''])[0])}</span>` : '✗'; }); const sc = $('#notes-score', root); if (sc) sc.textContent = `${ok}/${blanks.length} correct`; return ok; };
    const cn = $('#check-notes', root); if (cn) cn.onclick = () => { markNotes(false); state.notesChecked = true; const sn = $('#show-notes', root); if (sn) sn.hidden = false; saveNow(); };
    const sn = $('#show-notes', root); if (sn) sn.onclick = () => markNotes(true);
    if (state.notesChecked && blanks.length) markNotes(!!ctx.readOnly);
    // worked examples: one line at a time
    $$('[data-next]', root).forEach(b => (b.onclick = () => { const box = b.closest('.ex'), next = $('.step[hidden]', box); if (next) { next.hidden = false; next.classList.add('pop'); } if (!$('.step[hidden]', box)) { b.disabled = true; b.textContent = 'All steps shown'; } }));
    $$('[data-allsteps]', root).forEach(b => (b.onclick = () => { const box = b.closest('.ex'); $$('.step[hidden]', box).forEach(s => (s.hidden = false)); const nx = $('[data-next]', box); if (nx) { nx.disabled = true; nx.textContent = 'All steps shown'; } }));
    // your turn: self-check
    const f = $('#yt-form', root); if (f) U.bindPreviews(f);
    const check = qid => {
      const q = ts.find(x => x.id === qid), resp = U.readResponses(f, [q])[qid], box = $('#fb-' + qid, root);
      box.innerHTML = q.parts.map(p => { if (p.answer.kind === 'open') return `<div class="fb fb-wait"><b>(${esc(p.label)})</b> Write this one on paper, then compare with the solution.</div>`; const m = Hub.math.markPart(p, resp[p.id]); const [t, c] = m.verdict === 'correct' ? ['Correct ✓', 'ok'] : m.verdict === 'blank' ? ['Not answered yet', 'no'] : m.verdict === 'inexact' ? ['Right value — give it exactly', 'part'] : m.verdict === 'partial' ? ['Partly right', 'part'] : m.verdict === 'invalid' ? ['I can’t read that answer', 'no'] : ['Not yet — try again', 'no']; return `<div class="fb fb-${c}"><b>(${esc(p.label)})</b> <span class="verdict ${c}">${t}</span>${m.feedback ? ` <span class="small">${M(m.feedback)}</span>` : ''}</div>`; }).join('');
      state.checked[qid] = true; const sb = $(`[data-sol="${qid}"]`, root); if (sb) sb.hidden = false;
    };
    $$('[data-check]', root).forEach(b => (b.onclick = () => { check(b.dataset.check); saveNow(); }));
    $$('[data-sol]', root).forEach(b => (b.onclick = () => { const q = ts.find(x => x.id === b.dataset.sol), box = $('#sol-' + q.id, root); box.hidden = !box.hidden; if (!box.hidden && !box.innerHTML) box.innerHTML = q.parts.map(p => `<div class="yt-sol-part"><b>(${esc(p.label)})</b> <span class="key-lab">Answer</span> ${U.answerDisplay(p)}<div class="hand">${p.working.map(w => `<div>${M(w)}</div>`).join('')}</div>${U.numworks(p.numworks)}</div>`).join(''); b.textContent = box.hidden ? 'Show the solution' : 'Hide the solution'; }));
    if (ctx.readOnly) ts.forEach(q => { if ((r.checked || {})[q.id]) check(q.id); });
    // my own notes
    const mineBox = $('#mine-list', root);
    const rich = box => { if (box && Hub.mathpad && !ctx.readOnly) Hub.mathpad.richifyAll(box); };
    const redrawMine = () => { if (mineBox) { mineBox.innerHTML = mineHTML(state.mine, ctx); loadPhotos(mineBox); rich(mineBox); } };
    rich(mineBox);
    root.addEventListener('input', e => { const el = e.target.closest && e.target.closest('[data-mi]'); if (!el) return; const i = Number(el.dataset.mi); state.mine[i] = Object.assign({}, state.mine[i], { [el.dataset.mk]: el.value }); const pv = $(`[data-mpv="${i}"]`, root); if (pv && state.mine[i].type !== 'photo') pv.innerHTML = `<span class="key-lab">Shows as</span>${mineView(state.mine[i])}`; });
    root.addEventListener('click', e => {
      const a = e.target.closest && e.target.closest('[data-mine-add]'); if (a) { state.mine.push({ type: a.dataset.mineAdd, title: '', text: '', q: '', steps: '', at: nowISO() }); redrawMine(); saveNow(); const f = $(`[data-mb="${state.mine.length - 1}"] input, [data-mb="${state.mine.length - 1}"] .mnote, [data-mb="${state.mine.length - 1}"] textarea:not([hidden])`, root); if (f) f.focus(); return; }
      const d = e.target.closest && e.target.closest('[data-mine-del]'); if (d) { state.mine.splice(Number(d.dataset.mineDel), 1); redrawMine(); saveNow(); }
    });
    const ph = $('[data-mine-photo]', root); if (ph) ph.onchange = async () => {
      const file = ph.files[0]; ph.value = ''; if (!file) return;
      if (!ctx.save) { toast('Students can add photos from their own notebook.'); return; }
      try { toast('Uploading your photo…'); const up = await Hub.uploads.add(file); state.mine.push({ type: 'photo', title: '', upload: up, at: nowISO() }); redrawMine(); saveNow(); toast('Photo added.'); } catch (err) { toast(err.message || 'Could not add the photo.', 'error'); }
    };
    loadPhotos(root);
    return { collect };
  }
  /** How far a student got (for the teacher's responses table and the student's list). */
  function summary(L, resp) {
    if (!resp) return null;
    const bl = blanksOf(L.keyIdeas), ts = tasksOf(L);
    const notesOK = bl.filter((a, k) => blankOK(a, (resp.blanks || {})[k])).length;
    let parts = 0, right = 0; ts.forEach(q => { if (!(resp.checked || {})[q.id]) return; q.parts.forEach(p => { if (p.answer.kind === 'open') return; parts++; if (Hub.math.markPart(p, ((resp.tasks || {})[q.id] || {})[p.id]).verdict === 'correct') right++; }); });
    return { notes: bl.length ? `${notesOK}/${bl.length}` : '—', yt: parts ? `${right}/${parts}` : '—', own: (resp.mine || []).length, rag: resp.rag || '', learned: resp.learned || '', question: resp.question || '' };
  }
  const ragChip = v => v ? `<span class="rag-chip ${v}">${{ red: 'Stuck', amber: 'Getting there', green: 'Got it' }[v]}</span>` : '<span class="tiny muted">—</span>';

  /* ================= teacher: list ================= */
  function list(main, params) {
    const course = params.course || ((Hub.teacher.pref('group') || 'HL-A').slice(0, 2));
    const show = params.show || 'upcoming', asOf = Hub.mastery.asOf(), from = Hub.core.addDays(asOf, -7);
    const made = Object.fromEntries(all().filter(L => L.course === course).map(L => [L.id, L]));
    const cal = calendar(course), ids = new Set(cal.map(r => r.id));
    const rows = cal.concat(Object.values(made).filter(L => !ids.has(L.id))).filter(r => show === 'all' || [r.dates.A, r.dates.B].some(d => d && d >= from)).sort((x, y) => firstDate(x).localeCompare(firstDate(y)));
    const dl = r => ['A', 'B'].map(d => r.dates[d] ? `<span class="ls-day"><b>${d}</b> ${fmtDate(r.dates[d])}</span>` : '').join('');
    main.innerHTML = U.heading('LESSONS', 'Lessons & notebooks', 'One interactive notebook per lesson: your slide deck, guided notes, optional extra worked examples, optional “Your turn” practice, the Exit Ticket and homework you assign, students’ own notes and a reflection. Students only see a notebook once you release it to their day.',
      `<div class="tabs" role="tablist">${['SL', 'HL'].map(c => `<a role="tab" class="tab ${c === course ? 'on' : ''}" aria-selected="${c === course}" href="#/lessons?course=${c}&show=${show}">AA ${c}</a>`).join('')}</div>`) +
      `<section class="card"><div class="row-between"><h2 class="bar-head blue">AA ${course} calendar · A and B days</h2><div class="tabs">${[['upcoming', 'From last week'], ['all', 'Whole year']].map(([k, t]) => `<a class="tab ${k === show ? 'on' : ''}" href="#/lessons?course=${course}&show=${k}">${t}</a>`).join('')}</div></div>
      <div class="ls">${rows.map(r => { const L = made[r.id]; return `<div class="ls-row ${L ? 'has' : ''}"><div class="ls-dates">${dl(r)}</div><div class="ls-main"><b>${esc(r.title)}</b>${r.skills && r.skills.length ? `<div class="chips">${r.skills.map(s => U.skillChip(s)).join('')}</div>` : ''}</div>
        <div class="ls-status">${L ? groupsOf(course).map(g => { const [t, c] = relLabel(L, g); return `<span class="pill ${c}" title="${C().GROUPS[g].label}">${g.slice(-1)} · ${t}</span>`; }).join('') : '<span class="tiny muted">No notebook yet</span>'}</div>
        <div class="ls-act">${L ? `<a class="btn small" href="#/lesson/${encodeURIComponent(r.id)}">Open</a>` : `<button class="btn small ghost" data-make="${esc(r.id)}">+ Create notebook</button>`}</div></div>`; }).join('') || U.empty('No lessons in this range.')}</div></section>`;
    $$('[data-make]').forEach(b => (b.onclick = () => { const row = cal.find(r => r.id === b.dataset.make); if (!row) return; create(row); toast('Notebook created — add your slides and notes, then release it.'); go('#/lesson/' + encodeURIComponent(row.id)); }));
  }

  /* ================= teacher: one lesson (edit · student view · responses) ================= */
  function edit(main, params) {
    const L = get(params.id);
    if (!L) {
      const row = calendar(String(params.id).slice(0, 2)).find(r => r.id === params.id);
      main.innerHTML = `<a class="back" href="#/lessons">← Lessons & notebooks</a>` + U.empty(row ? `No notebook yet for <b>${esc(row.title)}</b>.` : 'That lesson is not in the calendar.', row ? '<button class="btn primary" id="mk">+ Create notebook</button>' : '');
      const mk = $('#mk'); if (mk) mk.onclick = () => { create(row); Hub.app.render(); };
      return;
    }
    if (!L.notesFilled && Hub.guidedNotes && Hub.guidedNotes.has(L.id) && !(L.keyIdeas || '').trim()) { L.keyIdeas = Hub.guidedNotes.text(L.id); L.notesFilled = true; put(L); }
    // Worked examples come from her slides; the notebook carries optional EXTRA examples. Drop page-reference-only cards and add two extra examples once.
    if (!L.extraSet) { L.myExamples = ownExamples(L); if (!(L.examples || []).length) L.examples = defaultExamples(L.skills, L.id); L.extraSet = true; put(L); }
    const view = params.view || 'edit', base = '#/lesson/' + encodeURIComponent(L.id);
    const nResp = groupsOf(L.course).reduce((n, g) => n + Hub.roster.inGroup(g, true).filter(s => S().progress[s.id + '|' + NB + L.id]).length, 0);
    const head = `<a class="back" href="#/lessons?course=${L.course}">← Lessons & notebooks</a>` + U.heading(`AA ${L.course} · ${['A', 'B'].filter(d => L.dates[d]).map(d => d + ' day ' + fmtDate(L.dates[d], true)).join(' · ')}`, esc(L.title), '',
      `<div class="tabs">${[['edit', '✎ Build'], ['student', '👁 Student view'], ['responses', `Responses (${nResp})`]].map(([k, t]) => `<a class="tab ${k === view ? 'on' : ''}" href="${base}${k === 'edit' ? '' : '?view=' + k}">${t}</a>`).join('')}</div>`);
    const release = `<section class="card release-card"><h2 class="bar-head green">Release to students</h2>${groupsOf(L.course).map(g => { const [t, c] = relLabel(L, g), d = L.dates[g.slice(-1)]; return `<div class="rel-row"><b>${C().GROUPS[g].label}</b><span class="tiny muted">${d ? 'lesson ' + fmtDate(d, true) : 'not on this calendar'}</span><span class="pill ${c}">${t}</span><span class="actions"><button class="btn small primary" data-rel="${g}" data-act="now">Release now</button><button class="btn small ghost" data-rel="${g}" data-act="sched" ${d ? '' : 'disabled'}>Open on lesson day</button><button class="btn small ghost" data-rel="${g}" data-act="hide">Hide</button></span></div>`; }).join('')}<p class="tiny muted">“Open on lesson day” releases it at 7:00 that morning. Students never see a hidden notebook in their list.</p></section>`;
    if (view === 'student') {
      main.innerHTML = head + `<div class="notice preview">Student view — try it out. Nothing you type here is saved.</div><div id="nb-root" class="nb">${notebookHTML(L, { preview: true, teacher: true })}</div>`;
      bindNotebook($('#nb-root'), L, { preview: true }); return;
    }
    if (view === 'responses') return responses(main, L, params, head, base);
    const ets = S().assessments.filter(a => a.type === 'Exit Ticket' && a.course === L.course && a.status !== 'archived');
    const gens = gensFor(L.skills.length ? L.skills : C().skillsFor(L.course).map(s => s.id));
    const genOpts = gens.map(g => { const r = Hub.qcore.registry[g]; return `<option value="${g}">${esc((C().SKILL[r.skill] || {}).ox || '')} ${esc(r.title)} · Paper ${r.paper}</option>`; }).join('');
    const qList = (kind, specs) => specs.map((s, i) => { const q = buildQ(s, kind + i); return q ? `<div class="spec-row"><div class="spec-q"><span class="q-num">${i + 1}</span>${U.skillChip(q.skill)} ${U.paperBadge(q.paper)} <span class="small">${M(q.stem || q.parts[0].prompt)}</span></div><span class="actions"><button class="btn small ghost" data-reseed="${kind}:${i}">↻ New numbers</button><button class="btn small ghost danger" data-del="${kind}:${i}">Remove</button></span></div>` : ''; }).join('') || '<p class="tiny muted">None yet.</p>';
    main.innerHTML = head + release + `
      <section class="card"><h2 class="bar-head blue">Lesson details</h2><div class="form-grid">
        <label class="span2">Title<input data-f="title" value="${esc(L.title)}"></label>
        <label class="span2">Essential question <span class="tiny muted">(shown in a strip at the top)</span><input data-f="eq" value="${esc(L.eq || '')}" placeholder="e.g. How can we tell whether a relation is a function?"></label>
        <fieldset class="span2 skills-pick"><legend>Skills</legend><div class="skill-grid">${C().skillsFor(L.course).map(s => `<label class="sk ${U.unitColour(s.unit)}"><input type="checkbox" data-skill value="${s.id}" ${L.skills.includes(s.id) ? 'checked' : ''}> ${U.skillLabel(s.id)}</label>`).join('')}</div></fieldset></div></section>
      <section class="card"><h2 class="bar-head amber">Slide deck</h2>
        <label>Link to your slides (Google Slides, a PowerPoint or PDF in Google Drive, PowerPoint online embed code, or Canva)<input data-f="deck" value="${esc(L.deck ? L.deck.url : '')}" placeholder="https://docs.google.com/presentation/d/…"></label>
        <p class="tiny muted">Share the file as <b>Anyone with the link · Viewer</b> so students signed in with their school accounts can see it.</p>
        <div id="deck-pv">${deckPreview(L.deck)}</div></section>
      <section class="card"><h2 class="bar-head pink">Do Now · Reflection</h2><label class="inline-check"><input type="checkbox" data-f="doNow" ${L.doNow ? 'checked' : ''}> Show a link to each student’s personalised Do Now</label><label class="inline-check"><input type="checkbox" data-f="reflect" ${L.reflect !== false ? 'checked' : ''}> Ask for a reflection (confidence, one thing learned, a question)</label></section>
      <section class="card"><h2 class="bar-head green">Key ideas · guided notes</h2>
        <div class="grid g2"><label>Notes<textarea data-f="keyIdeas" rows="12" placeholder="## Key idea&#10;A function maps each input to [[exactly one]] output.&#10;- The set of inputs is the [[domain]].&#10;- $f(x)=x^2$: $f(3)=$ [[9]]">${esc(L.keyIdeas || '')}</textarea></label>
        <div><span class="key-lab">Students see</span><div class="nb-notes pv-box" id="notes-pv">${notesHTML(L.keyIdeas, {}, { dis: 'disabled' })}</div></div></div>
        ${Hub.guidedNotes && Hub.guidedNotes.has(L.id) ? `<p class="tiny"><button class="btn small ghost" id="notes-reset" type="button">Use the ready-made guided notes for this lesson</button></p>` : ''}
        <p class="tiny muted"><b>[[answer]]</b> makes a blank (several accepted answers: [[domain|the domain]]). Maths in $…$, e.g. $\\frac{1}{2}$ (keep blanks outside the $…$). <b>## </b> starts a heading, <b>- </b> a bullet. Students check their blanks themselves.</p></section>
      <section class="card"><h2 class="bar-head blue">Extra worked examples <span class="tiny muted">· optional for students · for extra support</span></h2>
        <p class="tiny muted">Your main worked examples are on your slides. These are extra examples with new numbers, shown to students as optional, with the solution revealed one line at a time.</p>
        <div id="ex-list">${qList('examples', L.examples || [])}</div>${gens.length ? `<div class="add-row"><select id="ex-gen">${genOpts}</select><button class="btn small" id="ex-add">+ Add example</button></div>` : ''}
        <details class="gen-extra" ${(L.myExamples || []).length ? 'open' : ''}><summary>Type your own extra example (optional)</summary>
        <div id="my-list">${(L.myExamples || []).map((e, i) => `<fieldset class="my-ex"><legend>Example ${i + 1}</legend><label>Label (optional)<input data-my="${i}" data-k="ref" value="${esc(e.ref || '')}" placeholder="e.g. Extra example"></label><label>Question<textarea data-my="${i}" data-k="q" rows="2" placeholder="Type the question; maths in $…$">${esc(e.q || '')}</textarea></label><label>Solution steps (one line each, revealed one at a time)<textarea data-my="${i}" data-k="steps" rows="5">${esc(e.steps || '')}</textarea></label><button class="btn small ghost danger" type="button" data-mydel="${i}">Remove</button></fieldset>`).join('')}</div>
        <div class="actions"><button class="btn small" id="my-add" type="button">+ Type an example</button></div></details></section>
      <section class="card"><h2 class="bar-head amber">Your turn <span class="tiny muted">· optional practice, not graded · students check it themselves</span></h2><div id="yt-list">${qList('tasks', L.tasks || [])}</div>${gens.length ? `<div class="add-row"><select id="yt-gen">${genOpts}</select><label class="inline-check"><input type="checkbox" id="yt-ch"> Challenge</label><button class="btn small" id="yt-add">+ Add question</button></div>` : ''}</section>
      <section class="card"><h2 class="bar-head pink">Exit Ticket <span class="tiny muted">· assigned</span></h2><label>Link an Exit Ticket from the studio<select data-f="exitTicketId"><option value="">— none —</option>${ets.map(a => `<option value="${a.id}" ${a.id === L.exitTicketId ? 'selected' : ''}>${esc(a.title)} · ${a.status}</option>`).join('')}</select></label><p class="tiny muted">Students see it here once it is published to their day. <a href="#/studio?group=${L.course}-A">Build an Exit Ticket →</a></p></section>
      <section class="card"><h2 class="bar-head green">Homework <span class="tiny muted">· assigned</span></h2><label>Link homework from the studio<select data-f="homeworkId"><option value="">— none —</option>${S().assessments.filter(a => a.type === 'Homework' && a.course === L.course && a.status !== 'archived').map(a => `<option value="${a.id}" ${a.id === L.homeworkId ? 'selected' : ''}>${esc(a.title)} · ${a.status}</option>`).join('')}</select></label><p class="tiny muted">Students get a button to start it once it is published to their day. <a href="#/studio?group=${L.course}-A">Build homework →</a></p>${Hub.bookex ? Hub.bookex.notebookButtons(L) : ''}<div class="form-grid"><label>What to do<input data-f="homework" value="${esc(L.homework || '')}" placeholder="Exercise 2A — on the Hub"></label><label>Link (optional)<input data-f="homeworkUrl" value="${esc(L.homeworkUrl || '')}" placeholder="https://…"></label></div></section>
      <section class="card danger-zone"><div class="row-between"><span class="tiny muted">Created ${fmtDateTime(L.createdAt)} · last change ${fmtDateTime(L.updatedAt)}</span><button class="btn small ghost danger" id="nb-del">Delete this notebook</button></div></section>`;
    bindEdit(main, L);
    if (Hub.bookex) Hub.bookex.bindNotebook(main, L, put);
  }
  function deckPreview(d) {
    if (!d) return '<p class="tiny muted">No slides linked yet.</p>';
    if (d.error) return `<p class="parse-error">${esc(d.error)}</p>`;
    return `<p class="tiny"><span class="pill blue">${esc(d.kind)}</span> ${d.note ? esc(d.note) : ''}</p>${deckHTML(d)}`;
  }
  function bindEdit(main, L) {
    const timers = {}; // one debounce per field, so quick edits to different fields are all kept
    const commit = el => { const k = el.dataset.f; clearTimeout(timers[k]); timers[k] = setTimeout(() => apply(el), 500); };
    const apply = el => {
      const f = el.dataset.f;
      if (f === 'deck') { L.deck = deckFrom(el.value); $('#deck-pv').innerHTML = deckPreview(L.deck); if (L.deck && L.deck.error) L.deck = Object.assign({}, L.deck, { embed: null }); }
      else if (f === 'doNow' || f === 'reflect') L[f] = el.checked;
      else if (f === 'exitTicketId' || f === 'homeworkId') L[f] = el.value || null;
      else if (f === 'homeworkUrl') { const v = el.value.trim(); el.setCustomValidity(v && !/^https:\/\//.test(v) ? 'Use a link that starts with https://' : ''); el.reportValidity(); L.homeworkUrl = v; }
      else L[f] = el.value;
      if (f === 'keyIdeas') $('#notes-pv').innerHTML = notesHTML(L.keyIdeas, {}, { dis: 'disabled' });
      put(L);
    };
    $$('[data-f]', main).forEach(el => el.addEventListener(el.type === 'checkbox' || el.tagName === 'SELECT' ? 'change' : 'input', () => commit(el)));
    $$('[data-skill]', main).forEach(c => (c.onchange = () => { L.skills = $$('[data-skill]:checked', main).map(x => x.value); put(L); }));
    $$('[data-rel]', main).forEach(b => (b.onclick = () => { setRelease(L, b.dataset.rel, b.dataset.act); toast(b.dataset.act === 'hide' ? 'Hidden from students.' : b.dataset.act === 'now' ? 'Released — students can open it now.' : 'Scheduled for the lesson day.'); Hub.app.render(); }));
    const spec = s => { const [k, i] = s.split(':'); return [k, Number(i)]; };
    $$('[data-reseed]', main).forEach(b => (b.onclick = () => { const [k, i] = spec(b.dataset.reseed); L[k][i] = Object.assign({}, L[k][i], { seed: newSeed() }); put(L); Hub.app.render(); }));
    $$('[data-del]', main).forEach(b => (b.onclick = () => { const [k, i] = spec(b.dataset.del); L[k].splice(i, 1); put(L); Hub.app.render(); }));
    const myTimers = {};
    $$('[data-my]', main).forEach(el => el.addEventListener('input', () => { const i = Number(el.dataset.my), k = el.dataset.k, key = i + k; clearTimeout(myTimers[key]); myTimers[key] = setTimeout(() => { L.myExamples = L.myExamples || []; L.myExamples[i] = Object.assign({}, L.myExamples[i], { [k]: el.value }); put(L); }, 500); }));
    $$('[data-mydel]', main).forEach(b => (b.onclick = () => { L.myExamples.splice(Number(b.dataset.mydel), 1); put(L); Hub.app.render(); }));
    const nr = $('#notes-reset'); if (nr) nr.onclick = async () => { if ((L.keyIdeas || '').trim() && !(await U.confirmBox('Replace the notes in the box with the ready-made guided notes for this lesson?', 'Replace notes'))) return; L.keyIdeas = Hub.guidedNotes.text(L.id); put(L); Hub.app.render(); };
    const ma = $('#my-add'); if (ma) ma.onclick = () => { (L.myExamples = L.myExamples || []).push({ ref: '', q: '', steps: '' }); put(L); Hub.app.render(); };
    const ea = $('#ex-add'); if (ea) ea.onclick = () => { (L.examples = L.examples || []).push({ gen: $('#ex-gen').value, seed: newSeed() }); put(L); Hub.app.render(); };
    const ya = $('#yt-add'); if (ya) ya.onclick = () => { (L.tasks = L.tasks || []).push({ gen: $('#yt-gen').value, seed: newSeed(), challenge: $('#yt-ch').checked }); put(L); Hub.app.render(); };
    $('#nb-del').onclick = async () => { if (await U.confirmBox('Delete this notebook? Students lose access to it. Their saved notebook answers stay in your data.', 'Delete notebook', { danger: true })) { remove(L.id); toast('Notebook deleted.'); go('#/lessons?course=' + L.course); } };
  }
  function responses(main, L, params, head, base) {
    if (params.sid) {
      const s = Hub.roster.byId(params.sid), resp = (S().progress[params.sid + '|' + NB + L.id] || {}).responses;
      main.innerHTML = head + `<a class="back" href="${base}?view=responses">← All responses</a><h2 class="sec">${esc(s ? s.name : params.sid)}</h2>${resp ? '' : '<p>Not started yet.</p>'}<div id="nb-root" class="nb">${notebookHTML(L, { resp: resp || {}, readOnly: true, sid: params.sid, teacher: true })}</div>`;
      bindNotebook($('#nb-root'), L, { resp: resp || {}, readOnly: true }); return;
    }
    main.innerHTML = head + groupsOf(L.course).map(g => { const st = Hub.roster.inGroup(g, true); const done = st.filter(s => S().progress[s.id + '|' + NB + L.id]).length; const qs = st.map(s => [s, summary(L, (S().progress[s.id + '|' + NB + L.id] || {}).responses)]).filter(([, x]) => x && x.question.trim());
      return `<section class="card scroll"><div class="row-between"><h2 class="bar-head blue">${C().GROUPS[g].label}</h2><span class="tiny muted">${done}/${st.length} opened · ${relLabel(L, g)[0]}</span></div>
      ${qs.length ? `<div class="sticky"><b>Questions from students</b><ul>${qs.map(([s, x]) => `<li><b>${esc(s.name)}:</b> ${esc(x.question)}</li>`).join('')}</ul></div>` : ''}
      <table class="tbl"><thead><tr><th>Student</th><th>Confidence</th><th>Notes</th><th>Your turn</th><th>Own notes</th><th>One thing learned</th><th>Updated</th></tr></thead><tbody>${st.map(s => { const p = S().progress[s.id + '|' + NB + L.id], x = p && summary(L, p.responses); return `<tr><td>${x ? `<a href="${base}?view=responses&sid=${encodeURIComponent(s.id)}">${esc(s.name)}</a>` : esc(s.name)}</td><td>${x ? ragChip(x.rag) : '<span class="tiny muted">not opened</span>'}</td><td>${x ? x.notes : ''}</td><td>${x ? x.yt : ''}</td><td>${x ? x.own || '—' : ''}</td><td class="small">${x ? esc(x.learned) : ''}</td><td class="tiny">${p ? fmtDateTime(p.updatedAt) : ''}</td></tr>`; }).join('')}</tbody></table></section>`; }).join('');
  }

  /* ================= student ================= */
  const me = () => Hub.roster.byId(Hub.auth.sid());
  function student(main, params) {
    const s = me(); if (!s) { main.innerHTML = U.empty('Your account is not on a class roster.'); return; }
    if (params.id) return studentPage(main, s, params.id);
    const day = s.group.slice(-1), mine = all().filter(L => L.course === s.course && visibleTo(L, s.group)).sort((a, b) => String(b.dates[day] || firstDate(b)).localeCompare(String(a.dates[day] || firstDate(a))));
    main.innerHTML = U.heading('MY NOTEBOOK', 'Lesson notebooks', 'Slides, notes, worked examples and practice for every lesson. Your answers save as you type.') +
      (mine.length ? `<section class="card"><div class="ls">${mine.map(L => { const p = Hub.assess.getProgress(s.id, NB + L.id), x = p && summary(L, p.responses); return `<div class="ls-row has"><div class="ls-dates"><span class="ls-day">${fmtDate(L.dates[day] || firstDate(L), true)}</span></div><div class="ls-main"><b>${esc(L.title)}</b>${L.eq ? `<div class="tiny muted">${M(L.eq)}</div>` : ''}</div><div class="ls-status">${x ? ragChip(x.rag) : '<span class="pill">New</span>'}</div><div class="ls-act"><a class="btn small ${x ? 'ghost' : 'primary'}" href="#/notebook/${encodeURIComponent(L.id)}">${x ? 'Open' : 'Start'}</a></div></div>`; }).join('')}</div></section>` : U.empty('No notebooks yet. They appear here when Miss Badmus releases each lesson.'));
  }
  function studentPage(main, s, id) {
    const L = get(id);
    if (!L || L.course !== s.course || !visibleTo(L, s.group)) { main.innerHTML = U.empty('This notebook is not open yet.', '<a class="btn" href="#/notebook">My notebook</a>'); return; }
    const key = NB + L.id, prev = Hub.assess.getProgress(s.id, key), preview = Hub.auth.isPreview(), day = s.group.slice(-1);
    main.innerHTML = `<div class="row-between no-print"><a class="back" href="#/notebook">← My notebook</a><span id="nb-saved" class="tiny muted">${preview ? 'Preview — not saved' : prev ? 'Saved ' + fmtDateTime(prev.updatedAt) : 'Your answers save as you type.'}</span></div>` +
      U.heading(`AA ${s.course} · ${fmtDate(L.dates[day] || firstDate(L), true).toUpperCase()}`, esc(L.title)) + `<div id="nb-root" class="nb">${notebookHTML(L, { resp: prev ? prev.responses : {}, sid: s.id })}</div>`;
    bindNotebook($('#nb-root'), L, { resp: prev ? prev.responses : {}, save: preview ? null : resp => { Hub.assess.saveProgress(s.id, key, { responses: resp, reflection: resp.learned, createdAt: (prev && prev.createdAt) || nowISO() }); const el = $('#nb-saved'); if (el) el.textContent = 'Saving to cloud…'; setTimeout(() => { const e2 = $('#nb-saved'); if (e2 && !Hub.store.dirty) e2.textContent = 'Saved ✓'; }, 2500); } });
  }
  /** Latest released notebook for a student (for My day). */
  function latestFor(s) { const day = s.group.slice(-1); return all().filter(L => L.course === s.course && visibleTo(L, s.group)).sort((a, b) => String(b.dates[day] || '').localeCompare(String(a.dates[day] || '')))[0] || null; }

  Hub.lessons = { list, edit, student, calendar, idFor, all, get, create, setRelease, visibleTo, deckFrom, notesHTML, blanksOf, blankOK, summary, latestFor, notebookHTML };
})(window.Hub = window.Hub || {});
